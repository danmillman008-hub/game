import {
  boolean,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/pg-core";

export type StepKind =
  | "concept_bite"
  | "guided_cloze"
  | "token_assembly"
  | "trap_detector"
  | "step_solver"
  | "konkur_test";

export type AtomicConceptNode = {
  id: string;
  title: string;
  textbookQuote: string;
  cognitiveLevel: "remember" | "understand" | "apply" | "analyze";
  isPrerequisite: boolean;
  targetMechanic: StepKind;
};

export type PrerequisiteEdge = {
  fromId: string;
  toId: string;
  relation: string;
};

export type KonkurModifierItem = {
  id: string;
  phrase: string;
  category:
    | "قید کمّی (همه/برخی/اغلب)"
    | "فرمول و رابطه کلیدی"
    | "استثنای کتاب درسی"
    | "ترتیب و توالی مکانیزم";
  explanation: string;
};

export type DesignerTrapItem = {
  id: string;
  trapTitle: string;
  trapCategory:
    | "تله قیدی"
    | "تله تعمیم افراطی"
    | "تله تقدم و تاخر"
    | "تله واحد و علامت"
    | "تله خلط مفاهیم مشابه";
  commonWrongBelief: string;
  scientificTruth: string;
};

export type PedagogicalBlueprint = {
  atomicConcepts: AtomicConceptNode[];
  prerequisiteChain: PrerequisiteEdge[];
  konkurModifiersAndFormulas: KonkurModifierItem[];
  designerTraps: DesignerTrapItem[];
  missingLinkMapping: {
    mimoOriginalMechanic: string;
    konkurIsomorphicMechanic: string;
    bridgingRationale: string;
  };
};

export type QualityMetricItem = {
  id: string;
  label: string;
  score: number;
  maxScore: number;
  weight: number;
  status: "optimal" | "warning" | "violation";
  diagnosticNote: string;
  algorithmicFormula: string;
};

export type GuardrailViolation = {
  code: string;
  severity: "critical" | "warning";
  stepIndex?: number;
  field: string;
  message: string;
  autoFixInstruction: string;
};

export type QualityAuditReport = {
  overallScore: number;
  passedGate: boolean;
  gradeBadge: "A+ (تراز میمو-سنجش)" | "A (استاندارد)" | "B (نیازمند بازبینی)" | "F (رد شده توسط گاردریل)";
  metrics: QualityMetricItem[];
  violations: GuardrailViolation[];
};

export type ConceptBiteStep = {
  kind: "concept_bite";
  title: string;
  hookAnalogy: string;
  bodyMarkdown: string;
  highlightedModifiers: string[];
  coreFormulaOrRule: string;
  interactiveCheckQuestion: string;
  interactiveCheckAnswer: boolean;
  interactiveCheckExplanation: string;
};

export type GuidedClozeStep = {
  kind: "guided_cloze";
  prompt: string;
  templateWithBlank: string;
  correctAnswer: string;
  chipOptions: string[];
  targetedModifierId: string;
  nudgeHint: string;
  deepExplanation: string;
};

export type TokenAssemblyStep = {
  kind: "token_assembly";
  prompt: string;
  assemblyMode:
    | "causal_chain"
    | "formula_derivation"
    | "stoichiometry_pipeline"
    | "syntactic_logic";
  orderedTokens: string[];
  distractorTokens: { token: string; trapReason: string }[];
  nudgeHint: string;
  assemblyExplanation: string;
};

export type TrapDetectorStep = {
  kind: "trap_detector";
  prompt: string;
  contextType: "statement_autopsy" | "math_solution_bug" | "chemistry_exception";
  segments: string[];
  flawedSegmentIndex: number;
  trapCategory: string;
  fixOptions: string[];
  correctFixIndex: number;
  diagnosticAutopsy: string;
};

export type StepSolverStep = {
  kind: "step_solver";
  problemStatement: string;
  subSteps: {
    stageLabel: string;
    question: string;
    options: string[];
    correctIndex: number;
    microFeedback: string;
  }[];
  finalTakeaway: string;
};

export type KonkurTestStep = {
  kind: "konkur_test";
  questionStem: string;
  sourceBadge: string;
  targetTimeSeconds: number;
  options: [string, string, string, string];
  correctIndex: number;
  optionDiagnostics: {
    optionIndex: number;
    isCorrect: boolean;
    trapOrMisconceptionLabel: string;
    detailedAnalysis: string;
  }[];
  eliminationShortcut: string;
};

export type KonkurStepContent =
  | ConceptBiteStep
  | GuidedClozeStep
  | TokenAssemblyStep
  | TrapDetectorStep
  | StepSolverStep
  | KonkurTestStep;

export const konkurCourses = pgTable("konkur_courses", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 160 }).notNull().unique(),
  title: varchar("title", { length: 220 }).notNull(),
  subject: varchar("subject", { length: 80 }).notNull(),
  grade: varchar("grade", { length: 60 }).notNull(),
  reshte: varchar("reshte", { length: 60 }).notNull(),
  icon: varchar("icon", { length: 16 }).notNull().default("🧬"),
  color: varchar("color", { length: 40 }).notNull().default("emerald"),
  tagline: varchar("tagline", { length: 320 }).notNull().default(""),
  description: text("description").notNull().default(""),
  position: integer("position").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const konkurLessons = pgTable("konkur_lessons", {
  id: serial("id").primaryKey(),
  courseId: integer("course_id")
    .notNull()
    .references(() => konkurCourses.id, { onDelete: "cascade" }),
  slug: varchar("slug", { length: 160 }).notNull().unique(),
  title: varchar("title", { length: 220 }).notNull(),
  chapterReference: varchar("chapter_reference", { length: 240 }).notNull(),
  rawTextbookExcerpt: text("raw_textbook_excerpt").notNull(),
  xpReward: integer("xp_reward").notNull().default(40),
  estimatedMinutes: integer("estimated_minutes").notNull().default(5),
  status: varchar("status", { length: 40 }).notNull().default("published"),
  pedagogicalBlueprint: jsonb("pedagogical_blueprint")
    .$type<PedagogicalBlueprint>()
    .notNull(),
  qualityAudit: jsonb("quality_audit").$type<QualityAuditReport>().notNull(),
  position: integer("position").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const konkurSteps = pgTable("konkur_steps", {
  id: serial("id").primaryKey(),
  lessonId: integer("lesson_id")
    .notNull()
    .references(() => konkurLessons.id, { onDelete: "cascade" }),
  position: integer("position").notNull().default(0),
  type: varchar("type", { length: 40 }).$type<StepKind>().notNull(),
  conceptNodeId: varchar("concept_node_id", { length: 64 }).notNull(),
  scaffoldingLevel: integer("scaffolding_level").notNull().default(1),
  cognitiveLoadWords: integer("cognitive_load_words").notNull().default(40),
  content: jsonb("content").$type<KonkurStepContent>().notNull(),
});

export const learnerProgress = pgTable("learner_progress", {
  id: serial("id").primaryKey(),
  stepId: integer("step_id")
    .notNull()
    .references(() => konkurSteps.id, { onDelete: "cascade" }),
  lessonId: integer("lesson_id")
    .notNull()
    .references(() => konkurLessons.id, { onDelete: "cascade" }),
  correctFirstTry: boolean("correct_first_try").notNull().default(true),
  attempts: integer("attempts").notNull().default(1),
  xpEarned: integer("xp_earned").notNull().default(10),
  completedAt: timestamp("completed_at").notNull().defaultNow(),
});

export const agentCompilationLogs = pgTable("agent_compilation_logs", {
  id: serial("id").primaryKey(),
  subject: varchar("subject", { length: 80 }).notNull(),
  topicTitle: varchar("topic_title", { length: 220 }).notNull(),
  rawExcerpt: text("raw_excerpt").notNull(),
  initialScore: integer("initial_score").notNull(),
  finalScore: integer("final_score").notNull(),
  passedGuardrail: boolean("passed_guardrail").notNull().default(true),
  violationsCount: integer("violations_count").notNull().default(0),
  autoRepaired: boolean("auto_repaired").notNull().default(false),
  createdLessonId: integer("created_lesson_id"),
  auditSnapshot: jsonb("audit_snapshot").$type<QualityAuditReport>().notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type KonkurCourse = typeof konkurCourses.$inferSelect;
export type KonkurLesson = typeof konkurLessons.$inferSelect;
export type KonkurStep = typeof konkurSteps.$inferSelect;
export type AgentCompilationLog = typeof agentCompilationLogs.$inferSelect;
