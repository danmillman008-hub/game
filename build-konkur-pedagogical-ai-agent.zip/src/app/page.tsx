"use client";

import React, { useCallback, useEffect, useState } from "react";
import {
  Award,
  BookOpen,
  Cpu,
  Flame,
  Layers,
  Microscope,
  Play,
  ShieldCheck,
  Sliders,
  Sparkles,
  Zap,
} from "lucide-react";
import { AgentCompilerStudio } from "@/components/AgentCompilerStudio";
import { EnforcedGuardrailForm } from "@/components/EnforcedGuardrailForm";
import { MimoKonkurPlayer } from "@/components/MimoKonkurPlayer";
import { PedagogyResearchAndSpec } from "@/components/PedagogyResearchAndSpec";
import type {
  AgentCompilationLog,
  KonkurCourse,
  KonkurLesson,
  KonkurStep,
} from "@/db/schema";
import type {
  LegacyFormDefectAnalysis,
  SubjectIsomorphismGuide,
} from "@/lib/pedagogy-engine";

type ActiveTab = "player" | "compiler" | "guardrail" | "research";

type PlatformStateResponse = {
  courses: KonkurCourse[];
  lessons: KonkurLesson[];
  steps: KonkurStep[];
  logs: AgentCompilationLog[];
  totalXp: number;
  presets: {
    id: string;
    subject: string;
    grade: string;
    topicTitle: string;
    chapterReference: string;
    rawTextbookExcerpt: string;
  }[];
  legacyDefects: LegacyFormDefectAnalysis[];
  isomorphismMatrix: SubjectIsomorphismGuide[];
  agentSystemPrompt: string;
};

export default function MimoKonkurPlatformPage() {
  const [data, setData] = useState<PlatformStateResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<ActiveTab>("player");
  const [selectedLessonId, setSelectedLessonId] = useState<number>(1);

  const fetchState = useCallback(async (preferredLessonId?: number | null) => {
    try {
      const res = await fetch("/api/konkur/state", { cache: "no-store" });
      if (res.ok) {
        const json: PlatformStateResponse = await res.json();
        setData(json);
        if (preferredLessonId) {
          setSelectedLessonId(preferredLessonId);
        } else if (json.lessons.length > 0) {
          setSelectedLessonId((prev) =>
            json.lessons.some((l) => l.id === prev) ? prev : json.lessons[0].id,
          );
        }
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchState();
  }, [fetchState]);

  async function handleStepComplete(payload: {
    stepId: number;
    lessonId: number;
    correctFirstTry: boolean;
    attempts: number;
    xpEarned: number;
  }) {
    await fetch("/api/konkur/progress", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    await fetchState(payload.lessonId);
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      {/* Top Command Header */}
      <header className="sticky top-0 z-30 border-b border-slate-800/80 bg-slate-950/90 backdrop-blur-md">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-4 px-4 py-3.5 sm:px-6">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-emerald-400 to-indigo-500 text-xl font-black text-slate-950 shadow-lg shadow-emerald-950/50">
              M
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base font-black text-white sm:text-lg">
                  میمو-کنکور (Mimo-Konkur Engine)
                </h1>
                <span className="rounded-full border border-emerald-500/40 bg-emerald-500/15 px-2.5 py-0.5 text-[10px] font-black text-emerald-300">
                  کامپایلر پداگوژیک + عیارسنج گاردریل ایجنت
                </span>
              </div>
              <p className="text-xs text-slate-400">
                پر کردن حلقه مفقوده بین سیستم تعاملی Mimo و کتب کنکور سراسری بدون افت کیفیت
              </p>
            </div>
          </div>

          {/* Global Stats Strip */}
          {data && (
            <div className="flex flex-wrap items-center gap-2 text-xs font-bold">
              <div className="flex items-center gap-1.5 rounded-xl border border-slate-800 bg-slate-900 px-3 py-1.5 text-emerald-300">
                <ShieldCheck className="h-4 w-4 text-emerald-400" />
                <span>درسنامه‌های تاییدشده گاردریل: {data.lessons.length}</span>
              </div>
              <div className="flex items-center gap-1.5 rounded-xl border border-slate-800 bg-slate-900 px-3 py-1.5 text-amber-300">
                <Zap className="h-4 w-4 text-amber-400" />
                <span>مجموع امتیاز: {data.totalXp} XP</span>
              </div>
            </div>
          )}
        </div>

        {/* Navigation Tabs */}
        <div className="mx-auto max-w-7xl px-4 pb-3 sm:px-6">
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            <button
              type="button"
              onClick={() => setActiveTab("player")}
              className={`flex items-center justify-center gap-2 rounded-2xl border px-3 py-2.5 text-xs font-black transition-all ${
                activeTab === "player"
                  ? "border-emerald-400 bg-emerald-500/20 text-white shadow-lg shadow-emerald-950/40"
                  : "border-slate-800 bg-slate-900/70 text-slate-400 hover:border-slate-700 hover:text-slate-200"
              }`}
            >
              <Play className="h-4 w-4 text-emerald-400" />
              <span>۱. پلیر تعاملی میمو-کنکور (Live)</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab("compiler")}
              className={`flex items-center justify-center gap-2 rounded-2xl border px-3 py-2.5 text-xs font-black transition-all ${
                activeTab === "compiler"
                  ? "border-indigo-400 bg-indigo-500/20 text-white shadow-lg shadow-indigo-950/40"
                  : "border-slate-800 bg-slate-900/70 text-slate-400 hover:border-slate-700 hover:text-slate-200"
              }`}
            >
              <Cpu className="h-4 w-4 text-indigo-400" />
              <span>۲. کامپایلر کتاب کنکور برای ایجنت</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab("guardrail")}
              className={`flex items-center justify-center gap-2 rounded-2xl border px-3 py-2.5 text-xs font-black transition-all ${
                activeTab === "guardrail"
                  ? "border-amber-400 bg-amber-500/20 text-white shadow-lg shadow-amber-950/40"
                  : "border-slate-800 bg-slate-900/70 text-slate-400 hover:border-slate-700 hover:text-slate-200"
              }`}
            >
              <Sliders className="h-4 w-4 text-amber-400" />
              <span>۳. فرم اجبارگر و عیارسنج ۱۰ شاخصه</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab("research")}
              className={`flex items-center justify-center gap-2 rounded-2xl border px-3 py-2.5 text-xs font-black transition-all ${
                activeTab === "research"
                  ? "border-rose-400 bg-rose-500/20 text-white shadow-lg shadow-rose-950/40"
                  : "border-slate-800 bg-slate-900/70 text-slate-400 hover:border-slate-700 hover:text-slate-200"
              }`}
            >
              <Microscope className="h-4 w-4 text-rose-400" />
              <span>۴. کالبدشکافی ریپو و حلقه مفقوده</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Container */}
      <main className="mx-auto max-w-7xl px-4 py-6 sm:px-6">
        {/* Architectural Overview Cards */}
        <div className="mb-6 grid gap-3 sm:grid-cols-4">
          <div className="rounded-2xl border border-slate-800/90 bg-slate-900/70 p-4">
            <div className="text-[11px] font-bold text-rose-400">
              مسئله کشف‌شده در ریپوی میمو
            </div>
            <div className="mt-1 text-xs font-extrabold text-white">
              چرا فرم ساده `text | quiz | fill | code` برای کنکور شکست می‌خورد؟
            </div>
            <p className="mt-1 text-[11px] leading-5 text-slate-400">
              در فرم قبلی، ایجنت گام `code` را حذف می‌کند و در `text` دیوار متنی ۳۰۰ کلمه‌ای می‌ریزد.
            </p>
          </div>

          <div className="rounded-2xl border border-slate-800/90 bg-slate-900/70 p-4">
            <div className="text-[11px] font-bold text-violet-400">
              حلقه مفقوده (Isomorphic Bridge)
            </div>
            <div className="mt-1 text-xs font-extrabold text-white">
              تبدیل گام `Code` و `Debug` میمو به مکانیک‌های کنکوری
            </div>
            <p className="mt-1 text-[11px] leading-5 text-slate-400">
              چیدمان بلوکی مسیر/فرمول (`token_assembly`) + شکارچی تله طراح کنکور (`trap_detector`).
            </p>
          </div>

          <div className="rounded-2xl border border-slate-800/90 bg-slate-900/70 p-4">
            <div className="text-[11px] font-bold text-amber-400">
              الگوریتم اجبارگر ایجنت
            </div>
            <div className="mt-1 text-xs font-extrabold text-white">
              کامپایل ۲ مرحله‌ای (اول گراف و تله‌ها، بعد ۶ گام مقید)
            </div>
            <p className="mt-1 text-[11px] leading-5 text-slate-400">
              ایجنت بدون استخراج گره‌های اتمی، قیدهای کتاب و تله‌های طراح مجاز به ساخت گام نیست.
            </p>
          </div>

          <div className="rounded-2xl border border-slate-800/90 bg-slate-900/70 p-4">
            <div className="text-[11px] font-bold text-emerald-400">
              عیارسنج ریاضی ۱۰ شاخصه
            </div>
            <div className="mt-1 text-xs font-extrabold text-white">
              قفل انتشار زیر عیار ۸۵/۱۰۰ + تعمیر خودکار
            </div>
            <p className="mt-1 text-[11px] leading-5 text-slate-400">
              بررسی خودکار سقف ۸۵ کلمه، شیب داربست، کالبدشکافی ۴ گزینه و فیلتر ضدکلی‌گویی.
            </p>
          </div>
        </div>

        {loading || !data ? (
          <div className="rounded-3xl border border-slate-800 bg-slate-900 p-12 text-center text-sm font-bold text-slate-300">
            در حال راه‌اندازی موتور پداگوژیک میمو-کنکور و بارگذاری دیتابیس PostgreSQL...
          </div>
        ) : (
          <>
            {activeTab === "player" && (
              <MimoKonkurPlayer
                courses={data.courses}
                lessons={data.lessons}
                steps={data.steps}
                selectedLessonId={selectedLessonId}
                onSelectLesson={(id) => setSelectedLessonId(id)}
                onStepComplete={handleStepComplete}
                onOpenGuardrailEditor={(id) => {
                  setSelectedLessonId(id);
                  setActiveTab("guardrail");
                }}
              />
            )}

            {activeTab === "compiler" && (
              <AgentCompilerStudio
                courses={data.courses}
                presets={data.presets}
                logs={data.logs}
                onCompiledAndSaved={async (newLessonId) => {
                  await fetchState(newLessonId);
                  if (newLessonId) {
                    setSelectedLessonId(newLessonId);
                    setActiveTab("player");
                  }
                }}
              />
            )}

            {activeTab === "guardrail" && (
              <EnforcedGuardrailForm
                lessons={data.lessons}
                steps={data.steps}
                selectedLessonId={selectedLessonId}
                onSelectLesson={(id) => setSelectedLessonId(id)}
                onSavedToDb={async () => {
                  await fetchState(selectedLessonId);
                }}
              />
            )}

            {activeTab === "research" && (
              <PedagogyResearchAndSpec
                legacyDefects={data.legacyDefects}
                isomorphismMatrix={data.isomorphismMatrix}
                agentSystemPrompt={data.agentSystemPrompt}
              />
            )}
          </>
        )}
      </main>
    </div>
  );
}
