import { asc, desc } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  agentCompilationLogs,
  konkurCourses,
  konkurLessons,
  konkurSteps,
  learnerProgress,
} from "@/db/schema";
import {
  AGENT_PEDAGOGICAL_COMPILER_PROMPT,
  LEGACY_MIMO_FORM_DEFECTS,
  MIMO_TO_KONKUR_ISOMORPHISM_MATRIX,
} from "@/lib/pedagogy-engine";
import { ensureKonkurSeeded, PRESET_TEXTBOOK_SAMPLES } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await ensureKonkurSeeded();

    const courses = await db
      .select()
      .from(konkurCourses)
      .orderBy(asc(konkurCourses.position), asc(konkurCourses.id));

    const lessons = await db
      .select()
      .from(konkurLessons)
      .orderBy(asc(konkurLessons.position), asc(konkurLessons.id));

    const steps = await db
      .select()
      .from(konkurSteps)
      .orderBy(asc(konkurSteps.lessonId), asc(konkurSteps.position));

    const progress = await db.select().from(learnerProgress);

    const logs = await db
      .select()
      .from(agentCompilationLogs)
      .orderBy(desc(agentCompilationLogs.createdAt))
      .limit(15);

    const totalXp = progress.reduce((sum, p) => sum + p.xpEarned, 0) + 120;

    return NextResponse.json({
      courses,
      lessons,
      steps,
      progress,
      logs,
      totalXp,
      presets: PRESET_TEXTBOOK_SAMPLES,
      legacyDefects: LEGACY_MIMO_FORM_DEFECTS,
      isomorphismMatrix: MIMO_TO_KONKUR_ISOMORPHISM_MATRIX,
      agentSystemPrompt: AGENT_PEDAGOGICAL_COMPILER_PROMPT,
    });
  } catch (error) {
    console.error("[GET /api/konkur/state] error:", error);
    return NextResponse.json(
      { error: "خطا در بارگذاری وضعیت پلتفرم میمو-کنکور" },
      { status: 500 },
    );
  }
}
