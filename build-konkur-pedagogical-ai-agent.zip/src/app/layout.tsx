import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "میمو-کنکور | کامپایلر پداگوژیک ایجنت، گاردریل عیارسنج و پلیر تعاملی کنکور",
  description:
    "مهندسی معکوس پداگوژی میمو برای کنکور سراسری: پر کردن حلقه مفقوده بین آموزش تعاملی میمو و کتب کنکور به همراه الگوریتم اجبارگر ایجنت و عیارسنج ۱۰ شاخصه.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fa" dir="rtl">
      <body
        className="min-h-screen bg-slate-950 text-slate-100 antialiased selection:bg-emerald-500 selection:text-slate-950"
        style={{
          fontFamily:
            'Vazirmatn, "IRANSansX", Tahoma, "Segoe UI", system-ui, sans-serif',
        }}
      >
        {children}
      </body>
    </html>
  );
}
