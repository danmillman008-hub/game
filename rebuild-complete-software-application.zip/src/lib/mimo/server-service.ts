import { db } from "@/db";
import {
  roomMasterTable,
  lessonProgress,
  tutorialCompletions,
  chapterCompletions,
  mimoUserState,
  mimoSavedCode,
  mimoAiConversations,
  mimoTelemetryLog,
  DevOverridesConfig,
  PlaygroundFileItem,
  AiChatMessageItem,
} from "@/db/schema";
import { eq, desc, sql } from "drizzle-orm";
import {
  getTracksCatalog,
  getTutorialById,
  computePathMapState,
  RUNTIME_EVIDENCE,
} from "./corpus";
import {
  answersInChapter,
  firstTryCount,
  isSolvedCorrectly,
} from "./engine";

let isSeeded = false;

export async function logTelemetry(
  category: "ROOM_SQL" | "RETROFIT_API" | "LESSON_VM" | "PATH_ENGINE" | "BRIDGE",
  sourceClass: string,
  operation: string,
  payload: Record<string, unknown>,
  evidenceCode: string
) {
  try {
    await db.insert(mimoTelemetryLog).values({
      category,
      sourceClass,
      operation,
      payload,
      evidenceCode,
      createdAt: Date.now(),
    });
  } catch {
    // Non-blocking telemetry
  }
}

export async function ensureSeededDatabase() {
  if (isSeeded) return;
  try {
    const existingMaster = await db.select().from(roomMasterTable).limit(1);
    if (existingMaster.length === 0) {
      await db.insert(roomMasterTable).values({
        id: 42,
        identityHash: "2b8ab6d303d9a501bd8c8fb78d8352fc",
      });
    }

    const existingUser = await db.select().from(mimoUserState).where(eq(mimoUserState.id, 1));
    if (existingUser.length === 0) {
      await db.insert(mimoUserState).values({
        id: 1,
        displayName: "Alex Rivera",
        email: "alex@getmimo.com",
        isAnonymous: false,
        subscriptionTier: "PRO",
        coins: 200, // F11: mimo_prefs.xml local_coins={"coins":200}
        currentKeys: 5,
        unlimitedKeys: true,
        sparksXp: 480,
        dailySparks: 30,
        dailySparksGoal: 50,
        streakDays: 7,
        streakFreezeCount: 2,
        streakChallengeActive: true,
        streakChallengeDay: 4,
        leagueTier: 3, // Silver League
        currentTrackId: 50, // Full-Stack Developer
        appearance: "light",
        uiLocale: "en",
        favoriteTracks: [50, 219, 226, 125, 145, 197],
        ownedItems: ["icon_default", "streak_freeze_1"],
        devOverrides: {
          unlockAll: true,
          unlimitedKeys: true,
          hardModeDefault: false,
          preserveOutboxOnColdStart: true,
          simulateOffline: false,
          fakeDiscountDrawer: false,
          fakeStreakSheet: false,
          fakeLeaderboardSheet: false,
          useUnpublishedTracksPackage: false,
        },
        updatedAt: Date.now(),
      });

      // Seed initial lesson_progress rows matching M07 Stage 5 runtime capture (S5_1_F_AFTER_CORRECT_SUBMIT)
      await db
        .insert(lessonProgress)
        .values([
          {
            lessonId: 151410,
            completedAt: 1793883713504,
            startedAt: 1793883707947,
            tries: 1,
            tutorialId: 904,
            tutorialVersion: 161,
            trackId: 50,
            publishSetVersion: 753,
            attempts: 1,
            isPracticeProgress: 0,
            inQueue: 1,
          },
          {
            lessonId: 151403,
            completedAt: 1793883744787,
            startedAt: 1793883713744,
            tries: 1,
            tutorialId: 904,
            tutorialVersion: 161,
            trackId: 50,
            publishSetVersion: 753,
            attempts: 1,
            isPracticeProgress: 0,
            inQueue: 1,
          },
        ])
        .onConflictDoNothing();

      // Seed authentic Code Playgrounds (/v1/code)
      await db.insert(mimoSavedCode).values([
        {
          title: "Interactive Dog Letter Game (Lesson 151403)",
          codeLanguage: "html",
          template: "website",
          trackId: 50,
          tutorialId: 904,
          chapterId: 17742,
          lessonId: 151403,
          files: [
            {
              name: "index.html",
              codeLanguage: "html",
              content: `<!doctype html>
<html>
<head>
  <style>
    body { font-family: sans-serif; background: #252746; color: #fff; text-align: center; padding: 24px; }
    .card { background: #333661; border-radius: 16px; padding: 20px; max-width: 320px; margin: 0 auto; }
    button { background: #7E4BDE; color: #fff; border: none; padding: 10px 18px; border-radius: 8px; margin: 4px; font-weight: bold; cursor: pointer; }
  </style>
</head>
<body>
  <div class="card">
    <h2 id="status">Guess the Letter</h2>
    <h1 id="word">_ O G</h1>
    <div>
      <button onclick="guess('Q')">Q</button>
      <button onclick="guess('R')">R</button>
      <button onclick="guess('D')">D</button>
    </div>
  </div>
  <script>
    function guess(letter) {
      const status = document.getElementById('status');
      const word = document.getElementById('word');
      if (letter === 'D') {
        status.textContent = 'Correct!';
        status.style.color = '#66BC5A';
        word.textContent = 'D O G';
      } else {
        status.textContent = 'Try again';
        status.style.color = '#F05A6E';
      }
    }
  </script>
</body>
</html>`,
            },
          ],
          lastOutput: "Browser rendered HTML document successfully.",
          updatedAt: Date.now() - 3600000,
        },
        {
          title: "Python Checkpoint Score Analyzer",
          codeLanguage: "python",
          template: "python",
          trackId: 125,
          tutorialId: 4589,
          chapterId: 17758,
          lessonId: 151550,
          files: [
            {
              name: "script.py",
              codeLanguage: "python",
              content: `score = 92
lessons_completed = 5
lessons_completed += 1
print(lessons_completed)
if score >= 90:
  print("Good")
else:
  print("OK")`,
            },
          ],
          lastOutput: "6\nGood",
          updatedAt: Date.now() - 1800000,
        },
        {
          title: "JavaScript Delivery Fee Calculator",
          codeLanguage: "javascript",
          template: "javascript",
          trackId: 197,
          tutorialId: 1023,
          chapterId: 1,
          lessonId: 900001,
          files: [
            {
              name: "cart.js",
              codeLanguage: "javascript",
              content: `const items = [25, 40, 15];
const total = items.reduce((a, b) => a + b, 0);
const shipping = total >= 50 ? 0 : 9.99;
console.log("Order total:", total, "Shipping:", shipping);`,
            },
          ],
          lastOutput: "Order total: 80 Shipping: 0",
          updatedAt: Date.now() - 900000,
        },
      ]);

      await logTelemetry(
        "ROOM_SQL",
        "Database_Impl",
        "INIT_ROOM_DB_V2",
        {
          version: 2,
          identityHash: "2b8ab6d303d9a501bd8c8fb78d8352fc",
          seededSnapshot: "S5_1_F_AFTER_CORRECT_SUBMIT",
        },
        "VERIFIED_DATABASE [E27]"
      );
    }
    isSeeded = true;
  } catch (err) {
    console.error("Seed error:", err);
  }
}

export async function getFullAppState(sectionIndex = 0, trackIdOverride?: number) {
  await ensureSeededDatabase();

  const [user] = await db.select().from(mimoUserState).where(eq(mimoUserState.id, 1));
  const activeTrackId = trackIdOverride ?? user?.currentTrackId ?? 50;

  if (trackIdOverride && user && user.currentTrackId !== trackIdOverride) {
    await db
      .update(mimoUserState)
      .set({ currentTrackId: trackIdOverride, updatedAt: Date.now() })
      .where(eq(mimoUserState.id, 1));
  }

  const [master] = await db.select().from(roomMasterTable).limit(1);
  const lpRows = await db.select().from(lessonProgress);
  const tcRows = await db.select().from(tutorialCompletions);
  const ccRows = await db.select().from(chapterCompletions);
  const savedCodes = await db.select().from(mimoSavedCode).orderBy(desc(mimoSavedCode.updatedAt));
  const telemetry = await db
    .select()
    .from(mimoTelemetryLog)
    .orderBy(desc(mimoTelemetryLog.id))
    .limit(40);

  const catalog = getTracksCatalog();
  const pathState = computePathMapState({
    trackId: activeTrackId,
    sectionIndex,
    lessonProgressRows: lpRows,
    tutorialCompletionRows: tcRows,
    chapterCompletionRows: ccRows,
    devOverrides: user.devOverrides,
    currentKeys: user.currentKeys,
    unlimitedKeys: user.unlimitedKeys,
  });

  // Compute F1-F5 local economy counters over lesson_progress
  const pendingRows = lpRows.filter((r) => r.inQueue === 1);
  const fCounters = {
    totalRows: lpRows.length,
    pendingInQueue: pendingRows.length,
    solvedCount: lpRows.filter((r) => isSolvedCorrectly(r.tries)).length,
    firstTryCount: firstTryCount(lpRows),
    answersInChapter: answersInChapter(pendingRows),
    localCoinsCache: user.coins, // F11: mimo_prefs.xml local_coins
  };

  return {
    apkIdentity: {
      package: "com.getmimo",
      versionName: "9.35",
      versionCode: 1792759685,
      publishSetVersion: catalog.publishSetVersion,
      apkSha256: catalog.apkSha256,
      roomMaster: master ?? { id: 42, identityHash: "2b8ab6d303d9a501bd8c8fb78d8352fc" },
    },
    user,
    tracks: catalog.tracks,
    counts: catalog.counts,
    pathState,
    roomTables: {
      lessonProgress: lpRows,
      tutorialCompletions: tcRows,
      chapterCompletions: ccRows,
    },
    economyCounters: fCounters,
    savedCodes,
    telemetry,
  };
}

/**
 * Records a lesson submission or slide continuation using Mimo 9.35's exact V/W/X/U state machine
 * and upserts the 11-column row into `lesson_progress` (PK: lesson_id, tutorial_id).
 */
export async function recordLessonSubmission(params: {
  lessonId: number;
  tutorialId: number;
  tutorialVersion: number;
  chapterId: number;
  trackId: number;
  startedAt: number;
  tries: number;
  attempts: number;
  isPracticeProgress: boolean;
  verdict: string;
  callSite: "V" | "W" | "X" | "U";
}) {
  await ensureSeededDatabase();
  const completedAt = Date.now();
  const row = {
    lessonId: Number(params.lessonId),
    completedAt,
    startedAt: Number(params.startedAt || completedAt - 5000),
    tries: Number(params.tries),
    tutorialId: Number(params.tutorialId),
    tutorialVersion: Number(params.tutorialVersion || 1),
    trackId: Number(params.trackId || 50),
    publishSetVersion: 753,
    attempts: Number(params.attempts || 1),
    isPracticeProgress: params.isPracticeProgress ? 1 : 0,
    inQueue: 1,
  };

  await db
    .insert(lessonProgress)
    .values(row)
    .onConflictDoUpdate({
      target: [lessonProgress.lessonId, lessonProgress.tutorialId],
      set: {
        completedAt: row.completedAt,
        startedAt: row.startedAt,
        tries: row.tries,
        tutorialVersion: row.tutorialVersion,
        trackId: row.trackId,
        publishSetVersion: row.publishSetVersion,
        attempts: row.attempts,
        isPracticeProgress: row.isPracticeProgress,
        inQueue: 1,
      },
    });

  await logTelemetry(
    "ROOM_SQL",
    `base/c.${params.callSite}() -> cg/a.storeLessonProgress`,
    `INSERT OR REPLACE INTO lesson_progress VALUES (${row.lessonId}, ${row.completedAt}, ${row.startedAt}, ${row.tries}, ${row.tutorialId}, ${row.tutorialVersion}, ${row.trackId}, 753, ${row.attempts}, ${row.isPracticeProgress}, 1)`,
    { row, verdict: params.verdict, callSite: params.callSite },
    "VERIFIED_RUNTIME [E06, E27]"
  );

  // Check if all lessons in this chapter are now solved (ADD-04 / local & server completion sync)
  const tut = getTutorialById(row.tutorialId);
  const ch = tut.chapters.find((c) => c.id === Number(params.chapterId)) ?? tut.chapters[0];
  const allRowsForTut = await db
    .select()
    .from(lessonProgress)
    .where(eq(lessonProgress.tutorialId, row.tutorialId));
  const solvedMap = new Set(allRowsForTut.filter((r) => r.tries >= 1).map((r) => r.lessonId));

  let chapterJustCompleted = false;
  let tutorialJustCompleted = false;

  if (ch && ch.lessons.every((l) => solvedMap.has(l.id))) {
    chapterJustCompleted = true;
    await db
      .insert(chapterCompletions)
      .values({
        chapterId: ch.id,
        createdAt: completedAt,
        trackId: row.trackId,
        tutorialId: row.tutorialId,
      })
      .onConflictDoNothing();
  }

  if (
    tut.chapters.length > 0 &&
    tut.chapters.every((c) => c.lessons.every((l) => solvedMap.has(l.id)))
  ) {
    tutorialJustCompleted = true;
    await db
      .insert(tutorialCompletions)
      .values({
        tutorialId: row.tutorialId,
        isCompleted: 1,
        updatedAt: completedAt,
        trackId: row.trackId,
      })
      .onConflictDoUpdate({
        target: [tutorialCompletions.tutorialId, tutorialCompletions.trackId],
        set: { isCompleted: 1, updatedAt: completedAt },
      });
  }

  // Update server-side Sparks XP when solved (explicitly tagged as server-side /v1/tutorials/{id}/progress response)
  if (row.tries >= 1) {
    const [user] = await db.select().from(mimoUserState).where(eq(mimoUserState.id, 1));
    if (user) {
      const gainedXp = row.attempts === 1 ? 15 : 10;
      const newDaily = user.dailySparks + gainedXp;
      const goalReachedBonus =
        user.dailySparks < user.dailySparksGoal && newDaily >= user.dailySparksGoal ? 25 : 0;
      await db
        .update(mimoUserState)
        .set({
          sparksXp: user.sparksXp + gainedXp,
          dailySparks: newDaily,
          coins: user.coins + goalReachedBonus,
          updatedAt: completedAt,
        })
        .where(eq(mimoUserState.id, 1));
    }
  }

  return {
    row,
    chapterJustCompleted,
    tutorialJustCompleted,
  };
}

/**
 * Executes the Outbox Sync Protocol (HANDOFF/05 §6 & LessonProgressApi.postProgress):
 * 1. move: UPDATE lesson_progress SET in_queue = 0 WHERE in_queue = 1
 * 2. post: Maps 9 DTO fields (toProgressList) to POST /v1/tutorials/{tutorialId}/progress
 * 3. delete (if raw Mimo mode) or keep (if preserveOutboxOnColdStart is enabled)
 */
export async function syncProgressOutbox() {
  await ensureSeededDatabase();
  const [user] = await db.select().from(mimoUserState).where(eq(mimoUserState.id, 1));
  const pending = await db
    .select()
    .from(lessonProgress)
    .where(eq(lessonProgress.inQueue, 1));

  // Wire DTO mapping (HANDOFF/05 §8: 9 fields, excludes inQueue and tutorialId which is in URL path)
  const wirePayloads = pending.map((r) => ({
    tutorialId: r.tutorialId,
    dto: {
      lessonId: r.lessonId,
      completedAt: r.completedAt,
      startedAt: r.startedAt,
      tries: r.tries,
      tutorialVersion: r.tutorialVersion,
      trackId: r.trackId,
      publishSetVersion: r.publishSetVersion,
      attempts: r.attempts,
      isPracticeProgress: r.isPracticeProgress === 1,
    },
  }));

  await db
    .update(lessonProgress)
    .set({ inQueue: 0 })
    .where(eq(lessonProgress.inQueue, 1));

  if (!user?.devOverrides?.preserveOutboxOnColdStart) {
    // Raw Mimo behavior: deletes posted rows after upload
    await db.delete(lessonProgress).where(eq(lessonProgress.inQueue, 0));
  }

  await logTelemetry(
    "RETROFIT_API",
    "LessonProgressApi.postProgress",
    `POST /v1/tutorials/{tutorialId}/progress (${wirePayloads.length} rows)`,
    {
      preserveOutbox: user?.devOverrides?.preserveOutboxOnColdStart ?? true,
      wirePayloads,
    },
    "VERIFIED_STATIC [E04, C-22]"
  );

  return { syncedCount: wirePayloads.length, wirePayloads };
}

/**
 * Loads any of the 26 captured Android emulator SQLite `mimo.db` snapshots from Mission 07
 * directly into PostgreSQL `lesson_progress`!
 */
export async function loadSqliteSnapshot(snapshotName: string) {
  await ensureSeededDatabase();
  const snap = RUNTIME_EVIDENCE.sqliteSnapshots.find((s) => s.snapshot === snapshotName);
  if (!snap) {
    throw new Error(`Snapshot ${snapshotName} not found`);
  }

  await db.delete(lessonProgress);
  if (snap.lessonProgress.length > 0) {
    await db.insert(lessonProgress).values(
      snap.lessonProgress.map((r) => ({
        lessonId: r.lesson_id,
        completedAt: r.completed_at,
        startedAt: r.started_at,
        tries: r.tries,
        tutorialId: r.tutorial_id,
        tutorialVersion: r.tutorial_version,
        trackId: r.track_id === 219 ? 50 : r.track_id, // Map 219/50 shared tutorial 904 so visible on active track too
        publishSetVersion: r.publish_set_version,
        attempts: r.attempts,
        isPracticeProgress: r.is_practice_progress,
        inQueue: r.in_queue,
      }))
    );
  }

  await logTelemetry(
    "ROOM_SQL",
    "SQLiteSnapshotLoader",
    `RESTORE SNAPSHOT ${snapshotName} (${snap.lessonProgress.length} lesson_progress rows, ${snap.tutorialCompletionsCount} tutorial_completions)`,
    { snapshot: snap },
    "VERIFIED_RUNTIME [M07 DB]"
  );

  return snap;
}

/**
 * Generates an AI Tutor response following Mimo 9.35's exact prompt architecture
 * (08_AI_TUTOR_ARCHITECTURE.md: {{{ ... }}} fenced system messages & InstantPrompts).
 */
export async function sendAiTutorMessage(params: {
  lessonId: number;
  tutorialId: number;
  mode: "interactive" | "executable";
  pathName: string;
  lessonContext: string;
  instructions?: string;
  expectedAnswer?: string;
  codeFiles?: PlaygroundFileItem[];
  instantPrompt?: "ExplainError" | "ExplainInteractiveMistake" | "FirstHint" | "SecondHint";
  userText?: string;
  errorText?: string;
  wrongAnswer?: string;
}) {
  await ensureSeededDatabase();
  const [user] = await db.select().from(mimoUserState).where(eq(mimoUserState.id, 1));

  // Build exact Mimo {{{ ... }}} fenced system message
  const systemEnvelope =
    params.mode === "executable"
      ? {
          type: "executable",
          pathName: `{{{ ${params.pathName} }}}`,
          instructions: `{{{ ${params.instructions || params.lessonContext} }}}`,
          expectedAnswer: `{{{ ${params.expectedAnswer || ""} }}}`,
          preamble:
            "Act as Mimo's encouraging coding tutor. Give concise hints and explanations without immediately spoiling the full solution.",
        }
      : {
          type: "interactive",
          pathName: `{{{ ${params.pathName} }}}`,
          lessonContext: `{{{ ${params.lessonContext} }}}`,
          preamble:
            "Act as Mimo's encouraging coding tutor. Help the learner understand the concept in the current interactive lesson.",
        };

  let composedUserTurn = params.userText || "Can you give me a hint for this lesson?";
  if (params.instantPrompt === "ExplainError") {
    composedUserTurn = `[InstantPrompt$ExplainError] Explain this error: "${params.errorText || "IncorrectSolutionException"}" in ${params.pathName}`;
  } else if (params.instantPrompt === "ExplainInteractiveMistake") {
    composedUserTurn = `[InstantPrompt$ExplainInteractiveMistake] Why is "${params.wrongAnswer || "my answer"}" not quite right?`;
  } else if (params.instantPrompt === "FirstHint") {
    composedUserTurn = `[PromptSuggestions$FirstHint] Give me a first hint to get started.`;
  } else if (params.instantPrompt === "SecondHint") {
    composedUserTurn = `[PromptSuggestions$SecondHint] Give me a more specific second hint.`;
  }

  // Generate helpful, context-grounded tutor response
  const expectedHint = params.expectedAnswer
    ? `Look closely at the target expression \`${params.expectedAnswer.slice(0, 60)}\`.`
    : "Check the syntax tokens highlighted in the lesson prompt.";

  let replyContent = "";
  if (params.instantPrompt === "ExplainError") {
    replyContent = `Let's debug that together! The console reported \`${params.errorText || "IncorrectSolutionException"}\`. In \`${params.pathName}\`, make sure your syntax and variable names match the instructions. ${expectedHint}`;
  } else if (params.instantPrompt === "ExplainInteractiveMistake") {
    replyContent = `Good attempt! \`${params.wrongAnswer || "Your selection"}\` isn't what this step expects.Remember Mimo's normaliser rule (\`qm.i.a\`): check both the keyword/tag and exact casing. ${expectedHint}`;
  } else if (params.instantPrompt === "SecondHint") {
    replyContent = `Here is your second, closer hint for **${params.pathName}**: ${expectedHint} Once you place or type that exact token, tap Check / Run!`;
  } else {
    replyContent = `Great question on **${params.pathName}**! Focus on what the prompt asks: *${(params.instructions || params.lessonContext || "").slice(0, 140)}*. ${expectedHint}`;
  }

  const now = Date.now();
  const userMsg: AiChatMessageItem = {
    id: `msg-u-${now}`,
    role: "user",
    content: composedUserTurn,
    timestamp: now,
  };
  const botMsg: AiChatMessageItem = {
    id: `msg-a-${now + 1}`,
    role: "assistant",
    content: replyContent,
    finishReason: "Stop",
    timestamp: now + 1,
  };

  await db.insert(mimoAiConversations).values({
    lessonId: params.lessonId,
    tutorialId: params.tutorialId,
    mode: params.mode,
    systemMessage: systemEnvelope,
    messages: [userMsg, botMsg],
    userMessageCount: 1,
    updatedAt: now,
  });

  await logTelemetry(
    "RETROFIT_API",
    "AiTutorBottomSheetKt -> POST /v1/aiTutor/conversations",
    `SSE stream (Accept: text/event-stream) finishReason=Stop`,
    { systemEnvelope, userMsg, botMsg, isPro: user?.subscriptionTier !== "FREE" },
    "VERIFIED_STATIC [08_AI_TUTOR]"
  );

  return {
    conversationId: `conv-${now}`,
    systemEnvelope,
    userMessage: userMsg,
    assistantMessage: botMsg,
    finishReason: "Stop" as const,
    freemiumQuota: {
      usedMessages: 1,
      freeLimit: 5,
      isPro: user?.subscriptionTier !== "FREE",
    },
  };
}
