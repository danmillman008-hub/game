import {
  pgTable,
  integer,
  bigint,
  text,
  boolean,
  serial,
  jsonb,
  primaryKey,
} from "drizzle-orm/pg-core";

export interface DevOverridesConfig {
  unlockAll: boolean;
  unlimitedKeys: boolean;
  hardModeDefault: boolean;
  preserveOutboxOnColdStart: boolean;
  simulateOffline: boolean;
  fakeDiscountDrawer: boolean;
  fakeStreakSheet: boolean;
  fakeLeaderboardSheet: boolean;
  useUnpublishedTracksPackage: boolean;
}

export interface PlaygroundFileItem {
  name: string;
  codeLanguage: string;
  content: string;
  solvedContent?: string | null;
}

export interface AiChatMessageItem {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  finishReason?: "Stop" | "Length";
  timestamp: number;
}

// 1. Exact Mimo 9.35 Room Master Table (mimo.db version 2)
// Identity Hash verified from APK & runtime DB snapshots: 2b8ab6d303d9a501bd8c8fb78d8352fc
export const roomMasterTable = pgTable("room_master_table", {
  id: integer("id").primaryKey(),
  identityHash: text("identity_hash").notNull(),
});

// 2. Exact Mimo 9.35 lesson_progress table (11 columns, PK(lesson_id, tutorial_id))
// Spec: HANDOFF/06_SPEC_STORAGE.md & ANALYSIS/MISSION_07/06_DATABASE_BEFORE_AFTER.md
export const lessonProgress = pgTable(
  "lesson_progress",
  {
    lessonId: integer("lesson_id").notNull(),
    completedAt: bigint("completed_at", { mode: "number" }).notNull(),
    startedAt: bigint("started_at", { mode: "number" }).notNull(),
    tries: integer("tries").notNull(), // 0 or 1 flag: isSolvedCorrectly() === (tries >= 1)
    tutorialId: integer("tutorial_id").notNull(),
    tutorialVersion: integer("tutorial_version").notNull(),
    trackId: integer("track_id").notNull(),
    publishSetVersion: integer("publish_set_version").notNull(), // 753 in shipped APK
    attempts: integer("attempts").notNull(),
    isPracticeProgress: integer("is_practice_progress").notNull(), // 0 or 1
    inQueue: integer("in_queue").notNull(), // 1 = pending upload outbox, 0 = claimed/synced
  },
  (table) => [
    primaryKey({ name: "lesson_progress_pk", columns: [table.lessonId, table.tutorialId] }),
  ]
);

// 3. Exact Mimo 9.35 tutorial_completions table (4 columns, PK(tutorial_id, track_id))
export const tutorialCompletions = pgTable(
  "tutorial_completions",
  {
    tutorialId: integer("tutorial_id").notNull(),
    isCompleted: integer("is_completed").notNull(), // 0 or 1
    updatedAt: bigint("updated_at", { mode: "number" }).notNull(),
    trackId: integer("track_id").notNull(),
  },
  (table) => [
    primaryKey({ name: "tutorial_completions_pk", columns: [table.tutorialId, table.trackId] }),
  ]
);

// 4. Exact Mimo 9.35 chapter_completions table (4 columns, PK(chapter_id, track_id))
export const chapterCompletions = pgTable(
  "chapter_completions",
  {
    chapterId: integer("chapter_id").notNull(),
    createdAt: bigint("created_at", { mode: "number" }).notNull(),
    trackId: integer("track_id").notNull(),
    tutorialId: integer("tutorial_id").notNull(),
  },
  (table) => [
    primaryKey({ name: "chapter_completions_pk", columns: [table.chapterId, table.trackId] }),
  ]
);

// 5. Mimo SharedPreferences (mimo_prefs.xml) + Server-Authoritative Economy/Account State
export const mimoUserState = pgTable("mimo_user_state", {
  id: integer("id").primaryKey(),
  displayName: text("display_name").notNull().default("Alex Rivera"),
  email: text("email").notNull().default("alex@getmimo.com"),
  isAnonymous: boolean("is_anonymous").notNull().default(false),
  subscriptionTier: text("subscription_tier").notNull().default("PRO"), // FREE | PRO | MAX
  coins: integer("coins").notNull().default(200), // F11: mimo_prefs.xml local_coins={"coins":200}
  currentKeys: integer("current_keys").notNull().default(5),
  unlimitedKeys: boolean("unlimited_keys").notNull().default(true),
  sparksXp: integer("sparks_xp").notNull().default(480),
  dailySparks: integer("daily_sparks").notNull().default(30),
  dailySparksGoal: integer("daily_sparks_goal").notNull().default(50),
  streakDays: integer("streak_days").notNull().default(7),
  streakFreezeCount: integer("streak_freeze_count").notNull().default(2),
  streakChallengeActive: boolean("streak_challenge_active").notNull().default(false),
  streakChallengeDay: integer("streak_challenge_day").notNull().default(0),
  leagueTier: integer("league_tier").notNull().default(3), // 1..5
  currentTrackId: integer("current_track_id").notNull().default(50), // 50 = Full-Stack Developer
  appearance: text("appearance").notNull().default("light"), // light | dark
  uiLocale: text("ui_locale").notNull().default("en"), // en | fa
  favoriteTracks: jsonb("favorite_tracks").$type<number[]>().notNull().default([50, 219, 226, 125]),
  ownedItems: jsonb("owned_items")
    .$type<string[]>()
    .notNull()
    .default(["icon_default", "streak_freeze_1"]),
  devOverrides: jsonb("dev_overrides")
    .$type<DevOverridesConfig>()
    .notNull()
    .default({
      unlockAll: true,
      unlimitedKeys: true,
      hardModeDefault: false,
      preserveOutboxOnColdStart: true,
      simulateOffline: false,
      fakeDiscountDrawer: false,
      fakeStreakSheet: false,
      fakeLeaderboardSheet: false,
      useUnpublishedTracksPackage: false,
    }),
  updatedAt: bigint("updated_at", { mode: "number" }).notNull(),
});

// 6. Code Playground & Lesson Saved Files (/v1/code & /v1/tracks/.../savefiles)
export const mimoSavedCode = pgTable("mimo_saved_code", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  codeLanguage: text("code_language").notNull(),
  template: text("template").notNull(),
  trackId: integer("track_id"),
  tutorialId: integer("tutorial_id"),
  chapterId: integer("chapter_id"),
  lessonId: integer("lesson_id"),
  files: jsonb("files").$type<PlaygroundFileItem[]>().notNull(),
  lastOutput: text("last_output").notNull().default(""),
  updatedAt: bigint("updated_at", { mode: "number" }).notNull(),
});

// 7. AI Tutor Conversations (/v1/aiTutor/conversations)
export const mimoAiConversations = pgTable("mimo_ai_conversations", {
  id: serial("id").primaryKey(),
  lessonId: integer("lesson_id").notNull(),
  tutorialId: integer("tutorial_id").notNull(),
  mode: text("mode").notNull(), // interactive | executable
  systemMessage: jsonb("system_message").notNull(),
  messages: jsonb("messages").$type<AiChatMessageItem[]>().notNull(),
  userMessageCount: integer("user_message_count").notNull().default(0),
  updatedAt: bigint("updated_at", { mode: "number" }).notNull(),
});

// 8. Runtime Telemetry & Room DAO / Retrofit Trace Log
export const mimoTelemetryLog = pgTable("mimo_telemetry_log", {
  id: serial("id").primaryKey(),
  category: text("category").notNull(), // ROOM_SQL | RETROFIT_API | LESSON_VM | PATH_ENGINE | BRIDGE
  sourceClass: text("source_class").notNull(), // e.g. cg/a, Lqm/i.a, base/c.V(), GetPathMapState
  operation: text("operation").notNull(),
  payload: jsonb("payload").notNull(),
  evidenceCode: text("evidence_code").notNull(), // e.g. VERIFIED_RUNTIME [E06], VERIFIED_STATIC [E25]
  createdAt: bigint("created_at", { mode: "number" }).notNull(),
});
