import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import {
  lessonProgress,
  tutorialCompletions,
  chapterCompletions,
  mimoUserState,
  mimoSavedCode,
  DevOverridesConfig,
  PlaygroundFileItem,
} from "@/db/schema";
import { eq } from "drizzle-orm";
import {
  ensureSeededDatabase,
  getFullAppState,
  recordLessonSubmission,
  syncProgressOutbox,
  loadSqliteSnapshot,
  sendAiTutorMessage,
  logTelemetry,
} from "@/lib/mimo/server-service";
import { getTutorialById } from "@/lib/mimo/corpus";
import { executeCodeSandbox } from "@/lib/mimo/engine";

export async function POST(req: NextRequest) {
  try {
    await ensureSeededDatabase();
    const body = await req.json();
    const action = String(body.action || "");
    const sectionIndex = Number(body.sectionIndex || 0);

    if (action === "OPEN_TUTORIAL") {
      const tutorialId = Number(body.tutorialId || 904);
      const tutorial = getTutorialById(tutorialId);
      await logTelemetry(
        "PATH_ENGINE",
        "PathMapViewModel$onTutorialClick",
        `Open Tutorial #${tutorial.id}: ${tutorial.title}`,
        { tutorialId: tutorial.id, version: tutorial.version, chapters: tutorial.chapters.length },
        "VERIFIED_RUNTIME [E29]"
      );
      const state = await getFullAppState(sectionIndex);
      return NextResponse.json({ ok: true, tutorial, state });
    }

    if (action === "SUBMIT_LESSON") {
      const res = await recordLessonSubmission({
        lessonId: Number(body.lessonId),
        tutorialId: Number(body.tutorialId),
        tutorialVersion: Number(body.tutorialVersion || 1),
        chapterId: Number(body.chapterId),
        trackId: Number(body.trackId || 50),
        startedAt: Number(body.startedAt || Date.now() - 4000),
        tries: Number(body.tries),
        attempts: Number(body.attempts || 1),
        isPracticeProgress: Boolean(body.isPracticeProgress),
        verdict: String(body.verdict || "CORRECT"),
        callSite: (body.callSite || "V") as "V" | "W" | "X" | "U",
      });
      const state = await getFullAppState(sectionIndex);
      return NextResponse.json({ ok: true, submission: res, state });
    }

    if (action === "SYNC_OUTBOX") {
      const syncResult = await syncProgressOutbox();
      const state = await getFullAppState(sectionIndex);
      return NextResponse.json({ ok: true, syncResult, state });
    }

    if (action === "COLD_START_SQL") {
      // Exact M07/M09 SQL observation: DELETE FROM lesson_progress WHERE in_queue = 1
      await db.delete(lessonProgress).where(eq(lessonProgress.inQueue, 1));
      await logTelemetry(
        "ROOM_SQL",
        "cg/a.clearQueue (M07/M09 Cold Start SQL seq 260)",
        "DELETE FROM lesson_progress WHERE in_queue = 1",
        { note: "Observed on cold start in M07/M09 runtime traces" },
        "VERIFIED_RUNTIME [M07 06, M09 seq 260]"
      );
      const state = await getFullAppState(sectionIndex);
      return NextResponse.json({ ok: true, state });
    }

    if (action === "CLEAR_ALL_TABLES") {
      // Exact Database_Impl.d clearAllTables
      await db.delete(lessonProgress);
      await db.delete(tutorialCompletions);
      await db.delete(chapterCompletions);
      await logTelemetry(
        "ROOM_SQL",
        "Database_Impl.d (clearAllTables)",
        "DELETE FROM lesson_progress; DELETE FROM tutorial_completions; DELETE FROM chapter_completions;",
        {},
        "VERIFIED_STATIC [HANDOFF/06 §1]"
      );
      const state = await getFullAppState(sectionIndex);
      return NextResponse.json({ ok: true, state });
    }

    if (action === "LOAD_SNAPSHOT") {
      const snapshotName = String(body.snapshotName || "S5_1_F_AFTER_CORRECT_SUBMIT");
      const snap = await loadSqliteSnapshot(snapshotName);
      const state = await getFullAppState(sectionIndex);
      return NextResponse.json({ ok: true, snapshot: snap, state });
    }

    if (action === "UPDATE_SETTINGS") {
      const [user] = await db.select().from(mimoUserState).where(eq(mimoUserState.id, 1));
      if (user) {
        const nextDevOverrides: DevOverridesConfig = body.devOverrides
          ? { ...user.devOverrides, ...body.devOverrides }
          : user.devOverrides;
        const nextFavorites: number[] = Array.isArray(body.favoriteTracks)
          ? body.favoriteTracks
          : user.favoriteTracks;

        await db
          .update(mimoUserState)
          .set({
            displayName: body.displayName ?? user.displayName,
            email: body.email ?? user.email,
            isAnonymous:
              body.isAnonymous !== undefined ? Boolean(body.isAnonymous) : user.isAnonymous,
            subscriptionTier: body.subscriptionTier ?? user.subscriptionTier,
            unlimitedKeys:
              body.unlimitedKeys !== undefined
                ? Boolean(body.unlimitedKeys)
                : nextDevOverrides.unlimitedKeys,
            dailySparksGoal:
              body.dailySparksGoal !== undefined
                ? Number(body.dailySparksGoal)
                : user.dailySparksGoal,
            currentTrackId:
              body.currentTrackId !== undefined
                ? Number(body.currentTrackId)
                : user.currentTrackId,
            appearance: body.appearance ?? user.appearance,
            uiLocale: body.uiLocale ?? user.uiLocale,
            favoriteTracks: nextFavorites,
            devOverrides: nextDevOverrides,
            updatedAt: Date.now(),
          })
          .where(eq(mimoUserState.id, 1));

        await logTelemetry(
          "RETROFIT_API",
          "kf/a.java -> PATCH /v1/user/settings",
          "Update user settings & DeveloperMenu overrides",
          {
            currentTrackId: body.currentTrackId ?? user.currentTrackId,
            appearance: body.appearance ?? user.appearance,
            subscriptionTier: body.subscriptionTier ?? user.subscriptionTier,
            devOverrides: nextDevOverrides,
          },
          "VERIFIED_STATIC [E13, 12_DEVELOPER_MENU]"
        );
      }
      const state = await getFullAppState(
        sectionIndex,
        body.currentTrackId !== undefined ? Number(body.currentTrackId) : undefined
      );
      return NextResponse.json({ ok: true, state });
    }

    if (action === "STORE_PURCHASE") {
      const [user] = await db.select().from(mimoUserState).where(eq(mimoUserState.id, 1));
      const itemType = String(body.itemType || "streak_freeze");
      const cost = Number(body.cost || 0);
      if (user) {
        let nextCoins = Math.max(0, user.coins - cost);
        let nextFreezes = user.streakFreezeCount;
        let nextKeys = user.currentKeys;
        let nextChallenge = user.streakChallengeActive;
        const nextOwned = [...(user.ownedItems || [])];

        if (itemType === "streak_freeze") {
          nextFreezes += 1;
        } else if (itemType === "refill_keys") {
          nextKeys += 5;
        } else if (itemType === "streak_challenge") {
          nextChallenge = true;
        } else if (itemType === "reward_chest") {
          // /v1/user/rewards/{rewardId}/confirm
          nextCoins = user.coins + 50;
        } else if (itemType.startsWith("icon_")) {
          if (!nextOwned.includes(itemType)) nextOwned.push(itemType);
        }

        await db
          .update(mimoUserState)
          .set({
            coins: nextCoins,
            streakFreezeCount: nextFreezes,
            currentKeys: nextKeys,
            streakChallengeActive: nextChallenge,
            ownedItems: nextOwned,
            updatedAt: Date.now(),
          })
          .where(eq(mimoUserState.id, 1));

        await logTelemetry(
          "RETROFIT_API",
          itemType === "reward_chest"
            ? "lh/a.java -> POST /v1/user/rewards/{rewardId}/confirm"
            : "nh/c.java -> POST /v1/products/user?useCoins=true",
          `Store transaction: ${itemType} (cost=${cost})`,
          { itemType, cost, coinsAfter: nextCoins },
          "VERIFIED_STATIC [10_GAMIFICATION]"
        );
      }
      const state = await getFullAppState(sectionIndex);
      return NextResponse.json({ ok: true, state });
    }

    if (action === "CONSUME_KEY") {
      const [user] = await db.select().from(mimoUserState).where(eq(mimoUserState.id, 1));
      if (user && !user.unlimitedKeys && !user.devOverrides.unlimitedKeys) {
        await db
          .update(mimoUserState)
          .set({
            currentKeys: Math.max(0, user.currentKeys - 1),
            updatedAt: Date.now(),
          })
          .where(eq(mimoUserState.id, 1));
        await logTelemetry(
          "RETROFIT_API",
          "bh/a.java -> POST /v1/user/keys/consume",
          "Consumed 1 key to unlock chapter",
          { keysRemaining: Math.max(0, user.currentKeys - 1) },
          "VERIFIED_STATIC [E28]"
        );
      }
      const state = await getFullAppState(sectionIndex);
      return NextResponse.json({ ok: true, state });
    }

    if (action === "RUN_CODE") {
      const files = (body.files || []) as PlaygroundFileItem[];
      const execResult = executeCodeSandbox(files);
      await logTelemetry(
        "RETROFIT_API",
        "hg/c.java -> POST /v1/code/runfiles",
        `Executed ${files[0]?.name || "code"} (${files[0]?.codeLanguage || "js"})`,
        { filesCount: files.length, stdout: execResult.stdout, error: execResult.error },
        "VERIFIED_STATIC [E04, E10]"
      );
      return NextResponse.json({ ok: true, execResult });
    }

    if (action === "SAVE_PLAYGROUND") {
      const files = (body.files || []) as PlaygroundFileItem[];
      const title = String(body.title || "Untitled Playground");
      const codeLanguage = String(body.codeLanguage || files[0]?.codeLanguage || "javascript");
      const template = String(body.template || "javascript");
      const execResult = executeCodeSandbox(files);

      if (body.id) {
        await db
          .update(mimoSavedCode)
          .set({
            title,
            codeLanguage,
            files,
            lastOutput: execResult.stdout,
            updatedAt: Date.now(),
          })
          .where(eq(mimoSavedCode.id, Number(body.id)));
      } else {
        await db.insert(mimoSavedCode).values({
          title,
          codeLanguage,
          template,
          files,
          lastOutput: execResult.stdout,
          updatedAt: Date.now(),
        });
      }

      await logTelemetry(
        "RETROFIT_API",
        "mh/c.java -> POST /v1/code",
        `Saved Code Playground "${title}"`,
        { title, codeLanguage },
        "VERIFIED_STATIC [E04]"
      );
      const state = await getFullAppState(sectionIndex);
      return NextResponse.json({ ok: true, execResult, state });
    }

    if (action === "AI_TUTOR") {
      const tutorRes = await sendAiTutorMessage({
        lessonId: Number(body.lessonId || 151403),
        tutorialId: Number(body.tutorialId || 904),
        mode: body.mode === "executable" ? "executable" : "interactive",
        pathName: String(body.pathName || "index.html"),
        lessonContext: String(body.lessonContext || ""),
        instructions: body.instructions ? String(body.instructions) : undefined,
        expectedAnswer: body.expectedAnswer ? String(body.expectedAnswer) : undefined,
        codeFiles: body.codeFiles,
        instantPrompt: body.instantPrompt,
        userText: body.userText,
        errorText: body.errorText,
        wrongAnswer: body.wrongAnswer,
      });
      const state = await getFullAppState(sectionIndex);
      return NextResponse.json({ ok: true, tutorRes, state });
    }

    return NextResponse.json({ ok: false, error: `Unknown action: ${action}` }, { status: 400 });
  } catch (err) {
    console.error("POST /api/mimo/action error:", err);
    return NextResponse.json(
      { ok: false, error: err instanceof Error ? err.message : "Action failed" },
      { status: 500 }
    );
  }
}
