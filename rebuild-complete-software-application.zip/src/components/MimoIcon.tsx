"use client";

import React from "react";
import arscVectorsRaw from "@/lib/mimo/data/arsc-vectors.json";

interface VectorPath {
  d: string;
  fill?: string | null;
  stroke?: string | null;
  strokeWidth?: number | null;
  fillType?: string | null;
}

interface VectorDef {
  source: string;
  viewport: number[];
  size_dp: number[];
  paths: VectorPath[];
}

const VECTORS = arscVectorsRaw as unknown as Record<string, VectorDef>;

export interface MimoIconProps {
  name: string;
  size?: number;
  mono?: boolean;
  className?: string;
}

export function MimoIcon({ name, size = 24, mono = false, className = "" }: MimoIconProps) {
  const def = VECTORS[name] ?? VECTORS["ic_cap"];
  if (!def) return null;

  const vw = def.viewport?.[0] || 24;
  const vh = def.viewport?.[1] || 24;

  return (
    <svg
      width={size}
      height={size}
      viewBox={`0 0 ${vw} ${vh}`}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`inline-block shrink-0 ${className}`}
      aria-hidden="true"
    >
      {def.paths.map((p, idx) => {
        const useCurrentColor =
          mono ||
          !p.fill ||
          p.fill === "#FF252746" ||
          p.fill === "#252746" ||
          p.fill === "#FFFFFFFF";
        const fillVal = p.fill
          ? mono
            ? "currentColor"
            : p.fill.length === 9 && p.fill.startsWith("#FF")
            ? `#${p.fill.slice(3)}`
            : useCurrentColor && mono
            ? "currentColor"
            : p.fill
          : "none";

        const strokeVal = p.stroke
          ? mono
            ? "currentColor"
            : p.stroke.length === 9 && p.stroke.startsWith("#FF")
            ? `#${p.stroke.slice(3)}`
            : p.stroke
          : undefined;

        return (
          <path
            key={idx}
            d={p.d}
            fill={fillVal}
            stroke={strokeVal}
            strokeWidth={p.strokeWidth ?? undefined}
            fillRule={p.fillType === "evenOdd" ? "evenodd" : undefined}
            clipRule={p.fillType === "evenOdd" ? "evenodd" : undefined}
          />
        );
      })}
    </svg>
  );
}
