package com.getmimo.ui.compose.components;

import kotlin.Metadata;
import o70.m;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX INFO: compiled from: r8-map-id-6b1b9a7aabb67c08b10510c084e2abcbeb53083883bac13e4d61278a32657bc6 */
/* JADX INFO: loaded from: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex */
@Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001¨\u0006\u0002"}, d2 = {"Lcom/getmimo/ui/compose/components/MimoBadgeType;", "", "ui"}, k = 1, mv = {2, 4, 0}, xi = 48)
public class MimoBadgeType {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final MimoBadgeType f14602c = null;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final MimoBadgeType f14603d = null;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final MimoBadgeType f14604e = null;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final MimoBadgeType f14605f = null;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final MimoBadgeType f14606g = null;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public static final MimoBadgeType f14607v = null;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public static final MimoBadgeType f14608w = null;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public static final MimoBadgeType f14609x = null;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public static final /* synthetic */ MimoBadgeType[] f14610y = null;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final m f14611a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final m f14612b;

    /* JADX INFO: compiled from: r8-map-id-6b1b9a7aabb67c08b10510c084e2abcbeb53083883bac13e4d61278a32657bc6 */
    @Metadata(d1 = {"\u0000\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000*\u0001\u0000\bÊ\u0001\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"com/getmimo/ui/compose/components/MimoBadgeType.ProFade", "Lcom/getmimo/ui/compose/components/MimoBadgeType;", "ui"}, k = 1, mv = {2, 4, 0}, xi = 48)
    public static final class ProFade extends MimoBadgeType {
    }

    /*  JADX ERROR: Method load error
        jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (848526358 > 16237920) in method: com.getmimo.ui.compose.components.MimoBadgeType.<init>(java.lang.String, int, o70.m, o70.m):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:78)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:127)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        Caused by: java.lang.IllegalArgumentException: newPosition > limit: (848526358 > 16237920)
        	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
        	at java.base/java.nio.Buffer.position(Buffer.java:327)
        	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
        	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
        	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
        	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
        	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
        	... 6 more
        */
    public MimoBadgeType(java.lang.String r1, int r2, o70.m r3, o70.m r4) {
        /*
        // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (848526358 > 16237920) in method: com.getmimo.ui.compose.components.MimoBadgeType.<init>(java.lang.String, int, o70.m, o70.m):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.compose.components.MimoBadgeType.<init>(java.lang.String, int, o70.m, o70.m):void");
    }

    /*  JADX ERROR: Method load error
        jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (2061015514 > 16237920) in method: com.getmimo.ui.compose.components.MimoBadgeType.valueOf(java.lang.String):com.getmimo.ui.compose.components.MimoBadgeType, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:78)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:127)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        Caused by: java.lang.IllegalArgumentException: newPosition > limit: (2061015514 > 16237920)
        	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
        	at java.base/java.nio.Buffer.position(Buffer.java:327)
        	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
        	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
        	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
        	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
        	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
        	... 6 more
        */
    public static com.getmimo.ui.compose.components.MimoBadgeType valueOf(java.lang.String r0) {
        /*
        // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (2061015514 > 16237920) in method: com.getmimo.ui.compose.components.MimoBadgeType.valueOf(java.lang.String):com.getmimo.ui.compose.components.MimoBadgeType, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.compose.components.MimoBadgeType.valueOf(java.lang.String):com.getmimo.ui.compose.components.MimoBadgeType");
    }

    /*  JADX ERROR: Method load error
        jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (1672802366 > 16237920) in method: com.getmimo.ui.compose.components.MimoBadgeType.values():com.getmimo.ui.compose.components.MimoBadgeType[], file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:78)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:127)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        Caused by: java.lang.IllegalArgumentException: newPosition > limit: (1672802366 > 16237920)
        	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
        	at java.base/java.nio.Buffer.position(Buffer.java:327)
        	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
        	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
        	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
        	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
        	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
        	... 6 more
        */
    public static com.getmimo.ui.compose.components.MimoBadgeType[] values() {
        /*
        // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (1672802366 > 16237920) in method: com.getmimo.ui.compose.components.MimoBadgeType.values():com.getmimo.ui.compose.components.MimoBadgeType[], file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.compose.components.MimoBadgeType.values():com.getmimo.ui.compose.components.MimoBadgeType[]");
    }
}
