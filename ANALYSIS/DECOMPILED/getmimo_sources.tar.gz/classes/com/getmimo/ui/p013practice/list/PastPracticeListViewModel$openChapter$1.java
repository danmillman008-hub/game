package com.getmimo.ui.p013practice.list;

import com.getmimo.ui.chapter.ChapterBundle;
import f70.c;
import hi.e;
import kotlin.Metadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import o70.m;

/* JADX INFO: compiled from: r8-map-id-6b1b9a7aabb67c08b10510c084e2abcbeb53083883bac13e4d61278a32657bc6 */
/* JADX INFO: loaded from: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex */
@c(c = "com.getmimo.ui.practice.list.PastPracticeListViewModel$openChapter$1", f = "PastPracticeListViewModel.kt", l = {276, 279, 280, 282, 286}, m = "invokeSuspend", v = 2)
@Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0004\u001a\u00020\u0003*\u000e\u0012\u0004\u0012\u00020\u0001\u0012\u0004\u0012\u00020\u00020\u0000H\n¢\u0006\u0004\b\u0004\u0010\u0005"}, d2 = {"Lorg/orbitmvi/orbit/syntax/b;", "Lbo/z;", "Lbo/h0;", "Lz60/q;", "<anonymous>", "(Lorg/orbitmvi/orbit/syntax/b;)V"}, k = 3, mv = {2, 4, 0})
final class PastPracticeListViewModel$openChapter$1 extends SuspendLambda implements m {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public ChapterBundle f17279a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public ChapterBundle f17280b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public byte f17281c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public /* synthetic */ Object f17282d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ e f17283e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ c f17284f;

    /*  JADX ERROR: Method load error
        jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-682244450 < 0) in method: com.getmimo.ui.practice.list.PastPracticeListViewModel$openChapter$1.<init>(hi.e, com.getmimo.ui.practice.list.c, d70.b):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:78)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:119)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-682244450 < 0)
        	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
        	at java.base/java.nio.Buffer.position(Buffer.java:327)
        	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
        	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
        	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
        	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
        	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
        	... 6 more
        */
    public PastPracticeListViewModel$openChapter$1(hi.e r1, com.getmimo.ui.p013practice.list.c r2, d70.b r3) {
        /*
        // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-682244450 < 0) in method: com.getmimo.ui.practice.list.PastPracticeListViewModel$openChapter$1.<init>(hi.e, com.getmimo.ui.practice.list.c, d70.b):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.p013practice.list.PastPracticeListViewModel$openChapter$1.<init>(hi.e, com.getmimo.ui.practice.list.c, d70.b):void");
    }

    /*  JADX ERROR: Method load error
        jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-1652703733 < 0) in method: com.getmimo.ui.practice.list.PastPracticeListViewModel$openChapter$1.create(java.lang.Object, d70.b):d70.b, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:78)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:119)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-1652703733 < 0)
        	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
        	at java.base/java.nio.Buffer.position(Buffer.java:327)
        	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
        	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
        	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
        	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
        	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
        	... 6 more
        */
    public final d70.b create(java.lang.Object r1, d70.b r2) {
        /*
        // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-1652703733 < 0) in method: com.getmimo.ui.practice.list.PastPracticeListViewModel$openChapter$1.create(java.lang.Object, d70.b):d70.b, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.p013practice.list.PastPracticeListViewModel$openChapter$1.create(java.lang.Object, d70.b):d70.b");
    }

    /*  JADX ERROR: Method load error
        jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-1769470774 < 0) in method: com.getmimo.ui.practice.list.PastPracticeListViewModel$openChapter$1.invoke(java.lang.Object, java.lang.Object):java.lang.Object, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:78)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:119)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-1769470774 < 0)
        	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
        	at java.base/java.nio.Buffer.position(Buffer.java:327)
        	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
        	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
        	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
        	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
        	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
        	... 6 more
        */
    public final java.lang.Object invoke(java.lang.Object r1, java.lang.Object r2) {
        /*
        // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-1769470774 < 0) in method: com.getmimo.ui.practice.list.PastPracticeListViewModel$openChapter$1.invoke(java.lang.Object, java.lang.Object):java.lang.Object, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.p013practice.list.PastPracticeListViewModel$openChapter$1.invoke(java.lang.Object, java.lang.Object):java.lang.Object");
    }

    /*  JADX ERROR: Method load error
        jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (714089130 > 16237920) in method: com.getmimo.ui.practice.list.PastPracticeListViewModel$openChapter$1.invokeSuspend(java.lang.Object):java.lang.Object, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:78)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:119)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        Caused by: java.lang.IllegalArgumentException: newPosition > limit: (714089130 > 16237920)
        	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
        	at java.base/java.nio.Buffer.position(Buffer.java:327)
        	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
        	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
        	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
        	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
        	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
        	... 6 more
        */
    public final java.lang.Object invokeSuspend(java.lang.Object r1) {
        /*
            Method dump skipped, instruction units count: 394
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.p013practice.list.PastPracticeListViewModel$openChapter$1.invokeSuspend(java.lang.Object):java.lang.Object");
    }
}
