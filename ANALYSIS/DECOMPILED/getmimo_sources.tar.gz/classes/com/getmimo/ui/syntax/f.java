package com.getmimo.ui.syntax;

import androidx.compose.runtime.internal.a;

/* JADX INFO: compiled from: r8-map-id-6b1b9a7aabb67c08b10510c084e2abcbeb53083883bac13e4d61278a32657bc6 */
/* JADX INFO: loaded from: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex */
public abstract class f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final a f13532a = null;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final a f13533b = null;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final a f13534c = null;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final a f13535d = null;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final a f13536e = null;
}
