package com.getmimo.ui.streaks.bottomsheet;

import androidx.lifecycle.f1;
import androidx.lifecycle.g;
import androidx.lifecycle.m0;
import com.getmimo.analytics.a;
import com.getmimo.analytics.properties.OpenStreakDropdownSource;
import kotlin.Metadata;
import org.joda.time.DateTime;
import ua0.i;
import ua0.q;

/* JADX INFO: compiled from: r8-map-id-6b1b9a7aabb67c08b10510c084e2abcbeb53083883bac13e4d61278a32657bc6 */
/* JADX INFO: loaded from: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex */
@Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/getmimo/ui/streaks/bottomsheet/b;", "Landroidx/lifecycle/f1;", "app"}, k = 1, mv = {2, 4, 0}, xi = 48)
public final class b extends f1 {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final com.getmimo.interactors.streak.b f18234b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final a f18235c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final ke.a f18236d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final com.getmimo.interactors.profile.a f18237e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public OpenStreakDropdownSource f18238f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final kotlinx.coroutines.channels.a f18239g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final DateTime f18240h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final q f18241i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final g f18242j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final i f18243k;
    public final m0 l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final m0 f18244m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final m0 f18245n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final m0 f18246o;

    /*  JADX ERROR: Method load error
        jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-1535724717 < 0) in method: com.getmimo.ui.streaks.bottomsheet.b.<init>(com.getmimo.interactors.streak.a, com.getmimo.interactors.streak.b, com.getmimo.analytics.a, ke.a, com.getmimo.interactors.profile.a, ri.d):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:78)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:122)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-1535724717 < 0)
        	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
        	at java.base/java.nio.Buffer.position(Buffer.java:327)
        	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
        	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
        	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
        	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
        	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
        	... 6 more
        */
    public b(com.getmimo.interactors.streak.a r1, com.getmimo.interactors.streak.b r2, com.getmimo.analytics.a r3, ke.a r4, com.getmimo.interactors.profile.a r5, ri.d r6) {
        /*
            Method dump skipped, instruction units count: 217
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.streaks.bottomsheet.b.<init>(com.getmimo.interactors.streak.a, com.getmimo.interactors.streak.b, com.getmimo.analytics.a, ke.a, com.getmimo.interactors.profile.a, ri.d):void");
    }
}
