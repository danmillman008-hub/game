package com.getmimo.ui.publicprofile;

import androidx.lifecycle.f1;
import kotlin.Metadata;
import kotlinx.coroutines.flow.i;
import kotlinx.coroutines.flow.k;
import ua0.p;
import ua0.q;

/* JADX INFO: compiled from: r8-map-id-6b1b9a7aabb67c08b10510c084e2abcbeb53083883bac13e4d61278a32657bc6 */
/* JADX INFO: loaded from: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001:\u0001\u0002¨\u0006\u0003"}, d2 = {"Lcom/getmimo/ui/publicprofile/PublicProfileViewModel;", "Landroidx/lifecycle/f1;", "FollowButtonStatus", "app"}, k = 1, mv = {2, 4, 0}, xi = 48)
public final class PublicProfileViewModel extends f1 {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final com.getmimo.interactors.profile.a f17765b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final com.getmimo.interactors.publicprofile.a f17766c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final com.getmimo.interactors.playgrounds.c f17767d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final com.getmimo.data.source.remote.publicprofile.a f17768e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final com.getmimo.analytics.a f17769f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public PublicProfileBundle f17770g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final q f17771h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final q f17772i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final k f17773j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final q f17774k;
    public final q l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final i f17775m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final p f17776n;

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX INFO: compiled from: r8-map-id-6b1b9a7aabb67c08b10510c084e2abcbeb53083883bac13e4d61278a32657bc6 */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001¨\u0006\u0002"}, d2 = {"Lcom/getmimo/ui/publicprofile/PublicProfileViewModel$FollowButtonStatus;", "", "app"}, k = 1, mv = {2, 4, 0}, xi = 48)
    public static final class FollowButtonStatus {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static final FollowButtonStatus f17777a = null;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public static final FollowButtonStatus f17778b = null;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public static final FollowButtonStatus f17779c = null;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public static final FollowButtonStatus f17780d = null;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        public static final /* synthetic */ FollowButtonStatus[] f17781e = null;

        /*  JADX ERROR: Method load error
            jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-404068464 < 0) in method: com.getmimo.ui.publicprofile.PublicProfileViewModel.FollowButtonStatus.valueOf(java.lang.String):com.getmimo.ui.publicprofile.PublicProfileViewModel$FollowButtonStatus, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
            	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
            	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
            	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
            	at jadx.core.ProcessClass.process(ProcessClass.java:78)
            	at jadx.core.ProcessClass.generateCode(ProcessClass.java:122)
            	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
            	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
            	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
            Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-404068464 < 0)
            	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
            	at java.base/java.nio.Buffer.position(Buffer.java:327)
            	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
            	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
            	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
            	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
            	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
            	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
            	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
            	... 7 more
            */
        public static com.getmimo.ui.publicprofile.PublicProfileViewModel.FollowButtonStatus valueOf(java.lang.String r0) {
            /*
            // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-404068464 < 0) in method: com.getmimo.ui.publicprofile.PublicProfileViewModel.FollowButtonStatus.valueOf(java.lang.String):com.getmimo.ui.publicprofile.PublicProfileViewModel$FollowButtonStatus, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
            */
            throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.publicprofile.PublicProfileViewModel.FollowButtonStatus.valueOf(java.lang.String):com.getmimo.ui.publicprofile.PublicProfileViewModel$FollowButtonStatus");
        }

        /*  JADX ERROR: Method load error
            jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-774275653 < 0) in method: com.getmimo.ui.publicprofile.PublicProfileViewModel.FollowButtonStatus.values():com.getmimo.ui.publicprofile.PublicProfileViewModel$FollowButtonStatus[], file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
            	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
            	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
            	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
            	at jadx.core.ProcessClass.process(ProcessClass.java:78)
            	at jadx.core.ProcessClass.generateCode(ProcessClass.java:122)
            	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
            	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
            	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
            Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-774275653 < 0)
            	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
            	at java.base/java.nio.Buffer.position(Buffer.java:327)
            	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
            	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
            	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
            	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
            	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
            	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
            	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
            	... 7 more
            */
        public static com.getmimo.ui.publicprofile.PublicProfileViewModel.FollowButtonStatus[] values() {
            /*
            // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-774275653 < 0) in method: com.getmimo.ui.publicprofile.PublicProfileViewModel.FollowButtonStatus.values():com.getmimo.ui.publicprofile.PublicProfileViewModel$FollowButtonStatus[], file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
            */
            throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.publicprofile.PublicProfileViewModel.FollowButtonStatus.values():com.getmimo.ui.publicprofile.PublicProfileViewModel$FollowButtonStatus[]");
        }
    }

    /*  JADX ERROR: Method load error
        jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-1664993501 < 0) in method: com.getmimo.ui.publicprofile.PublicProfileViewModel.<init>(com.getmimo.interactors.profile.a, com.getmimo.interactors.publicprofile.a, com.getmimo.interactors.playgrounds.c, com.getmimo.data.source.remote.publicprofile.a, com.getmimo.analytics.a, ri.d):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:78)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:122)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-1664993501 < 0)
        	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
        	at java.base/java.nio.Buffer.position(Buffer.java:327)
        	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
        	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
        	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
        	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
        	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
        	... 6 more
        */
    public PublicProfileViewModel(com.getmimo.interactors.profile.a r1, com.getmimo.interactors.publicprofile.a r2, com.getmimo.interactors.playgrounds.c r3, com.getmimo.data.source.remote.publicprofile.a r4, com.getmimo.analytics.a r5, ri.d r6) {
        /*
            Method dump skipped, instruction units count: 232
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.publicprofile.PublicProfileViewModel.<init>(com.getmimo.interactors.profile.a, com.getmimo.interactors.publicprofile.a, com.getmimo.interactors.playgrounds.c, com.getmimo.data.source.remote.publicprofile.a, com.getmimo.analytics.a, ri.d):void");
    }
}
