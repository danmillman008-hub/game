package com.getmimo.ui.developermenu.discount;

import aj.p;
import androidx.lifecycle.m0;
import jf.e;
import kotlin.Metadata;
import xf.f;

/* JADX INFO: compiled from: r8-map-id-6b1b9a7aabb67c08b10510c084e2abcbeb53083883bac13e4d61278a32657bc6 */
/* JADX INFO: loaded from: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001:\u0001\u0002¨\u0006\u0003"}, d2 = {"Lcom/getmimo/ui/developermenu/discount/c;", "Laj/p;", "wk/c", "app"}, k = 1, mv = {2, 4, 0}, xi = 48)
public final class c extends p {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final f f14805b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final bg.a f14806c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final e f14807d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final ki.b f14808e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final a90.f f14809f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final ze.a f14810g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final com.getmimo.data.source.remote.iap.purchase.a f14811h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final m0 f14812i;

    /*  JADX ERROR: Method load error
        jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (1810815242 > 16237920) in method: com.getmimo.ui.developermenu.discount.c.<init>(xf.f, bg.a, jf.e, ki.b, a90.f, ze.a, com.getmimo.data.source.remote.iap.purchase.a, com.getmimo.analytics.a):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:78)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:122)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        Caused by: java.lang.IllegalArgumentException: newPosition > limit: (1810815242 > 16237920)
        	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
        	at java.base/java.nio.Buffer.position(Buffer.java:327)
        	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
        	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
        	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
        	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
        	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
        	... 6 more
        */
    public c(xf.f r1, bg.a r2, jf.e r3, ki.b r4, a90.f r5, ze.a r6, com.getmimo.data.source.remote.iap.purchase.a r7, com.getmimo.analytics.a r8) {
        /*
        // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (1810815242 > 16237920) in method: com.getmimo.ui.developermenu.discount.c.<init>(xf.f, bg.a, jf.e, ki.b, a90.f, ze.a, com.getmimo.data.source.remote.iap.purchase.a, com.getmimo.analytics.a):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.developermenu.discount.c.<init>(xf.f, bg.a, jf.e, ki.b, a90.f, ze.a, com.getmimo.data.source.remote.iap.purchase.a, com.getmimo.analytics.a):void");
    }

    /*  JADX ERROR: Method load error
        jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (1353341194 > 16237920) in method: com.getmimo.ui.developermenu.discount.c.E():void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:78)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:122)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        Caused by: java.lang.IllegalArgumentException: newPosition > limit: (1353341194 > 16237920)
        	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
        	at java.base/java.nio.Buffer.position(Buffer.java:327)
        	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
        	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
        	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
        	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
        	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
        	... 6 more
        */
    public final void E() {
        /*
            Method dump skipped, instruction units count: 288
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.developermenu.discount.c.E():void");
    }
}
