package com.getmimo.ui.developermenu;

import aj.p;
import androidx.lifecycle.m0;
import kf.d;
import kotlin.Metadata;
import kotlinx.coroutines.flow.i;
import kotlinx.coroutines.flow.k;
import np.h;
import ua0.q;
import xf.f;
import ye.e;
import ye.g;

/* JADX INFO: compiled from: r8-map-id-6b1b9a7aabb67c08b10510c084e2abcbeb53083883bac13e4d61278a32657bc6 */
/* JADX INFO: loaded from: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001:\u0001\u0002¨\u0006\u0003"}, d2 = {"Lcom/getmimo/ui/developermenu/c;", "Laj/p;", "sk/h", "app"}, k = 1, mv = {2, 4, 0}, xi = 48)
public final class c extends p {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final ze.a f14740b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final h f14741c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final yf.c f14742d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final zf.a f14743e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final com.getmimo.data.notification.a f14744f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final com.getmimo.data.source.remote.livepreview.a f14745g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final g f14746h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final com.getmimo.data.source.remote.reward.a f14747i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final com.getmimo.analytics.b f14748j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final com.getmimo.analytics.a f14749k;
    public final pe.a l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final np.g f14750m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final d f14751n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final f f14752o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final ee.a f14753p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final e f14754q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final com.getmimo.data.local.a f14755r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final m0 f14756s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final k f14757t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final q f14758u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final m0 f14759v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final m0 f14760w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final androidx.lifecycle.g f14761x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final i f14762y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final i f14763z;

    /*  JADX ERROR: Method load error
        jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-860752861 < 0) in method: com.getmimo.ui.developermenu.c.<init>(ze.a, np.h, yf.c, zf.a, com.getmimo.data.notification.a, com.getmimo.data.source.remote.livepreview.a, ye.g, com.getmimo.data.source.remote.reward.a, com.getmimo.analytics.b, com.getmimo.analytics.a, mg.a, pe.a, np.g, kf.d, xf.f, ee.a, ye.e, com.getmimo.data.local.a):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:78)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:127)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-860752861 < 0)
        	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
        	at java.base/java.nio.Buffer.position(Buffer.java:327)
        	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
        	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
        	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
        	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
        	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
        	... 6 more
        */
    public c(ze.a r1, np.h r2, yf.c r3, zf.a r4, com.getmimo.data.notification.a r5, com.getmimo.data.source.remote.livepreview.a r6, ye.g r7, com.getmimo.data.source.remote.reward.a r8, com.getmimo.analytics.b r9, com.getmimo.analytics.a r10, mg.a r11, pe.a r12, np.g r13, kf.d r14, xf.f r15, ee.a r16, ye.e r17, com.getmimo.data.local.a r18) {
        /*
            Method dump skipped, instruction units count: 288
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.developermenu.c.<init>(ze.a, np.h, yf.c, zf.a, com.getmimo.data.notification.a, com.getmimo.data.source.remote.livepreview.a, ye.g, com.getmimo.data.source.remote.reward.a, com.getmimo.analytics.b, com.getmimo.analytics.a, mg.a, pe.a, np.g, kf.d, xf.f, ee.a, ye.e, com.getmimo.data.local.a):void");
    }

    /*  JADX ERROR: Method load error
        jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (1234585001 > 16237920) in method: com.getmimo.ui.developermenu.c.E():void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:78)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:127)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        Caused by: java.lang.IllegalArgumentException: newPosition > limit: (1234585001 > 16237920)
        	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
        	at java.base/java.nio.Buffer.position(Buffer.java:327)
        	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
        	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
        	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
        	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
        	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
        	... 6 more
        */
    public final void E() {
        /*
        // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (1234585001 > 16237920) in method: com.getmimo.ui.developermenu.c.E():void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.developermenu.c.E():void");
    }
}
