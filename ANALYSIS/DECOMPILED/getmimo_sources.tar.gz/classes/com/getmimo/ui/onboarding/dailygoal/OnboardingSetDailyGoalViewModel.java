package com.getmimo.ui.onboarding.dailygoal;

import aj.p;
import androidx.lifecycle.m0;
import com.getmimo.interactors.authentication.e;
import kf.d;
import kotlin.Metadata;
import kotlinx.coroutines.flow.i;

/* JADX INFO: compiled from: r8-map-id-6b1b9a7aabb67c08b10510c084e2abcbeb53083883bac13e4d61278a32657bc6 */
/* JADX INFO: loaded from: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001:\u0001\u0002¨\u0006\u0003"}, d2 = {"Lcom/getmimo/ui/onboarding/dailygoal/OnboardingSetDailyGoalViewModel;", "Laj/p;", "NextScreen", "app"}, k = 1, mv = {2, 4, 0}, xi = 48)
public final class OnboardingSetDailyGoalViewModel extends p {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final com.getmimo.data.settings.a f16611b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final com.getmimo.analytics.a f16612c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final e f16613d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final d f16614e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final i f16615f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final ua0.p f16616g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final m0 f16617h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final m0 f16618i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final i f16619j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final ua0.p f16620k;
    public int l;

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX INFO: compiled from: r8-map-id-6b1b9a7aabb67c08b10510c084e2abcbeb53083883bac13e4d61278a32657bc6 */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001¨\u0006\u0002"}, d2 = {"Lcom/getmimo/ui/onboarding/dailygoal/OnboardingSetDailyGoalViewModel$NextScreen;", "", "app"}, k = 1, mv = {2, 4, 0}, xi = 48)
    public static final class NextScreen {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static final NextScreen f16621a = null;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public static final NextScreen f16622b = null;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public static final /* synthetic */ NextScreen[] f16623c = null;

        /*  JADX ERROR: Failed to decode insn: 0x000E: FILL_ARRAY_DATA_PAYLOAD
            jadx.plugins.input.dex.DexException: Unexpected element size in FILL_ARRAY_DATA_PAYLOAD: 11
            	at jadx.plugins.input.dex.insns.DexInsnFormat$30.decode(DexInsnFormat.java:345)
            	at jadx.plugins.input.dex.sections.DexCodeReader.decode(DexCodeReader.java:97)
            	at jadx.plugins.input.dex.insns.DexInsnData.decode(DexInsnData.java:46)
            	at jadx.core.dex.instructions.InsnDecoder.lambda$process$0(InsnDecoder.java:50)
            	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:86)
            	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
            	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
            	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
            	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
            	at jadx.core.ProcessClass.process(ProcessClass.java:78)
            	at jadx.core.ProcessClass.generateCode(ProcessClass.java:127)
            	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
            	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
            	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
            */
        public static com.getmimo.ui.onboarding.dailygoal.OnboardingSetDailyGoalViewModel.NextScreen valueOf(java.lang.String r5) {
            /*
                r1 = r5
                java.lang.Class<com.getmimo.ui.onboarding.dailygoal.OnboardingSetDailyGoalViewModel$NextScreen> r0 = com.getmimo.ui.onboarding.dailygoal.OnboardingSetDailyGoalViewModel.NextScreen.class
                r3 = 6
                java.lang.Enum.valueOf(r0, r1)
                r3 = move-result
                r1 = r3
                com.getmimo.ui.onboarding.dailygoal.OnboardingSetDailyGoalViewModel$NextScreen r1 = (com.getmimo.ui.onboarding.dailygoal.OnboardingSetDailyGoalViewModel.NextScreen) r1
                r4 = 4
                return r1
                // decode failed: Unexpected element size in FILL_ARRAY_DATA_PAYLOAD: 11
            */
            throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.onboarding.dailygoal.OnboardingSetDailyGoalViewModel.NextScreen.valueOf(java.lang.String):com.getmimo.ui.onboarding.dailygoal.OnboardingSetDailyGoalViewModel$NextScreen");
        }

        /*  JADX ERROR: Method load error
            jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-1572075557 < 0) in method: com.getmimo.ui.onboarding.dailygoal.OnboardingSetDailyGoalViewModel.NextScreen.values():com.getmimo.ui.onboarding.dailygoal.OnboardingSetDailyGoalViewModel$NextScreen[], file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
            	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
            	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
            	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
            	at jadx.core.ProcessClass.process(ProcessClass.java:78)
            	at jadx.core.ProcessClass.generateCode(ProcessClass.java:127)
            	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
            	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
            	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
            Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-1572075557 < 0)
            	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
            	at java.base/java.nio.Buffer.position(Buffer.java:327)
            	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
            	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
            	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
            	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
            	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
            	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
            	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
            	... 7 more
            */
        public static com.getmimo.ui.onboarding.dailygoal.OnboardingSetDailyGoalViewModel.NextScreen[] values() {
            /*
            // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-1572075557 < 0) in method: com.getmimo.ui.onboarding.dailygoal.OnboardingSetDailyGoalViewModel.NextScreen.values():com.getmimo.ui.onboarding.dailygoal.OnboardingSetDailyGoalViewModel$NextScreen[], file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
            */
            throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.onboarding.dailygoal.OnboardingSetDailyGoalViewModel.NextScreen.values():com.getmimo.ui.onboarding.dailygoal.OnboardingSetDailyGoalViewModel$NextScreen[]");
        }
    }

    /*  JADX ERROR: Method load error
        jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (1441279481 > 16237920) in method: com.getmimo.ui.onboarding.dailygoal.OnboardingSetDailyGoalViewModel.<init>(com.getmimo.data.settings.a, com.getmimo.analytics.a, com.getmimo.interactors.authentication.e, kf.d):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:78)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:127)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        Caused by: java.lang.IllegalArgumentException: newPosition > limit: (1441279481 > 16237920)
        	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
        	at java.base/java.nio.Buffer.position(Buffer.java:327)
        	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
        	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
        	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
        	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
        	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
        	... 6 more
        */
    public OnboardingSetDailyGoalViewModel(com.getmimo.data.settings.a r1, com.getmimo.analytics.a r2, com.getmimo.interactors.authentication.e r3, kf.d r4) {
        /*
        // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (1441279481 > 16237920) in method: com.getmimo.ui.onboarding.dailygoal.OnboardingSetDailyGoalViewModel.<init>(com.getmimo.data.settings.a, com.getmimo.analytics.a, com.getmimo.interactors.authentication.e, kf.d):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.onboarding.dailygoal.OnboardingSetDailyGoalViewModel.<init>(com.getmimo.data.settings.a, com.getmimo.analytics.a, com.getmimo.interactors.authentication.e, kf.d):void");
    }
}
