package com.getmimo.ui.iap.freetrial;

import bk.e0;
import com.getmimo.analytics.Analytics$Core$PaywallShown$Source;
import kotlin.Metadata;
import kotlinx.coroutines.flow.k;
import ua0.q;
import ye.g;

/* JADX INFO: compiled from: r8-map-id-6b1b9a7aabb67c08b10510c084e2abcbeb53083883bac13e4d61278a32657bc6 */
/* JADX INFO: loaded from: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex */
@Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/getmimo/ui/iap/freetrial/e;", "Lcom/getmimo/ui/iap/paywall/base/a;", "app"}, k = 1, mv = {2, 4, 0}, xi = 48)
public final class e extends com.getmimo.ui.iap.paywall.base.a {
    public final kotlinx.coroutines.channels.a A;
    public final ua0.a B;
    public Long C;
    public final k D;
    public final e0 E;
    public final k F;
    public final q G;
    public boolean H;
    public final boolean I;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final com.getmimo.data.source.remote.iap.purchase.a f15036h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final com.getmimo.analytics.a f15037i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final pe.a f15038j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final com.getmimo.interactors.upgrade.inventory.a f15039k;
    public final np.d l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final com.getmimo.data.settings.a f15040m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final kf.d f15041n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final mr.e f15042o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final g f15043p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final df.d f15044q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final Analytics$Core$PaywallShown$Source f15045r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final kotlinx.coroutines.channels.a f15046s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final ua0.a f15047t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final kotlinx.coroutines.channels.a f15048u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final ua0.a f15049v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final kotlinx.coroutines.channels.a f15050w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final ua0.a f15051x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final kotlinx.coroutines.channels.a f15052y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final ua0.a f15053z;

    /*  JADX ERROR: Method load error
        jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (523403090 > 16237920) in method: com.getmimo.ui.iap.freetrial.e.<init>(com.getmimo.data.source.remote.iap.purchase.a, com.getmimo.analytics.a, pe.a, com.getmimo.interactors.upgrade.inventory.a, np.d, com.getmimo.data.settings.a, kf.d, mr.e, ye.g, df.d, ce.c, com.getmimo.data.source.remote.iap.c, com.getmimo.data.source.remote.iap.purchase.b):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:78)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:122)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        Caused by: java.lang.IllegalArgumentException: newPosition > limit: (523403090 > 16237920)
        	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
        	at java.base/java.nio.Buffer.position(Buffer.java:327)
        	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
        	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
        	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
        	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
        	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
        	... 6 more
        */
    public e(com.getmimo.data.source.remote.iap.purchase.a r1, com.getmimo.analytics.a r2, pe.a r3, com.getmimo.interactors.upgrade.inventory.a r4, np.d r5, com.getmimo.data.settings.a r6, kf.d r7, mr.e r8, ye.g r9, df.d r10, ce.c r11, com.getmimo.data.source.remote.iap.c r12, com.getmimo.data.source.remote.iap.purchase.b r13) {
        /*
            Method dump skipped, instruction units count: 280
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.iap.freetrial.e.<init>(com.getmimo.data.source.remote.iap.purchase.a, com.getmimo.analytics.a, pe.a, com.getmimo.interactors.upgrade.inventory.a, np.d, com.getmimo.data.settings.a, kf.d, mr.e, ye.g, df.d, ce.c, com.getmimo.data.source.remote.iap.c, com.getmimo.data.source.remote.iap.purchase.b):void");
    }

    /*  JADX ERROR: Method load error
        jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-888931494 < 0) in method: com.getmimo.ui.iap.freetrial.e.J():com.getmimo.analytics.Analytics$Core$PaywallShown$Source, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:78)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:122)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-888931494 < 0)
        	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
        	at java.base/java.nio.Buffer.position(Buffer.java:327)
        	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
        	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
        	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
        	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
        	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
        	... 6 more
        */
    @Override // com.getmimo.ui.iap.paywall.base.a
    public final com.getmimo.analytics.Analytics$Core$PaywallShown$Source J() {
        /*
        // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-888931494 < 0) in method: com.getmimo.ui.iap.freetrial.e.J():com.getmimo.analytics.Analytics$Core$PaywallShown$Source, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.iap.freetrial.e.J():com.getmimo.analytics.Analytics$Core$PaywallShown$Source");
    }

    /*  JADX ERROR: Method load error
        jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (535653780 > 16237920) in method: com.getmimo.ui.iap.freetrial.e.Q(com.getmimo.analytics.properties.FreeTrialMethod):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:78)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:122)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        Caused by: java.lang.IllegalArgumentException: newPosition > limit: (535653780 > 16237920)
        	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
        	at java.base/java.nio.Buffer.position(Buffer.java:327)
        	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
        	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
        	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
        	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
        	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
        	... 6 more
        */
    public final void Q(com.getmimo.analytics.properties.FreeTrialMethod r1) {
        /*
        // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (535653780 > 16237920) in method: com.getmimo.ui.iap.freetrial.e.Q(com.getmimo.analytics.properties.FreeTrialMethod):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.iap.freetrial.e.Q(com.getmimo.analytics.properties.FreeTrialMethod):void");
    }

    /*  JADX ERROR: Method load error
        jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-1006213490 < 0) in method: com.getmimo.ui.iap.freetrial.e.R():void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:78)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:122)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-1006213490 < 0)
        	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
        	at java.base/java.nio.Buffer.position(Buffer.java:327)
        	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
        	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
        	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
        	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
        	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
        	... 6 more
        */
    public final void R() {
        /*
        // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-1006213490 < 0) in method: com.getmimo.ui.iap.freetrial.e.R():void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.iap.freetrial.e.R():void");
    }
}
