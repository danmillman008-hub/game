package com.getmimo.ui.iap.paywall;

import com.getmimo.analytics.Analytics$Core$PaywallShown$Source;
import kotlin.Metadata;
import xf.f;

/* JADX INFO: compiled from: r8-map-id-6b1b9a7aabb67c08b10510c084e2abcbeb53083883bac13e4d61278a32657bc6 */
/* JADX INFO: loaded from: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex */
@Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/getmimo/ui/iap/paywall/b;", "Lcom/getmimo/ui/iap/paywall/base/a;", "app"}, k = 1, mv = {2, 4, 0}, xi = 48)
public final class b extends com.getmimo.ui.iap.paywall.base.a {

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final com.getmimo.analytics.a f15132h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final com.getmimo.data.source.remote.keys.a f15133i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final f f15134j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final Analytics$Core$PaywallShown$Source f15135k;
    public final kotlinx.coroutines.channels.a l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final ua0.a f15136m;

    /*  JADX ERROR: Method load error
        jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (1342211362 > 16237920) in method: com.getmimo.ui.iap.paywall.b.<init>(com.getmimo.data.source.remote.iap.c, com.getmimo.data.source.remote.iap.purchase.b, com.getmimo.data.source.remote.iap.purchase.a, com.getmimo.analytics.a, com.getmimo.data.source.remote.keys.a, xf.f):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:78)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:119)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        Caused by: java.lang.IllegalArgumentException: newPosition > limit: (1342211362 > 16237920)
        	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
        	at java.base/java.nio.Buffer.position(Buffer.java:327)
        	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
        	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
        	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
        	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
        	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
        	... 6 more
        */
    public b(com.getmimo.data.source.remote.iap.c r1, com.getmimo.data.source.remote.iap.purchase.b r2, com.getmimo.data.source.remote.iap.purchase.a r3, com.getmimo.analytics.a r4, com.getmimo.data.source.remote.keys.a r5, xf.f r6) {
        /*
        // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (1342211362 > 16237920) in method: com.getmimo.ui.iap.paywall.b.<init>(com.getmimo.data.source.remote.iap.c, com.getmimo.data.source.remote.iap.purchase.b, com.getmimo.data.source.remote.iap.purchase.a, com.getmimo.analytics.a, com.getmimo.data.source.remote.keys.a, xf.f):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.iap.paywall.b.<init>(com.getmimo.data.source.remote.iap.c, com.getmimo.data.source.remote.iap.purchase.b, com.getmimo.data.source.remote.iap.purchase.a, com.getmimo.analytics.a, com.getmimo.data.source.remote.keys.a, xf.f):void");
    }

    /*  JADX ERROR: Method load error
        jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-1030916506 < 0) in method: com.getmimo.ui.iap.paywall.b.J():com.getmimo.analytics.Analytics$Core$PaywallShown$Source, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:78)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:119)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-1030916506 < 0)
        	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
        	at java.base/java.nio.Buffer.position(Buffer.java:327)
        	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
        	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
        	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
        	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
        	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
        	... 6 more
        */
    @Override // com.getmimo.ui.iap.paywall.base.a
    public final com.getmimo.analytics.Analytics$Core$PaywallShown$Source J() {
        /*
        // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-1030916506 < 0) in method: com.getmimo.ui.iap.paywall.b.J():com.getmimo.analytics.Analytics$Core$PaywallShown$Source, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.iap.paywall.b.J():com.getmimo.analytics.Analytics$Core$PaywallShown$Source");
    }
}
