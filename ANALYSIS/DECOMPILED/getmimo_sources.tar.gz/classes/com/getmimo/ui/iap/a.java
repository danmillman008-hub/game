package com.getmimo.ui.iap;

import aj.p;
import androidx.lifecycle.m0;
import kf.d;
import ki.c;
import kotlin.Metadata;
import kotlinx.coroutines.flow.i;
import ra0.q1;
import tr.b;
import ua0.r;
import xf.f;

/* JADX INFO: compiled from: r8-map-id-6b1b9a7aabb67c08b10510c084e2abcbeb53083883bac13e4d61278a32657bc6 */
/* JADX INFO: loaded from: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex */
@Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/getmimo/ui/iap/a;", "Laj/p;", "app"}, k = 1, mv = {2, 4, 0}, xi = 48)
public final class a extends p {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final com.getmimo.data.source.remote.iap.purchase.a f14940b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final com.getmimo.analytics.a f14941c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final d f14942d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final pe.a f14943e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final np.a f14944f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final ri.d f14945g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final f f14946h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final com.getmimo.interactors.upgrade.inventory.a f14947i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final np.d f14948j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final ki.a f14949k;
    public final c l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final df.d f14950m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final com.getmimo.data.source.remote.keys.a f14951n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final m0 f14952o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public Long f14953p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final m0 f14954q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public q1 f14955r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final b f14956s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final m0 f14957t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final m0 f14958u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final kotlinx.coroutines.channels.a f14959v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final ua0.a f14960w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final i f14961x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final ua0.p f14962y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final r f14963z;

    /*  JADX ERROR: Method load error
        jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-1493670676 < 0) in method: com.getmimo.ui.iap.a.<init>(com.getmimo.data.source.remote.iap.purchase.a, com.getmimo.analytics.a, kf.d, pe.a, np.a, ri.d, nb0.a, a90.f, xf.f, com.getmimo.interactors.upgrade.inventory.a, np.d, ki.a, ki.c, df.d, com.getmimo.data.source.remote.keys.a):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:78)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:122)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-1493670676 < 0)
        	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
        	at java.base/java.nio.Buffer.position(Buffer.java:327)
        	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
        	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
        	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
        	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
        	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
        	... 6 more
        */
    public a(com.getmimo.data.source.remote.iap.purchase.a r1, com.getmimo.analytics.a r2, kf.d r3, pe.a r4, np.a r5, ri.d r6, nb0.a r7, a90.f r8, xf.f r9, com.getmimo.interactors.upgrade.inventory.a r10, np.d r11, ki.a r12, ki.c r13, df.d r14, com.getmimo.data.source.remote.keys.a r15) {
        /*
        // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-1493670676 < 0) in method: com.getmimo.ui.iap.a.<init>(com.getmimo.data.source.remote.iap.purchase.a, com.getmimo.analytics.a, kf.d, pe.a, np.a, ri.d, nb0.a, a90.f, xf.f, com.getmimo.interactors.upgrade.inventory.a, np.d, ki.a, ki.c, df.d, com.getmimo.data.source.remote.keys.a):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.iap.a.<init>(com.getmimo.data.source.remote.iap.purchase.a, com.getmimo.analytics.a, kf.d, pe.a, np.a, ri.d, nb0.a, a90.f, xf.f, com.getmimo.interactors.upgrade.inventory.a, np.d, ki.a, ki.c, df.d, com.getmimo.data.source.remote.keys.a):void");
    }

    /*  JADX ERROR: Method load error
        jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (791888746 > 16237920) in method: com.getmimo.ui.iap.a.I(com.getmimo.ui.iap.a, android.app.Activity, java.lang.String, int, com.getmimo.analytics.properties.upgrade.UpgradeSource):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:78)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:122)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        Caused by: java.lang.IllegalArgumentException: newPosition > limit: (791888746 > 16237920)
        	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
        	at java.base/java.nio.Buffer.position(Buffer.java:327)
        	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
        	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
        	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
        	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
        	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
        	... 6 more
        */
    public static void I(com.getmimo.ui.iap.a r0, android.app.Activity r1, java.lang.String r2, int r3, com.getmimo.analytics.properties.upgrade.UpgradeSource r4) {
        /*
        // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (791888746 > 16237920) in method: com.getmimo.ui.iap.a.I(com.getmimo.ui.iap.a, android.app.Activity, java.lang.String, int, com.getmimo.analytics.properties.upgrade.UpgradeSource):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.iap.a.I(com.getmimo.ui.iap.a, android.app.Activity, java.lang.String, int, com.getmimo.analytics.properties.upgrade.UpgradeSource):void");
    }

    /*  JADX ERROR: Method load error
        jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (850266006 > 16237920) in method: com.getmimo.ui.iap.a.E(java.lang.String, int, com.getmimo.analytics.properties.upgrade.UpgradeSource):zg.b, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:78)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:122)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        Caused by: java.lang.IllegalArgumentException: newPosition > limit: (850266006 > 16237920)
        	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
        	at java.base/java.nio.Buffer.position(Buffer.java:327)
        	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
        	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
        	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
        	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
        	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
        	... 6 more
        */
    public final zg.b E(java.lang.String r1, int r2, com.getmimo.analytics.properties.upgrade.UpgradeSource r3) {
        /*
            Method dump skipped, instruction units count: 222
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.iap.a.E(java.lang.String, int, com.getmimo.analytics.properties.upgrade.UpgradeSource):zg.b");
    }

    /*  JADX ERROR: Method load error
        jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (49897542 > 16237920) in method: com.getmimo.ui.iap.a.F(com.getmimo.data.source.remote.iap.inventory.PriceReduction):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:78)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:122)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        Caused by: java.lang.IllegalArgumentException: newPosition > limit: (49897542 > 16237920)
        	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
        	at java.base/java.nio.Buffer.position(Buffer.java:327)
        	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
        	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
        	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
        	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
        	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
        	... 6 more
        */
    public final void F(com.getmimo.data.source.remote.iap.inventory.PriceReduction r1) {
        /*
        // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (49897542 > 16237920) in method: com.getmimo.ui.iap.a.F(com.getmimo.data.source.remote.iap.inventory.PriceReduction):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.iap.a.F(com.getmimo.data.source.remote.iap.inventory.PriceReduction):void");
    }

    /*  JADX ERROR: Method load error
        jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (302367798 > 16237920) in method: com.getmimo.ui.iap.a.G(com.getmimo.analytics.properties.upgrade.UpgradeSource):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:78)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:122)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        Caused by: java.lang.IllegalArgumentException: newPosition > limit: (302367798 > 16237920)
        	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
        	at java.base/java.nio.Buffer.position(Buffer.java:327)
        	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
        	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
        	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
        	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
        	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
        	... 6 more
        */
    public final void G(com.getmimo.analytics.properties.upgrade.UpgradeSource r1) {
        /*
        // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (302367798 > 16237920) in method: com.getmimo.ui.iap.a.G(com.getmimo.analytics.properties.upgrade.UpgradeSource):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.iap.a.G(com.getmimo.analytics.properties.upgrade.UpgradeSource):void");
    }

    /*  JADX ERROR: Method load error
        jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-1561851578 < 0) in method: com.getmimo.ui.iap.a.H(int, long):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:78)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:122)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-1561851578 < 0)
        	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
        	at java.base/java.nio.Buffer.position(Buffer.java:327)
        	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
        	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
        	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
        	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
        	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
        	... 6 more
        */
    public final void H(int r1, long r2) {
        /*
        // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-1561851578 < 0) in method: com.getmimo.ui.iap.a.H(int, long):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.iap.a.H(int, long):void");
    }
}
