package com.getmimo.ui.iap;

import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-6b1b9a7aabb67c08b10510c084e2abcbeb53083883bac13e4d61278a32657bc6 */
/* JADX INFO: loaded from: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00060\u0001j\u0002`\u0002¨\u0006\u0003"}, d2 = {"Lcom/getmimo/ui/iap/InventoryException;", "Ljava/lang/Exception;", "Lkotlin/Exception;", "app"}, k = 1, mv = {2, 4, 0}, xi = 48)
public final class InventoryException extends Exception {
}
