package com.getmimo.ui.store;

import kotlin.Metadata;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX INFO: compiled from: r8-map-id-6b1b9a7aabb67c08b10510c084e2abcbeb53083883bac13e4d61278a32657bc6 */
/* JADX INFO: loaded from: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex */
@Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001¨\u0006\u0002"}, d2 = {"Lcom/getmimo/ui/store/PurchaseResult;", "", "app"}, k = 1, mv = {2, 4, 0}, xi = 48)
public final class PurchaseResult {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final PurchaseResult f18154a = null;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final PurchaseResult f18155b = null;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final PurchaseResult f18156c = null;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final /* synthetic */ PurchaseResult[] f18157d = null;

    /*  JADX ERROR: Method load error
        jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (1068774714 > 16237920) in method: com.getmimo.ui.store.PurchaseResult.valueOf(java.lang.String):com.getmimo.ui.store.PurchaseResult, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:78)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:127)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        Caused by: java.lang.IllegalArgumentException: newPosition > limit: (1068774714 > 16237920)
        	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
        	at java.base/java.nio.Buffer.position(Buffer.java:327)
        	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
        	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
        	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
        	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
        	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
        	... 6 more
        */
    public static com.getmimo.ui.store.PurchaseResult valueOf(java.lang.String r0) {
        /*
        // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (1068774714 > 16237920) in method: com.getmimo.ui.store.PurchaseResult.valueOf(java.lang.String):com.getmimo.ui.store.PurchaseResult, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.store.PurchaseResult.valueOf(java.lang.String):com.getmimo.ui.store.PurchaseResult");
    }

    /*  JADX ERROR: Method load error
        jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-1230312123 < 0) in method: com.getmimo.ui.store.PurchaseResult.values():com.getmimo.ui.store.PurchaseResult[], file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:78)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:127)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-1230312123 < 0)
        	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
        	at java.base/java.nio.Buffer.position(Buffer.java:327)
        	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
        	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
        	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
        	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
        	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
        	... 6 more
        */
    public static com.getmimo.ui.store.PurchaseResult[] values() {
        /*
        // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-1230312123 < 0) in method: com.getmimo.ui.store.PurchaseResult.values():com.getmimo.ui.store.PurchaseResult[], file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.store.PurchaseResult.values():com.getmimo.ui.store.PurchaseResult[]");
    }
}
