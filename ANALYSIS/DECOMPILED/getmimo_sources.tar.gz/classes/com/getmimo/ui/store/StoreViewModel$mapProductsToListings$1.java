package com.getmimo.ui.store;

import com.getmimo.data.model.store.Products;
import com.getmimo.data.model.store.PurchasedProduct;
import fp.a0;
import java.util.Collection;
import java.util.List;
import kotlin.Metadata;
import kotlin.coroutines.jvm.internal.ContinuationImpl;

/* JADX INFO: compiled from: r8-map-id-6b1b9a7aabb67c08b10510c084e2abcbeb53083883bac13e4d61278a32657bc6 */
/* JADX INFO: loaded from: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex */
@f70.c(c = "com.getmimo.ui.store.StoreViewModel", f = "StoreViewModel.kt", l = {154, 173}, m = "mapProductsToListings", v = 2)
@Metadata(k = 3, mv = {2, 4, 0}, xi = 560)
final class StoreViewModel$mapProductsToListings$1 extends ContinuationImpl {
    public final /* synthetic */ c A;
    public int B;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public Products f18177a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public List f18178b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public List f18179c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public a0 f18180d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Collection f18181e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public Object f18182f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public PurchasedProduct f18183g;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public String f18184v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public Collection f18185w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public boolean f18186x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public int f18187y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public /* synthetic */ Object f18188z;

    /*  JADX ERROR: Method load error
        jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-772125654 < 0) in method: com.getmimo.ui.store.StoreViewModel$mapProductsToListings$1.<init>(com.getmimo.ui.store.c, kotlin.coroutines.jvm.internal.ContinuationImpl):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:78)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:119)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-772125654 < 0)
        	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
        	at java.base/java.nio.Buffer.position(Buffer.java:327)
        	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
        	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
        	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
        	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
        	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
        	... 6 more
        */
    public StoreViewModel$mapProductsToListings$1(com.getmimo.ui.store.c r1, kotlin.coroutines.jvm.internal.ContinuationImpl r2) {
        /*
        // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-772125654 < 0) in method: com.getmimo.ui.store.StoreViewModel$mapProductsToListings$1.<init>(com.getmimo.ui.store.c, kotlin.coroutines.jvm.internal.ContinuationImpl):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.store.StoreViewModel$mapProductsToListings$1.<init>(com.getmimo.ui.store.c, kotlin.coroutines.jvm.internal.ContinuationImpl):void");
    }

    /*  JADX ERROR: Method load error
        jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-1402165228 < 0) in method: com.getmimo.ui.store.StoreViewModel$mapProductsToListings$1.invokeSuspend(java.lang.Object):java.lang.Object, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:78)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:119)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-1402165228 < 0)
        	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
        	at java.base/java.nio.Buffer.position(Buffer.java:327)
        	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
        	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
        	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
        	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
        	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
        	... 6 more
        */
    public final java.lang.Object invokeSuspend(java.lang.Object r1) {
        /*
        // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-1402165228 < 0) in method: com.getmimo.ui.store.StoreViewModel$mapProductsToListings$1.invokeSuspend(java.lang.Object):java.lang.Object, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.store.StoreViewModel$mapProductsToListings$1.invokeSuspend(java.lang.Object):java.lang.Object");
    }
}
