package com.getmimo.ui.authentication;

import android.os.Parcelable;
import com.getmimo.analytics.properties.AuthenticationLocation;
import kotlin.Metadata;

/*  JADX ERROR: NullPointerException in pass: ClassModifier
    java.lang.NullPointerException: Cannot invoke "java.util.List.forEach(java.util.function.Consumer)" because "blocks" is null
    	at jadx.core.utils.BlockUtils.collectAllInsns(BlockUtils.java:1323)
    	at jadx.core.dex.visitors.ClassModifier.removeBridgeMethod(ClassModifier.java:246)
    	at jadx.core.dex.visitors.ClassModifier.removeSyntheticMethods(ClassModifier.java:161)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1596)
    	at jadx.core.dex.visitors.ClassModifier.visit(ClassModifier.java:66)
    	at jadx.core.dex.visitors.ClassModifier.visit(ClassModifier.java:59)
    */
/* JADX INFO: compiled from: r8-map-id-6b1b9a7aabb67c08b10510c084e2abcbeb53083883bac13e4d61278a32657bc6 */
/* JADX INFO: loaded from: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex */
@Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b7\u0018\u00002\u00020\u0001:\u0002\u0004\u0005B\t\b\u0004¢\u0006\u0004\b\u0002\u0010\u0003\u0082\u0001\u0002\u0006\u0007¨\u0006\b"}, d2 = {"Lcom/getmimo/ui/authentication/AuthenticationScreenType;", "Landroid/os/Parcelable;", "<init>", "()V", "Login", "Signup", "Lcom/getmimo/ui/authentication/AuthenticationScreenType$Login;", "Lcom/getmimo/ui/authentication/AuthenticationScreenType$Signup;", "app"}, k = 1, mv = {2, 4, 0}, xi = 48)
public abstract class AuthenticationScreenType implements Parcelable {

    /* JADX INFO: compiled from: r8-map-id-6b1b9a7aabb67c08b10510c084e2abcbeb53083883bac13e4d61278a32657bc6 */
    @Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b7\u0018\u00002\u00020\u0001:\u0006\u0004\u0005\u0006\u0007\b\tB\t\b\u0004¢\u0006\u0004\b\u0002\u0010\u0003\u0082\u0001\u0006\n\u000b\f\r\u000e\u000f¨\u0006\u0010"}, d2 = {"Lcom/getmimo/ui/authentication/AuthenticationScreenType$Login;", "Lcom/getmimo/ui/authentication/AuthenticationScreenType;", "<init>", "()V", "Onboarding", "Settings", "Leaderboard", "Profile", "Activity", "Practice", "Lcom/getmimo/ui/authentication/AuthenticationScreenType$Login$Activity;", "Lcom/getmimo/ui/authentication/AuthenticationScreenType$Login$Leaderboard;", "Lcom/getmimo/ui/authentication/AuthenticationScreenType$Login$Onboarding;", "Lcom/getmimo/ui/authentication/AuthenticationScreenType$Login$Practice;", "Lcom/getmimo/ui/authentication/AuthenticationScreenType$Login$Profile;", "Lcom/getmimo/ui/authentication/AuthenticationScreenType$Login$Settings;", "app"}, k = 1, mv = {2, 4, 0}, xi = 48)
    public static abstract class Login extends AuthenticationScreenType {

        /* JADX INFO: compiled from: r8-map-id-6b1b9a7aabb67c08b10510c084e2abcbeb53083883bac13e4d61278a32657bc6 */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/getmimo/ui/authentication/AuthenticationScreenType$Login$Activity;", "Lcom/getmimo/ui/authentication/AuthenticationScreenType$Login;", "app"}, k = 1, mv = {2, 4, 0}, xi = 48)
        public static final /* data */ class Activity extends Login {
            public static final Parcelable.Creator<Activity> CREATOR = null;

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            public final AuthenticationLocation f13548a;

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-1332731234 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Activity.<init>(com.getmimo.analytics.properties.AuthenticationLocation):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-1332731234 < 0)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            public Activity(com.getmimo.analytics.properties.AuthenticationLocation r1) {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-1332731234 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Activity.<init>(com.getmimo.analytics.properties.AuthenticationLocation):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Activity.<init>(com.getmimo.analytics.properties.AuthenticationLocation):void");
            }

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (1905046465 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Activity.a():com.getmimo.analytics.properties.AuthenticationLocation, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition > limit: (1905046465 > 16237920)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            @Override // com.getmimo.ui.authentication.AuthenticationScreenType
            public final com.getmimo.analytics.properties.AuthenticationLocation a() {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (1905046465 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Activity.a():com.getmimo.analytics.properties.AuthenticationLocation, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Activity.a():com.getmimo.analytics.properties.AuthenticationLocation");
            }

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-1450547358 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Activity.describeContents():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-1450547358 < 0)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            @Override // android.os.Parcelable
            public final int describeContents() {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-1450547358 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Activity.describeContents():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Activity.describeContents():int");
            }

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (1240373976 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Activity.equals(java.lang.Object):boolean, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition > limit: (1240373976 > 16237920)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            public final boolean equals(java.lang.Object r1) {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (1240373976 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Activity.equals(java.lang.Object):boolean, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Activity.equals(java.lang.Object):boolean");
            }

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-215976178 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Activity.hashCode():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-215976178 < 0)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            public final int hashCode() {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-215976178 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Activity.hashCode():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Activity.hashCode():int");
            }

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (1470862076 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Activity.toString():java.lang.String, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition > limit: (1470862076 > 16237920)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            public final java.lang.String toString() {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (1470862076 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Activity.toString():java.lang.String, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Activity.toString():java.lang.String");
            }

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-901218046 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Activity.writeToParcel(android.os.Parcel, int):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-901218046 < 0)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            @Override // android.os.Parcelable
            public final void writeToParcel(android.os.Parcel r1, int r2) {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-901218046 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Activity.writeToParcel(android.os.Parcel, int):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Activity.writeToParcel(android.os.Parcel, int):void");
            }
        }

        /* JADX INFO: compiled from: r8-map-id-6b1b9a7aabb67c08b10510c084e2abcbeb53083883bac13e4d61278a32657bc6 */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/getmimo/ui/authentication/AuthenticationScreenType$Login$Leaderboard;", "Lcom/getmimo/ui/authentication/AuthenticationScreenType$Login;", "app"}, k = 1, mv = {2, 4, 0}, xi = 48)
        public static final /* data */ class Leaderboard extends Login {
            public static final Parcelable.Creator<Leaderboard> CREATOR = null;

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            public final AuthenticationLocation f13549a;

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (743743026 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Leaderboard.<init>(com.getmimo.analytics.properties.AuthenticationLocation):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition > limit: (743743026 > 16237920)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            public Leaderboard(com.getmimo.analytics.properties.AuthenticationLocation r1) {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (743743026 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Leaderboard.<init>(com.getmimo.analytics.properties.AuthenticationLocation):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Leaderboard.<init>(com.getmimo.analytics.properties.AuthenticationLocation):void");
            }

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (801611951 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Leaderboard.a():com.getmimo.analytics.properties.AuthenticationLocation, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition > limit: (801611951 > 16237920)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            @Override // com.getmimo.ui.authentication.AuthenticationScreenType
            public final com.getmimo.analytics.properties.AuthenticationLocation a() {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (801611951 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Leaderboard.a():com.getmimo.analytics.properties.AuthenticationLocation, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Leaderboard.a():com.getmimo.analytics.properties.AuthenticationLocation");
            }

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (54633713 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Leaderboard.describeContents():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition > limit: (54633713 > 16237920)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            @Override // android.os.Parcelable
            public final int describeContents() {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (54633713 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Leaderboard.describeContents():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Leaderboard.describeContents():int");
            }

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-321611466 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Leaderboard.equals(java.lang.Object):boolean, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-321611466 < 0)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            public final boolean equals(java.lang.Object r1) {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-321611466 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Leaderboard.equals(java.lang.Object):boolean, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Leaderboard.equals(java.lang.Object):boolean");
            }

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-2065659392 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Leaderboard.hashCode():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-2065659392 < 0)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            public final int hashCode() {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-2065659392 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Leaderboard.hashCode():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Leaderboard.hashCode():int");
            }

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (574465457 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Leaderboard.toString():java.lang.String, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition > limit: (574465457 > 16237920)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            public final java.lang.String toString() {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (574465457 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Leaderboard.toString():java.lang.String, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Leaderboard.toString():java.lang.String");
            }

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (383384287 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Leaderboard.writeToParcel(android.os.Parcel, int):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition > limit: (383384287 > 16237920)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            @Override // android.os.Parcelable
            public final void writeToParcel(android.os.Parcel r1, int r2) {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (383384287 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Leaderboard.writeToParcel(android.os.Parcel, int):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Leaderboard.writeToParcel(android.os.Parcel, int):void");
            }
        }

        /* JADX INFO: compiled from: r8-map-id-6b1b9a7aabb67c08b10510c084e2abcbeb53083883bac13e4d61278a32657bc6 */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/getmimo/ui/authentication/AuthenticationScreenType$Login$Onboarding;", "Lcom/getmimo/ui/authentication/AuthenticationScreenType$Login;", "app"}, k = 1, mv = {2, 4, 0}, xi = 48)
        public static final /* data */ class Onboarding extends Login {
            public static final Parcelable.Creator<Onboarding> CREATOR = null;

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            public final AuthenticationLocation f13550a;

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-259166380 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Onboarding.<clinit>():void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-259166380 < 0)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            static {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-259166380 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Onboarding.<clinit>():void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Onboarding.<clinit>():void");
            }

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-332986494 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Onboarding.<init>():void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-332986494 < 0)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            public /* synthetic */ Onboarding() {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-332986494 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Onboarding.<init>():void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Onboarding.<init>():void");
            }

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (1207805972 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Onboarding.<init>(com.getmimo.analytics.properties.AuthenticationLocation):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition > limit: (1207805972 > 16237920)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            public Onboarding(com.getmimo.analytics.properties.AuthenticationLocation r1) {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (1207805972 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Onboarding.<init>(com.getmimo.analytics.properties.AuthenticationLocation):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Onboarding.<init>(com.getmimo.analytics.properties.AuthenticationLocation):void");
            }

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (484755246 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Onboarding.a():com.getmimo.analytics.properties.AuthenticationLocation, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition > limit: (484755246 > 16237920)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            @Override // com.getmimo.ui.authentication.AuthenticationScreenType
            public final com.getmimo.analytics.properties.AuthenticationLocation a() {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (484755246 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Onboarding.a():com.getmimo.analytics.properties.AuthenticationLocation, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Onboarding.a():com.getmimo.analytics.properties.AuthenticationLocation");
            }

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (1459690600 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Onboarding.describeContents():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition > limit: (1459690600 > 16237920)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            @Override // android.os.Parcelable
            public final int describeContents() {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (1459690600 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Onboarding.describeContents():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Onboarding.describeContents():int");
            }

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (2074456170 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Onboarding.equals(java.lang.Object):boolean, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition > limit: (2074456170 > 16237920)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            public final boolean equals(java.lang.Object r1) {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (2074456170 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Onboarding.equals(java.lang.Object):boolean, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Onboarding.equals(java.lang.Object):boolean");
            }

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (1397648438 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Onboarding.hashCode():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition > limit: (1397648438 > 16237920)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            public final int hashCode() {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (1397648438 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Onboarding.hashCode():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Onboarding.hashCode():int");
            }

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-61741775 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Onboarding.toString():java.lang.String, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-61741775 < 0)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            public final java.lang.String toString() {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-61741775 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Onboarding.toString():java.lang.String, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Onboarding.toString():java.lang.String");
            }

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-393724556 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Onboarding.writeToParcel(android.os.Parcel, int):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-393724556 < 0)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            @Override // android.os.Parcelable
            public final void writeToParcel(android.os.Parcel r1, int r2) {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-393724556 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Onboarding.writeToParcel(android.os.Parcel, int):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Onboarding.writeToParcel(android.os.Parcel, int):void");
            }
        }

        /* JADX INFO: compiled from: r8-map-id-6b1b9a7aabb67c08b10510c084e2abcbeb53083883bac13e4d61278a32657bc6 */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/getmimo/ui/authentication/AuthenticationScreenType$Login$Practice;", "Lcom/getmimo/ui/authentication/AuthenticationScreenType$Login;", "app"}, k = 1, mv = {2, 4, 0}, xi = 48)
        public static final /* data */ class Practice extends Login {
            public static final Parcelable.Creator<Practice> CREATOR = null;

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            public final AuthenticationLocation f13551a;

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (540606496 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Practice.<clinit>():void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition > limit: (540606496 > 16237920)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            static {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (540606496 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Practice.<clinit>():void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Practice.<clinit>():void");
            }

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (1430493302 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Practice.<init>(com.getmimo.analytics.properties.AuthenticationLocation):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition > limit: (1430493302 > 16237920)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            public Practice(com.getmimo.analytics.properties.AuthenticationLocation r1) {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (1430493302 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Practice.<init>(com.getmimo.analytics.properties.AuthenticationLocation):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Practice.<init>(com.getmimo.analytics.properties.AuthenticationLocation):void");
            }

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (584809051 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Practice.a():com.getmimo.analytics.properties.AuthenticationLocation, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition > limit: (584809051 > 16237920)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            @Override // com.getmimo.ui.authentication.AuthenticationScreenType
            public final com.getmimo.analytics.properties.AuthenticationLocation a() {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (584809051 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Practice.a():com.getmimo.analytics.properties.AuthenticationLocation, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Practice.a():com.getmimo.analytics.properties.AuthenticationLocation");
            }

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (1254552316 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Practice.describeContents():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition > limit: (1254552316 > 16237920)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            @Override // android.os.Parcelable
            public final int describeContents() {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (1254552316 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Practice.describeContents():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Practice.describeContents():int");
            }

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-1195378228 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Practice.equals(java.lang.Object):boolean, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-1195378228 < 0)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            public final boolean equals(java.lang.Object r1) {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-1195378228 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Practice.equals(java.lang.Object):boolean, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Practice.equals(java.lang.Object):boolean");
            }

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (1814918166 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Practice.hashCode():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition > limit: (1814918166 > 16237920)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            public final int hashCode() {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (1814918166 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Practice.hashCode():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Practice.hashCode():int");
            }

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-276260622 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Practice.toString():java.lang.String, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-276260622 < 0)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            public final java.lang.String toString() {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-276260622 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Practice.toString():java.lang.String, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Practice.toString():java.lang.String");
            }

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-144673416 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Practice.writeToParcel(android.os.Parcel, int):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-144673416 < 0)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            @Override // android.os.Parcelable
            public final void writeToParcel(android.os.Parcel r1, int r2) {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-144673416 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Practice.writeToParcel(android.os.Parcel, int):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Practice.writeToParcel(android.os.Parcel, int):void");
            }
        }

        /* JADX INFO: compiled from: r8-map-id-6b1b9a7aabb67c08b10510c084e2abcbeb53083883bac13e4d61278a32657bc6 */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/getmimo/ui/authentication/AuthenticationScreenType$Login$Profile;", "Lcom/getmimo/ui/authentication/AuthenticationScreenType$Login;", "app"}, k = 1, mv = {2, 4, 0}, xi = 48)
        public static final /* data */ class Profile extends Login {
            public static final Parcelable.Creator<Profile> CREATOR = null;

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            public final AuthenticationLocation f13552a;

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-817945005 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Profile.<clinit>():void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-817945005 < 0)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            static {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-817945005 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Profile.<clinit>():void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Profile.<clinit>():void");
            }

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-2095139358 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Profile.<init>(com.getmimo.analytics.properties.AuthenticationLocation):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-2095139358 < 0)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            public Profile(com.getmimo.analytics.properties.AuthenticationLocation r1) {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-2095139358 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Profile.<init>(com.getmimo.analytics.properties.AuthenticationLocation):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Profile.<init>(com.getmimo.analytics.properties.AuthenticationLocation):void");
            }

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (278320157 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Profile.a():com.getmimo.analytics.properties.AuthenticationLocation, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition > limit: (278320157 > 16237920)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            @Override // com.getmimo.ui.authentication.AuthenticationScreenType
            public final com.getmimo.analytics.properties.AuthenticationLocation a() {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (278320157 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Profile.a():com.getmimo.analytics.properties.AuthenticationLocation, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Profile.a():com.getmimo.analytics.properties.AuthenticationLocation");
            }

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-35629858 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Profile.describeContents():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-35629858 < 0)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            @Override // android.os.Parcelable
            public final int describeContents() {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-35629858 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Profile.describeContents():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Profile.describeContents():int");
            }

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (1826282996 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Profile.equals(java.lang.Object):boolean, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition > limit: (1826282996 > 16237920)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            public final boolean equals(java.lang.Object r1) {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (1826282996 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Profile.equals(java.lang.Object):boolean, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Profile.equals(java.lang.Object):boolean");
            }

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (44217920 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Profile.hashCode():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition > limit: (44217920 > 16237920)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            public final int hashCode() {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (44217920 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Profile.hashCode():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Profile.hashCode():int");
            }

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-1625081670 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Profile.toString():java.lang.String, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-1625081670 < 0)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            public final java.lang.String toString() {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-1625081670 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Profile.toString():java.lang.String, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Profile.toString():java.lang.String");
            }

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (215216935 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Profile.writeToParcel(android.os.Parcel, int):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition > limit: (215216935 > 16237920)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            @Override // android.os.Parcelable
            public final void writeToParcel(android.os.Parcel r1, int r2) {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (215216935 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Profile.writeToParcel(android.os.Parcel, int):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Profile.writeToParcel(android.os.Parcel, int):void");
            }
        }

        /* JADX INFO: compiled from: r8-map-id-6b1b9a7aabb67c08b10510c084e2abcbeb53083883bac13e4d61278a32657bc6 */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/getmimo/ui/authentication/AuthenticationScreenType$Login$Settings;", "Lcom/getmimo/ui/authentication/AuthenticationScreenType$Login;", "app"}, k = 1, mv = {2, 4, 0}, xi = 48)
        public static final /* data */ class Settings extends Login {
            public static final Parcelable.Creator<Settings> CREATOR = null;

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            public final AuthenticationLocation f13553a;

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-1552171853 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Settings.<clinit>():void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-1552171853 < 0)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            static {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-1552171853 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Settings.<clinit>():void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Settings.<clinit>():void");
            }

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-1681460142 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Settings.<init>(com.getmimo.analytics.properties.AuthenticationLocation):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-1681460142 < 0)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            public Settings(com.getmimo.analytics.properties.AuthenticationLocation r1) {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-1681460142 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Settings.<init>(com.getmimo.analytics.properties.AuthenticationLocation):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Settings.<init>(com.getmimo.analytics.properties.AuthenticationLocation):void");
            }

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (1734021030 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Settings.a():com.getmimo.analytics.properties.AuthenticationLocation, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition > limit: (1734021030 > 16237920)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            @Override // com.getmimo.ui.authentication.AuthenticationScreenType
            public final com.getmimo.analytics.properties.AuthenticationLocation a() {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (1734021030 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Settings.a():com.getmimo.analytics.properties.AuthenticationLocation, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Settings.a():com.getmimo.analytics.properties.AuthenticationLocation");
            }

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-1957321803 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Settings.describeContents():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-1957321803 < 0)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            @Override // android.os.Parcelable
            public final int describeContents() {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-1957321803 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Settings.describeContents():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Settings.describeContents():int");
            }

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (670903492 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Settings.equals(java.lang.Object):boolean, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition > limit: (670903492 > 16237920)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            public final boolean equals(java.lang.Object r1) {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (670903492 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Settings.equals(java.lang.Object):boolean, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Settings.equals(java.lang.Object):boolean");
            }

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (1012026214 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Settings.hashCode():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition > limit: (1012026214 > 16237920)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            public final int hashCode() {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (1012026214 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Settings.hashCode():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Settings.hashCode():int");
            }

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (369892442 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Settings.toString():java.lang.String, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition > limit: (369892442 > 16237920)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            public final java.lang.String toString() {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (369892442 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Settings.toString():java.lang.String, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Settings.toString():java.lang.String");
            }

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (920198256 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Settings.writeToParcel(android.os.Parcel, int):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition > limit: (920198256 > 16237920)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            @Override // android.os.Parcelable
            public final void writeToParcel(android.os.Parcel r1, int r2) {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (920198256 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Settings.writeToParcel(android.os.Parcel, int):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.Settings.writeToParcel(android.os.Parcel, int):void");
            }
        }

        /*  JADX ERROR: Method load error
            jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (958052878 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.<init>():void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
            	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
            	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
            	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
            	at jadx.core.ProcessClass.process(ProcessClass.java:78)
            	at jadx.core.ProcessClass.generateCode(ProcessClass.java:127)
            	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
            	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
            	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
            Caused by: java.lang.IllegalArgumentException: newPosition > limit: (958052878 > 16237920)
            	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
            	at java.base/java.nio.Buffer.position(Buffer.java:327)
            	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
            	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
            	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
            	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
            	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
            	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
            	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
            	... 7 more
            */
        private Login() {
            /*
            // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (958052878 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.<init>():void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
            */
            throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.<init>():void");
        }

        /*  JADX ERROR: Method load error
            jadx.core.utils.exceptions.DecodeException: Load method exception: ArrayIndexOutOfBoundsException: null in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.<init>(int):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
            	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
            	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
            	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
            	at jadx.core.ProcessClass.process(ProcessClass.java:78)
            	at jadx.core.ProcessClass.generateCode(ProcessClass.java:127)
            	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
            	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
            	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
            Caused by: java.lang.ArrayIndexOutOfBoundsException
            */
        public /* synthetic */ Login(int r1) {
            /*
            // Can't load method instructions: Load method exception: ArrayIndexOutOfBoundsException: null in method: com.getmimo.ui.authentication.AuthenticationScreenType.Login.<init>(int):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
            */
            throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Login.<init>(int):void");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-6b1b9a7aabb67c08b10510c084e2abcbeb53083883bac13e4d61278a32657bc6 */
    @Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b7\u0018\u00002\u00020\u0001:\u0001\u0004B\t\b\u0004¢\u0006\u0004\b\u0002\u0010\u0003\u0082\u0001\u0001\u0005Ê\u0001\f\b\u0007\u0012\b\b\b\u0012\u0004\b\u0003\u0010\u0000¨\u0006\u0006"}, d2 = {"Lcom/getmimo/ui/authentication/AuthenticationScreenType$Signup;", "Lcom/getmimo/ui/authentication/AuthenticationScreenType;", "<init>", "()V", "Prompt", "Lcom/getmimo/ui/authentication/AuthenticationScreenType$Signup$Prompt;", "app", "Landroidx/compose/runtime/internal/StabilityInferred;", "parameters"}, k = 1, mv = {2, 4, 0}, xi = 48)
    public static abstract class Signup extends AuthenticationScreenType {

        /* JADX INFO: compiled from: r8-map-id-6b1b9a7aabb67c08b10510c084e2abcbeb53083883bac13e4d61278a32657bc6 */
        @Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b7\u0018\u00002\u00020\u0001:\t\u0004\u0005\u0006\u0007\b\t\n\u000b\fB\t\b\u0004¢\u0006\u0004\b\u0002\u0010\u0003\u0082\u0001\t\r\u000e\u000f\u0010\u0011\u0012\u0013\u0014\u0015¨\u0006\u0016"}, d2 = {"Lcom/getmimo/ui/authentication/AuthenticationScreenType$Signup$Prompt;", "Lcom/getmimo/ui/authentication/AuthenticationScreenType$Signup;", "<init>", "()V", "SignupChapterEnd", "SignupPracticeTab", "SignupLeaderBoards", "SignupActivity", "SignupBeforeOpenChapter", "SignupAfterPurchase", "SignupAfterOnboardingPurchase", "SignupAtProfile", "SignupAtSettings", "Lcom/getmimo/ui/authentication/AuthenticationScreenType$Signup$Prompt$SignupActivity;", "Lcom/getmimo/ui/authentication/AuthenticationScreenType$Signup$Prompt$SignupAfterOnboardingPurchase;", "Lcom/getmimo/ui/authentication/AuthenticationScreenType$Signup$Prompt$SignupAfterPurchase;", "Lcom/getmimo/ui/authentication/AuthenticationScreenType$Signup$Prompt$SignupAtProfile;", "Lcom/getmimo/ui/authentication/AuthenticationScreenType$Signup$Prompt$SignupAtSettings;", "Lcom/getmimo/ui/authentication/AuthenticationScreenType$Signup$Prompt$SignupBeforeOpenChapter;", "Lcom/getmimo/ui/authentication/AuthenticationScreenType$Signup$Prompt$SignupChapterEnd;", "Lcom/getmimo/ui/authentication/AuthenticationScreenType$Signup$Prompt$SignupLeaderBoards;", "Lcom/getmimo/ui/authentication/AuthenticationScreenType$Signup$Prompt$SignupPracticeTab;", "app"}, k = 1, mv = {2, 4, 0}, xi = 48)
        public static abstract class Prompt extends Signup {

            /* JADX INFO: compiled from: r8-map-id-6b1b9a7aabb67c08b10510c084e2abcbeb53083883bac13e4d61278a32657bc6 */
            @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/getmimo/ui/authentication/AuthenticationScreenType$Signup$Prompt$SignupActivity;", "Lcom/getmimo/ui/authentication/AuthenticationScreenType$Signup$Prompt;", "app"}, k = 1, mv = {2, 4, 0}, xi = 48)
            public static final /* data */ class SignupActivity extends Prompt {
                public static final Parcelable.Creator<SignupActivity> CREATOR = null;

                /* JADX INFO: renamed from: a, reason: collision with root package name */
                public final int f13554a;

                /* JADX INFO: renamed from: b, reason: collision with root package name */
                public final AuthenticationLocation f13555b;

                /* JADX INFO: renamed from: c, reason: collision with root package name */
                public final boolean f13556c;

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-93682817 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupActivity.<clinit>():void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-93682817 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                static {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-93682817 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupActivity.<clinit>():void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupActivity.<clinit>():void");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-1957523938 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupActivity.<init>(int, com.getmimo.analytics.properties.AuthenticationLocation, boolean):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-1957523938 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                public SignupActivity(int r1, com.getmimo.analytics.properties.AuthenticationLocation r2, boolean r3) {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-1957523938 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupActivity.<init>(int, com.getmimo.analytics.properties.AuthenticationLocation, boolean):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupActivity.<init>(int, com.getmimo.analytics.properties.AuthenticationLocation, boolean):void");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-1332087694 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupActivity.a():com.getmimo.analytics.properties.AuthenticationLocation, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-1332087694 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                @Override // com.getmimo.ui.authentication.AuthenticationScreenType
                public final com.getmimo.analytics.properties.AuthenticationLocation a() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-1332087694 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupActivity.a():com.getmimo.analytics.properties.AuthenticationLocation, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupActivity.a():com.getmimo.analytics.properties.AuthenticationLocation");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (1030044990 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupActivity.b():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition > limit: (1030044990 > 16237920)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                @Override // com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt
                public final int b() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (1030044990 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupActivity.b():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupActivity.b():int");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-752622130 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupActivity.c():boolean, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-752622130 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                @Override // com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt
                public final boolean c() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-752622130 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupActivity.c():boolean, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupActivity.c():boolean");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (1253730248 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupActivity.describeContents():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition > limit: (1253730248 > 16237920)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                @Override // android.os.Parcelable
                public final int describeContents() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (1253730248 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupActivity.describeContents():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupActivity.describeContents():int");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-842607999 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupActivity.equals(java.lang.Object):boolean, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-842607999 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                public final boolean equals(java.lang.Object r1) {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-842607999 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupActivity.equals(java.lang.Object):boolean, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupActivity.equals(java.lang.Object):boolean");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-877853362 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupActivity.hashCode():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-877853362 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                public final int hashCode() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-877853362 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupActivity.hashCode():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupActivity.hashCode():int");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-492890440 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupActivity.toString():java.lang.String, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-492890440 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                public final java.lang.String toString() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-492890440 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupActivity.toString():java.lang.String, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupActivity.toString():java.lang.String");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-1343784080 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupActivity.writeToParcel(android.os.Parcel, int):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-1343784080 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                @Override // android.os.Parcelable
                public final void writeToParcel(android.os.Parcel r1, int r2) {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-1343784080 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupActivity.writeToParcel(android.os.Parcel, int):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupActivity.writeToParcel(android.os.Parcel, int):void");
                }
            }

            /* JADX INFO: compiled from: r8-map-id-6b1b9a7aabb67c08b10510c084e2abcbeb53083883bac13e4d61278a32657bc6 */
            @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/getmimo/ui/authentication/AuthenticationScreenType$Signup$Prompt$SignupAfterOnboardingPurchase;", "Lcom/getmimo/ui/authentication/AuthenticationScreenType$Signup$Prompt;", "app"}, k = 1, mv = {2, 4, 0}, xi = 48)
            public static final /* data */ class SignupAfterOnboardingPurchase extends Prompt {
                public static final Parcelable.Creator<SignupAfterOnboardingPurchase> CREATOR = null;

                /* JADX INFO: renamed from: a, reason: collision with root package name */
                public final int f13557a;

                /* JADX INFO: renamed from: b, reason: collision with root package name */
                public final AuthenticationLocation f13558b;

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-1181577342 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterOnboardingPurchase.<clinit>():void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-1181577342 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                static {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-1181577342 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterOnboardingPurchase.<clinit>():void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterOnboardingPurchase.<clinit>():void");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-920691362 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterOnboardingPurchase.<init>():void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-920691362 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                public /* synthetic */ SignupAfterOnboardingPurchase() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-920691362 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterOnboardingPurchase.<init>():void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterOnboardingPurchase.<init>():void");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (1909470997 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterOnboardingPurchase.<init>(int, com.getmimo.analytics.properties.AuthenticationLocation):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition > limit: (1909470997 > 16237920)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                public SignupAfterOnboardingPurchase(int r1, com.getmimo.analytics.properties.AuthenticationLocation r2) {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (1909470997 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterOnboardingPurchase.<init>(int, com.getmimo.analytics.properties.AuthenticationLocation):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterOnboardingPurchase.<init>(int, com.getmimo.analytics.properties.AuthenticationLocation):void");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-1949572933 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterOnboardingPurchase.a():com.getmimo.analytics.properties.AuthenticationLocation, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-1949572933 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                @Override // com.getmimo.ui.authentication.AuthenticationScreenType
                public final com.getmimo.analytics.properties.AuthenticationLocation a() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-1949572933 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterOnboardingPurchase.a():com.getmimo.analytics.properties.AuthenticationLocation, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterOnboardingPurchase.a():com.getmimo.analytics.properties.AuthenticationLocation");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (587776623 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterOnboardingPurchase.b():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition > limit: (587776623 > 16237920)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                @Override // com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt
                public final int b() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (587776623 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterOnboardingPurchase.b():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterOnboardingPurchase.b():int");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (477788253 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterOnboardingPurchase.describeContents():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition > limit: (477788253 > 16237920)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                @Override // android.os.Parcelable
                public final int describeContents() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (477788253 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterOnboardingPurchase.describeContents():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterOnboardingPurchase.describeContents():int");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (1695379306 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterOnboardingPurchase.equals(java.lang.Object):boolean, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition > limit: (1695379306 > 16237920)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                public final boolean equals(java.lang.Object r1) {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (1695379306 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterOnboardingPurchase.equals(java.lang.Object):boolean, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterOnboardingPurchase.equals(java.lang.Object):boolean");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (987450953 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterOnboardingPurchase.hashCode():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition > limit: (987450953 > 16237920)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                public final int hashCode() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (987450953 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterOnboardingPurchase.hashCode():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterOnboardingPurchase.hashCode():int");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-1235411802 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterOnboardingPurchase.toString():java.lang.String, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-1235411802 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                public final java.lang.String toString() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-1235411802 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterOnboardingPurchase.toString():java.lang.String, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterOnboardingPurchase.toString():java.lang.String");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-620873437 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterOnboardingPurchase.writeToParcel(android.os.Parcel, int):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-620873437 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                @Override // android.os.Parcelable
                public final void writeToParcel(android.os.Parcel r1, int r2) {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-620873437 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterOnboardingPurchase.writeToParcel(android.os.Parcel, int):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterOnboardingPurchase.writeToParcel(android.os.Parcel, int):void");
                }
            }

            /* JADX INFO: compiled from: r8-map-id-6b1b9a7aabb67c08b10510c084e2abcbeb53083883bac13e4d61278a32657bc6 */
            @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/getmimo/ui/authentication/AuthenticationScreenType$Signup$Prompt$SignupAfterPurchase;", "Lcom/getmimo/ui/authentication/AuthenticationScreenType$Signup$Prompt;", "app"}, k = 1, mv = {2, 4, 0}, xi = 48)
            public static final /* data */ class SignupAfterPurchase extends Prompt {
                public static final Parcelable.Creator<SignupAfterPurchase> CREATOR = null;

                /* JADX INFO: renamed from: a, reason: collision with root package name */
                public final int f13559a;

                /* JADX INFO: renamed from: b, reason: collision with root package name */
                public final AuthenticationLocation f13560b;

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (209614452 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterPurchase.<clinit>():void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition > limit: (209614452 > 16237920)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                static {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (209614452 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterPurchase.<clinit>():void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterPurchase.<clinit>():void");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-932148324 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterPurchase.<init>():void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-932148324 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                public /* synthetic */ SignupAfterPurchase() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-932148324 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterPurchase.<init>():void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterPurchase.<init>():void");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-1507661002 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterPurchase.<init>(int, com.getmimo.analytics.properties.AuthenticationLocation):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-1507661002 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                public SignupAfterPurchase(int r1, com.getmimo.analytics.properties.AuthenticationLocation r2) {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-1507661002 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterPurchase.<init>(int, com.getmimo.analytics.properties.AuthenticationLocation):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterPurchase.<init>(int, com.getmimo.analytics.properties.AuthenticationLocation):void");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-1648069414 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterPurchase.a():com.getmimo.analytics.properties.AuthenticationLocation, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-1648069414 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                @Override // com.getmimo.ui.authentication.AuthenticationScreenType
                public final com.getmimo.analytics.properties.AuthenticationLocation a() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-1648069414 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterPurchase.a():com.getmimo.analytics.properties.AuthenticationLocation, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterPurchase.a():com.getmimo.analytics.properties.AuthenticationLocation");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (478977592 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterPurchase.b():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition > limit: (478977592 > 16237920)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                @Override // com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt
                public final int b() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (478977592 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterPurchase.b():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterPurchase.b():int");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-9976942 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterPurchase.describeContents():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-9976942 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                @Override // android.os.Parcelable
                public final int describeContents() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-9976942 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterPurchase.describeContents():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterPurchase.describeContents():int");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (1560886556 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterPurchase.equals(java.lang.Object):boolean, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition > limit: (1560886556 > 16237920)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                public final boolean equals(java.lang.Object r1) {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (1560886556 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterPurchase.equals(java.lang.Object):boolean, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterPurchase.equals(java.lang.Object):boolean");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (211067724 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterPurchase.hashCode():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition > limit: (211067724 > 16237920)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                public final int hashCode() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (211067724 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterPurchase.hashCode():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterPurchase.hashCode():int");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-292562370 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterPurchase.toString():java.lang.String, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-292562370 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                public final java.lang.String toString() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-292562370 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterPurchase.toString():java.lang.String, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterPurchase.toString():java.lang.String");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-915578318 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterPurchase.writeToParcel(android.os.Parcel, int):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-915578318 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                @Override // android.os.Parcelable
                public final void writeToParcel(android.os.Parcel r1, int r2) {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-915578318 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterPurchase.writeToParcel(android.os.Parcel, int):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAfterPurchase.writeToParcel(android.os.Parcel, int):void");
                }
            }

            /* JADX INFO: compiled from: r8-map-id-6b1b9a7aabb67c08b10510c084e2abcbeb53083883bac13e4d61278a32657bc6 */
            @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/getmimo/ui/authentication/AuthenticationScreenType$Signup$Prompt$SignupAtProfile;", "Lcom/getmimo/ui/authentication/AuthenticationScreenType$Signup$Prompt;", "app"}, k = 1, mv = {2, 4, 0}, xi = 48)
            public static final /* data */ class SignupAtProfile extends Prompt {
                public static final Parcelable.Creator<SignupAtProfile> CREATOR = null;

                /* JADX INFO: renamed from: a, reason: collision with root package name */
                public final int f13561a;

                /* JADX INFO: renamed from: b, reason: collision with root package name */
                public final AuthenticationLocation f13562b;

                /* JADX INFO: renamed from: c, reason: collision with root package name */
                public final boolean f13563c;

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (1501588573 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtProfile.<clinit>():void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition > limit: (1501588573 > 16237920)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                static {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (1501588573 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtProfile.<clinit>():void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtProfile.<clinit>():void");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-1521760854 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtProfile.<init>(int, com.getmimo.analytics.properties.AuthenticationLocation, boolean):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-1521760854 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                public SignupAtProfile(int r1, com.getmimo.analytics.properties.AuthenticationLocation r2, boolean r3) {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-1521760854 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtProfile.<init>(int, com.getmimo.analytics.properties.AuthenticationLocation, boolean):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtProfile.<init>(int, com.getmimo.analytics.properties.AuthenticationLocation, boolean):void");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (990019135 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtProfile.a():com.getmimo.analytics.properties.AuthenticationLocation, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition > limit: (990019135 > 16237920)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                @Override // com.getmimo.ui.authentication.AuthenticationScreenType
                public final com.getmimo.analytics.properties.AuthenticationLocation a() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (990019135 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtProfile.a():com.getmimo.analytics.properties.AuthenticationLocation, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtProfile.a():com.getmimo.analytics.properties.AuthenticationLocation");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-69511843 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtProfile.b():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-69511843 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                @Override // com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt
                public final int b() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-69511843 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtProfile.b():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtProfile.b():int");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (1082287394 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtProfile.c():boolean, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition > limit: (1082287394 > 16237920)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                @Override // com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt
                public final boolean c() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (1082287394 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtProfile.c():boolean, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtProfile.c():boolean");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-1552399288 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtProfile.describeContents():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-1552399288 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                @Override // android.os.Parcelable
                public final int describeContents() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-1552399288 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtProfile.describeContents():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtProfile.describeContents():int");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (1669901410 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtProfile.equals(java.lang.Object):boolean, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition > limit: (1669901410 > 16237920)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                public final boolean equals(java.lang.Object r1) {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (1669901410 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtProfile.equals(java.lang.Object):boolean, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtProfile.equals(java.lang.Object):boolean");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (1363621686 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtProfile.hashCode():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition > limit: (1363621686 > 16237920)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                public final int hashCode() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (1363621686 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtProfile.hashCode():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtProfile.hashCode():int");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-721311271 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtProfile.toString():java.lang.String, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-721311271 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                public final java.lang.String toString() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-721311271 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtProfile.toString():java.lang.String, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtProfile.toString():java.lang.String");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (1262704866 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtProfile.writeToParcel(android.os.Parcel, int):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition > limit: (1262704866 > 16237920)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                @Override // android.os.Parcelable
                public final void writeToParcel(android.os.Parcel r1, int r2) {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (1262704866 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtProfile.writeToParcel(android.os.Parcel, int):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtProfile.writeToParcel(android.os.Parcel, int):void");
                }
            }

            /* JADX INFO: compiled from: r8-map-id-6b1b9a7aabb67c08b10510c084e2abcbeb53083883bac13e4d61278a32657bc6 */
            @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/getmimo/ui/authentication/AuthenticationScreenType$Signup$Prompt$SignupAtSettings;", "Lcom/getmimo/ui/authentication/AuthenticationScreenType$Signup$Prompt;", "app"}, k = 1, mv = {2, 4, 0}, xi = 48)
            public static final /* data */ class SignupAtSettings extends Prompt {
                public static final Parcelable.Creator<SignupAtSettings> CREATOR = null;

                /* JADX INFO: renamed from: a, reason: collision with root package name */
                public final int f13564a;

                /* JADX INFO: renamed from: b, reason: collision with root package name */
                public final AuthenticationLocation f13565b;

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (1690983806 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtSettings.<clinit>():void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition > limit: (1690983806 > 16237920)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                static {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (1690983806 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtSettings.<clinit>():void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtSettings.<clinit>():void");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-1754485788 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtSettings.<init>(int, com.getmimo.analytics.properties.AuthenticationLocation):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-1754485788 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                public SignupAtSettings(int r1, com.getmimo.analytics.properties.AuthenticationLocation r2) {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-1754485788 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtSettings.<init>(int, com.getmimo.analytics.properties.AuthenticationLocation):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtSettings.<init>(int, com.getmimo.analytics.properties.AuthenticationLocation):void");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-1941872023 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtSettings.a():com.getmimo.analytics.properties.AuthenticationLocation, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-1941872023 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                @Override // com.getmimo.ui.authentication.AuthenticationScreenType
                public final com.getmimo.analytics.properties.AuthenticationLocation a() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-1941872023 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtSettings.a():com.getmimo.analytics.properties.AuthenticationLocation, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtSettings.a():com.getmimo.analytics.properties.AuthenticationLocation");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (1024113898 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtSettings.b():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition > limit: (1024113898 > 16237920)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                @Override // com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt
                public final int b() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (1024113898 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtSettings.b():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtSettings.b():int");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (758031490 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtSettings.describeContents():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition > limit: (758031490 > 16237920)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                @Override // android.os.Parcelable
                public final int describeContents() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (758031490 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtSettings.describeContents():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtSettings.describeContents():int");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-2071834628 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtSettings.equals(java.lang.Object):boolean, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-2071834628 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                public final boolean equals(java.lang.Object r1) {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-2071834628 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtSettings.equals(java.lang.Object):boolean, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtSettings.equals(java.lang.Object):boolean");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-1868798462 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtSettings.hashCode():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-1868798462 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                public final int hashCode() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-1868798462 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtSettings.hashCode():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtSettings.hashCode():int");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-1644998515 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtSettings.toString():java.lang.String, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-1644998515 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                public final java.lang.String toString() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-1644998515 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtSettings.toString():java.lang.String, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtSettings.toString():java.lang.String");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-1800629914 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtSettings.writeToParcel(android.os.Parcel, int):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-1800629914 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                @Override // android.os.Parcelable
                public final void writeToParcel(android.os.Parcel r1, int r2) {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-1800629914 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtSettings.writeToParcel(android.os.Parcel, int):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupAtSettings.writeToParcel(android.os.Parcel, int):void");
                }
            }

            /* JADX INFO: compiled from: r8-map-id-6b1b9a7aabb67c08b10510c084e2abcbeb53083883bac13e4d61278a32657bc6 */
            @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/getmimo/ui/authentication/AuthenticationScreenType$Signup$Prompt$SignupBeforeOpenChapter;", "Lcom/getmimo/ui/authentication/AuthenticationScreenType$Signup$Prompt;", "app"}, k = 1, mv = {2, 4, 0}, xi = 48)
            public static final /* data */ class SignupBeforeOpenChapter extends Prompt {
                public static final Parcelable.Creator<SignupBeforeOpenChapter> CREATOR = null;

                /* JADX INFO: renamed from: a, reason: collision with root package name */
                public final long f13566a;

                /* JADX INFO: renamed from: b, reason: collision with root package name */
                public final int f13567b;

                /* JADX INFO: renamed from: c, reason: collision with root package name */
                public final AuthenticationLocation f13568c;

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-1008130834 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupBeforeOpenChapter.<clinit>():void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-1008130834 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                static {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-1008130834 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupBeforeOpenChapter.<clinit>():void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupBeforeOpenChapter.<clinit>():void");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-1255961403 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupBeforeOpenChapter.<init>(long, int, com.getmimo.analytics.properties.AuthenticationLocation):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-1255961403 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                public SignupBeforeOpenChapter(long r1, int r3, com.getmimo.analytics.properties.AuthenticationLocation r4) {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-1255961403 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupBeforeOpenChapter.<init>(long, int, com.getmimo.analytics.properties.AuthenticationLocation):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupBeforeOpenChapter.<init>(long, int, com.getmimo.analytics.properties.AuthenticationLocation):void");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-851957400 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupBeforeOpenChapter.a():com.getmimo.analytics.properties.AuthenticationLocation, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-851957400 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                @Override // com.getmimo.ui.authentication.AuthenticationScreenType
                public final com.getmimo.analytics.properties.AuthenticationLocation a() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-851957400 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupBeforeOpenChapter.a():com.getmimo.analytics.properties.AuthenticationLocation, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupBeforeOpenChapter.a():com.getmimo.analytics.properties.AuthenticationLocation");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (1605232066 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupBeforeOpenChapter.b():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition > limit: (1605232066 > 16237920)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                @Override // com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt
                public final int b() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (1605232066 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupBeforeOpenChapter.b():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupBeforeOpenChapter.b():int");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-845796147 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupBeforeOpenChapter.describeContents():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-845796147 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                @Override // android.os.Parcelable
                public final int describeContents() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-845796147 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupBeforeOpenChapter.describeContents():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupBeforeOpenChapter.describeContents():int");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-374872355 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupBeforeOpenChapter.equals(java.lang.Object):boolean, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-374872355 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                public final boolean equals(java.lang.Object r1) {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-374872355 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupBeforeOpenChapter.equals(java.lang.Object):boolean, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupBeforeOpenChapter.equals(java.lang.Object):boolean");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-1838503512 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupBeforeOpenChapter.hashCode():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-1838503512 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                public final int hashCode() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-1838503512 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupBeforeOpenChapter.hashCode():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupBeforeOpenChapter.hashCode():int");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-608864294 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupBeforeOpenChapter.toString():java.lang.String, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-608864294 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                public final java.lang.String toString() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-608864294 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupBeforeOpenChapter.toString():java.lang.String, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupBeforeOpenChapter.toString():java.lang.String");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (1158586706 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupBeforeOpenChapter.writeToParcel(android.os.Parcel, int):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition > limit: (1158586706 > 16237920)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                @Override // android.os.Parcelable
                public final void writeToParcel(android.os.Parcel r1, int r2) {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (1158586706 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupBeforeOpenChapter.writeToParcel(android.os.Parcel, int):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupBeforeOpenChapter.writeToParcel(android.os.Parcel, int):void");
                }
            }

            /* JADX INFO: compiled from: r8-map-id-6b1b9a7aabb67c08b10510c084e2abcbeb53083883bac13e4d61278a32657bc6 */
            @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/getmimo/ui/authentication/AuthenticationScreenType$Signup$Prompt$SignupChapterEnd;", "Lcom/getmimo/ui/authentication/AuthenticationScreenType$Signup$Prompt;", "app"}, k = 1, mv = {2, 4, 0}, xi = 48)
            public static final /* data */ class SignupChapterEnd extends Prompt {
                public static final Parcelable.Creator<SignupChapterEnd> CREATOR = null;

                /* JADX INFO: renamed from: a, reason: collision with root package name */
                public final int f13569a;

                /* JADX INFO: renamed from: b, reason: collision with root package name */
                public final AuthenticationLocation f13570b;

                /* JADX INFO: renamed from: c, reason: collision with root package name */
                public final boolean f13571c;

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-571911543 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupChapterEnd.<clinit>():void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-571911543 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                static {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-571911543 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupChapterEnd.<clinit>():void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupChapterEnd.<clinit>():void");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-1257906618 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupChapterEnd.<init>(int, com.getmimo.analytics.properties.AuthenticationLocation, boolean):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-1257906618 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                public SignupChapterEnd(int r1, com.getmimo.analytics.properties.AuthenticationLocation r2, boolean r3) {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-1257906618 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupChapterEnd.<init>(int, com.getmimo.analytics.properties.AuthenticationLocation, boolean):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupChapterEnd.<init>(int, com.getmimo.analytics.properties.AuthenticationLocation, boolean):void");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-1627620398 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupChapterEnd.a():com.getmimo.analytics.properties.AuthenticationLocation, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-1627620398 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                @Override // com.getmimo.ui.authentication.AuthenticationScreenType
                public final com.getmimo.analytics.properties.AuthenticationLocation a() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-1627620398 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupChapterEnd.a():com.getmimo.analytics.properties.AuthenticationLocation, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupChapterEnd.a():com.getmimo.analytics.properties.AuthenticationLocation");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (1342721658 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupChapterEnd.b():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition > limit: (1342721658 > 16237920)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                @Override // com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt
                public final int b() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (1342721658 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupChapterEnd.b():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupChapterEnd.b():int");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (667330189 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupChapterEnd.c():boolean, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition > limit: (667330189 > 16237920)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                @Override // com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt
                public final boolean c() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (667330189 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupChapterEnd.c():boolean, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupChapterEnd.c():boolean");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (61507350 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupChapterEnd.describeContents():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition > limit: (61507350 > 16237920)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                @Override // android.os.Parcelable
                public final int describeContents() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (61507350 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupChapterEnd.describeContents():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupChapterEnd.describeContents():int");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-731994616 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupChapterEnd.equals(java.lang.Object):boolean, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-731994616 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                public final boolean equals(java.lang.Object r1) {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-731994616 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupChapterEnd.equals(java.lang.Object):boolean, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupChapterEnd.equals(java.lang.Object):boolean");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (2039060862 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupChapterEnd.hashCode():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition > limit: (2039060862 > 16237920)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                public final int hashCode() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (2039060862 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupChapterEnd.hashCode():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupChapterEnd.hashCode():int");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (382460352 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupChapterEnd.toString():java.lang.String, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition > limit: (382460352 > 16237920)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                public final java.lang.String toString() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (382460352 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupChapterEnd.toString():java.lang.String, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupChapterEnd.toString():java.lang.String");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-1727940000 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupChapterEnd.writeToParcel(android.os.Parcel, int):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-1727940000 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                @Override // android.os.Parcelable
                public final void writeToParcel(android.os.Parcel r1, int r2) {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-1727940000 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupChapterEnd.writeToParcel(android.os.Parcel, int):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupChapterEnd.writeToParcel(android.os.Parcel, int):void");
                }
            }

            /* JADX INFO: compiled from: r8-map-id-6b1b9a7aabb67c08b10510c084e2abcbeb53083883bac13e4d61278a32657bc6 */
            @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/getmimo/ui/authentication/AuthenticationScreenType$Signup$Prompt$SignupLeaderBoards;", "Lcom/getmimo/ui/authentication/AuthenticationScreenType$Signup$Prompt;", "app"}, k = 1, mv = {2, 4, 0}, xi = 48)
            public static final /* data */ class SignupLeaderBoards extends Prompt {
                public static final Parcelable.Creator<SignupLeaderBoards> CREATOR = null;

                /* JADX INFO: renamed from: a, reason: collision with root package name */
                public final int f13572a;

                /* JADX INFO: renamed from: b, reason: collision with root package name */
                public final AuthenticationLocation f13573b;

                /* JADX INFO: renamed from: c, reason: collision with root package name */
                public final boolean f13574c;

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (822771554 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupLeaderBoards.<clinit>():void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition > limit: (822771554 > 16237920)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                static {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (822771554 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupLeaderBoards.<clinit>():void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupLeaderBoards.<clinit>():void");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (444192338 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupLeaderBoards.<init>(int, com.getmimo.analytics.properties.AuthenticationLocation, boolean):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition > limit: (444192338 > 16237920)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                public SignupLeaderBoards(int r1, com.getmimo.analytics.properties.AuthenticationLocation r2, boolean r3) {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (444192338 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupLeaderBoards.<init>(int, com.getmimo.analytics.properties.AuthenticationLocation, boolean):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupLeaderBoards.<init>(int, com.getmimo.analytics.properties.AuthenticationLocation, boolean):void");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-1330714253 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupLeaderBoards.a():com.getmimo.analytics.properties.AuthenticationLocation, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-1330714253 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                @Override // com.getmimo.ui.authentication.AuthenticationScreenType
                public final com.getmimo.analytics.properties.AuthenticationLocation a() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-1330714253 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupLeaderBoards.a():com.getmimo.analytics.properties.AuthenticationLocation, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupLeaderBoards.a():com.getmimo.analytics.properties.AuthenticationLocation");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-791380857 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupLeaderBoards.b():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-791380857 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                @Override // com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt
                public final int b() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-791380857 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupLeaderBoards.b():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupLeaderBoards.b():int");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-435863505 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupLeaderBoards.c():boolean, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-435863505 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                @Override // com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt
                public final boolean c() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-435863505 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupLeaderBoards.c():boolean, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupLeaderBoards.c():boolean");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-1392788948 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupLeaderBoards.describeContents():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-1392788948 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                @Override // android.os.Parcelable
                public final int describeContents() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-1392788948 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupLeaderBoards.describeContents():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupLeaderBoards.describeContents():int");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-219931928 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupLeaderBoards.equals(java.lang.Object):boolean, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-219931928 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                public final boolean equals(java.lang.Object r1) {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-219931928 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupLeaderBoards.equals(java.lang.Object):boolean, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupLeaderBoards.equals(java.lang.Object):boolean");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-855463324 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupLeaderBoards.hashCode():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-855463324 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                public final int hashCode() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-855463324 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupLeaderBoards.hashCode():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupLeaderBoards.hashCode():int");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (736714661 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupLeaderBoards.toString():java.lang.String, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition > limit: (736714661 > 16237920)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                public final java.lang.String toString() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (736714661 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupLeaderBoards.toString():java.lang.String, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupLeaderBoards.toString():java.lang.String");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (1343732780 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupLeaderBoards.writeToParcel(android.os.Parcel, int):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition > limit: (1343732780 > 16237920)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                @Override // android.os.Parcelable
                public final void writeToParcel(android.os.Parcel r1, int r2) {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (1343732780 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupLeaderBoards.writeToParcel(android.os.Parcel, int):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupLeaderBoards.writeToParcel(android.os.Parcel, int):void");
                }
            }

            /* JADX INFO: compiled from: r8-map-id-6b1b9a7aabb67c08b10510c084e2abcbeb53083883bac13e4d61278a32657bc6 */
            @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/getmimo/ui/authentication/AuthenticationScreenType$Signup$Prompt$SignupPracticeTab;", "Lcom/getmimo/ui/authentication/AuthenticationScreenType$Signup$Prompt;", "app"}, k = 1, mv = {2, 4, 0}, xi = 48)
            public static final /* data */ class SignupPracticeTab extends Prompt {
                public static final Parcelable.Creator<SignupPracticeTab> CREATOR = null;

                /* JADX INFO: renamed from: a, reason: collision with root package name */
                public final int f13575a;

                /* JADX INFO: renamed from: b, reason: collision with root package name */
                public final AuthenticationLocation f13576b;

                /* JADX INFO: renamed from: c, reason: collision with root package name */
                public final boolean f13577c;

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (1924936998 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupPracticeTab.<clinit>():void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition > limit: (1924936998 > 16237920)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                static {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (1924936998 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupPracticeTab.<clinit>():void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupPracticeTab.<clinit>():void");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-658123794 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupPracticeTab.<init>(int, com.getmimo.analytics.properties.AuthenticationLocation, boolean):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-658123794 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                public SignupPracticeTab(int r1, com.getmimo.analytics.properties.AuthenticationLocation r2, boolean r3) {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-658123794 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupPracticeTab.<init>(int, com.getmimo.analytics.properties.AuthenticationLocation, boolean):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupPracticeTab.<init>(int, com.getmimo.analytics.properties.AuthenticationLocation, boolean):void");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-1985432158 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupPracticeTab.a():com.getmimo.analytics.properties.AuthenticationLocation, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-1985432158 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                @Override // com.getmimo.ui.authentication.AuthenticationScreenType
                public final com.getmimo.analytics.properties.AuthenticationLocation a() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-1985432158 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupPracticeTab.a():com.getmimo.analytics.properties.AuthenticationLocation, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupPracticeTab.a():com.getmimo.analytics.properties.AuthenticationLocation");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-1967956257 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupPracticeTab.b():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-1967956257 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                @Override // com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt
                public final int b() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-1967956257 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupPracticeTab.b():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupPracticeTab.b():int");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-2102123038 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupPracticeTab.c():boolean, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-2102123038 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                @Override // com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt
                public final boolean c() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-2102123038 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupPracticeTab.c():boolean, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupPracticeTab.c():boolean");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-1544125214 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupPracticeTab.describeContents():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-1544125214 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                @Override // android.os.Parcelable
                public final int describeContents() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-1544125214 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupPracticeTab.describeContents():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupPracticeTab.describeContents():int");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (509301385 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupPracticeTab.equals(java.lang.Object):boolean, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition > limit: (509301385 > 16237920)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                public final boolean equals(java.lang.Object r1) {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (509301385 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupPracticeTab.equals(java.lang.Object):boolean, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupPracticeTab.equals(java.lang.Object):boolean");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-592128082 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupPracticeTab.hashCode():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-592128082 < 0)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                public final int hashCode() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-592128082 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupPracticeTab.hashCode():int, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupPracticeTab.hashCode():int");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (1133265341 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupPracticeTab.toString():java.lang.String, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition > limit: (1133265341 > 16237920)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                public final java.lang.String toString() {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (1133265341 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupPracticeTab.toString():java.lang.String, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupPracticeTab.toString():java.lang.String");
                }

                /*  JADX ERROR: Method load error
                    jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (737995088 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupPracticeTab.writeToParcel(android.os.Parcel, int):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                    	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                    Caused by: java.lang.IllegalArgumentException: newPosition > limit: (737995088 > 16237920)
                    	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                    	at java.base/java.nio.Buffer.position(Buffer.java:327)
                    	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                    	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                    	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                    	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                    	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                    	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                    	... 2 more
                    */
                @Override // android.os.Parcelable
                public final void writeToParcel(android.os.Parcel r1, int r2) {
                    /*
                    // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (737995088 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupPracticeTab.writeToParcel(android.os.Parcel, int):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.SignupPracticeTab.writeToParcel(android.os.Parcel, int):void");
                }
            }

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (566679186 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.<init>():void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition > limit: (566679186 > 16237920)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            private Prompt() {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (566679186 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.<init>():void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.<init>():void");
            }

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (705157788 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.<init>(int):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition > limit: (705157788 > 16237920)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            public /* synthetic */ Prompt(int r1) {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (705157788 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.<init>(int):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.<init>(int):void");
            }

            public abstract int b();

            /*  JADX ERROR: Method load error
                jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-294344558 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.c():boolean, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
                	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
                Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-294344558 < 0)
                	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
                	at java.base/java.nio.Buffer.position(Buffer.java:327)
                	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
                	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
                	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
                	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
                	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
                	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
                	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
                	... 2 more
                */
            public boolean c() {
                /*
                // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-294344558 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.c():boolean, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
                */
                throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.Prompt.c():boolean");
            }
        }

        /*  JADX ERROR: Method load error
            jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (346027674 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.<init>():void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
            	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
            	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
            	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
            	at jadx.core.ProcessClass.process(ProcessClass.java:78)
            	at jadx.core.ProcessClass.generateCode(ProcessClass.java:127)
            	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
            	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
            	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
            Caused by: java.lang.IllegalArgumentException: newPosition > limit: (346027674 > 16237920)
            	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
            	at java.base/java.nio.Buffer.position(Buffer.java:327)
            	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
            	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
            	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
            	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
            	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
            	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
            	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
            	... 7 more
            */
        private Signup() {
            /*
            // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (346027674 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.<init>():void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
            */
            throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.<init>():void");
        }

        /*  JADX ERROR: Method load error
            jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (1647630674 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.<init>(int):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
            	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
            	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
            	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:468)
            	at jadx.core.ProcessClass.process(ProcessClass.java:78)
            	at jadx.core.ProcessClass.generateCode(ProcessClass.java:127)
            	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
            	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
            	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
            Caused by: java.lang.IllegalArgumentException: newPosition > limit: (1647630674 > 16237920)
            	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
            	at java.base/java.nio.Buffer.position(Buffer.java:327)
            	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
            	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
            	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
            	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
            	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
            	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
            	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
            	... 7 more
            */
        public /* synthetic */ Signup(int r1) {
            /*
            // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (1647630674 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.<init>(int):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
            */
            throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.Signup.<init>(int):void");
        }
    }

    /*  JADX ERROR: Method load error
        jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (1279365725 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.<init>():void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:78)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:127)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        Caused by: java.lang.IllegalArgumentException: newPosition > limit: (1279365725 > 16237920)
        	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
        	at java.base/java.nio.Buffer.position(Buffer.java:327)
        	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
        	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
        	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
        	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
        	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
        	... 6 more
        */
    private AuthenticationScreenType() {
        /*
        // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition > limit: (1279365725 > 16237920) in method: com.getmimo.ui.authentication.AuthenticationScreenType.<init>():void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.<init>():void");
    }

    /*  JADX ERROR: Method load error
        jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-2009931478 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.<init>(int):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:78)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:127)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-2009931478 < 0)
        	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
        	at java.base/java.nio.Buffer.position(Buffer.java:327)
        	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
        	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
        	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
        	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
        	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
        	... 6 more
        */
    public /* synthetic */ AuthenticationScreenType(int r1) {
        /*
        // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-2009931478 < 0) in method: com.getmimo.ui.authentication.AuthenticationScreenType.<init>(int):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.authentication.AuthenticationScreenType.<init>(int):void");
    }

    public abstract AuthenticationLocation a();
}
