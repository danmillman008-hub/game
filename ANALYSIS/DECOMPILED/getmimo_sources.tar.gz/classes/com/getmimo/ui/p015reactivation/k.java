package com.getmimo.ui.p015reactivation;

import aj.p;
import com.getmimo.interactors.path.e;
import kf.d;
import kotlin.Metadata;
import mg.a;
import ud0.c;
import xf.f;
import ye.g;

/* JADX INFO: compiled from: r8-map-id-6b1b9a7aabb67c08b10510c084e2abcbeb53083883bac13e4d61278a32657bc6 */
/* JADX INFO: loaded from: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex */
@Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u00012$\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00040\u0002j\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u0004`\u0005¨\u0006\u0006"}, d2 = {"Lcom/getmimo/ui/reactivation/k;", "Laj/p;", "Lud0/c;", "Lwo/s;", "Lz60/q;", "Lorg/orbitmvi/orbit/ContainerHost;", "app"}, k = 1, mv = {2, 4, 0}, xi = 48)
public final class k extends p implements c {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final a f17935b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final d f17936c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final ze.a f17937d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final np.d f17938e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final com.getmimo.interactors.path.a f17939f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final e f17940g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final g f17941h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final com.getmimo.data.source.local.completion.a f17942i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final com.getmimo.data.settings.a f17943j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final np.a f17944k;
    public final com.getmimo.data.source.remote.iap.purchase.a l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final f f17945m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final com.getmimo.analytics.a f17946n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final xd0.e f17947o;

    /*  JADX ERROR: Method load error
        jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition > limit: (202499907 > 16237920) in method: com.getmimo.ui.reactivation.k.<init>(mg.a, kf.d, ze.a, np.d, com.getmimo.interactors.path.a, com.getmimo.interactors.path.e, ye.g, com.getmimo.data.source.local.completion.a, com.getmimo.data.settings.a, np.a, com.getmimo.data.source.remote.iap.purchase.a, xf.f, com.getmimo.analytics.a):void, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:78)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:119)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        Caused by: java.lang.IllegalArgumentException: newPosition > limit: (202499907 > 16237920)
        	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
        	at java.base/java.nio.Buffer.position(Buffer.java:327)
        	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
        	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
        	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
        	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
        	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
        	... 6 more
        */
    public k(mg.a r1, kf.d r2, ze.a r3, np.d r4, com.getmimo.interactors.path.a r5, com.getmimo.interactors.path.e r6, ye.g r7, com.getmimo.data.source.local.completion.a r8, com.getmimo.data.settings.a r9, np.a r10, com.getmimo.data.source.remote.iap.purchase.a r11, xf.f r12, com.getmimo.analytics.a r13) {
        /*
            Method dump skipped, instruction units count: 217
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.p015reactivation.k.<init>(mg.a, kf.d, ze.a, np.d, com.getmimo.interactors.path.a, com.getmimo.interactors.path.e, ye.g, com.getmimo.data.source.local.completion.a, com.getmimo.data.settings.a, np.a, com.getmimo.data.source.remote.iap.purchase.a, xf.f, com.getmimo.analytics.a):void");
    }

    /*  JADX ERROR: Method load error
        jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-1692666686 < 0) in method: com.getmimo.ui.reactivation.k.E(o70.m):ra0.b1, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:78)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:119)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-1692666686 < 0)
        	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
        	at java.base/java.nio.Buffer.position(Buffer.java:327)
        	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
        	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
        	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
        	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
        	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
        	... 6 more
        */
    public final /* bridge */ ra0.b1 E(o70.m r1) {
        /*
        // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-1692666686 < 0) in method: com.getmimo.ui.reactivation.k.E(o70.m):ra0.b1, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.p015reactivation.k.E(o70.m):ra0.b1");
    }

    /*  JADX ERROR: Method load error
        jadx.core.utils.exceptions.DecodeException: Load method exception: IllegalArgumentException: newPosition < 0: (-1538835842 < 0) in method: com.getmimo.ui.reactivation.k.getContainer():ud0.b, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:186)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:78)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:119)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        Caused by: java.lang.IllegalArgumentException: newPosition < 0: (-1538835842 < 0)
        	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
        	at java.base/java.nio.Buffer.position(Buffer.java:327)
        	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
        	at jadx.plugins.input.dex.sections.SectionReader.skip(SectionReader.java:92)
        	at jadx.plugins.input.dex.insns.DexInsnFormat$30.skip(DexInsnFormat.java:358)
        	at jadx.plugins.input.dex.sections.DexCodeReader.skip(DexCodeReader.java:105)
        	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:89)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
        	... 6 more
        */
    public final ud0.b getContainer() {
        /*
        // Can't load method instructions: Load method exception: IllegalArgumentException: newPosition < 0: (-1538835842 < 0) in method: com.getmimo.ui.reactivation.k.getContainer():ud0.b, file: /home/runner/work/game/game/ANALYSIS/_INPUT/classes.dex
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getmimo.ui.p015reactivation.k.getContainer():ud0.b");
    }
}
