import { db } from "@/db";
import {
  blueprintPhases,
  compiledMicroLessons,
  agentExecutionLogs,
} from "@/db/schema";
import { SEED_EXECUTION_PHASES } from "@/lib/phases-playbook-data";
import {
  INITIAL_COMPILED_LESSONS_SEED,
  compileTextbookExcerptToMimoQuest,
} from "@/lib/konkur-compiler";
import { asc, desc } from "drizzle-orm";

let isSeeding = false;

export async function ensureMasterBlueprintSeeded() {
  if (isSeeding) return;
  isSeeding = true;

  try {
    const existingPhases = await db
      .select({ id: blueprintPhases.id })
      .from(blueprintPhases)
      .limit(1);

    if (existingPhases.length === 0) {
      for (const phase of SEED_EXECUTION_PHASES) {
        await db.insert(blueprintPhases).values({
          phaseNumber: phase.phaseNumber,
          code: phase.code,
          title: phase.title,
          subtitle: phase.subtitle,
          weightPct: phase.weightPct,
          status: phase.status,
          category: phase.category,
          estimatedTurns: phase.estimatedTurns,
          sourceBranchRefs: phase.sourceBranchRefs,
          prerequisites: phase.prerequisites,
          objective: phase.objective,
          architecturalDeepDive: phase.architecturalDeepDive,
          deliverables: phase.deliverables,
          targetFiles: phase.targetFiles,
          antiDriftRules: phase.antiDriftRules,
          verificationCommands: phase.verificationCommands,
          agentPrompt: phase.agentPrompt,
          notes: "",
        });
      }
    }

    const existingLessons = await db
      .select({ id: compiledMicroLessons.id })
      .from(compiledMicroLessons)
      .limit(1);

    if (existingLessons.length === 0) {
      for (const item of INITIAL_COMPILED_LESSONS_SEED) {
        const compiled = compileTextbookExcerptToMimoQuest(item);
        await db.insert(compiledMicroLessons).values({
          chapterCode: item.chapterCode,
          curriculumId: item.curriculumId,
          subject: item.subject,
          grade: item.grade,
          topicTitle: item.topicTitle,
          sourceRef: item.sourceRef,
          rawOcrExcerpt: item.rawOcrExcerpt,
          sanitizedText: compiled.sanitizedText,
          ocrFixesApplied: compiled.ocrFixesApplied,
          unconditionalTruthAxiom: compiled.unconditionalTruthAxiom,
          motivatedDiscoveryHook: compiled.motivatedDiscoveryHook,
          designerTrap: compiled.designerTrap,
          targetQuantifier: compiled.targetQuantifier,
          dslBlocks: compiled.dslBlocks,
          guardrailScore: compiled.guardrailScore,
          guardrailChecks: compiled.guardrailChecks,
          reviewStatus: "approved",
          publishSetVersion: 753,
        });
      }
    }

    const existingLogs = await db
      .select({ id: agentExecutionLogs.id })
      .from(agentExecutionLogs)
      .limit(1);

    if (existingLogs.length === 0) {
      await db.insert(agentExecutionLogs).values([
        {
          phaseCode: "PHASE_00",
          actionType: "FORENSIC_AUDIT",
          targetStack: "Monorepo (aebb90b7 + ecb8af07)",
          summary:
            "کالبدشکافی کامل شاخه‌های aebb90b7-game و ecb8af07-game و ۵ آرشیو زیپ انجام شد؛ فایل‌های نامرتبط داروسازی (ttac-4.3.6.apk و pharmacy-inventory.html) قرنطینه شدند.",
          verificationPassed: true,
        },
        {
          phaseCode: "PHASE_01",
          actionType: "RE_CLOSURE",
          targetStack: "Mimo 9.35 Core Engine",
          summary:
            "الگوریتم نرمال‌ساز qm.i.a به همراه لایه یکسان‌ساز یونیکد فارسی (Q-44) و قوانین تکمیل محلی ADD-03 / ADD-04 تایید شدند (۵۴/۵۴ بردار تست سبز).",
          verificationPassed: true,
        },
        {
          phaseCode: "PHASE_02",
          actionType: "SCHEMA_SYNC",
          targetStack: "Next.js + Drizzle PostgreSQL + Room v2",
          summary:
            "معماری ۳ لایه ایزومورفیک (Core DSL/Grader + v12.5-fa Native UI + PostgreSQL/Room Sync) تثبیت شد.",
          verificationPassed: true,
        },
      ]);
    }
  } finally {
    isSeeding = false;
  }
}

export async function getMasterBlueprintState() {
  await ensureMasterBlueprintSeeded();

  const [phases, lessons, logs] = await Promise.all([
    db.select().from(blueprintPhases).orderBy(asc(blueprintPhases.phaseNumber)),
    db.select().from(compiledMicroLessons).orderBy(desc(compiledMicroLessons.id)),
    db.select().from(agentExecutionLogs).orderBy(desc(agentExecutionLogs.id)).limit(20),
  ]);

  return { phases, lessons, logs };
}
