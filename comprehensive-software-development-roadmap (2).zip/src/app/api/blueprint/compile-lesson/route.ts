import { NextResponse } from "next/server";
import { db } from "@/db";
import { compiledMicroLessons, agentExecutionLogs } from "@/db/schema";
import { compileTextbookExcerptToMimoQuest } from "@/lib/konkur-compiler";
import { getMasterBlueprintState } from "@/lib/seed";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const {
      chapterCode,
      curriculumId,
      subject,
      grade,
      topicTitle,
      sourceRef,
      rawOcrExcerpt,
      unconditionalTruthAxiom,
      motivatedDiscoveryHook,
      designerTrap,
    } = body as {
      chapterCode?: string;
      curriculumId?: number;
      subject?: string;
      grade?: string;
      topicTitle?: string;
      sourceRef?: string;
      rawOcrExcerpt?: string;
      unconditionalTruthAxiom?: string;
      motivatedDiscoveryHook?: string;
      designerTrap?: string;
    };

    if (!topicTitle?.trim() || !rawOcrExcerpt?.trim()) {
      return NextResponse.json(
        { error: "عنوان مبحث و متن منبع/کتاب درسی الزامی است." },
        { status: 400 },
      );
    }

    const finalCode =
      chapterCode?.trim() || `KONKUR-CH${Math.floor(10 + Math.random() * 89)}`;
    const finalCurriculumId =
      Number(curriculumId) > 0
        ? Number(curriculumId)
        : 120000 + Math.floor(Math.random() * 9000);

    const compiled = compileTextbookExcerptToMimoQuest({
      chapterCode: finalCode,
      curriculumId: finalCurriculumId,
      subject: subject?.trim() || "زیست‌شناسی ۳ (دوازدهم تجربی)",
      grade: grade?.trim() || "دوازدهم",
      topicTitle: topicTitle.trim(),
      sourceRef:
        sourceRef?.trim() ||
        "کتاب درسی کنکور · صفحه تاییدشده · نگاشت قطعی curriculumId",
      rawOcrExcerpt: rawOcrExcerpt.trim(),
      unconditionalTruthAxiom,
      motivatedDiscoveryHook,
      designerTrap,
    });

    await db.insert(compiledMicroLessons).values({
      chapterCode: finalCode,
      curriculumId: finalCurriculumId,
      subject: subject?.trim() || "زیست‌شناسی ۳ (دوازدهم تجربی)",
      grade: grade?.trim() || "دوازدهم",
      topicTitle: topicTitle.trim(),
      sourceRef:
        sourceRef?.trim() ||
        "کتاب درسی کنکور · صفحه تاییدشده · نگاشت قطعی curriculumId",
      rawOcrExcerpt: rawOcrExcerpt.trim(),
      sanitizedText: compiled.sanitizedText,
      ocrFixesApplied: compiled.ocrFixesApplied,
      unconditionalTruthAxiom: compiled.unconditionalTruthAxiom,
      motivatedDiscoveryHook: compiled.motivatedDiscoveryHook,
      designerTrap: compiled.designerTrap,
      targetQuantifier: compiled.targetQuantifier,
      dslBlocks: compiled.dslBlocks,
      guardrailScore: compiled.guardrailScore,
      guardrailChecks: compiled.guardrailChecks,
      reviewStatus: compiled.guardrailScore === 100 ? "approved" : "unreviewed",
      publishSetVersion: 753,
    });

    await db.insert(agentExecutionLogs).values({
      phaseCode: "PHASE_05",
      actionType: "TEXTBOOK_DSL_COMPILE",
      targetStack: "6-Stage OCR → Mimo 27-Tag DSL + LearnHarness",
      summary: `مبحث «${topicTitle.trim()}» (${finalCode}) با امتیاز گاردریل ${compiled.guardrailScore}٪ به ۶ ریزدرس میمو کامپایل و در دیتابیس ثبت شد.`,
      verificationPassed: compiled.guardrailScore >= 85,
    });

    const fresh = await getMasterBlueprintState();
    return NextResponse.json(fresh);
  } catch (error) {
    console.error("Failed to compile lesson:", error);
    return NextResponse.json(
      { error: "خطا در کامپایل متن کتاب به بسته ساختاریافته میمو" },
      { status: 500 },
    );
  }
}
