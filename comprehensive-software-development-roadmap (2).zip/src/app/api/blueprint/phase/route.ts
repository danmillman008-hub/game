import { NextResponse } from "next/server";
import { db } from "@/db";
import { blueprintPhases, agentExecutionLogs } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getMasterBlueprintState } from "@/lib/seed";

export async function PATCH(request: Request) {
  try {
    const body = await request.json();
    const { phaseNumber, status, toggleDeliverableId, notes } = body as {
      phaseNumber: number;
      status?: string;
      toggleDeliverableId?: string;
      notes?: string;
    };

    const existingRows = await db
      .select()
      .from(blueprintPhases)
      .where(eq(blueprintPhases.phaseNumber, phaseNumber))
      .limit(1);

    if (existingRows.length === 0) {
      return NextResponse.json({ error: "فاز مورد نظر یافت نشد" }, { status: 404 });
    }

    const row = existingRows[0];
    let updatedDeliverables = [...row.deliverables];
    let nextStatus = status ?? row.status;

    if (toggleDeliverableId) {
      updatedDeliverables = updatedDeliverables.map((item) =>
        item.id === toggleDeliverableId ? { ...item, done: !item.done } : item,
      );
      const allDone = updatedDeliverables.every((d) => d.done);
      const anyDone = updatedDeliverables.some((d) => d.done);
      if (allDone && nextStatus !== "verified") {
        nextStatus = "completed";
      } else if (anyDone && nextStatus === "pending") {
        nextStatus = "in_progress";
      }
    }

    await db
      .update(blueprintPhases)
      .set({
        status: nextStatus,
        deliverables: updatedDeliverables,
        notes: typeof notes === "string" ? notes : row.notes,
        updatedAt: new Date(),
      })
      .where(eq(blueprintPhases.phaseNumber, phaseNumber));

    await db.insert(agentExecutionLogs).values({
      phaseCode: row.code,
      actionType: toggleDeliverableId ? "DELIVERABLE_TOGGLE" : "STATUS_UPDATE",
      targetStack: row.category,
      summary: toggleDeliverableId
        ? `وضعیت تسک ${toggleDeliverableId} در ${row.title} به‌روزرسانی شد (وضعیت فاز: ${nextStatus}).`
        : `وضعیت ${row.title} به «${nextStatus}» تغییر یافت.`,
      verificationPassed: nextStatus === "verified" || nextStatus === "completed",
    });

    const fresh = await getMasterBlueprintState();
    return NextResponse.json(fresh);
  } catch (error) {
    console.error("Failed to update phase:", error);
    return NextResponse.json(
      { error: "خطا در به‌روزرسانی وضعیت فاز" },
      { status: 500 },
    );
  }
}
