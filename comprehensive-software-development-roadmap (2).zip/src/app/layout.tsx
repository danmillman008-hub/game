import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Vazirmatn, JetBrains_Mono } from "next/font/google";
import "./globals.css";

const vazirmatn = Vazirmatn({
  subsets: ["arabic", "latin"],
  weight: ["400", "500", "600", "700", "800"],
  variable: "--font-vazirmatn",
  display: "swap",
});

const jetbrainsMono = JetBrains_Mono({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-mono",
  display: "swap",
});

export const metadata: Metadata = {
  title: "نقشه گنج مهندسی کنکور-میمو × لرن‌هارنس | AI Agent Master Execution Blueprint",
  description:
    "کالبدشکافی جامع ریپوی danmillman008-hub/game، معماری یکپارچه میمو ۹٫۳۵ + کنکور + LearnHarness و برنامه اجرایی ۱۲ فازی وزن‌دار برای ایجنت هوش مصنوعی.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html
      lang="fa"
      dir="rtl"
      className={`${vazirmatn.variable} ${jetbrainsMono.variable}`}
    >
      <body className="min-h-screen bg-[#F6F7FB] font-[family-name:var(--font-vazirmatn)] text-[#1E2038] antialiased selection:bg-[#7E4BDE]/20 selection:text-[#252746]">
        {children}
      </body>
    </html>
  );
}
