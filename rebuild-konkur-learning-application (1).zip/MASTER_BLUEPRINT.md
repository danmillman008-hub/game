# نقشه گمشده گنج: معماری جامع مهندسی و پلی‌بوک گام‌به‌گام ایجنت هوش مصنوعی
## پروژه: پلتفرم کنکور-میمو × لرن‌هارنس (Konkur-Mimo × LearnHarness Adaptive Platform)

> **هدف این سند:** این فایل به گونه ای مهندسی شده است که شما بتوانید آن را مستقیماً به عنوان `CLAUDE.md`، `.cursorrules` یا پرامپت مرجع به هر ایجنت کدنویس (Claude Code, Cursor, OpenAI Codex, Windsurf) بدهید تا بدون سردرگمی، بدون انحراف (Drift) و بدون «وایب‌کدینگ کورکورانه»، مرحله‌به‌مرحله تا محصول نهایی پیش برود.

---

## بخش اول: کالبدشکافی دقیق ۱۹ ریپوزیتوری گیت‌هاب شما (`danmillman008-hub`)

ما تمام ۱۹ ریپوزیتوری اکانت گیت‌هاب شما را اسکن و کالبدشکافی کردیم. ایده‌های شما اصلاً کم‌ارزش یا بی‌اساس نبودند؛ بلکه **۵ قطعه طلایی یک پازل بزرگ** بودند که در ریپوهای مختلف پخش شده بودند:

1. **ریپوی `newlearning` (پروژه Gramophone — فازهای M1 تا M8):**
   - **آنچه ساخته‌اید:** موتور تبدیل متن کتاب درسی (PDF/Markdown) به گراف دانش، استخراج آیتم‌های اتمیک بلوم/DOK، ساخت DAG پیشنیاز (`surmise.py`)، شمارش وضعیت‌های نظریه فضای دانش (KST Birkhoff Ideals) و لبه بیرونی/درونی (`spacing.py`)، مدل تسلط BKT و کنترلر باند جریان ۷۰ تا ۸۵ درصد (`adapt.py`)، زمان‌بند مرور (`srs.py`) و لاگ استاندارد xAPI (`xapi.py`).
   - **باگ‌های کشف‌شده در `EVAL-QUALITATIVE.md` که باید در معماری جدید رفع شوند:**
     - **Q1 (افت شدید Recall در استخراج):** پرامپت استخراج پوشش کامل را الزام نمی‌کرد و فیلتر افعال انگلیسی `_VERBS` بیش از ۵۰٪ مفاهیم خوب را حذف می‌کرد.
     - **Q2 (حذف چک‌ها توسط Pruner):** پرامپت نویسنده داستان، لیست انواع مجاز چک (`choice | ordering | numeric`) را نداشت و چک‌های تولیدی حذف می‌شدند.
     - **Q3 & Q4 (غیرقابل دسترس بودن تسلط):** در کوئست تک‌عبوری با `p_init=0`، رسیدن به آستانه `0.95` نیازمند ۴ پاسخ درست متوالی بود در حالی که هر گره حداکثر ۲ بار پرسیده می‌شد.

2. **ریپوی `my-first` (شامل پلتفرم `Learnly` به سبک Mimo + ۱۷ آرشیو آزمایشگاه ایجنت تطبیقی):**
   - **آنچه ساخته‌اید:**
     - یک MVP کامل شبیه **Mimo / DataCamp** با Next.js + Drizzle + PostgreSQL (`Learnly` شامل Course -> Module -> Lesson -> Step با انواع `text`, `quiz`, `fill`, `code`، XP، استریک و پنل ادمین).
     - ۱۷ نسخه تکاملی از ایجنت یادگیری خودتطبیق‌گر همراه با مستندات علمی فوق‌العاده در `ARCHIVE_FORENSICS.md`، `RESEARCH.md` و `DECISIONS.md`.
   - **مهم‌ترین کشف علمی آزمایشگاه شما (`ARCHIVE_FORENSICS.md`):**
     - چت‌باتی که فقط توضیح می‌دهد (Explain-only Chat Tutor) یا باندیت ۷ سبکی توضیح (7-Style Bandit) فقط حس رضایت ظاهری (`understood rate = 0.54`) ایجاد می‌کند اما یادگیری واقعی و انتقال (`transfer = 0.08`) تقریباً صفر است!
     - در مقابل، **حلقه تمرین بازیابی (Retrieval Practice Loop) + مدل نیمه‌عمر حافظه + تفکیک پاسخ با کمک (Aided) از پاسخ مستقل (Unaided) + رفع کج‌فهمی**، بهره یادگیری را به **0.81** و ماندگاری را به **0.67** می‌رساند.

3. **ریپوهای `moshavere-va-azmoon` و `new-files` (پروتوتایپ‌های Stitch — Swiss Konkur Planner):**
   - **آنچه ساخته‌اید:** سیستم طراحی بسیار شیک **Swiss Konkur Planner** (`DESIGN.md` با پس‌زمینه کاغذی `#faf9f5`، مشکی `#1a1c1a`، قرمز کنکوری `#bc000a` و سرمه‌ای `#001551`) شامل فرم برنامه‌ریزی هفتگی، فرم گزارش کار تست‌زنی و **پاسخ‌برگ استاندارد ۳۰۰ تستی قلم‌چی/گزینه دو/سنجش**.

4. **ریپوهای `ensani`، `reshte`، `tajrobi`، `books` و `qaleb-amade`:**
   - دفترچه‌های واقعی کنکور سراسری و سنجش (۱۴۰۲ تا ۱۴۰۵)، جزوه نکته و تست زیست‌شناسی و جزوه علوم انسانی.

---

## بخش دوم: ریپوزیتوری‌های متن‌باز (Open-Source) و ابزارهای مورد نیاز از اینترنت

ایجنت هوش مصنوعی برای ساخت و توسعه کامل این پلتفرم باید از ترکیب ریپوها و پکیج‌های استاندارد زیر استفاده کند:

| ردیف | نام ریپوزیتوری / ابزار | آدرس GitHub / پکیج | نقش دقیق در معماری کنکور-میمو × لرن‌هارنس |
|---|---|---|---|
| ۱ | **LearnHarness** | `https://github.com/amosblomqvist/learnharness` | معماری ۴ فازی (`Probe → Plan → Teach → Practice`)، اصل اول (Unconditional Truth)، اصل دوم (Motivated Discovery)، فیلد «بلند فکر کن» و گراف گزاره‌ها (`Extractor → Auditor → Merger`). |
| ۲ | **Gramophone (ریپوی خودتان)** | `https://github.com/danmillman008-hub/newlearning` | الگوریتم‌های Knowledge Space Theory (`spacing.py`)، حذف دور گراف پیشنیاز (`surmise.py`)، کنترلر باند جریان ۷۰-۸۵٪ (`adapt.py`) و استاندارد `xAPI`. |
| ۳ | **TS-FSRS (FSRS v5)** | `https://github.com/open-spaced-repetition/ts-fsrs` | الگوریتم تکرار فاصله‌دار مدرن بر اساس پایداری ($S$)، دشواری ($D$) و احتمال بازیابی ($R$) برای زمان‌بندی مرور تا روز کنکور. |
| ۴ | **MinerU / Marker / Surya OCR** | `https://github.com/opendatalab/MinerU` | استخراج متن فارسی، فرمول‌های LaTeX و تست‌های چهارگزینه‌ای از PDF کتاب‌های درسی و دفترچه‌های سنجش/قلم‌چی. |
| ۵ | **KaTeX + Mermaid.js** | `https://github.com/KaTeX/KaTeX` | رندر آنی فرمول‌های ریاضی/فیزیک/شیمی و رسم زنده نقشه درختی درس (`plan_init`). |
| ۶ | **Drizzle ORM + PostgreSQL** | `https://github.com/drizzle-team/drizzle-orm` | ذخیره‌سازی تراکنشی گراف دانش، لاگ‌های Append-Only یادگیری، کارنامه‌های آزمون و برنامه هفتگی. |

---

## بخش سوم: معماری ۵ لایه نرم‌افزار و پداگوژی آموزشی

```
┌────────────────────────────────────────────────────────────────────────────┐
│ LAYER 5: UI/UX — SWISS KONKUR EDITORIAL × MIMO MICRO-LEARNING PLAYER       │
│  • Mimo Step Cards (Probe, Unconditional Truth, Fill-Blank, Ordering, MCQ) │
│  • Konkur 300-Bubble Optical Sheet + Chronograph + Swiss Weekly Planner    │
├────────────────────────────────────────────────────────────────────────────┤
│ LAYER 4: LEARNHARNESS COGNITIVE HARNESS (Probe → Plan → Teach → Practice)  │
│  • Probe: Binary-search dependency strands + Confidence % + Think-Aloud    │
│  • Plan: Minimal Dependency Tree from Unconditional Truths to Konkur Goal  │
│  • Teach: Principle i (Axioms) + Principle ii (Discovery) + Micro-Checks   │
│  • Practice: Inactive Proposition Retrieval + Hint Ladder + Model Solution │
├────────────────────────────────────────────────────────────────────────────┤
│ LAYER 3: HYBRID EPISTEMIC & MEMORY ENGINE (BKT + FSRS-5 + Flow Controller) │
│  • Calibrated BKT (Aided vs Unaided guardrails from my-first DECISIONS.md) │
│  • FSRS-5 Stability/Difficulty/Retrievability + Massed-Practice Cap        │
│  • Flow-Band Controller holding rolling accuracy inside 70%–85% ZPD        │
├────────────────────────────────────────────────────────────────────────────┤
│ LAYER 2: KNOWLEDGE SPACE THEORY (KST) & DISTRACTOR TRAP GRAPH              │
│  • Surmise Prerequisite DAG + Outer Fringe (Ready) + Inner Fringe (Review) │
│  • Konkur Designer Trap Topology (mapping wrong options to misconceptions) │
├────────────────────────────────────────────────────────────────────────────┤
│ LAYER 1: TEXTBOOK & JOZVE INGESTION COMPILER (Gramophone M1–M6 Fixed)      │
│  • PDF/Markdown Chunker → Proposition Extractor → DAG Validator → Beats    │
└────────────────────────────────────────────────────────────────────────────┘
```

---

## بخش چهارم: برنامه اجرایی ۱۰ مرحله‌ای وزن‌دار برای ایجنت (مجموع وزن = ۱۰۰٪)

> **دستورالعمل استفاده با ایجنت:** هر بار یک فاز را کپی کرده و به ایجنت بدهید. ایجنت موظف است در پایان هر فاز، دستورات بخش `Verification Gate` را اجرا کند و تنها در صورت پاس شدن ۱۰۰٪ سراغ فاز بعدی برود.

### فاز ۱ (وزن: ۸٪): زیرساخت پایه، تایپوگرافی فارسی RTL و سیستم طراحی Swiss Konkur × Mimo
- **پیش‌نیاز:** پروژه Next.js (App Router) + TypeScript + Tailwind CSS
- **اهداف:** پیکربندی کامل راست‌به‌چپ (`dir="rtl" lang="fa"`)، فونت وزیرمتن + JetBrains Mono، و اعمال پالت رنگی `DESIGN.md` از ریپوی `moshavere-va-azmoon` (`#FAF9F5` کاغذی، `#1A1C1A` مرکبی، `#BC000A` قرمز کنکور، `#001551` سرمه‌ای علمی، `#059669` سبز تسلط میمو).
- **دروازه تایید:** `npx next typegen && npm exec tsc -- --noEmit`

### فاز ۲ (وزن: ۱۲٪): مهندسی اسکیمای یکپارچه PostgreSQL با Drizzle ORM
- **اهداف:** ایجاد جداول `learner_profiles`، `knowledge_nodes`، `mimo_lessons`، `learning_evidence` (فقط الحاقی / Append-Only)، `konkur_exams`، `exam_submissions`، `weekly_study_plans` و `blueprint_phases` در `src/db/schema.ts`.
- **قانون حیاتی:** جداسازی شمارنده `aided_successes` از `unaided_successes` طبق تصمیم شماره ۵ در `DECISIONS.md`.
- **دروازه تایید:** `npx drizzle-kit push && npm exec tsc -- --noEmit`

### فاز ۳ (وزن: ۱۴٪): پایپ‌لاین تبدیل جزوه و کتاب درسی به کوئست میمو (رفع باگ‌های Q1–Q7 گراموفون)
- **اهداف:** پیاده‌سازی کامپایلر `compileJozveToQuest` و روت `POST /api/ingest` که متن درس یا جزوه کنکور را به گره دانش (شامل اصل بدیهی اول، مسیر کشف دوم و دام طراح) و گام‌های تعاملی میمو تبدیل می‌کند.
- **دروازه تایید:** تست `POST /api/ingest` و اطمینان از تولید حداقل ۳ گام ارزیابی معتبر برای هر ورودی.

### فاز ۴ (وزن: ۱۲٪): موتور نظریه فضای دانش (KST) و محاسبه لبه بیرونی (Outer Fringe)
- **اهداف:** پیاده‌سازی تابع `computeKSTStates` برای دسته‌بندی تمام گره‌های کنکور به ۴ ناحیه: `mastered` ($\ge 0.82$)، `outer_fringe` (آماده یادگیری — تمام پیشنیازها پاس شده)، `learning` و `locked`.

### فاز ۵ (وزن: ۱۶٪): هسته شناختی ۴ فازی LearnHarness (`Probe → Plan → Teach → Practice`)
- **اهداف:** پیاده‌سازی چرخه کامل LearnHarness در پلیر یادگیری و `POST /api/learn/attempt`:
  1. `Probe`: سوال تشخیصی + اسلایدر ضریب اطمینان (۰ تا ۱۰۰٪) + باکس «بلند فکر کن».
  2. `Plan`: نمایش گراف پیشنیاز از اصول بدیهی تا هدف تستی.
  3. `Teach`: ارائه گام‌به‌گام بر اساس Principle i & ii همراه با چک مفهومی فوری.
  4. `Practice`: طرح تست از گزاره غیرفعال همراه با نردبان راهنمایی (`Hint Ladder`) و پاسخ تشریحی قفل‌شده (`Model Solution`).

### فاز ۶ (وزن: ۱۴٪): پلیر میکرولرنینگ به سبک Mimo و کنترلر باند جریان (Flow-Band 70%–85%)
- **اهداف:** ساخت رابط کاربری گام‌به‌گام شبیه Mimo با پشتیبانی از کارت‌های جای خالی (`fill_blank`)، چیدمان زنجیره استدلال (`ordering_chain`)، تست چهارگزینه‌ای ضدتله (`check_mcq`) و مسئله کنکوری (`practice_problem`) به همراه قلب، استریک، XP و حفظ نرخ موفقیت در بازه ۷۰ تا ۸۵ درصد.

### فاز ۷ (وزن: ۱۰٪): موتور حافظه ترکیبی BKT کالیبره‌شده + زمان‌بند FSRS-5
- **اهداف:** پیاده‌سازی توابع `updateBKTMastery` و `updateFSRSState` در `src/lib/algorithms.ts`. اعمال قانون عدم تسلط با راهنمایی (Aided Guard) و محدودکننده تمرین فشرده (Massed Cap).

### فاز ۸ (وزن: ۸٪): شبیه‌ساز آزمون کنکور، پاسخ‌برگ کلیدی و اتصال خودکار به صف ترمیم
- **اهداف:** پیاده‌سازی آزمون‌ساز کنکور با فرمول نمره منفی یک‌سوم $\frac{3C - W}{3N} \times 100$، محاسبه تراز تخمینی، پاسخ‌برگ کلیدی، علامت‌گذاری سوالات (شک‌دار، زمان‌بر، تله) و اتصال مستقیم غلط‌های آزمون به کاهش پایداری FSRS و تولید صف ترمیم در بخش یادگیری میمو.

### فاز ۹ (وزن: ۴٪): میز کار مشاوره و برنامه‌ریزی هفتگی Swiss Konkur
- **اهداف:** پیاده‌سازی دیجیتال فرم برنامه‌ریزی هفتگی و گزارش کار ریپوی `moshavere-va-azmoon` متصل به PostgreSQL و پیشنهاد هوشمند مبحث بر اساس `Outer Fringe`.

### فاز ۱۰ (وزن: ۲٪): ممیزی نهایی Typegen، TypeScript و بیلد پروداکشن
- **دروازه تایید نهایی:**
  ```bash
  npx next typegen
  npm exec tsc -- --noEmit --pretty false
  npm run build
  ```
