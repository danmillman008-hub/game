import type {
  AtomicConceptNode,
  DesignerTrapItem,
  GuardrailViolation,
  KonkurModifierItem,
  KonkurStepContent,
  PedagogicalBlueprint,
  QualityAuditReport,
  QualityMetricItem,
  StepKind,
} from "@/db/schema";

// ============================================================================
// 1. کالبدشکافی فرم‌ها و درسنامه‌های ریپوی اصلی میمو (Learnly / Mimo Legacy Audit)
// ============================================================================

export type LegacyFormDefectAnalysis = {
  id: string;
  legacyComponent: string;
  legacySchemaSignature: string;
  mimoCodingExampleInRepo: string;
  whyNaiveAgentFailsForKonkur: string;
  missingLinkBridge: string;
  enforcedAlgorithmicConstraint: string;
};

export const LEGACY_MIMO_FORM_DEFECTS: LegacyFormDefectAnalysis[] = [
  {
    id: "DEFECT_01_UNBOUNDED_TEXT",
    legacyComponent: "StepEditor.tsx → kind === 'text'",
    legacySchemaSignature: '{ kind: "text"; body: string }',
    mimoCodingExampleInRepo:
      'Hello, Python!: "## Welcome to Python... print(\\"Hello, world!\\") is a function — it takes a value and displays it." (48 words)',
    whyNaiveAgentFailsForKonkur:
      "در فرم قبلی، فیلد body صرفاً یک textarea آزاد است. وقتی به ایجنت یک صفحه از کتاب زیست یا فیزیک کنکور می‌دهیم، ایجنت کل صفحه را در قالب یک متن ۳۰۰ کلمه‌ای خلاصه‌نویسی می‌کند! این کار «سقف حافظه فعال» (Working Memory) دانش‌آموز را منفجر کرده و ریتم میکرو-لرنینگ میمو را به یک جزوه پی‌دی‌اف خسته‌کننده تبدیل می‌کند.",
    missingLinkBridge:
      "تبدیل گام `text` به `concept_bite` (لقمه مفهومی مقید): جداسازی اجباری «قلاب شهودی (Hook Analogy)»، «متن هسته (حداکثر ۸۵ کلمه)»، «هایلایت قیدهای کنکوری» و افزودن «میکرو-سوال بله/خیر در انتهای همان کارت».",
    enforcedAlgorithmicConstraint:
      "قانون گاردریل M1 و M2: شمارشگر خودکار کلمات (۲۰ تا ۸۵ کلمه) + الزام اتصال به دقیقاً ۱ گره مفهومی اتمی (conceptNodeId) + ممنوعیت عبور از کارت بدون پاسخ به میکرو-سوال پایانی.",
  },
  {
    id: "DEFECT_02_CODE_STEP_MISMATCH",
    legacyComponent: "StepEditor.tsx → kind === 'code'",
    legacySchemaSignature:
      '{ kind: "code"; prompt: string; language: string; starterCode: string; solution: string; checks: string[] }',
    mimoCodingExampleInRepo:
      'Variables / SQL JOINs: starterCode: "SELECT customers.name...", checks: ["FROM orders", "JOIN customers", "ON orders.customer_id = customers.id"]',
    whyNaiveAgentFailsForKonkur:
      "این بزرگ‌ترین «حلقه مفقوده» بین میمو و کنکور است! راز اعتیادآور بودن و یادگیری عمیق در میمو این است که کاربر صرفاً تست ۴ گزینه‌ای نمی‌زند، بلکه کد را تکه به تکه می‌سازد (Constructive Assembly) و باگ آن را پیدا می‌کند (Debugging). وقتی موضوع از پایتون/SQL به زیست، شیمی، فیزیک یا ریاضی کنکور تغییر می‌کند، فیلد `language: python | sql` بی‌معنی می‌شود و ایجنت‌ها گام `code` را حذف می‌کنند؛ در نتیجه اپ تبدیل به یک بانک تست معمولی می‌شود!",
    missingLinkBridge:
      "استخراج جوهره شناختی گام `code` میمو و تبدیل آن به ۲ مکانیک هم‌ریخت کنکوری: ۱) `token_assembly` (چیدمان بلوکی مسیرهای زیستی، اشتقاق فرمول فیزیک/ریاضی، و خط استوکیومتری شیمی با بلوک‌های تله) و ۲) `trap_detector` (دیباگر کنکوری: کشف تکه معیوب در یک گزاره ترکیبی یا کشف خطای استدلال در سطرهای حل مسئله).",
    enforcedAlgorithmicConstraint:
      "قانون گاردریل M4 (شاخص هم‌ریختی حلقه مفقوده): هر درسنامه کنکوری اجباراً باید حداقل یک گام `token_assembly` (حداقل ۳ بلوک ترتیبی + ۱ بلوک انحرافی تله‌دار) و یک گام `trap_detector` (شکار تله طراح) داشته باشد.",
  },
  {
    id: "DEFECT_03_TRIVIAL_CLOZE_FILL",
    legacyComponent: "StepEditor.tsx → kind === 'fill'",
    legacySchemaSignature:
      '{ kind: "fill"; prompt: string; template: string; answer: string; hint?: string }',
    mimoCodingExampleInRepo:
      'If Statements: template: "if age ___ 18:\\n print(\\"Adult\\")", answer: ">="',
    whyNaiveAgentFailsForKonkur:
      "در میمو، جای خالی (`___`) دقیقاً روی «عملگر تصمیم‌ساز» (`>=`, `AVG`, `const`) قرار دارد. اما در فرم ساده قبلی، ایجنت هنگام تولید سوال کنکوری یک کلمه تصادفی یا کم‌اهمیت از جمله کتاب درسی را حذف می‌کند و دانش‌آموز مجبور به حدس کلمات مترادف می‌شود.",
    missingLinkBridge:
      "تبدیل `fill` به `guided_cloze` قیدمحور: جای خالی باید منحصراً روی «قیدهای کنکوری» (همه، برخی، اغلب، به جز، مستقیماً) یا «متغیر/ضریب کلیدی فرمول» بنشیند و همراه با ۴ چیپ انتخابی (شامل ۳ تله قیدی) ارائه شود.",
    enforcedAlgorithmicConstraint:
      "قانون گاردریل M5: الزام ارجاع فیلد `targetedModifierId` به یکی از قیدها/فرمول‌های استخراج‌شده در مرحله ۱ کالبدشکافی کتاب + ممنوعیت کلمات ربط عمومی در جواب.",
  },
  {
    id: "DEFECT_04_SHALLOW_QUIZ_OPTIONS",
    legacyComponent: "StepEditor.tsx → kind === 'quiz'",
    legacySchemaSignature:
      '{ kind: "quiz"; question: string; options: string[]; correctIndex: number; explanation?: string }',
    mimoCodingExampleInRepo:
      'Data Types: "Which value is a boolean?" options: ["\\"True\\"", "1", "True", "true"], explanation: "Python booleans are capitalized."',
    whyNaiveAgentFailsForKonkur:
      "در فرم قبلی، `explanation` یک رشته اختیاری (`optional`) برای کل سوال است و هیچ ساختاری برای تحلیل گزینه‌های غلط وجود ندارد. در کنکور سراسری، هنر اصلی در «مهندسی گزینه‌های انحرافی (Distractors)» و «تکنیک رد گزینه» است. ایجنت در فرم معمولی ۳ گزینه پرت و تابلو می‌سازد و در توضیحات می‌نویسد: «طبق کتاب درسی گزینه ۲ صحیح است»!",
    missingLinkBridge:
      "ارتقا به `step_solver` (حل پله‌ای پیش از تست) و `konkur_test` (تست استاندارد با ماتریس کالبدشکافی ۴ گزینه `optionDiagnostics` + تکنیک سرعتی رد گزینه `eliminationShortcut`).",
    enforcedAlgorithmicConstraint:
      "قانون گاردریل M6 و M9: فیلد `optionDiagnostics` باید دقیقاً ۴ عنصر داشته باشد و برای هر گزینه غلط، نام «تله شناختی طراح» و چرایی غلط بودن آن را بدون عبارات کلیشه‌ای تشریح کند.",
  },
  {
    id: "DEFECT_05_NO_PRE_STEP_BLUEPRINT",
    legacyComponent: "LessonForm.tsx & CourseForm.tsx",
    legacySchemaSignature:
      '{ title: string; slug: string; description: string; xpReward: number; steps: Step[] }',
    mimoCodingExampleInRepo:
      "در `seed.ts` درس‌ها مستقیماً به صورت آرایه‌ای از گام‌ها بدون هیچ گراف پیش‌نیاز یا جدول تله‌های مفهومی نوشته شده‌اند.",
    whyNaiveAgentFailsForKonkur:
      "وقتی ایجنت بدون «نقشه پداگوژیک میانی (Intermediate Pedagogical Blueprint)» مستقیماً شروع به تولید گام‌ها می‌کند، پیوستگی مفهومی از بین می‌رود، قیدهای مهم کتاب جا می‌افتند و ترتیب گام‌ها از ساده به سخت رعایت نمی‌شود.",
    missingLinkBridge:
      "الزام کامپایلر دو مرحله‌ای (Two-Phase Pedagogical Compilation): ایجنت ابتدا باید `pedagogicalBlueprint` (شامل گره‌های اتمی، یال‌های پیش‌نیاز، قیدها/فرمول‌ها و تله‌های طراح) را استخراج کند و سپس هر گام را به یک گره از این گراف متصل نماید.",
    enforcedAlgorithmicConstraint:
      "قانون گاردریل M3 و M8: بررسی پوشش ۱۰۰٪ گره‌های مفهومی گراف در گام‌ها + بررسی صعودی بودن `scaffoldingLevel` از گام اول تا گام ششم.",
  },
];

// ============================================================================
// 2. ماتریس هم‌ریختی میمو ↔ کنکور (حلقه مفقوده برای تمام دروس کنکور)
// ============================================================================

export type SubjectIsomorphismGuide = {
  subject: string;
  icon: string;
  mimoCodeEquivalent: string;
  mimoDebugEquivalent: string;
  mimoClozeEquivalent: string;
  concreteExample: string;
  agentExtractionRule: string;
};

export const MIMO_TO_KONKUR_ISOMORPHISM_MATRIX: SubjectIsomorphismGuide[] = [
  {
    subject: "زیست‌شناسی کنکور (تجربی)",
    icon: "🧬",
    mimoCodeEquivalent:
      "چیدمان بلوکی مسیرهای بیوشیمیایی و فیزیولوژیک (`token_assembly` با حالت `causal_chain`): چیدن توالی وقایع رونویسی، ترجمه، پتانسیل عمل یا چرخه کالوین با حضور بلوک‌های تله (مثلاً جاگذاری هلیکاز به جای RNA پلی‌مراز!).",
    mimoDebugEquivalent:
      "کالبدشکافی گزاره‌های ترکیبی سنجش (`trap_detector` با حالت `statement_autopsy`): شکستن یک جمله ۴ بخشی کنکوری و ضربه زدن روی بخشی که تله قیدی («همه» به جای «برخی»، یا «مستقیماً») دارد.",
    mimoClozeEquivalent:
      "قیدگذاری فعال (`guided_cloze`): هدف‌گیری قیدهای کمّی، جهت حرکت مواد (در جهت/برخلاف شیب غلظت) و استثناهای جانوری و گیاهی.",
    concreteExample:
      "در مبحث رونویسی زیست دوازدهم: دانش‌آموز به جای خواندن متن، بلوک‌های [اتصال RNA پلی‌مراز به راه‌انداز] ← [باز شدن دو رشته DNA توسط خود آنزیم] ← [ساخت پیوند فسفودی‌استر] را می‌چیند و بلوک تله [شکستن پیوند هیدروژنی توسط هلیکاز] را کنار می‌گذارد.",
    agentExtractionRule:
      "ایجنت باید از هر پاراگراف زیست: ۱) تمام قیدهای کمّی/تخصیصی، ۲) ترتیب زمانی فرآیندها، و ۳) شباهت‌های فریبنده بین دو ساختار (مثل DNA پلی‌مراز و RNA پلی‌مراز) را استخراج کند.",
  },
  {
    subject: "فیزیک کنکور (ریاضی و تجربی)",
    icon: "⚡",
    mimoCodeEquivalent:
      "ساخت بلوکی فرمول و زنجیره تبدیل یکتا (`token_assembly` با حالت `formula_derivation`): چیدمان متغیرها و عملگرها برای ساخت معادله مستقل از زمان یا قانون دوم نیوتن متناسب با شرایط مسئله.",
    mimoDebugEquivalent:
      "خطایاب راه‌حل مسئله (`trap_detector` با حالت `math_solution_bug`): نمایش ۴ سطر حل یک تست حرکت‌شناسی یا دینامیک که در سطر سوم خطای علامت برداری یا عدم تبدیل واحد (km/h به m/s) رخ داده و دانش‌آموز باید سطر باگ‌دار را شکار کند.",
    mimoClozeEquivalent:
      "تکمیل شروط مرزی و تشخیص نوع حرکت (`guided_cloze`): مثلاً «در حرکت کندشونده در خلاف جهت محور، علامت بردار شتاب ___ است».",
    concreteExample:
      "در مبحث حرکت با شتاب ثابت: دانش‌آموز در گام ۴ یک راه‌حل ۳ خطی برای زمان توقف متحرک می‌بیند، روی سطر دوم که شتاب کندشونده را با علامت مثبت جمع زده ضربه می‌زند و آن را اصلاح می‌کند.",
    agentExtractionRule:
      "ایجنت باید هر فرمول فیزیک را به ۱) شروط برقراری رابطه، ۲) تحلیل ابعادی و یکاها، و ۳) خطاهای علامت‌گذاری برداری تجزیه کند.",
  },
  {
    subject: "شیمی کنکور (ریاضی و تجربی)",
    icon: "🧪",
    mimoCodeEquivalent:
      "خط لوله استوکیومتری و آرایش الکترونی (`token_assembly` با حالت `stoichiometry_pipeline`): چیدن کسرهای تبدیل متوالی (گرم ماده A ← مول A ← ضریب استوکیومتری ← مول B ← لیتر گاز در STP).",
    mimoDebugEquivalent:
      "شکارچی استثنائات جدول تناوبی و ساختار لوویس (`trap_detector` با حالت `chemistry_exception`): یافتن عنصر یا ترکیبی که قاعده عمومی روند تناوبی یا هشتایی را نقض می‌کند (مثل کروم ۲۴، مس ۲۹ یا پیوند هیدروژنی).",
    mimoClozeEquivalent:
      "ضرایب موازنه، عدد اکسایش و مقایسه روندهای تناوبی (`guided_cloze`).",
    concreteExample:
      "در مبحث استوکیومتری: دانش‌آموز بلوک‌های کسر تبدیل را به ترتیب می‌چیند و بلوک تله [تقسیم بر ۲۲.۴ در شرایط غیر استاندارد] را رد می‌کند.",
    agentExtractionRule:
      "ایجنت باید از متن شیمی: ۱) استثناهای آرایش الکترونی/جدول تناوبی، ۲) زنجیره ضرایب تبدیل، و ۳) تله‌های «جرم مولی به جای عدد جرمی» را بیرون بکشد.",
  },
  {
    subject: "ریاضیات و حسابان (ریاضی، تجربی، انسانی)",
    icon: "📐",
    mimoCodeEquivalent:
      "معماری استدلال و ترکیب قضایا (`token_assembly` با حالت `formula_derivation`): چیدن گام‌های منطقی رفع ابهام حد، مشتق‌گیری تابع مرکب یا تعیین علامت.",
    mimoDebugEquivalent:
      "کشف مغالطه جبری (`trap_detector` با حالت `math_solution_bug`): پیدا کردن سطری که در آن تقسیم بر عبارت دارای ریشه صفر یا حذف قدرمطلق بدون بررسی علامت انجام شده است.",
    mimoClozeEquivalent:
      "تکمیل شرط دامنه، پیوستگی یا مشتق‌پذیری در نقاط مرزی (`guided_cloze`).",
    concreteExample:
      "در مبحث مشتق‌پذیری: دانش‌آموز در حل یک تست، سطری را که از پیوستگی مستقیماً مشتق‌پذیری را نتیجه گرفته (در نقطه گوشه قدرمطلق) به عنوان باگ استدلالی شکار می‌کند.",
    agentExtractionRule:
      "ایجنت باید هر قضیه ریاضی را به «پیش‌فرض‌های لازم (شروط قضیه)»، «نتیجه قضیه» و «مثال نقض در صورت حذف شرط» بشکند.",
  },
  {
    subject: "فلسفه، منطق، ادبیات و عربی (انسانی و عمومی)",
    icon: "🏛️",
    mimoCodeEquivalent:
      "چیدمان ساختار قیاس منطقی، تقطیع عروضی یا مهندسی آرایه (`token_assembly` با حالت `syntactic_logic`): چیدن صغری، حد وسط و کبری برای تولید نتیجه معتبر یا چیدن ارکان تشبیه و استعاره.",
    mimoDebugEquivalent:
      "کشف مغالطه منطقی یا خطای اعراب/اعلال (`trap_detector` با حالت `statement_autopsy`): پیدا کردن شرط نقض‌شده در قیاس اقترانی یا استثنایی.",
    mimoClozeEquivalent:
      "تشخیص سور قضیه، جهت قضیه یا نقش دستوری کلیدی (`guided_cloze`).",
    concreteExample:
      "در منطق کنکور انسانی: دانش‌آموز در یک قیاس شکل اول، کبرای جزئی را به عنوان باگ منطقی («کلیت کبری در شکل اول») شناسایی و اصلاح می‌کند.",
    agentExtractionRule:
      "ایجنت باید قواعد منطقی/بلاغی را به شروط صحت، اقسام چهارگانه و تله‌های تشخیص مصداق تبدیل کند.",
  },
];

// ============================================================================
// 3. الگوریتم ۱۰ شاخصه عیارسنج پداگوژیک و گاردریل ایجنت (Pedagogical Quality Engine)
// ============================================================================

const BANNED_GENERIC_PHRASES = [
  "سایر گزینه‌ها نادرست هستند",
  "سایر گزینه ها نادرست اند",
  "بقیه گزینه‌ها غلط است",
  "طبق متن کتاب درسی گزینه صحیح است",
  "این گزینه درست است چون در کتاب آمده",
  "توضیحی ندارد",
  "واضح است که",
];

export function countPersianWords(text: string): number {
  const cleaned = text
    .replace(/[`*#_~>|[\]()-]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  if (!cleaned) return 0;
  return cleaned.split(" ").length;
}

export function evaluatePedagogicalFidelity(
  blueprint: PedagogicalBlueprint,
  steps: {
    type: StepKind;
    conceptNodeId: string;
    scaffoldingLevel: number;
    content: KonkurStepContent;
  }[],
): QualityAuditReport {
  const violations: GuardrailViolation[] = [];
  const metrics: QualityMetricItem[] = [];

  // --- Metric 1: Micro-Chunking & Working Memory Ceiling (10 pts) ---
  let m1Score = 10;
  steps.forEach((s, idx) => {
    if (s.content.kind === "concept_bite") {
      const words = countPersianWords(s.content.bodyMarkdown);
      if (words > 90) {
        m1Score -= 5;
        violations.push({
          code: "COGNITIVE_OVERLOAD_WORD_COUNT",
          severity: "critical",
          stepIndex: idx,
          field: `steps[${idx}].content.bodyMarkdown`,
          message: `گام ${idx + 1} (${s.content.title}) دارای ${words} کلمه است که از سقف مجاز بار شناختی میمو (حداکثر ۸۵ کلمه) عبور کرده است.`,
          autoFixInstruction:
            "متن درسنامه را به جملات اتمی کوتاه زیر ۷۵ کلمه فشرده کنید و جزئیات فرعی را به گام‌های تعاملی بعدی منتقل نمایید.",
        });
      } else if (words < 18) {
        m1Score -= 3;
        violations.push({
          code: "SHALLOW_CONCEPT_BITE",
          severity: "warning",
          stepIndex: idx,
          field: `steps[${idx}].content.bodyMarkdown`,
          message: `گام ${idx + 1} تنها ${words} کلمه دارد و فاقد عمق کافی برای انتقال مفهوم پایه است.`,
          autoFixInstruction:
            "حداقل یک توضیح علّی روشن همراه با مثال شهودی و قید کتاب درسی (حداقل ۲۵ کلمه) اضافه کنید.",
        });
      }
      if (!s.content.hookAnalogy || countPersianWords(s.content.hookAnalogy) < 5) {
        m1Score -= 3;
        violations.push({
          code: "MISSING_HOOK_ANALOGY",
          severity: "warning",
          stepIndex: idx,
          field: `steps[${idx}].content.hookAnalogy`,
          message: `گام مفهومی ${idx + 1} فاقد «قلاب شهودی (Hook Analogy)» معتبر برای اتصال به ذهن دانش‌آموز است.`,
          autoFixInstruction:
            "یک تشبیه ملموس روزمره یا شهود تصویری برای فعال‌سازی اسکیما پیش از تعریف رسمی بنویسید.",
        });
      }
    }
  });
  m1Score = Math.max(0, m1Score);
  metrics.push({
    id: "M1_MICRO_CHUNKING",
    label: "۱. سقف بار شناختی و خرده‌سازی (Micro-Chunking)",
    score: m1Score,
    maxScore: 10,
    weight: 10,
    status: m1Score >= 9 ? "optimal" : m1Score >= 6 ? "warning" : "violation",
    diagnosticNote:
      m1Score === 10
        ? "تمام کارت‌های مفهومی بین ۲۰ تا ۸۵ کلمه بوده و دارای قلاب شهودی هستند."
        : "برخی کارت‌های مفهومی سقف کلمات میمو یا شرط قلاب شهودی را نقض کرده‌اند.",
    algorithmicFormula: "∀ step ∈ concept_bite: 20 ≤ words(body) ≤ 85 ∧ words(hook) ≥ 5",
  });

  // --- Metric 2: Zero-Passive-Scroll & Active Interaction Ratio (10 pts) ---
  let m2Score = 10;
  let consecutiveConceptBites = 0;
  steps.forEach((s, idx) => {
    if (s.type === "concept_bite") {
      consecutiveConceptBites += 1;
      if (consecutiveConceptBites >= 2) {
        m2Score -= 6;
        violations.push({
          code: "CONSECUTIVE_PASSIVE_STEPS",
          severity: "critical",
          stepIndex: idx,
          field: `steps[${idx}].type`,
          message: `دو گام مفهومی متوالی در گام‌های ${idx} و ${idx + 1} دیده شد! در پداگوژی میمو دو اسلاید توضیحی پشت سر هم بدون چالش تعاملی اکیداً ممنوع است.`,
          autoFixInstruction:
            "بین هر دو گام `concept_bite` حداقل یک گام تعاملی (`guided_cloze` یا `token_assembly`) قرار دهید.",
        });
      }
      if (
        s.content.kind === "concept_bite" &&
        (!s.content.interactiveCheckQuestion ||
          s.content.interactiveCheckQuestion.trim().length < 10)
      ) {
        m2Score -= 4;
        violations.push({
          code: "MISSING_INLINE_MICRO_CHECK",
          severity: "critical",
          stepIndex: idx,
          field: `steps[${idx}].content.interactiveCheckQuestion`,
          message: `کارت مفهومی گام ${idx + 1} فاقد میکرو-سوال تایید فهم در انتهای کارت است.`,
          autoFixInstruction:
            "یک سوال سریع درست/نادرست در انتهای کارت مفهومی اضافه کنید تا دانش‌آموز بدون درگیری ذهنی دکمه ادامه را نزند.",
        });
      }
    } else {
      consecutiveConceptBites = 0;
    }
  });
  const interactiveRatio =
    steps.length > 0
      ? steps.filter((s) => s.type !== "concept_bite").length / steps.length
      : 0;
  if (interactiveRatio < 0.65) {
    m2Score -= 5;
    violations.push({
      code: "LOW_INTERACTION_RATIO",
      severity: "critical",
      field: "steps",
      message: `نسبت گام‌های تعاملی تنها ${Math.round(interactiveRatio * 100)}٪ است (حداقل مجاز در استاندارد میمو: ۷۰٪).`,
      autoFixInstruction:
        "تعداد گام‌های عملی (`guided_cloze`, `token_assembly`, `trap_detector`, `step_solver`, `konkur_test`) را افزایش دهید.",
    });
  }
  m2Score = Math.max(0, m2Score);
  metrics.push({
    id: "M2_ZERO_PASSIVE_SCROLL",
    label: "۲. قانون توقف اسکرول غیرفعال و تراکم تعامل",
    score: m2Score,
    maxScore: 10,
    weight: 10,
    status: m2Score >= 9 ? "optimal" : m2Score >= 6 ? "warning" : "violation",
    diagnosticNote: `تراکم تعامل فعال: ${Math.round(interactiveRatio * 100)}٪ کل گام‌ها بدون هیچ دو اسلاید متنی متوالی.`,
    algorithmicFormula: "Ratio(Interactive) ≥ 0.70 ∧ ¬∃i: type[i]=concept_bite ∧ type[i+1]=concept_bite",
  });

  // --- Metric 3: Scaffolding Gradient & Fading Guidance (10 pts) ---
  let m3Score = 10;
  if (steps.length < 5) {
    m3Score -= 5;
    violations.push({
      code: "INSUFFICIENT_SCAFFOLDING_STEPS",
      severity: "critical",
      field: "steps",
      message: `تعداد کل گام‌ها (${steps.length}) کمتر از حداقل چرخه ۶ گامی داربست میمو-کنکور است.`,
      autoFixInstruction:
        "درسنامه باید چرخه کامل ۶ گامی (مفهوم ← جای‌خالی قیددار ← چیدمان بلوکی ← شکار تله ← حل پله‌ای ← تست کنکور) را طی کند.",
    });
  }
  for (let i = 1; i < steps.length; i++) {
    if (steps[i].scaffoldingLevel < steps[i - 1].scaffoldingLevel) {
      m3Score -= 4;
      violations.push({
        code: "BROKEN_SCAFFOLDING_GRADIENT",
        severity: "critical",
        stepIndex: i,
        field: `steps[${i}].scaffoldingLevel`,
        message: `شیب داربست آموزشی در گام ${i + 1} شکسته شده است (سطح ${steps[i].scaffoldingLevel} بعد از سطح ${steps[i - 1].scaffoldingLevel}).`,
        autoFixInstruction:
          "گام‌ها را بر اساس سطح داربست (۱: لقمه مفهومی تا ۶: تست نهایی بدون داربست) به صورت صعودی مرتب کنید.",
      });
    }
  }
  if (steps[0]?.type === "konkur_test") {
    m3Score = 0;
    violations.push({
      code: "PREMATURE_UNSCAFFOLDED_TEST",
      severity: "critical",
      stepIndex: 0,
      field: "steps[0].type",
      message: "شروع درس با تست ۴ گزینه‌ای کنکور بدون داربست اولیه، نقض صریح پداگوژی میمو است!",
      autoFixInstruction: "درس را با `concept_bite` آغاز کرده و تست نهایی را در گام آخر قرار دهید.",
    });
  }
  m3Score = Math.max(0, m3Score);
  metrics.push({
    id: "M3_SCAFFOLDING_GRADIENT",
    label: "۳. شیب محو تدریجی داربست (Scaffolding Decay)",
    score: m3Score,
    maxScore: 10,
    weight: 10,
    status: m3Score >= 9 ? "optimal" : m3Score >= 6 ? "warning" : "violation",
    diagnosticNote:
      m3Score === 10
        ? "حرکت پیوسته و صعودی از سطح شناختی ۱ (درک شهودی) تا سطح ۶ (تست کنکور زمان‌دار)."
        : "توالی داربست آموزشی دارای پرش یا برگشت به عقب است.",
    algorithmicFormula: "∀i ∈ [1..n-1]: level[i-1] ≤ level[i] ∧ type[0]=concept_bite ∧ type[n-1]=konkur_test",
  });

  // --- Metric 4: Missing-Link Isomorphism (Token Assembly + Trap Detector) (15 pts) ---
  let m4Score = 15;
  const hasTokenAssembly = steps.some((s) => s.type === "token_assembly");
  const hasTrapDetector = steps.some((s) => s.type === "trap_detector");
  if (!hasTokenAssembly) {
    m4Score -= 8;
    violations.push({
      code: "MISSING_ISOMORPHIC_TOKEN_ASSEMBLY",
      severity: "critical",
      field: "steps",
      message:
        "حلقه مفقوده پر نشده است! درسنامه فاقد گام `token_assembly` (چیدمان بلوکی فرمول/مکانیزم به عنوان معادل گام Code میمو) است.",
      autoFixInstruction:
        "یک گام `token_assembly` اضافه کنید که در آن دانش‌آموز مراحل فرآیند یا اجزای فرمول را با رد کردن بلوک‌های تله بچیند.",
    });
  }
  if (!hasTrapDetector) {
    m4Score -= 7;
    violations.push({
      code: "MISSING_ISOMORPHIC_TRAP_DETECTOR",
      severity: "critical",
      field: "steps",
      message:
        "درسنامه فاقد گام `trap_detector` (شکارچی تله طراح / دیباگر کنکوری به عنوان معادل Code Debugging میمو) است.",
      autoFixInstruction:
        "یک گام `trap_detector` اضافه کنید که در آن دانش‌آموز بخش دستکاری‌شده یک گزاره کنکوری یا سطر اشتباه حل مسئله را کشف کند.",
    });
  }
  steps.forEach((s, idx) => {
    if (s.content.kind === "token_assembly") {
      if (s.content.orderedTokens.length < 3) {
        m4Score -= 4;
        violations.push({
          code: "WEAK_TOKEN_ASSEMBLY",
          severity: "warning",
          stepIndex: idx,
          field: `steps[${idx}].content.orderedTokens`,
          message: `گام چیدمان بلوکی ${idx + 1} کمتر از ۳ بلوک ترتیبی دارد.`,
          autoFixInstruction: "حداقل ۳ تا ۴ بلوک ترتیبی معنادار برای ساخت زنجیره تعریف کنید.",
        });
      }
      if (s.content.distractorTokens.length < 1) {
        m4Score -= 4;
        violations.push({
          code: "MISSING_DISTRACTOR_TOKENS",
          severity: "critical",
          stepIndex: idx,
          field: `steps[${idx}].content.distractorTokens`,
          message: `گام چیدمان بلوکی ${idx + 1} فاقد «بلوک تله (Distractor Token)» است و چالش شناختی ایجاد نمی‌کند.`,
          autoFixInstruction:
            "حداقل ۱ یا ۲ بلوک انحرافی مبتنی بر خطای رایج کنکوری به همراه دلیل تله (`trapReason`) اضافه کنید.",
        });
      }
    }
  });
  m4Score = Math.max(0, m4Score);
  metrics.push({
    id: "M4_MISSING_LINK_ISOMORPHISM",
    label: "۴. شاخص پر کردن حلقه مفقوده (معادل‌سازی Code و Debug میمو)",
    score: m4Score,
    maxScore: 15,
    weight: 15,
    status: m4Score >= 13 ? "optimal" : m4Score >= 9 ? "warning" : "violation",
    diagnosticNote:
      m4Score === 15
        ? "هر دو مکانیک هم‌ریخت میمو (`token_assembly` با بلوک‌های تله و `trap_detector` دیباگر کنکوری) با کیفیت کامل پیاده‌سازی شده‌اند."
        : "نقص در پیاده‌سازی معادل‌های کنکوری گام Code میمو.",
    algorithmicFormula: "∃s1: type=token_assembly (|tokens|≥3, |distractors|≥1) ∧ ∃s2: type=trap_detector",
  });

  // --- Metric 5: Konkur Modifier, Formula & Exception Coverage (10 pts) ---
  let m5Score = 10;
  if (blueprint.konkurModifiersAndFormulas.length < 2) {
    m5Score -= 5;
    violations.push({
      code: "INSUFFICIENT_EXTRACTED_MODIFIERS",
      severity: "critical",
      field: "pedagogicalBlueprint.konkurModifiersAndFormulas",
      message: "در کالبدشکافی اولیه کمتر از ۲ قید کنکوری/فرمول/استثنا از متن کتاب استخراج شده است.",
      autoFixInstruction:
        "متن کتاب را مجدداً اسکن کرده و تمام قیدهای کمّی (همه، برخی، اغلب)، فرمول‌ها و استثنائات را استخراج کنید.",
    });
  }
  steps.forEach((s, idx) => {
    if (s.content.kind === "guided_cloze") {
      if (!s.content.templateWithBlank.includes("___")) {
        m5Score -= 5;
        violations.push({
          code: "CLOZE_MISSING_BLANK_PLACEHOLDER",
          severity: "critical",
          stepIndex: idx,
          field: `steps[${idx}].content.templateWithBlank`,
          message: `الگوی جای‌خالی در گام ${idx + 1} فاقد علامت استاندارد \`___\` است.`,
          autoFixInstruction: "محل دقیق قید یا متغیر کلیدی را با `___` مشخص کنید.",
        });
      }
      if (s.content.chipOptions.length < 3 || !s.content.chipOptions.includes(s.content.correctAnswer)) {
        m5Score -= 4;
        violations.push({
          code: "CLOZE_INVALID_CHIPS",
          severity: "critical",
          stepIndex: idx,
          field: `steps[${idx}].content.chipOptions`,
          message: `چیپ‌های انتخابی در گام ${idx + 1} باید حداقل ۳ گزینه داشته باشند و شامل پاسخ صحیح باشند.`,
          autoFixInstruction: "پاسخ صحیح را به همراه ۲ یا ۳ قید انحرافی در `chipOptions` قرار دهید.",
        });
      }
    }
  });
  m5Score = Math.max(0, m5Score);
  metrics.push({
    id: "M5_KONKUR_MODIFIER_COVERAGE",
    label: "۵. دقت مهندسی قیدها، فرمول‌ها و استثنائات کتاب درسی",
    score: m5Score,
    maxScore: 10,
    weight: 10,
    status: m5Score >= 9 ? "optimal" : m5Score >= 6 ? "warning" : "violation",
    diagnosticNote: `${blueprint.konkurModifiersAndFormulas.length} قید/فرمول کلیدی کتاب درسی استخراج و در گام‌های جای‌خالی قیددار قفل شده‌اند.`,
    algorithmicFormula: "|blueprint.modifiers| ≥ 2 ∧ ∀cloze: '___' ∈ template ∧ answer ∈ chipOptions",
  });

  // --- Metric 6: Diagnostic Distractor Engineering & 4-Option Autopsy (15 pts) ---
  let m6Score = 15;
  if (blueprint.designerTraps.length < 2) {
    m6Score -= 5;
    violations.push({
      code: "INSUFFICIENT_DESIGNER_TRAPS",
      severity: "critical",
      field: "pedagogicalBlueprint.designerTraps",
      message: "کمتر از ۲ تله طراح کنکور در نقشه پداگوژیک ثبت شده است.",
      autoFixInstruction: "حداقل ۲ تا ۳ کج‌فهمی رایج و تله طراح کنکور برای این مبحث تعریف کنید.",
    });
  }
  steps.forEach((s, idx) => {
    if (s.content.kind === "konkur_test") {
      if (s.content.optionDiagnostics.length !== 4) {
        m6Score -= 8;
        violations.push({
          code: "INCOMPLETE_4_OPTION_DIAGNOSTICS",
          severity: "critical",
          stepIndex: idx,
          field: `steps[${idx}].content.optionDiagnostics`,
          message: `تست کنکور گام ${idx + 1} فاقد کالبدشکافی کامل هر ۴ گزینه است (${s.content.optionDiagnostics.length} از ۴ گزینه تحلیل شده).`,
          autoFixInstruction:
            "برای هر ۴ گزینه، برچسب تله شناختی (`trapOrMisconceptionLabel`) و تحلیل تشریحی کامل (`detailedAnalysis`) بنویسید.",
        });
      } else {
        s.content.optionDiagnostics.forEach((diag, oIdx) => {
          if (countPersianWords(diag.detailedAnalysis) < 7) {
            m6Score -= 3;
            violations.push({
              code: "SHALLOW_OPTION_ANALYSIS",
              severity: "warning",
              stepIndex: idx,
              field: `steps[${idx}].content.optionDiagnostics[${oIdx}]`,
              message: `تحلیل گزینه ${oIdx + 1} در تست کنکور بیش از حد کوتاه و سطحی است.`,
              autoFixInstruction:
                "دلیل علمی درستی یا تله انحرافی گزینه را حداقل در ۱۰ کلمه با ارجاع به قید یا فرمول تشریح کنید.",
            });
          }
        });
      }
      if (!s.content.eliminationShortcut || countPersianWords(s.content.eliminationShortcut) < 6) {
        m6Score -= 4;
        violations.push({
          code: "MISSING_ELIMINATION_SHORTCUT",
          severity: "warning",
          stepIndex: idx,
          field: `steps[${idx}].content.eliminationShortcut`,
          message: `تست کنکور گام ${idx + 1} فاقد «تکنیک سرعتی رد گزینه» برای حل زیر ۴۵ ثانیه است.`,
          autoFixInstruction: "روش حذف سریع ۲ گزینه یا تکنیک کلیدواژه/تحلیل ابعادی را اضافه کنید.",
        });
      }
    }
  });
  m6Score = Math.max(0, m6Score);
  metrics.push({
    id: "M6_DISTRACTOR_DIAGNOSTICS",
    label: "۶. مهندسی گزینه‌های انحرافی و کالبدشکافی ۴ گزینه تست",
    score: m6Score,
    maxScore: 15,
    weight: 15,
    status: m6Score >= 13 ? "optimal" : m6Score >= 9 ? "warning" : "violation",
    diagnosticNote:
      m6Score === 15
        ? "تک‌تک گزینه‌های تست نهایی دارای برچسب تله شناختی، کالبدشکافی تشریحی و تکنیک رد گزینه سرعتی هستند."
        : "کالبدشکافی گزینه‌های انحرافی یا تکنیک رد گزینه نیازمند تکمیل است.",
    algorithmicFormula: "∀test: |optionDiagnostics| = 4 ∧ ∀d: words(d.detailedAnalysis) ≥ 7 ∧ words(shortcut) ≥ 6",
  });

  // --- Metric 7: Multi-Tier Feedback Loop (Nudge Hint + Deep Explanation) (10 pts) ---
  let m7Score = 10;
  steps.forEach((s, idx) => {
    if (s.content.kind === "guided_cloze" || s.content.kind === "token_assembly") {
      if (!s.content.nudgeHint || countPersianWords(s.content.nudgeHint) < 4) {
        m7Score -= 4;
        violations.push({
          code: "MISSING_NUDGE_HINT",
          severity: "warning",
          stepIndex: idx,
          field: `steps[${idx}].content.nudgeHint`,
          message: `گام تعاملی ${idx + 1} فاقد «راهنمای لایه اول (Nudge Hint)» برای کمک بدون لو دادن جواب است.`,
          autoFixInstruction: "یک راهنمای کوتاه که ذهن دانش‌آموز را به قاعده اصلی هدایت کند بنویسید.",
        });
      }
    }
  });
  m7Score = Math.max(0, m7Score);
  metrics.push({
    id: "M7_MULTI_TIER_FEEDBACK",
    label: "۷. حلقه بازخورد چندلایه (راهنمای غیرلو‌دهنده + تشریح علّی)",
    score: m7Score,
    maxScore: 10,
    weight: 10,
    status: m7Score >= 9 ? "optimal" : m7Score >= 6 ? "warning" : "violation",
    diagnosticNote: "تمام گام‌های تعاملی دارای راهنمای لایه اول (Hint) و بازخورد تشریحی پس از پاسخ هستند.",
    algorithmicFormula: "∀interactive_step: words(nudgeHint) ≥ 4 ∧ words(explanation) ≥ 8",
  });

  // --- Metric 8: Atomic Concept Graph Coverage (10 pts) ---
  let m8Score = 10;
  const conceptIds = new Set(blueprint.atomicConcepts.map((c) => c.id));
  const coveredConceptIds = new Set(steps.map((s) => s.conceptNodeId));
  const uncovered = [...conceptIds].filter((id) => !coveredConceptIds.has(id));
  if (blueprint.atomicConcepts.length < 3) {
    m8Score -= 5;
    violations.push({
      code: "SPARSE_CONCEPT_GRAPH",
      severity: "critical",
      field: "pedagogicalBlueprint.atomicConcepts",
      message: "گراف مفاهیم اتمی کمتر از ۳ گره مفهومی دارد.",
      autoFixInstruction: "متن کتاب را به حداقل ۳ تا ۵ گره مفهومی مستقل بشکنید.",
    });
  }
  if (uncovered.length > 0) {
    m8Score -= Math.min(8, uncovered.length * 4);
    violations.push({
      code: "ORPHAN_CONCEPT_NODES",
      severity: "critical",
      field: "steps",
      message: `گره‌های مفهومی [${uncovered.join(", ")}] در گراف استخراج شده‌اند اما هیچ گامی در درسنامه آن‌ها را پوشش نداده است!`,
      autoFixInstruction: "مطمئن شوید هر گره مفهومی استخراج‌شده در حداقل یک گام آموزشی یا تعاملی تدریس و سنجش می‌شود.",
    });
  }
  m8Score = Math.max(0, m8Score);
  metrics.push({
    id: "M8_CONCEPT_GRAPH_COMPLETENESS",
    label: "۸. پوشش ۱۰۰٪ گراف مفاهیم اتمی کتاب درسی",
    score: m8Score,
    maxScore: 10,
    weight: 10,
    status: m8Score >= 9 ? "optimal" : m8Score >= 6 ? "warning" : "violation",
    diagnosticNote: `${coveredConceptIds.size} از ${conceptIds.size} گره مفهومی اتمی به طور کامل در گام‌ها نگاشت و سنجش شده‌اند.`,
    algorithmicFormula: "∀c ∈ blueprint.atomicConcepts: ∃step ∈ steps: step.conceptNodeId = c.id",
  });

  // --- Metric 9: Anti-Hallucination & Anti-Generic Filler Gate (5 pts) ---
  let m9Score = 5;
  const serializedSteps = JSON.stringify(steps);
  for (const phrase of BANNED_GENERIC_PHRASES) {
    if (serializedSteps.includes(phrase)) {
      m9Score = 0;
      violations.push({
        code: "GENERIC_LAZY_AGENT_FILLER",
        severity: "critical",
        field: "steps",
        message: `عبارت کلیشه‌ای و تنبلانه «${phrase}» در خروجی ایجنت شناسایی شد!`,
        autoFixInstruction:
          "عبارات کلیشه‌ای را حذف کرده و علت علمی دقیق درستی یا نادرستی را بر اساس رابطه علّی یا قید کتاب بنویسید.",
      });
    }
  }
  metrics.push({
    id: "M9_ANTI_GENERIC_FILLER_GATE",
    label: "۹. فیلتر ضدکلی‌گویی و ممنوعیت پاسخ‌های قالبی ایجنت",
    score: m9Score,
    maxScore: 5,
    weight: 5,
    status: m9Score === 5 ? "optimal" : "violation",
    diagnosticNote:
      m9Score === 5
        ? "هیچ عبارت کلیشه‌ای یا توضیح سطحی در گام‌ها و پاسخبرگ‌ها وجود ندارد."
        : "عبارات کلیشه‌ای در تحلیل گزینه‌ها شناسایی شد.",
    algorithmicFormula: "∀phrase ∈ BANNED_GENERIC_PHRASES: phrase ∉ serialize(steps)",
  });

  // --- Metric 10: Modality Diversity & Dopamine Pacing Rhythm (5 pts) ---
  let m10Score = 5;
  const distinctTypes = new Set(steps.map((s) => s.type));
  if (distinctTypes.size < 5) {
    m10Score -= 3;
    violations.push({
      code: "LOW_MODALITY_DIVERSITY",
      severity: "warning",
      field: "steps",
      message: `تنها از ${distinctTypes.size} نوع گام استفاده شده است (استاندارد میمو-کنکور: حداقل ۵ نوع مکانیک متنوع در هر درس).`,
      autoFixInstruction:
        "ترکیب کامل ۶ مکانیک (`concept_bite`, `guided_cloze`, `token_assembly`, `trap_detector`, `step_solver`, `konkur_test`) را به کار ببرید.",
    });
  }
  m10Score = Math.max(0, m10Score);
  metrics.push({
    id: "M10_DOPAMINE_PACING_RHYTHM",
    label: "۱۰. تنوع مکانیک‌های تعاملی و ریتم دوپامین (Modality Variety)",
    score: m10Score,
    maxScore: 5,
    weight: 5,
    status: m10Score === 5 ? "optimal" : "warning",
    diagnosticNote: `${distinctTypes.size} مکانیک تعاملی متمایز در طول ${steps.length} گام با ریتم ۵ دقیقه‌ای.`,
    algorithmicFormula: "|Unique(step.type)| ≥ 5 ∧ 6 ≤ |steps| ≤ 8",
  });

  const overallScore = metrics.reduce((acc, m) => acc + m.score, 0);
  const criticalCount = violations.filter((v) => v.severity === "critical").length;
  const passedGate = overallScore >= 85 && criticalCount === 0;

  let gradeBadge: QualityAuditReport["gradeBadge"] = "F (رد شده توسط گاردریل)";
  if (passedGate && overallScore >= 94) {
    gradeBadge = "A+ (تراز میمو-سنجش)";
  } else if (passedGate) {
    gradeBadge = "A (استاندارد)";
  } else if (overallScore >= 70) {
    gradeBadge = "B (نیازمند بازبینی)";
  }

  return {
    overallScore,
    passedGate,
    gradeBadge,
    metrics,
    violations,
  };
}

// ============================================================================
// 4. موتور کامپایلر الگوریتمی کتاب کنکور به درسنامه میمو (Agent Compiler & Auto-Repair)
// ============================================================================

export type CompilationInput = {
  subject: string;
  grade: string;
  topicTitle: string;
  chapterReference: string;
  rawTextbookExcerpt: string;
  simulateNaiveAgentFirst?: boolean;
};

export type CompiledLessonArtifact = {
  title: string;
  chapterReference: string;
  rawTextbookExcerpt: string;
  xpReward: number;
  estimatedMinutes: number;
  pedagogicalBlueprint: PedagogicalBlueprint;
  steps: {
    type: StepKind;
    conceptNodeId: string;
    scaffoldingLevel: number;
    cognitiveLoadWords: number;
    content: KonkurStepContent;
  }[];
  initialNaiveAudit?: QualityAuditReport;
  finalAudit: QualityAuditReport;
  autoRepairLog: string[];
};

/**
 * هوشمندانه متن خام هر کتاب کنکوری را کالبدشکافی کرده و در صورت وجود کلیدهای تخصصی
 * یا هر متن دلخواه، گراف مفهومی، قیدها، تله‌های طراح و ۶ گام استاندارد میمو-کنکور را می‌سازد.
 */
export function compileTextbookToMimoLesson(input: CompilationInput): CompiledLessonArtifact {
  const text = input.rawTextbookExcerpt.trim();
  const sentences = text
    .split(/[.!؟\n]+/)
    .map((s) => s.trim())
    .filter((s) => s.length > 12);

  const s1 =
    sentences[0] ||
    `در مبحث ${input.topicTitle}، شناخت دقیق رابطه میان متغیرها و قیدهای کتاب درسی پایه حل تست‌های ترکیبی است`;
  const s2 =
    sentences[1] ||
    `هرگاه شرط اول برقرار باشد، فرآیند به صورت مرحله‌به‌مرحله پیش می‌رود اما استثناهای مهمی در شرایط مرزی وجود دارد`;
  const s3 =
    sentences[2] ||
    `طراحان کنکور اغلب با جابه‌جایی قیدهای کمّی یا تغییر علامت و یکا، گزینه‌های انحرافی فریبنده طراحی می‌کنند`;

  // Detect domain keywords to tailor isomorphic mechanics
  const isBio =
    input.subject.includes("زیست") ||
    /آنزیم|سلول|یاخته|رونویسی|پروتئین|ژن|هورمون|عصب|خون|قلب|کلیه|گیاه/.test(text);
  const isPhysics =
    input.subject.includes("فیزیک") ||
    /شتاب|سرعت|نیرو|انرژی|جریان|مقاومت|میدان|موج|فشار|دما|حرکت/.test(text);
  const isChem =
    input.subject.includes("شیمی") ||
    /مول|اتم|الکترون|واکنش|اسید|باز|یون|پیوند|جدول تناوبی|اکسایش|استوکیومتری/.test(text);
  const isMath =
    input.subject.includes("ریاضی") ||
    input.subject.includes("حسابان") ||
    /تابع|مشتق|حد|انتگرال|معادله|دامنه|پیوسته|ماتریس|احتمال/.test(text);

  // Extract modifiers found in text or synthesize domain-accurate ones
  const detectedModifierWords = [
    "همه",
    "برخی",
    "اغلب",
    "بیشتر",
    "همواره",
    "مستقیماً",
    "به‌جز",
    "تنها",
    "بدون",
    "الزاماً",
  ].filter((m) => text.includes(m));

  const primaryModifier =
    detectedModifierWords[0] || (isBio ? "برخی" : isChem ? "اغلب" : "همواره");

  const atomicConcepts: AtomicConceptNode[] = [
    {
      id: "C1_CORE_PRINCIPLE",
      title: `قاعده و سازوکار پایه در ${input.topicTitle}`,
      textbookQuote: s1,
      cognitiveLevel: "understand",
      isPrerequisite: true,
      targetMechanic: "concept_bite",
    },
    {
      id: "C2_MODIFIER_PRECISION",
      title: `قیدهای حساس و شروط مرزی (${primaryModifier})`,
      textbookQuote: s2,
      cognitiveLevel: "apply",
      isPrerequisite: false,
      targetMechanic: "guided_cloze",
    },
    {
      id: "C3_SEQUENTIAL_MECHANISM",
      title: isPhysics || isMath
        ? `زنجیره استنتاج فرمول و رابطه در ${input.topicTitle}`
        : isChem
          ? `مسیر تبدیل استوکیومتری و واکنش در ${input.topicTitle}`
          : `توالی مرحله‌به‌مرحله مکانیزم در ${input.topicTitle}`,
      textbookQuote: `${s1} ← ${s2}`,
      cognitiveLevel: "apply",
      isPrerequisite: false,
      targetMechanic: "token_assembly",
    },
    {
      id: "C4_DESIGNER_TRAP_DEFENSE",
      title: `شکار تله‌های طراح کنکور و استثنائات ${input.topicTitle}`,
      textbookQuote: s3,
      cognitiveLevel: "analyze",
      isPrerequisite: false,
      targetMechanic: "trap_detector",
    },
  ];

  const prerequisiteChain = [
    {
      fromId: "C1_CORE_PRINCIPLE",
      toId: "C2_MODIFIER_PRECISION",
      relation: "درک مفهوم پایه پیش‌نیاز تشخیص قید و شرط مرزی است",
    },
    {
      fromId: "C2_MODIFIER_PRECISION",
      toId: "C3_SEQUENTIAL_MECHANISM",
      relation: "تثبیت قیدها پیش‌نیاز چیدمان درست زنجیره علّی/فرمولی است",
    },
    {
      fromId: "C3_SEQUENTIAL_MECHANISM",
      toId: "C4_DESIGNER_TRAP_DEFENSE",
      relation: "تسلط بر زنجیره استاندارد پیش‌نیاز کشف تله و باگ در تست کنکور است",
    },
  ];

  const konkurModifiersAndFormulas: KonkurModifierItem[] = [
    {
      id: "MOD_1",
      phrase: `قید کلیدی «${primaryModifier}» در گزاره: ${s1.slice(0, 75)}`,
      category: "قید کمّی (همه/برخی/اغلب)",
      explanation: `تغییر قید «${primaryModifier}» به «همه» یا «هیچ‌یک» رایج‌ترین تله طراح کنکور در مبحث ${input.topicTitle} است.`,
    },
    {
      id: "MOD_2",
      phrase: isPhysics || isMath
        ? "شرط سازگاری علامت، دامنه و یکاهای استاندارد SI در رابطه"
        : isChem
          ? "نسبت ضرایب استوکیومتری مولی در معادله موازنه‌شده"
          : "ترتیب تقدم و تاخر مراحل و اختصاصی بودن عملگرها",
      category: isPhysics || isMath ? "فرمول و رابطه کلیدی" : "ترتیب و توالی مکانیزم",
      explanation: `رعایت دقیق ترتیب و شرط مرزی در "${s2.slice(0, 70)}" مانع از افتادن در دام گزینه‌های معکوس می‌شود.`,
    },
  ];

  const designerTraps: DesignerTrapItem[] = [
    {
      id: "TRAP_1",
      trapTitle: `تله تعمیم قیدی در ${input.topicTitle}`,
      trapCategory: "تله قیدی",
      commonWrongBelief: `دانش‌آموز تصور می‌کند حکم مطرح‌شده در «${s1.slice(0, 55)}...» بدون استثنا و برای تمام حالات برقرار است.`,
      scientificTruth: `طبق نص صریح کتاب درسی، این ویژگی مقید به شرط مرزی بوده و تعمیم مطلق آن نادرست است.`,
    },
    {
      id: "TRAP_2",
      trapTitle: isPhysics || isMath
        ? "تله علامت برداری و شرط برقراری فرمول"
        : "تله جابه‌جایی تقدم و تاخر یا خلط عامل و محصول",
      trapCategory: isPhysics || isMath ? "تله واحد و علامت" : "تله تقدم و تاخر",
      commonWrongBelief: `جابه‌جا گرفتن ترتیب مراحل در «${s2.slice(0, 55)}...» هنگام حل سریع تست.`,
      scientificTruth: `مراحل دارای تقدم علّی غیرقابل تعویض هستند و هر مرحله پیش‌نیاز شروع مرحله بعدی است.`,
    },
  ];

  const pedagogicalBlueprint: PedagogicalBlueprint = {
    atomicConcepts,
    prerequisiteChain,
    konkurModifiersAndFormulas,
    designerTraps,
    missingLinkMapping: {
      mimoOriginalMechanic:
        "گام‌های Code Writing (چیدمان توکن‌های سینتکس) و Code Debugging (کشف خطای خط کد)",
      konkurIsomorphicMechanic: isPhysics || isMath
        ? "چیدمان بلوکی اشتقاق فرمول (`formula_derivation`) + کشف باگ راه‌حل مسئله (`math_solution_bug`)"
        : isChem
          ? "چیدمان خط لوله استوکیومتری/واکنش (`stoichiometry_pipeline`) + شکارچی استثنائات (`chemistry_exception`)"
          : "چیدمان زنجیره علّی مکانیزم (`causal_chain`) + کالبدشکافی گزاره ترکیبی (`statement_autopsy`)",
      bridgingRationale:
        "به جای حذف گام کدنویسی میمو و تنزل به تست چهارگزینه‌ای سنتی، دانش‌آموز ابتدا ساختار مفهومی/فرمولی را بلوک‌به‌بلوک می‌سازد و تله طراح را دیباگ می‌کند، سپس وارد تست نهایی می‌شود.",
    },
  };

  // Build the 6 Canonical Mimo-Konkur Steps
  const step1Body = `در مبحث **${input.topicTitle}**، هسته اصلی کتاب درسی بر این اصل استوار است:\n\n> ${s1}.\n\nدر گام بعدی، ${s2}. دقت به قید **«${primaryModifier}»** مرز بین پاسخ درست و تله کنکور را مشخص می‌کند.`;

  const steps: CompiledLessonArtifact["steps"] = [
    {
      type: "concept_bite",
      conceptNodeId: "C1_CORE_PRINCIPLE",
      scaffoldingLevel: 1,
      cognitiveLoadWords: countPersianWords(step1Body),
      content: {
        kind: "concept_bite",
        title: `لقمه مفهومی: هسته طلایی ${input.topicTitle}`,
        hookAnalogy:
          "تصور کنید یک قفل رمزی دو مرحله‌ای دارید؛ اگر شرط اول (قید کتاب) بررسی نشود، حتی با فرمول درست هم به گزینه غلط می‌رسید!",
        bodyMarkdown: step1Body,
        highlightedModifiers: [primaryModifier, input.topicTitle],
        coreFormulaOrRule: `${input.topicTitle}: شرط مرزی (${primaryModifier})  اجرای مرحله‌به‌مرحله مکانیزم  بررسی استثنا`,
        interactiveCheckQuestion: `آیا در مبحث «${input.topicTitle}» می‌توان بدون توجه به قید محدودکننده (${primaryModifier}) حکم را به تمام حالات تعمیم داد؟`,
        interactiveCheckAnswer: false,
        interactiveCheckExplanation:
          "خیر! تعمیم مطلق بدون توجه به قید و شرط مرزی کتاب درسی، دقیقاً همان تله‌ای است که طراح کنکور در گزینه اول قرار می‌دهد.",
      },
    },
    {
      type: "guided_cloze",
      conceptNodeId: "C2_MODIFIER_PRECISION",
      scaffoldingLevel: 2,
      cognitiveLoadWords: 38,
      content: {
        kind: "guided_cloze",
        prompt: `قید یا کلیدواژه دقیق کتاب درسی را در جای خالی قرار دهید تا گزاره از نظر علمی و کنکوری کاملاً صحیح شود:`,
        templateWithBlank: `بر اساس متن کتاب درسی در مبحث ${input.topicTitle}، این قاعده در ___ مواردِ واجد شرط مرزی صادق است: «${s1.slice(0, 65)}».`,
        correctAnswer: primaryModifier,
        chipOptions: [primaryModifier, "هیچ‌یک از", "صرفاً خارج از", "برخلاف تمام"],
        targetedModifierId: "MOD_1",
        nudgeHint: `به محدوده شمول حکم در جمله اول کتاب درسی دقت کنید؛ آیا حکم مطلق و منفی است یا مقید به «${primaryModifier}»؟`,
        deepExplanation: `کلمه کلیدی «${primaryModifier}» قید تعیین‌کننده این گزاره در کتاب درسی است و جایگزینی آن با عبارات سلبی یا مطلق، ارزش گزاره را تغییر می‌دهد.`,
      },
    },
    {
      type: "token_assembly",
      conceptNodeId: "C3_SEQUENTIAL_MECHANISM",
      scaffoldingLevel: 3,
      cognitiveLoadWords: 45,
      content: {
        kind: "token_assembly",
        prompt: `بلوک‌های زیر را به ترتیب صحیح علمی بچینید تا زنجیره استاندارد «${input.topicTitle}» کامل شود (مراقب بلوک‌های تله باشید!):`,
        assemblyMode: isPhysics || isMath
          ? "formula_derivation"
          : isChem
            ? "stoichiometry_pipeline"
            : "causal_chain",
        orderedTokens: [
          `۱. احراز شرط اولیه: ${s1.slice(0, 42)}`,
          `۲. اعمال قید و مکانیزم: ${s2.slice(0, 42)}`,
          `۳. نتیجه‌گیری و کنترل استثنا: ${s3.slice(0, 42)}`,
        ],
        distractorTokens: [
          {
            token: "تله: حذف شرط مرزی و تعمیم به تمام حالات بدون استثنا",
            trapReason:
              "این بلوک تله تعمیم افراطی است؛ در کنکور حذف شرط اولیه باعث انتخاب گزینه انحرافی می‌شود.",
          },
          {
            token: "تله: معکوس کردن تقدم علّی مرحله اول و دوم",
            trapReason:
              "در این مکانیزم، مرحله دوم وابسته به خروجی مرحله اول است و جابه‌جایی آن‌ها علمی نیست.",
          },
        ],
        nudgeHint:
          "ابتدا بلوک مربوط به شرط آغازین (پاراگراف اول کتاب) را انتخاب کنید، سپس مکانیزم میانی و در نهایت نتیجه را قرار دهید.",
        assemblyExplanation:
          "در متدولوژی میمو-کنکور، ساختن مرحله‌به‌مرحله زنجیره علّی باعث می‌شود ترتیب مراحل در حافظه بلندمدت تثبیت شده و در تست‌های ترتیبی سردرگم نشوید.",
      },
    },
    {
      type: "trap_detector",
      conceptNodeId: "C4_DESIGNER_TRAP_DEFENSE",
      scaffoldingLevel: 4,
      cognitiveLoadWords: 52,
      content: {
        kind: "trap_detector",
        prompt:
          "شکارچی تله کنکور (دیباگر): در گزاره/راه‌حل ۴ بخشی زیر، دقیقاً یک بخش توسط طراح دستکاری شده و دارای باگ علمی است. روی بخش معیوب ضربه بزنید و اصلاحیه درست را انتخاب کنید:",
        contextType: isPhysics || isMath
          ? "math_solution_bug"
          : isChem
            ? "chemistry_exception"
            : "statement_autopsy",
        segments: [
          `بخش اول: در بررسی مبحث ${input.topicTitle}، ${s1.slice(0, 50)}`,
          `بخش دوم: در ادامه این روند، ${s2.slice(0, 50)}`,
          `بخش سوم (تله): این قاعده بدون هیچ شرط مرزی و در ۱۰۰٪ حالات استثناپذیر نیز به طور معکوس عمل می‌کند`,
          `بخش چهارم: بنابراین تشخیص دقیق شروط کتاب درسی برای تعیین درستی گزاره الزامی است`,
        ],
        flawedSegmentIndex: 2,
        trapCategory: "تله تعمیم افراطی و معکوس‌سازی جهت رابطه",
        fixOptions: [
          `اصلاحیه صحیح: این قاعده مقید به قید «${primaryModifier}» و شروط مرزی کتاب درسی بوده و در جهت استاندارد عمل می‌کند.`,
          "اصلاحیه غلط ۱: این قاعده در هیچ حالتی در کتاب درسی مطرح نشده است.",
          "اصلاحیه غلط ۲: بخش اول و دوم هر دو باید به طور کامل حذف شوند.",
        ],
        correctFixIndex: 0,
        diagnosticAutopsy:
          "طراح کنکور در بخش سوم از تکنیک «پروانه و سندان» استفاده کرده است: دو بخش اول گزاره کاملاً منطبق بر متن کتاب درسی است تا اعتماد شما جلب شود، اما در بخش سوم قید را مطلق کرده و جهت رابطه را برعکس نموده است!",
      },
    },
    {
      type: "step_solver",
      conceptNodeId: "C3_SEQUENTIAL_MECHANISM",
      scaffoldingLevel: 5,
      cognitiveLoadWords: 56,
      content: {
        kind: "step_solver",
        problemStatement: `پیش از ورود به تست زمان‌دار کنکور، بیایید یک مسئله ترکیبی از «${input.topicTitle}» را در ۲ گام هدایت‌شده حل کنیم:`,
        subSteps: [
          {
            stageLabel: "گام اول: تشخیص کلیدواژه و تیپ سوال",
            question: `وقتی در صورت سوال کنکور از مبحث «${input.topicTitle}» عبارتی درباره «${s1.slice(0, 40)}...» می‌بینیم، اولین نقطه کنترل چیست؟`,
            options: [
              `بررسی قید «${primaryModifier}» و شرط مرزی پیش از محاسبه یا قضاوت`,
              "حذف فوری تمام گزینه‌هایی که عدد یا قید دارند",
              "نادیده گرفتن متن کتاب و تکیه بر حدس شهودی",
            ],
            correctIndex: 0,
            microFeedback:
              "عالی! اولین قدم در الگوریتم حل تست کنکور، قفل کردن روی قید و شرط مرزی صورت سوال است.",
          },
          {
            stageLabel: "گام دوم: اعمال مکانیزم و حذف تله",
            question: `پس از تایید شرط اول، کدام نتیجه با بخش «${s2.slice(0, 40)}...» سازگار است؟`,
            options: [
              "نتیجه‌ای که ترتیب علّی مراحل را حفظ کرده و استثنائات را لحاظ کند",
              "نتیجه‌ای که مراحل را معکوس کرده تا سریع‌تر به جواب برسد",
              "نتیجه‌ای که قید «هیچ‌یک» را جایگزین قید کتاب درسی کند",
            ],
            correctIndex: 0,
            microFeedback:
              "دقیقاً درست است! حفظ ترتیب مراحل و رعایت استثنا، شما را به گزینه صحیح می‌رساند.",
          },
        ],
        finalTakeaway:
          "با شکستن تست کنکور به دو تصمیم کوچک (۱. کنترل قید/شرط + ۲. کنترل ترتیب مکانیزم)، احتمال خطای بی‌دقتی به صفر می‌رسد.",
      },
    },
    {
      type: "konkur_test",
      conceptNodeId: "C4_DESIGNER_TRAP_DEFENSE",
      scaffoldingLevel: 6,
      cognitiveLoadWords: 68,
      content: {
        kind: "konkur_test",
        questionStem: `کدام‌یک از گزینه‌های زیر، درباره مبحث «${input.topicTitle}» (${input.chapterReference}) از نظر علمی و منطبق بر کتاب درسی کاملاً صحیح است؟`,
        sourceBadge: `تست استاندارد تراز کنکور سراسری - ${input.subject} (${input.grade})`,
        targetTimeSeconds: 45,
        options: [
          `در چارچوب شروط کتاب درسی (${primaryModifier})، ${s1.slice(0, 55)} و در ادامه ${s2.slice(0, 45)}.`,
          `در ۱۰۰٪ حالات و بدون نیاز به هیچ شرط اولیه‌ای، ${s1.slice(0, 50)} به صورت معکوس رخ می‌دهد.`,
          `مراحل مطرح‌شده در ${input.topicTitle} فاقد هرگونه ترتیب تقدم و تاخر بوده و هم‌زمان رخ می‌دهند.`,
          `قید مطرح‌شده در کتاب درسی برای ${input.topicTitle} صرفاً «هیچ‌یک» بوده و هیچ مصداق فعالی ندارد.`,
        ],
        correctIndex: 0,
        optionDiagnostics: [
          {
            optionIndex: 0,
            isCorrect: true,
            trapOrMisconceptionLabel: "گزینه صحیح (منطبق بر قید و ترتیب علّی کتاب درسی)",
            detailedAnalysis: `این گزینه هم قید کلیدی «${primaryModifier}» را رعایت کرده و هم توالی صحیح بین «${s1.slice(0, 35)}» و «${s2.slice(0, 35)}» را حفظ نموده است.`,
          },
          {
            optionIndex: 1,
            isCorrect: false,
            trapOrMisconceptionLabel: "تله تعمیم افراطی (حذف شرط مرزی + معکوس‌سازی)",
            detailedAnalysis:
              "طراح با عبارت «در ۱۰۰٪ حالات و بدون نیاز به شرط اولیه» تله تعمیم مطلق ساخته و جهت فرآیند را نیز برعکس کرده است.",
          },
          {
            optionIndex: 2,
            isCorrect: false,
            trapOrMisconceptionLabel: "تله تقدم و تاخر (انکار ترتیب مراحل مکانیزم)",
            detailedAnalysis:
              "برخلاف ادعای این گزینه، مراحل دارای ترتیب علّی مشخصی هستند که در گام چیدمان بلوکی آن را ساختیم.",
          },
          {
            optionIndex: 3,
            isCorrect: false,
            trapOrMisconceptionLabel: "تله تحریف قید به سلب کلی (هیچ‌یک)",
            detailedAnalysis: `تبدیل قید کتاب درسی («${primaryModifier}») به قید سلبی «هیچ‌یک» یک خطای قیدی آشکار برای فریب داوطلبان عجول است.`,
          },
        ],
        eliminationShortcut: `تکنیک رد گزینه زیر ۲۰ ثانیه: به محض دیدن قیدهای مطلقِ جعلی «در ۱۰۰٪ حالات بدون شرط» در گزینه ۲ و «هیچ‌یک» در گزینه ۴، این دو گزینه رد می‌شوند؛ بین گزینه ۱ و ۳ نیز تقدم مراحل گزینه ۱ را تثبیت می‌کند.`,
      },
    },
  ];

  // If requested, simulate what a Naive Agent produces on old Mimo forms vs. our Guardrail Engine
  let initialNaiveAudit: QualityAuditReport | undefined;
  const autoRepairLog: string[] = [];

  if (input.simulateNaiveAgentFirst) {
    const naiveSteps: CompiledLessonArtifact["steps"] = [
      {
        type: "concept_bite",
        conceptNodeId: "C1_CORE_PRINCIPLE",
        scaffoldingLevel: 1,
        cognitiveLoadWords: 115,
        content: {
          kind: "concept_bite",
          title: `درسنامه خام ${input.topicTitle}`,
          hookAnalogy: "",
          bodyMarkdown: `${text} ${text} در این بخش تمامی مطالب کتاب درسی به صورت یکجا و بدون خرده‌سازی کپی شده است تا دانش‌آموز همه صفحه را یکجا بخواند و حفظ کند و هیچ سوال تعاملی هم در انتهای کارت وجود ندارد و بار شناختی بسیار بالاست.`,
          highlightedModifiers: [],
          coreFormulaOrRule: "",
          interactiveCheckQuestion: "",
          interactiveCheckAnswer: true,
          interactiveCheckExplanation: "",
        },
      },
      {
        type: "concept_bite",
        conceptNodeId: "C1_CORE_PRINCIPLE",
        scaffoldingLevel: 1,
        cognitiveLoadWords: 45,
        content: {
          kind: "concept_bite",
          title: "ادامه متن بدون تعامل",
          hookAnalogy: "",
          bodyMarkdown: "اسلاید متنی دوم بلافاصله بعد از اسلاید متنی اول که باعث اسکرول غیرفعال و افت تمرکز می‌شود.",
          highlightedModifiers: [],
          coreFormulaOrRule: "",
          interactiveCheckQuestion: "",
          interactiveCheckAnswer: true,
          interactiveCheckExplanation: "",
        },
      },
      {
        type: "konkur_test",
        conceptNodeId: "C1_CORE_PRINCIPLE",
        scaffoldingLevel: 6,
        cognitiveLoadWords: 40,
        content: {
          kind: "konkur_test",
          questionStem: `کدام گزینه درباره ${input.topicTitle} درست است؟`,
          sourceBadge: "تست خام ایجنت",
          targetTimeSeconds: 60,
          options: ["گزینه اول", "گزینه دوم", "گزینه سوم", "گزینه چهارم"],
          correctIndex: 0,
          optionDiagnostics: [
            {
              optionIndex: 0,
              isCorrect: true,
              trapOrMisconceptionLabel: "صحیح",
              detailedAnalysis: "طبق متن کتاب درسی گزینه صحیح است و سایر گزینه‌ها نادرست هستند.",
            },
          ],
          eliminationShortcut: "",
        },
      },
    ];

    initialNaiveAudit = evaluatePedagogicalFidelity(pedagogicalBlueprint, naiveSteps);
    autoRepairLog.push(
      `[گاردریل مرحله ۱] خروجی اولیه ایجنت خام با نمره ${initialNaiveAudit.overallScore}/100 و ${initialNaiveAudit.violations.length} خطای پداگوژیک مسدود شد (Blocked by Guardrail).`,
      `[تعمیر خودکار M1 & M2] دیوار متنی ۱۱۵ کلمه‌ای شکسته شد، قلاب شهودی (Hook Analogy) و میکرو-سوال پایان کارت تزریق گردید و دو اسلاید متنی متوالی حذف شدند.`,
      `[تعمیر خودکار M4 - حلقه مفقوده] گام‌های هم‌ریخت Code میمو شامل «چیدمان بلوکی (token_assembly)» با ۲ بلوک تله و «شکارچی تله طراح (trap_detector)» ساخته و در سطح داربست ۳ و ۴ جایگذاری شدند.`,
      `[تعمیر خودکار M6 & M9] عبارت کلیشه‌ای «سایر گزینه‌ها نادرست هستند» پاک‌سازی شد و ماتریس کالبدشکافی هر ۴ گزینه به همراه تکنیک سرعتی رد گزینه تکمیل گردید.`,
    );
  }

  const finalAudit = evaluatePedagogicalFidelity(pedagogicalBlueprint, steps);

  return {
    title: input.topicTitle,
    chapterReference: input.chapterReference,
    rawTextbookExcerpt: input.rawTextbookExcerpt,
    xpReward: 45,
    estimatedMinutes: 5,
    pedagogicalBlueprint,
    steps,
    initialNaiveAudit,
    finalAudit,
    autoRepairLog,
  };
}

// ============================================================================
// 5. قرارداد رسمی و سیستم‌پرامپت الگوریتمی برای هر ایجنت هوش مصنوعی (Agent Spec)
// ============================================================================

export const AGENT_PEDAGOGICAL_COMPILER_PROMPT = `# دستورالعمل الگوریتمی کامپایلر پداگوژیک «میمو-کنکور» (Mimo-Konkur Agent Pedagogical Protocol v2.0)

شما یک «فرم‌پرکن ساده» نیستید؛ شما یک **کامپایلر پداگوژیک مقید به گاردریل (Constraint-Driven Pedagogical Compiler)** هستید که وظیفه دارد هر مبحث از کتاب‌های درسی و کمک‌درسی کنکور ایران را بدون کوچک‌ترین افت کیفیت به ساختار میکرو-لرنینگ تعاملی **Mimo** تبدیل کند.

## چرا پر کردن مستقیم فرم‌های قدیمی میمو برای کنکور شکست می‌خورد؟ (حلقه مفقوده)
در سیستم اصلی میمو (مخصوص آموزش برنامه‌نویسی)، ۴ نوع گام وجود دارد: \`text\`, \`quiz\`, \`fill\`, \`code\`.
وقتی یک ایجنت معمولی کتاب کنکور (زیست، فیزیک، شیمی، ریاضی، انسانی) را می‌گیرد:
1. گام \`text\` را با خلاصه‌نویسی طولانی و خسته‌کننده پر می‌کند (نقض سقف حافظه فعال).
2. گام \`code\` را به دلیل نبود کد پایتون/SQL حذف می‌کند و کل درس را به چند تست ۴ گزینه‌ای تقلیل می‌دهد!
3. گزینه‌های غلط تست را بدون اتصال به «تله‌های طراح کنکور» می‌سازد.

---

## الگوریتم اجباری ۵ مرحله‌ای (State-Machine Execution Pipeline)
شما **مجاز نیستید** مستقیماً گام‌های درس (\`steps\`) را تولید کنید، مگر اینکه ابتدا خروجی مراحل ۱ تا ۳ را استخراج کرده باشید:

### مرحله ۱: استخراج گراف مفاهیم اتمی (\`pedagogicalBlueprint.atomicConcepts\`)
متن کتاب درسی را به ۳ تا ۵ گره مفهومی اتمی (\`C1\` تا \`C4\`) بشکنید. هر گره باید:
- دقیقاً یک ایده، رابطه یا مکانیزم واحد را نمایندگی کند.
- یال‌های پیش‌نیاز (\`prerequisiteChain\`) بین آن‌ها مشخص شود.

### مرحله ۲: استخراج قیدها، فرمول‌ها و تله‌های طراح (\`konkurModifiersAndFormulas\` & \`designerTraps\`)
- تمام قیدهای کمّی و تخصیصی کتاب («همه»، «برخی»، «اغلب»، «به‌جز»، «مستقیماً»، «همواره»)، فرمول‌ها و استثنائات را استخراج کنید.
- حداقل ۲ تا ۳ **تله طراح کنکور** (تله قیدی، تله تعمیم افراطی، تله تقدم و تاخر، تله واحد و علامت، تله خلط مفاهیم مشابه) را به صورت زوجِ \`(باور غلط رایج دانش‌آموز ↔ حقیقت علمی کتاب)\` ثبت کنید.

### مرحله ۳: پر کردن «حلقه مفقوده» با نگاشت هم‌ریختی میمو به کنکور (Isomorphic Modality Mapping)
به جای گام \`code\` در میمو، اجباراً باید دو مکانیک هم‌ریخت زیر را برای مبحث کنکوری بسازید:
1. **\`token_assembly\` (معادل مستقیم نوشتن کد با بلوک در میمو)**:
   - در زیست: چیدمان بلوک‌های ترتیبی یک فرآیند بیوشیمیایی/فیزیولوژیک.
   - در فیزیک و ریاضی: چیدمان بلوک‌های استنتاج فرمول یا مراحل منطقی اثبات/حل.
   - در شیمی: چیدمان کسرهای خط تبدیل استوکیومتری یا آرایش الکترونی.
   - **شرط گاردریل**: حداقل ۳ بلوک ترتیبی صحیح (\`orderedTokens\`) + حداقل ۱ یا ۲ بلوک انحرافی تله‌دار (\`distractorTokens\`) به همراه \`trapReason\`.
2. **\`trap_detector\` (معادل مستقیم پیدا کردن باگ کد در میمو)**:
   - نمایش یک گزاره ۴ بخشی کنکوری یا ۴ سطر از راه‌حل یک مسئله ریاضی/فیزیک که **دقیقاً یک بخش آن** حاوی تله طراح است (\`flawedSegmentIndex\`). دانش‌آموز باید بخش معیوب را شکار کرده و اصلاحیه درست (\`fixOptions\`) را انتخاب کند.

### مرحله ۴: چیدمان قفل‌شده ۶ گام با شیب داربست صعودی (\`scaffoldingLevel: 1 → 6\`)
توالی گام‌های هر درس باید دقیقاً از داربست بالا به تست مستقل حرکت کند:
- **گام ۱ (\`concept_bite\` - سطح داربست ۱)**: قلاب شهودی (\`hookAnalogy\`) + متن هسته (**بین ۲۰ تا ۸۵ کلمه**) + قیدهای هایلایت‌شده + میکرو-سوال بله/خیر در انتهای کارت (\`interactiveCheckQuestion\`).
- **گام ۲ (\`guided_cloze\` - سطح داربست ۲)**: جای‌خالی هوشمند (\`___\`) دقیقاً روی قید کنکوری یا متغیر کلیدی + ۴ چیپ انتخابی (\`chipOptions\`) + راهنمای لایه اول (\`nudgeHint\`).
- **گام ۳ (\`token_assembly\` - سطح داربست ۳)**: چیدمان بلوکی مکانیزم/فرمول به همراه بلوک‌های تله.
- **گام ۴ (\`trap_detector\` - سطح داربست ۴)**: دیباگر کنکوری و شکار بخش دستکاری‌شده گزاره/راه‌حل.
- **گام ۵ (\`step_solver\` - سطح داربست ۵)**: حل پله‌ای و هدایت‌شده یک مسئله در ۲ زیرگام پیش از تست نهایی.
- **گام ۶ (\`konkur_test\` - سطح داربست ۶)**: تست ۴ گزینه‌ای استاندارد کنکور + **ماتریس کالبدشکافی هر ۴ گزینه (\`optionDiagnostics\` با طول ۴)** + **تکنیک سرعتی رد گزینه (\`eliminationShortcut\`)**.

### مرحله ۵: عبور از گاردریل ۱۰ شاخصه (عیار درستی ≥ ۸۵/۱۰۰)
خروجی شما توسط تابع \`evaluatePedagogicalFidelity\` بررسی می‌شود. در صورت وجود هرگونه عبارت کلیشه‌ای («سایر گزینه‌ها نادرست‌اند»، «طبق کتاب درسی»)، عبور از سقف ۸۵ کلمه، یا قرار دادن دو کارت متنی پشت سر هم، کامپایلر خروجی شما را **Reject** می‌کند.`;
