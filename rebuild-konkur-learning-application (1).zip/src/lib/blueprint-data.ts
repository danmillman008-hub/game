export interface RepoForensicItem {
  repoName: string;
  githubUrl: string;
  discoveredAssets: string;
  strengthsToKeep: string[];
  criticalGapsFound: string[];
  howWeWeaveIt: string;
}

export interface ExternalRepoSpec {
  name: string;
  url: string;
  category: string;
  license: string;
  roleInKonkurMimo: string;
  integrationPattern: string;
  priority: "حیاتی (Core)" | "مکمل قوی (High)" | "توسعه آتی (Optional)";
}

export interface WeightedAgentPhase {
  phaseNumber: number;
  code: string;
  title: string;
  weightPct: number;
  estimatedAgentTurns: string;
  prerequisites: string[];
  objective: string;
  deliverables: string[];
  targetFiles: string[];
  antiDriftGuardrails: string[];
  verificationCommands: string[];
  agentPromptToCopy: string;
}

export interface AlgorithmicUpgradeProposal {
  id: string;
  title: string;
  badge: string;
  scientificBasis: string;
  problemSolved: string;
  mathematicalFormulation: string;
  agentImplementationHint: string;
}

export const USER_REPO_FORENSICS: RepoForensicItem[] = [
  {
    repoName: "danmillman008-hub/newlearning (Gramophone M1–M8)",
    githubUrl: "https://github.com/danmillman008-hub/newlearning",
    discoveredAssets:
      "موتور پایتونی ۸ ماژوله تبدیل کتاب درسی (PDF/Markdown) به کوئست تطبیقی: استخراج گراف دانش (M1)، طراحی گام‌های داستانی و اعتبارسنج محلی (M2)، ادغام فصل‌ها و اجرای زنده (M3)، حلقه تطبیقی لبه دانش (M4)، ارکستراسیون کل کتاب (M5–M7) و اتصال Gemini Flash (M8) به همراه گزارش EVAL-QUALITATIVE.md.",
    strengthsToKeep: [
      "معماری بی‌نظیر Knowledge Space Theory (KST) در spacing.py برای محاسبه لبه بیرونی (Outer Fringe) و لبه درونی (Inner Fringe).",
      "حذف دور (Cycle Removal) قطعی با DFS روی گراف پیشنیازها در surmise.py.",
      "کنترلر باند جریان (Flow Controller) در adapt.py که نرخ موفقیت داوطلب را در بازه طلایی ۷۰٪ تا ۸۵٪ نگه می‌دارد.",
      "ثبت استاندارد رویدادهای یادگیری در قالب xAPI JSONL و جداسازی کامل LLMClient از منطق قطعی موتور.",
    ],
    criticalGapsFound: [
      "گزارش Q1 در EVAL-QUALITATIVE: افت شدید Recall در استخراج مفاهیم (۲۵ کیلوبایت متن فقط به ۲ آیتم تبدیل شده چون پرامپت پوشش کامل را الزام نکرده و فیلتر افعال _VERBS بیش از حد سخت‌گیر است).",
      "گزارش Q2: حذف شدن چک‌ها توسط Pruner به دلیل عدم ذکر صریح انواع مجاز (choice | ordering | numeric) در پرامپت نویسنده.",
      "گزارش Q3 و Q4: تک‌عبوری بودن کوئست و غیرقابل دسترس بودن آستانه تسلط ۰.۹۵ در BKT با p_init=0 در یک نشست.",
    ],
    howWeWeaveIt:
      "منطق ریاضی KST، حذف دور DAG، کنترلر باند ۷۰-۸۵٪ و اعتبارسنج‌های محلی Gramophone را مستقیماً به هسته TypeScript/PostgreSQL پلتفرم منتقل می‌کنیم و هر ۸ باگ گزارش‌شده در EVAL-QUALITATIVE (F1 تا F8) را در کامپایلر جزوه به میمو-کوئست برطرف می‌سازیم.",
  },
  {
    repoName: "danmillman008-hub/my-first (Learnly Mimo MVP + 17 Adaptive Agent Labs)",
    githubUrl: "https://github.com/danmillman008-hub/my-first",
    discoveredAssets:
      "شامل ۱۹ آرشیو زیپ از ۱۷ تلاش مجزا: ۱) پلتفرم کامل Learnly به سبک Mimo/DataCamp (Next.js + Drizzle + PostgreSQL با پلیر درس، XP، استریک و پنل ادمین) و ۲) آزمایشگاه‌های عامل خودتطبیق‌گر به همراه مستندات طلایی ARCHIVE_FORENSICS.md، RESEARCH.md و DECISIONS.md.",
    strengthsToKeep: [
      "کشف علمی حیاتی در ARCHIVE_FORENSICS: حلقه تمرین بازیابی (Retrieval Practice Loop) با مدل نیمه‌عمر حافظه و رفع کج‌فهمی، بهره یادگیری (Gain) را به ۰.۸۱ و ماندگاری (Retention) را به ۰.۶۷ می‌رساند، در حالی که چت‌بات توضیح‌محور فقط ۰.۲۲ ماندگاری دارد!",
      "تفکیک سخت‌گیرانه پاسخ با کمک (Aided) از پاسخ مستقل (Unaided) و تمرین فشرده (Massed) از تمرین فاصله‌دار (Spaced).",
      "رابط کاربری و ساختار گیمیفیکیشن Learnly (کارت‌های گام‌به‌گام، نوار پیشرفت، XP، استریک و بازخورد فوری به سبک Mimo).",
      "لایه استاندارد MCP (Model Context Protocol) در /api/mcp برای اتصال دستیارهای هوش مصنوعی خارجی به مدل دانش‌آموز.",
    ],
    criticalGapsFound: [
      "در نسخه Learnly محتوا کاملاً ایستا بود و به موتور تطبیقی KST/FSRS یا چرخه تشخیصی LearnHarness متصل نبود.",
      "در نسخه‌های اولیه ایجنت، باندیت ۷ سبکی توضیح (Explanation Bandit) فقط حس رضایت ظاهری را بالا می‌برد نه یادگیری واقعی را (طبق DECISIONS.md حذف و با قاعده Worked-Example به Unaided Retrieval جایگزین شد).",
    ],
    howWeWeaveIt:
      "پوسته تعاملی و لذت‌بخش Learnly (به سبک Mimo) را به عنوان لایه تجربه کاربری (UI/UX) حفظ کرده و مغز تصمیم‌گیرنده Learning-Loop (تصمیمات ۱ تا ۲۰ در DECISIONS.md) را در زیرساخت آن قرار می‌دهیم.",
  },
  {
    repoName: "danmillman008-hub/moshavere-va-azmoon & new-files (Swiss Konkur Planner)",
    githubUrl: "https://github.com/danmillman008-hub/moshavere-va-azmoon",
    discoveredAssets:
      "پروتوتایپ‌های طراحی‌شده در Google Stitch با سیستم طراحی «Swiss Konkur Planner»: فرم برنامه‌ریزی هفتگی مشاوره کنکور، فرم گزارش کار و پایش تست هفتگی، و پاسخ‌برگ خام ۳۰۰ تستی استاندارد قلم‌چی/گزینه دو/سنجش.",
    strengthsToKeep: [
      "زبان بصری فوق‌العاده شیک، جدی و خوانای Swiss International Style (پس‌زمینه کاغذی گرم #faf9f5، مشکی مرکبی #1a1c1a، قرمز کنکوری #bc000a و سرمه‌ای علمی #001551).",
      "ساختار دقیق جدول گزارش کار کنکوری (هدف ساعت، هدف تست، میزان رضایت، نظر مشاور) و پاسخ‌برگ کلیدی استاندارد.",
    ],
    criticalGapsFound: [
      "فایل‌ها صرفاً برگه‌های HTML/A4 چاپی و ایستا بودند و به دیتابیس، تایمر آزمون، تصحیح خودکار با نمره منفی و گراف یادگیری متصل نبودند.",
    ],
    howWeWeaveIt:
      "توکن‌های رنگی DESIGN.md این ریپو را به عنوان تم اصلی پلتفرم به کار می‌گیریم و پاسخ‌برگ و برنامه هفتگی را به ماژول‌های تعاملی متصل به PostgreSQL و موتور FSRS تبدیل می‌کنیم تا هر تست غلط در آزمون مستقیماً وارد صف مرور هوشمند شود.",
  },
  {
    repoName: "danmillman008-hub/ensani, reshte, tajrobi, books, qaleb-amade",
    githubUrl: "https://github.com/danmillman008-hub/ensani",
    discoveredAssets:
      "دفترچه‌های واقعی کنکور سراسری و سنجش (۱۴۰۲ تا ۱۴۰۵)، جزوه نکته و تست زیست‌شناسی سنجش، جزوه علوم انسانی (NOTE_CS_Ensani_v2.pdf) و قالب‌های اکسل/PDF مشاوره.",
    strengthsToKeep: [
      "نمونه داده‌های واقعی و استاندارد از ادبیات طراحان کنکور ایران (تست‌های مفهومی، ترکیبی، شمارشی و تله‌های رایج).",
    ],
    criticalGapsFound: [
      "به صورت فایل‌های PDF خام رها شده بودند و پایپ‌لاین استخراج گزاره (Proposition Extraction) روی آن‌ها اجرا نشده بود.",
    ],
    howWeWeaveIt:
      "از ساختار واقعی سوالات این دفترچه‌ها (زیست، شیمی، فیزیک، ریاضی، فلسفه و منطق، فنون ادبی) برای بذرگذاری (Seed) اولیه دیتابیس و طراحی پایپ‌لاین تبدیل جزوه PDF به درس‌های میمو استفاده می‌کنیم.",
  },
  {
    repoName: "danmillman008-hub/game (ریپوی معرفی‌شده در پیام شما)",
    githubUrl: "https://github.com/danmillman008-hub/game",
    discoveredAssets:
      "شامل ۳ فایل آپلودی آزمایشی (pharmacy-inventory.html و دو فایل باینری) که نشان می‌دهد ریپوهای اصلی کنکوری و یادگیری شما در اکانتتان پخش شده بودند.",
    strengthsToKeep: [
      "با بررسی کل اکانت GitHub شما (۱۹ ریپو)، تمام قطعات گمشده پازل در ریپوهای newlearning، my-first، moshavere-va-azmoon و ensani/reshte پیدا و یکپارچه شدند!",
    ],
    criticalGapsFound: [
      "نبود یک ریپوزیتوری واحد (Single Source of Truth) که تمام این ۵ قطعه را در یک معماری مهندسی تمیز به هم ببافد.",
    ],
    howWeWeaveIt:
      "در همین پروژه فول‌استک، هم «نقشه گنج جامع مهندسی و پرامپت‌های مرحله‌به‌مرحله ایجنت» و هم «نسخه عملیاتی و یکپارچه پلتفرم کنکور-میمو × لرن‌هارنس» را به صورت کامل پیاده‌سازی کرده‌ایم.",
  },
];

export const OPEN_SOURCE_REPOS_MATRIX: ExternalRepoSpec[] = [
  {
    name: "amosblomqvist/learnharness (ajpemok/learn-harness)",
    url: "https://github.com/amosblomqvist/learnharness",
    category: "هسته شناختی و ایجنت تدریس (Core AI Tutor Harness)",
    license: "AGPL-3.0",
    roleInKonkurMimo:
      "معماری ۴ فازی (Probe → Plan → Teach → Practice)، تفکیک اصل بدیهی (Principle i: Unconditional Truth) از گام اکتشافی (Principle ii: Motivated Discovery)، فیلد «بلند فکر کن» (Think-Out-Loud) و پایپ‌لاین گراف گزاره‌ها (Extractor → Auditor → Merger).",
    integrationPattern:
      "پورت کردن منطق src/core/phases.ts، src/core/question-core.ts، src/core/graph.ts و دکترین پرامپت‌های src/agent/prompts/{prober,teacher,practice} به لایه سرور Next.js.",
    priority: "حیاتی (Core)",
  },
  {
    name: "danmillman008-hub/newlearning (Gramophone M1–M8)",
    url: "https://github.com/danmillman008-hub/newlearning",
    category: "موتور گراف فضای دانش و کوئست (KST & Quest Engine)",
    license: "MIT",
    roleInKonkurMimo:
      "تبدیل فصل کتاب درسی به DAG پیشنیازها، محاسبه Birkhoff Ideals و Outer/Inner Fringe (نظریه فضای دانش فالمان و دوینیون)، کنترلر باند جریان ۷۰-۸۵٪ و تله‌متری xAPI.",
    integrationPattern:
      "استفاده از الگوریتم‌های spacing.py، surmise.py و adapt.py در ماژول src/lib/algorithms.ts با اعمال هر ۸ اصلاحیه گزارش EVAL-QUALITATIVE.",
    priority: "حیاتی (Core)",
  },
  {
    name: "open-spaced-repetition/ts-fsrs",
    url: "https://github.com/open-spaced-repetition/ts-fsrs",
    category: "الگوریتم تکرار فاصله‌دار نسل ۵ (FSRS-5 Scheduler)",
    license: "MIT",
    roleInKonkurMimo:
      "مدیریت حافظه بلندمدت داوطلب تا روز کنکور بر اساس سه متغیر پایداری (Stability S)، دشواری ذاتی مبحث (Difficulty D) و احتمال بازیابی (Retrievability R) با هدف ماندگاری ۸۵٪ تا ۹۰٪.",
    integrationPattern:
      "نصب پکیج npm i ts-fsrs یا استفاده از هسته DSR/FSRS کالیبره‌شده در src/lib/algorithms.ts با محدودکننده تمرین فشرده (Massed Practice Cap).",
    priority: "حیاتی (Core)",
  },
  {
    name: "VikParuchuri/marker & opendatalab/MinerU",
    url: "https://github.com/opendatalab/MinerU",
    category: "استخراج PDF فارسی، فرمول ریاضی و دفترچه کنکور (PDF/OCR Pipeline)",
    license: "Apache-2.0 / GPL",
    roleInKonkurMimo:
      "تبدیل دقیق کتاب‌های درسی آموزش و پرورش، جزوات اساتید و دفترچه‌های PDF سنجش/قلم‌چی به Markdown تمیز به همراه فرمول‌های LaTeX و جداول بدون به هم ریختگی حروف فارسی.",
    integrationPattern:
      "اجرای آفلاین یا میکروسرویس پایتونی برای تبدیل PDFهای ریپوهای ensani/reshte/books به JSON استاندارد ورودی کامپایلر میمو-کوئست.",
    priority: "مکمل قوی (High)",
  },
  {
    name: "KaTeX/KaTeX & mermaid-js/mermaid",
    url: "https://github.com/KaTeX/KaTeX",
    category: "رندر فرمول‌های ریاضی/شیمی و نقشه درختی درس (Math & DAG UI)",
    license: "MIT",
    roleInKonkurMimo:
      "نمایش سریع فرمول‌های ریاضی، فیزیک و معادلات شیمی در کارت‌های میمو و رندر زنده نقشه درختی plan_init به سبک LearnHarness.",
    integrationPattern:
      "استفاده در کامپوننت‌های LessonPlayer و PlanTreeMap برای نمایش گراف پیشنیازها و روابط علمی.",
    priority: "مکمل قوی (High)",
  },
  {
    name: "modelcontextprotocol/typescript-sdk",
    url: "https://github.com/modelcontextprotocol/typescript-sdk",
    category: "پروتکل اتصال مدل به وضعیت داوطلب (MCP Server)",
    license: "MIT",
    roleInKonkurMimo:
      "امکان اتصال مستقیم Claude Code، Cursor یا هر ایجنت خارجی به پروفایل یادگیری داوطلب از طریق اندپوینت POST /api/mcp (برگرفته از ریپوی my-first شما).",
    integrationPattern:
      "پیاده‌سازی ابزارهای get_learner_state، get_outer_fringe، record_attempt و generate_konkur_quest روی روت /api/mcp.",
    priority: "توسعه آتی (Optional)",
  },
];

export const WEIGHTED_AGENT_PHASES: WeightedAgentPhase[] = [
  {
    phaseNumber: 1,
    code: "PHASE-01-FOUNDATION",
    title: "معماری پایه، تایپوگرافی فارسی RTL و سیستم طراحی Swiss Konkur × Mimo",
    weightPct: 8,
    estimatedAgentTurns: "۳ تا ۵ گام ایجنت",
    prerequisites: ["Node.js 20+", "PostgreSQL 15+", "Next.js App Router"],
    objective:
      "راه‌اندازی اسکلت پروژه Next.js (App Router) با TypeScript سخت‌گیرانه، پیکربندی کامل راست‌به‌چپ (RTL)، فونت وزیرمتن (Vazirmatn) + JetBrains Mono و پیاده‌سازی توکن‌های رنگی DESIGN.md از ریپوی moshavere-va-azmoon.",
    deliverables: [
      "پیکربندی dir='rtl' و lang='fa' در layout.tsx با فونت استاندارد فارسی",
      "تعریف پالت رنگی Swiss Konkur Paper (#FAF9F5)، Ink (#1A1C1A)، Crimson (#BC000A)، Cobalt (#001551) و Mimo Emerald (#059669)",
      "ساخت Shell اصلی اپلیکیشن با نوار وضعیت گیمیفیکیشن (XP، استریک، قلب/انرژی، باند جریان ۷۰-۸۵٪ و تراز تخمینی)",
    ],
    targetFiles: ["src/app/layout.tsx", "src/app/globals.css", "src/components/AppHeader.tsx"],
    antiDriftGuardrails: [
      "هرگز از تم‌های بنفش نئونی شلوغ یا چپ‌به‌راست (LTR) برای متون فارسی استفاده نکنید.",
      "فرمول‌های ریاضی، کدها و شناسه‌ها باید با dir='ltr' و فونت Monospace نمایش داده شوند تا پرانتزها برعکس نشوند.",
    ],
    verificationCommands: [
      "npx next typegen",
      "npm exec tsc -- --noEmit",
      "curl -s -o /dev/null -w '%{http_code}' http://localhost:3000/api/health",
    ],
    agentPromptToCopy: `You are executing PHASE 1 (Weight: 8%) of the Konkur-Mimo x LearnHarness Master Blueprint.
Task: Set up the RTL Persian layout, Vazirmatn + JetBrains Mono typography, and Swiss Konkur Editorial + Mimo Interactive design system in Next.js App Router.
1. Configure src/app/layout.tsx with lang="fa" dir="rtl" and load Vazirmatn & JetBrains Mono fonts.
2. Define color tokens matching the Swiss Konkur Planner DESIGN.md: surface #FAF9F5, ink #1A1C1A, konkur-crimson #BC000A, academic-cobalt #001551, mimo-emerald #059669.
3. Build a responsive top command bar displaying live Learner telemetry: XP, Streak Days, Hearts (5/5), Flow-Band Accuracy (target 70-85%), and Estimated Konkur Taraz.
4. Verify with npx next typegen && npm exec tsc -- --noEmit.`,
  },
  {
    phaseNumber: 2,
    code: "PHASE-02-SCHEMA",
    title: "مهندسی دیتابیس یکپارچه PostgreSQL با Drizzle ORM (مدل داده ۵ لایه)",
    weightPct: 12,
    estimatedAgentTurns: "۴ تا ۶ گام ایجنت",
    prerequisites: ["PHASE-01-FOUNDATION"],
    objective:
      "طراحی و اعمال اسکیمای جامع دیتابیس که گراف گزاره‌های LearnHarness، فضای دانش Gramophone، گام‌های میکرولرنینگ Mimo، حافظه FSRS/BKT و آزمون‌های کنکور را در یک مدل داده منسجم متحد می‌کند.",
    deliverables: [
      "جدول learner_profiles (رشته، تراز هدف، XP، استریک، قلب، مقیاس فراموشی فردی)",
      "جدول knowledge_nodes (گزاره بدیهی Principle i، انگیزش اکتشافی Principle ii، تله طراح، پیشنیازها، احتمال تسلط BKT، پایداری و دشواری FSRS، وضعیت KST)",
      "جدول mimo_lessons و beats (گام‌های تعاملی Probe، Plan، Teach و Practice)",
      "جدول learning_evidence (لاگ تغییرناپذیر xAPI شامل پاسخ، ضریب اطمینان، متن بلند فکر کن و نوع کمک)",
      "جداول konkur_exams، exam_submissions و weekly_study_plans",
    ],
    targetFiles: ["src/db/schema.ts", "src/db/index.ts", "src/lib/seed.ts"],
    antiDriftGuardrails: [
      "جدول learning_evidence باید Append-Only باشد؛ هرگز تاریخچه تلاش‌های داوطلب را بازنویسی یا پاک نکنید.",
      "ستون‌های aided_successes و unaided_successes باید جداگانه ذخیره شوند (طبق تصمیم شماره ۵ در DECISIONS.md ریپوی my-first).",
    ],
    verificationCommands: [
      "npx drizzle-kit push",
      "npm exec tsc -- --noEmit",
    ],
    agentPromptToCopy: `You are executing PHASE 2 (Weight: 12%) of the Konkur-Mimo x LearnHarness Master Blueprint.
Task: Implement the unified PostgreSQL schema in src/db/schema.ts using Drizzle ORM and create an idempotent seed module in src/lib/seed.ts.
Tables required:
1. learner_profiles: track ('tajrobi'|'riazi'|'ensani'), xp, level, streak_days, hearts, flow_band_accuracy, forgetting_scale.
2. knowledge_nodes: slug, track, subject, chapter, title, unconditional_truth (Principle i), discovery_motivation (Principle ii), common_trap, prerequisites (string[]), mastery_p (BKT), stability_days (FSRS S), difficulty (FSRS D), retrievability, kst_state ('mastered'|'outer_fringe'|'learning'|'locked'), aided_successes, unaided_successes.
3. mimo_lessons: slug, track, subject, title, mermaid_plan, beats (JSONB array of MimoBeatStep).
4. learning_evidence: append-only log with confidence_pct, thinking_trace, support_used ('unaided'|'hint_1'|'hint_2'|'worked_example'), mastery_before, mastery_after, stability_after, xapi_verb.
5. konkur_exams, exam_submissions, weekly_study_plans, blueprint_phases.
Push schema with npx drizzle-kit push and verify idempotent seeding.`,
  },
  {
    phaseNumber: 3,
    code: "PHASE-03-INGESTION",
    title: "پایپ‌لاین تبدیل کتاب درسی و جزوه کنکور به گراف گزاره‌ها و کوئست میمو (رفع باگ‌های Q1–Q7 گراموفون)",
    weightPct: 14,
    estimatedAgentTurns: "۶ تا ۸ گام ایجنت",
    prerequisites: ["PHASE-02-SCHEMA"],
    objective:
      "ساخت کامپایلر دوحالته (قطعی + LLM) که متن فصل کتاب درسی یا جزوه کنکور را می‌گیرد و با رفع هر ۷ باگ کشف‌شده در EVAL-QUALITATIVE.md ریپوی newlearning، آن را به گره‌های دانش، یال‌های پیشنیاز بدون دور و گام‌های تعاملی میمو تبدیل می‌کند.",
    deliverables: [
      "حذف فیلتر شکننده افعال انگلیسی (_VERBS) و جایگزینی با دروازه ارزیابی‌پذیری (Assessability Gate) مناسب زبان فارسی و کنکور (رفع باگ Q1)",
      "الزام اسکیمای JSON/TypeBox برای انواع سوالات (probe_diagnostic, unconditional_truth, fill_blank, check_mcq, ordering_chain, practice_problem) تا هیچ گامی توسط Pruner دور ریخته نشود (رفع باگ Q2 و Q5)",
      "استخراج خودکار «دام طراح کنکور» (Distractor Trap) برای هر گره دانش",
      "اندپوینت POST /api/ingest برای تبدیل زنده هر متن یا جزوه کنکوری به کوئست قابل بازی",
    ],
    targetFiles: ["src/lib/algorithms.ts", "src/app/api/ingest/route.ts"],
    antiDriftGuardrails: [
      "هرگز اجازه ندهید خطای LLM یا نبود API Key باعث کرش شدن پایپ‌لاین شود؛ مسیر Fallback قطعی باید همیشه کوئست معتبر با حداقل ۳ گام ارزیابی تولید کند.",
      "گراف پیشنیاز خروجی باید حتماً از فیلتر حذف دور (DFS Cycle Removal) عبور کند تا یک DAG معتبر باشد.",
    ],
    verificationCommands: [
      "npm exec tsc -- --noEmit",
      "curl -X POST http://localhost:3000/api/ingest -H 'Content-Type: application/json' -d '{\"track\":\"tajrobi\",\"subject\":\"زیست‌شناسی\",\"chapter\":\"فصل ۲\",\"title\":\"تنظیم عصبی\",\"rawText\":\"پتانسیل آرامش غشا در نورون برابر منفی ۷۰ میلی‌ولت است.\"}'",
    ],
    agentPromptToCopy: `You are executing PHASE 3 (Weight: 14%) of the Konkur-Mimo x LearnHarness Master Blueprint.
Task: Build the Textbook/Jozve-to-Quest ingestion compiler fixing Q1, Q2, and Q5 from Gramophone's EVAL-QUALITATIVE.md, plusLearnHarness's Extractor-Auditor-Merger pattern.
1. Implement compileJozveToQuest() in src/lib/algorithms.ts with deterministic fallback and optional LLM enrichment (GEMINI_API_KEY / OPENAI_API_KEY).
2. For each concept extracted, synthesize:
   - Principle i (Unconditional Truth / اصل بدیهی پایه)
   - Principle ii (Motivated Discovery / مسیر کشف گام‌به‌گام)
   - Konkur Designer Trap (تله رایج طراح کنکور)
   - A 3-to-5 beat Mimo sequence spanning Probe -> Teach -> Practice.
3. Expose POST /api/ingest to persist the new KnowledgeNode and MimoLesson directly into PostgreSQL.`,
  },
  {
    phaseNumber: 4,
    code: "PHASE-04-KST-GRAPH",
    title: "موتور نظریه فضای دانش (KST)، محاسبه لبه بیرونی (Outer Fringe) و نقشه درختی زنده",
    weightPct: 12,
    estimatedAgentTurns: "۴ تا ۶ گام ایجنت",
    prerequisites: ["PHASE-02-SCHEMA", "PHASE-03-INGESTION"],
    objective:
      "پیاده‌سازی کامل الگوریتم Knowledge Space Theory (برگرفته از spacing.py در Gramophone و plan-tree.ts در LearnHarness) برای تعیین دقیق اینکه داوطلب در هر لحظه آماده یادگیری کدام مبحث کنکور است.",
    deliverables: [
      "تابع computeKSTStates برای تفکیک کل مباحث به ۴ وضعیت: Mastered (تسلط کامل)، Outer Fringe (لبه بیرونی آماده یادگیری — تمام پیشنیازها پاس شده)، Learning (در حال یادگیری) و Locked (قفل — دارای نقص پیشنیاز)",
      "محاسبه Inner Fringe (لبه درونی) برای تشخیص مباحثی که بهترین کاندیدای مرور ترکیبی هستند",
      "ویژوالایزر تعاملی گراف دانش و نقشه درختی (Mermaid / Interactive DAG) با قابلیت کلیک روی هر گره برای مشاهده اصل بدیهی، تله تستی و آمار حافظه",
    ],
    targetFiles: ["src/lib/algorithms.ts", "src/components/KnowledgeGraphView.tsx"],
    antiDriftGuardrails: [
      "طبق یافته‌های ARCHIVE_FORENSICS.md، گراف دانش نباید فقط یک ویترین تزئینی باشد؛ انتخاب درس بعدی (Next Beat Policy) باید مستقیماً از روی Outer Fringe انجام شود.",
    ],
    verificationCommands: ["npm exec tsc -- --noEmit"],
    agentPromptToCopy: `You are executing PHASE 4 (Weight: 12%) of the Konkur-Mimo x LearnHarness Master Blueprint.
Task: Implement the Knowledge Space Theory (KST) state & fringe engine and interactive Dependency Map visualizer.
1. In src/lib/algorithms.ts, implement computeKSTStates(nodes) calculating:
   - Mastered set S = { node | node.masteryP >= 0.82 }
   - Outer Fringe(S) = { node not in S | all prerequisites of node are in S }
   - Inner Fringe(S) = { node in S | no other node in S depends on node }
   - Locked = { node not in S | has unmastered prerequisites }
2. Build an interactive visual dependency graph component allowing learners to inspect every node's Principle i, Principle ii, Konkur trap, BKT mastery, FSRS stability, and prerequisite links.`,
  },
  {
    phaseNumber: 5,
    code: "PHASE-05-LEARNHARNESS-CORE",
    title: "هسته شناختی ۴ فازی LearnHarness (Probe → Plan → Teach → Practice)",
    weightPct: 16,
    estimatedAgentTurns: "۷ تا ۱۰ گام ایجنت",
    prerequisites: ["PHASE-04-KST-GRAPH"],
    objective:
      "پیاده‌سازی وفادارانه معماری شناختی LearnHarness (ریپوی amosblomqvist/learnharness) تطبیق‌یافته با کنکور ایران: سنجش دودویی مرز دانش، ترسیم نقشه، تدریس گام‌به‌گام از اصول بدیهی و تمرین بازیابی گزاره‌های غیرفعال.",
    deliverables: [
      "فاز ۱ (PROBE): سوال تشخیصی همراه با اسلایدر ضریب اطمینان (۰ تا ۱۰۰٪) و فیلد «بلند فکر کن (Think Out Loud)» برای ثبت استدلال داوطلب پیش از شروع درس",
      "فاز ۲ (PLAN): نمایش نقشه درختی اختصاصی از اصل بدیهی پایه تا هدف تستی کنکور",
      "فاز ۳ (TEACH): ارائه گام‌های کوچک بر پایه Principle i (Unconditional Truth) و Principle ii (چطور خودمان می‌توانستیم این رابطه را کشف کنیم؟) همراه با سوال Predict و Check",
      "فاز ۴ (PRACTICE): طرح مسئله تستی بدون لو دادن نام فرمول در صورت سوال (Inactive Proposition Retrieval) همراه با نردبان راهنمایی (Hint Ladder) و پاسخ تشریحی قفل‌شده (Committed Model Solution)",
    ],
    targetFiles: ["src/app/api/learn/attempt/route.ts", "src/components/MimoLearnPlayer.tsx"],
    antiDriftGuardrails: [
      "قانون طلایی LearnHarness (question-core.ts): گزینه‌های سوال هرگز نباید شامل توضیحات اضافی باشند که جواب درست را لو بدهد (فقط ادعای خالص).",
      "در فاز Practice، نمایش راهنمایی (Hint) یا پاسخ تشریحی قبل از تلاش داوطلب، آن نوبت را به عنوان Aided ثبت می‌کند تا تسلط کاذب ایجاد نشود.",
    ],
    verificationCommands: ["npm exec tsc -- --noEmit"],
    agentPromptToCopy: `You are executing PHASE 5 (Weight: 16%) of the Konkur-Mimo x LearnHarness Master Blueprint.
Task: Implement the 4-phase LearnHarness cognitive engine (Probe -> Plan -> Teach -> Practice) inside the interactive learning player and /api/learn/attempt endpoint.
Requirements:
1. Every attempt captures: selectedAnswer, confidencePct (0-100%), thinkingTrace ("بلند فکر کن"), and supportUsed ('unaided'|'hint_1'|'hint_2'|'worked_example').
2. Enforce the LearnHarness phase transitions: Probe diagnostics calibrate prior mastery; Plan displays the dependency tree; Teach delivers Principle i (Unconditional Truth) + Principle ii (Motivated Discovery) with immediate verification checks; Practice tests retrieval of inactive propositions with a progressive Hint Ladder.
3. On misconception or trap selection, immediately show surgical trap remediation explaining why the Konkur designer crafted that distractor.`,
  },
  {
    phaseNumber: 6,
    code: "PHASE-06-MIMO-PLAYER",
    title: "پلیر میکرولرنینگ به سبک Mimo و کنترلر باند جریان (Flow-Band 70%–85%)",
    weightPct: 14,
    estimatedAgentTurns: "۶ تا ۸ گام ایجنت",
    prerequisites: ["PHASE-05-LEARNHARNESS-CORE"],
    objective:
      "طراحی تجربه کاربری فوق‌العاده روان، اعتیادآور و گام‌به‌گام دقیقاً به سبک اپلیکیشن Mimo (برگرفته از LessonPlayer در Learnly و adapt.py در Gramophone) ولی برای مباحث کنکور.",
    deliverables: [
      "پشتیبانی از انواع گام‌های تعاملی میمو: ۱) کارت اصل بدیهی، ۲) جای خالی هوشمند (Fill-in-the-blank)، ۳) چیدمان زنجیره استدلال (Ordering Steps با امتیاز جزئی Kendall-Tau)، ۴) تست چهارگزینه‌ای ضدتله و ۵) مسئله زمان‌دار کنکوری",
      "نوار پیشرفت بالای صفحه، انیمیشن بازخورد فوری (سبز تسلط / قرمز کالبدشکافی دام طراح)، سیستم قلب/انرژی، شمارنده استریک و پاداش XP",
      "کنترلر باند جریان (Flow-Band Controller): رصد میانگین متحرک ۱۰ تلاش اخیر و نگه‌داشتن دشواری در ناحیه طلایی ۷۰٪ تا ۸۵٪",
    ],
    targetFiles: ["src/components/MimoLearnPlayer.tsx"],
    antiDriftGuardrails: [
      "هر گام (Beat) در پلیر میمو باید در یک صفحه واحد و بدون نیاز به اسکرول‌های طولانی قابل خواندن و پاسخ‌گویی باشد (One Step, One Fact).",
      "در صورت پاسخ غلط، داوطلب نباید بدون دیدن دلیل علمی و تله طراح به گام بعدی پرتاب شود؛ قابلیت تلاش مجدد (Retry) باید فعال باشد.",
    ],
    verificationCommands: ["npm exec tsc -- --noEmit"],
    agentPromptToCopy: `You are executing PHASE 6 (Weight: 14%) of the Konkur-Mimo x LearnHarness Master Blueprint.
Task: Build the Mimo-style interactive micro-step player supporting multiple interactive step kinds:
- probe_diagnostic (with confidence slider & think-out-loud input)
- unconditional_truth & fill_blank (interactive chip selection into formula/concept blanks)
- ordering_chain (reordering causal steps in biology/chemistry/logic derivations)
- check_mcq & practice_problem (with Konkur trap badges, progressive Hint Ladder, and instant bottom-sheet feedback drawer).
Include Mimo gamification telemetry: progress bar, Hearts, Streak counter, XP gain toast, and live Flow-Band (70%-85%) indicator.`,
  },
  {
    phaseNumber: 7,
    code: "PHASE-07-MEMORY-ENGINE",
    title: "موتور حافظه ترکیبی: BKT کالیبره‌شده + زمان‌بند تکرار فاصله‌دار FSRS-5",
    weightPct: 10,
    estimatedAgentTurns: "۴ تا ۵ گام ایجنت",
    prerequisites: ["PHASE-05-LEARNHARNESS-CORE", "PHASE-06-MIMO-PLAYER"],
    objective:
      "ادغام الگوریتم Bayesian Knowledge Tracing (برای تسلط کوتاه‌مدت در جلسه یادگیری) با الگوریتم FSRS-5 / Half-Life Regression (برای ماندگاری بلندمدت تا روز کنکور) به همراه تمام قوانین محافظتی کشف‌شده در آزمایشگاه my-first.",
    deliverables: [
      "به‌روزرسانی همزمان mastery_p (با BKT کالیبره‌شده) و stability_days / difficulty / retrievability (با فرمول FSRS-5) پس از هر تلاش",
      "اعمال قانون محافظتی Bug #2 و #3 از ARCHIVE_FORENSICS: تلاش‌های با راهنمایی (Aided) نمی‌توانند گره را به وضعیت Mastered برسانند و تمرین‌های متوالی در یک روز (Massed) ضریب رشد پایداری محدودی دارند",
      "داشبورد صف مرور هوشمند امروز (Due for Review) بر اساس افت احتمال بازیابی به زیر آستانه ۰.۸۵",
    ],
    targetFiles: ["src/lib/algorithms.ts", "src/app/api/learn/attempt/route.ts"],
    antiDriftGuardrails: [
      "هرگز از آستانه دست‌نیافتنی ۰.۹۵ با p_init=0 استفاده نکنید (باگ Q4 گراموفون)؛ پارامترهای BKT باید طوری تنظیم شوند که ۳ تا ۴ پاسخ درست مستقل (Unaided) گره را به تسلط ≥ ۰.۸۲ برساند.",
    ],
    verificationCommands: ["npm exec tsc -- --noEmit"],
    agentPromptToCopy: `You are executing PHASE 7 (Weight: 10%) of the Konkur-Mimo x LearnHarness Master Blueprint.
Task: Wire the hybrid BKT + FSRS-5 memory scheduler into POST /api/learn/attempt.
1. Update node masteryP via updateBKTMastery(prior, isCorrect, supportUsed, confidencePct).
2. Update stabilityDays, difficulty, and retrievability via updateFSRSState().
3. Recompute KST states (mastered, outer_fringe, learning, locked) across all knowledge nodes whenever a node crosses the mastery threshold (0.82), unlocking downstream dependent Konkur topics automatically!`,
  },
  {
    phaseNumber: 8,
    code: "PHASE-08-KONKUR-EXAM",
    title: "شبیه‌ساز آزمون کنکور، پاسخ‌برگ کلیدی استاندارد، نمره منفی ۳۳٪ و اتصال خودکار به گراف ترمیم",
    weightPct: 8,
    estimatedAgentTurns: "۵ تا ۷ گام ایجنت",
    prerequisites: ["PHASE-07-MEMORY-ENGINE"],
    objective:
      "ساخت موتور آزمون‌ساز و شبیه‌ساز استاندارد کنکور سراسری (سنجش / قلم‌چی / گزینه دو) بر اساس طراحی پاسخ‌برگ ریپوی moshavere-va-azmoon که نتایج آزمون را مستقیماً به موتور LearnHarness و FSRS خوراک می‌دهد.",
    deliverables: [
      "تایمر معکوس استاندارد کنکور، پاسخ‌برگ حبابی کلیدی (Optical Bubble Sheet) و علامت‌گذاری تکنیک ضربدر و منها (شک‌دار ؟، زمان‌بر ⏱، تله تستی ⚠)",
      "محاسبه دقیق درصد با نمره منفی یک‌سوم: ((3*C - W) / (3*N)) * 100، درصد بدون نمره منفی و تراز تخمینی (تراز ۳۴۰۰ تا ۸۳۵۰)",
      "تحلیلگر هوشمند پس از آزمون: تشخیص اینکه هر غلط ناشی از «شکار شدن در تله طراح»، «نقص پیشنیاز» یا «بی‌دقتی» بوده و کاهش خودکار پایداری FSRS آن مبحث برای قرار گرفتن در صدر صف مرور میمو!",
    ],
    targetFiles: ["src/app/api/exams/submit/route.ts", "src/components/KonkurExamSimulator.tsx"],
    antiDriftGuardrails: [
      "بخش آزمون نباید از بخش یادگیری جدا باشد؛ ثبت کارنامه آزمون باید در همان تراکنش دیتابیس، وضعیت گره‌های دانش مرتبط (knowledge_nodes) را در موتور LearnHarness به‌روز کند.",
    ],
    verificationCommands: ["npm exec tsc -- --noEmit"],
    agentPromptToCopy: `You are executing PHASE 8 (Weight: 8%) of the Konkur-Mimo x LearnHarness Master Blueprint.
Task: Build the Konkur Exam Simulator & Optical Bubble Answer Sheet component and POST /api/exams/submit endpoint.
1. Support timed taking of multi-subject Konkur booklets with bubble-sheet rapid marking and question flags ('doubt', 'time_consuming', 'trap_alert').
2. Compute exact Iranian Konkur score with -33.3% negative marking: ((3*C - W)/(3*N))*100, plus Estimated Taraz.
3. Detect whenever a student picked the designer's trap option (trapOption), categorize the error, penalize the linked knowledgeNode's BKT mastery & FSRS stability in PostgreSQL, and generate a 1-click Remediation Quest queue.`,
  },
  {
    phaseNumber: 9,
    code: "PHASE-09-SWISS-PLANNER",
    title: "میز کار برنامه‌ریزی هفتگی Swiss Konkur، گزارش کار داوطلب و پروتکل MCP",
    weightPct: 4,
    estimatedAgentTurns: "۳ تا ۴ گام ایجنت",
    prerequisites: ["PHASE-08-KONKUR-EXAM"],
    objective:
      "تبدیل برگه‌های برنامه‌ریزی هفتگی و گزارش کار ریپوی moshavere-va-azmoon (طراحی‌شده در Stitch) به یک سامانه تعاملی متصل به دیتابیس و ارائه اندپوینت بازرسی مدل داوطلب.",
    deliverables: [
      "جدول برنامه‌ریزی هفتگی و ثبت گزارش کار روزانه داوطلب (ساعت مطالعه، تعداد تست، درصد درستی، سطح رضایت و توصیه هوشمند مشاور)",
      "تولید خودکار پیشنهاد برنامه روزانه بر اساس گره‌های موجود در Outer Fringe و کارت‌های سررسیدشده FSRS",
      "قابلیت افزودن تسک مطالعاتی جدید و تیک زدن تسک‌های انجام‌شده با ذخیره آنی در PostgreSQL",
    ],
    targetFiles: ["src/app/api/planner/route.ts", "src/components/SwissPlannerStudio.tsx"],
    antiDriftGuardrails: [
      "طراحی بصری جدول برنامه‌ریزی باید وفادار به سبک تمیز، خط‌کشی‌شده و خوانای Swiss Konkur Planner در ریپوی moshavere-va-azmoon باشد.",
    ],
    verificationCommands: ["npm exec tsc -- --noEmit"],
    agentPromptToCopy: `You are executing PHASE 9 (Weight: 4%) of the Konkur-Mimo x LearnHarness Master Blueprint.
Task: Implement the interactive Swiss Konkur Weekly Planner & Study Log (from moshavere-va-azmoon Stitch prototypes) backed by weekly_study_plans in PostgreSQL.
Allow students/advisors to log study minutes, test counts, correct/wrong counts, satisfaction level, and toggle completion status, while automatically highlighting recommended topics from the KST Outer Fringe.`,
  },
  {
    phaseNumber: 10,
    code: "PHASE-10-VERIFICATION",
    title: "تست یکپارچگی سرتاسری، ممیزی تایپ‌اسکریپت و بیلد پروداکشن بدون خطا",
    weightPct: 2,
    estimatedAgentTurns: "۲ تا ۳ گام ایجنت",
    prerequisites: ["PHASE-01 تا PHASE-09"],
    objective:
      "اجرای کامل زنجیره اعتبارسنجی (Typegen، TypeScript، Production Build، تست APIها و دیتابیس) تا اطمینان حاصل شود هیچ خطای زمان کامپایل یا زمان اجرا وجود ندارد.",
    deliverables: [
      "فایل مستند جامع MASTER_BLUEPRINT.md در ریشه پروژه برای استفاده مستقیم در Claude Code / Cursor / Windsurf",
      "اندپوینت GET /api/state و GET /api/health با پاسخ ۲۰۰ و داده کامل",
      "عبور صددرصدی از npx next typegen، tsc --noEmit و npm run build",
    ],
    targetFiles: ["MASTER_BLUEPRINT.md", "src/app/api/state/route.ts", "src/app/api/health/route.ts"],
    antiDriftGuardrails: [
      "هرگز کار را بدون اجرای هر سه دستور next typegen، tsc --noEmit و npm run build تمام‌شده اعلام نکنید.",
    ],
    verificationCommands: [
      "npx next typegen",
      "npm exec tsc -- --noEmit --pretty false",
      "npm run build",
    ],
    agentPromptToCopy: `You are executing PHASE 10 (Weight: 2%) of the Konkur-Mimo x LearnHarness Master Blueprint.
Task: Run full final verification across the entire fullstack application:
1. Run npx next typegen
2. Run npm exec tsc -- --noEmit --pretty false
3. Run npm run build
4. Verify /api/health and /api/state return 200 OK with seeded Konkur knowledge graph, Mimo quests, Konkur exams, and Swiss planner items.`,
  },
];

export const ALGORITHMIC_UPGRADES: AlgorithmicUpgradeProposal[] = [
  {
    id: "UPGRADE-01-DISTRACTOR-GRAPH",
    title: "۱. گراف تله‌های طراح کنکور (Cognitive Distractor & Trap Topology)",
    badge: "پیشنهاد ویژه کنکور ایران",
    scientificBasis: "Diagnostic Classification Models (DCM) & Buggy Rule Theory (Brown & Burton)",
    problemSolved:
      "در کنکور ایران، گزینه‌های غلط تصادفی نیستند؛ هر گزینه غلط حاصل یک اشتباه محاسباتی یا مفهومی مهندسی‌شده توسط طراح است (مثلاً فراموش کردن ضریب استوکیومتری یا اشتباه گرفتن میتوز و میوز).",
    mathematicalFormulation:
      "به جای ذخیره صرفاً Correct/Wrong باینری، هر گزینه $o_i \\in \\{1,2,3,4\\}$ به یک بردار کج‌فهمی $m(o_i) \\in V_{trap}$ نگاشت می‌شود. انتخاب گزینه تله، مستقیماً یک «گره ترمیمی ضدتله» (Trap-Breaker Micro-Beat) را در صدر صف Mimo قرار می‌دهد.",
    agentImplementationHint:
      "در اسکیمای سوالات، فیلد trapOption و trapReason را به یال‌های نوع TRIGGERS_REMEDIATION در گراف دانش متصل کنید تا به محض انتخاب گزینه دام، کارت کالبدشکافی دام طراح باز شود.",
  },
  {
    id: "UPGRADE-02-CHRONO-IRT",
    title: "۲. مدل پاسخ به سوال زمان‌محور (Chronometric 3PL-IRT & Speed-Accuracy Tradeoff)",
    badge: "مدیریت زمان جلسه کنکور",
    scientificBasis: "Hierarchical Speed-Accuracy Response Time Model (van der Linden, 2007)",
    problemSolved:
      "داوطلبی که یک تست فیزیک یا زیست را در ۴ دقیقه درست حل می‌کند، در جلسه واقعی کنکور (با میانگین ۴۵ تا ۷۰ ثانیه برای هر تست) شکست می‌خورد. BKT معمولی زمان پاسخ‌گویی را نمی‌بیند.",
    mathematicalFormulation:
      "امتیاز مؤثر تلاش به صورت $E = \\mathbb{I}(\\text{correct}) \\cdot \\exp\\left(-\\lambda \\max(0, \\frac{t - t_{\\text{ideal}}}{t_{\\text{ideal}}})\\right)$ محاسبه می‌شود. اگر $t > 1.5 \\times t_{\\text{ideal}}$، گره از نظر مفهومی پاس شده ولی به وضعیت Fluency Drill (تمرین سرعتی) می‌رود.",
    agentImplementationHint:
      "زمان صرف‌شده روی هر کارت (latencySec) را با idealTimeSec مقایسه کنید و برای پاسخ‌های درستِ کند، تگ 'نیاز به افزایش سرعت تستی' صادر نمایید.",
  },
  {
    id: "UPGRADE-03-CROSS-SUBJECT-TRANSFER",
    title: "۳. گراف انتقال پیشنیاز بین‌درسی (Cross-Subject Prerequisite Propagation)",
    badge: "کشف گپ‌های پنهان پایه",
    scientificBasis: "Hierarchical Bayesian Belief Propagation over Posets (LearnHarness + KST)",
    problemSolved:
      "بسیاری از داوطلبان تجربی در «سینماتیک فیزیک» یا «سینتیک شیمی» ضعف دارند، در حالی که ریشه مشکل آن‌ها در «مشتق و شیب خط ریاضی» یا «تناسب و درصد» است!",
    mathematicalFormulation:
      "تعریف یال‌های پیشنیاز بین‌درسی $e: \\text{Math.Derivative} \\to \\text{Physics.Kinematics}$. در صورت ۳ شکست متوالی در گره مقصد، الگوریتم Bisection Prober در LearnHarness به‌طور خودکار یک سوال تشخیصی از گره پیشنیاز در درس دیگر می‌پرسد.",
    agentImplementationHint:
      "در جدول knowledge_nodes اجازه دهید آرایه prerequisites شامل slugهایی از سایر دروس (مثلاً ریاضی به فیزیک، شیمی به زیست) باشد.",
  },
  {
    id: "UPGRADE-04-HALF-LIFE-CALIBRATION",
    title: "۴. کالیبراسیون نرخ فراموشی اختصاصی هر داوطلب برای هر درس (Per-Learner Subject Forgetting Scale)",
    badge: "شخصی‌سازی عمیق FSRS",
    scientificBasis: "Half-Life Regression (Settles & Meeder, Duolingo) & Archive Decision #4",
    problemSolved:
      "یک داوطلب ممکن است فرمول‌های فیزیک را دیر فراموش کند ولی قیدهای زیست‌شناسی («همه»، «بیشتر»، «برخی») را ظرف ۴۸ ساعت فراموش کند.",
    mathematicalFormulation:
      "مدل احتمال یادآوری $p = p_{\\text{known}} \\cdot 2^{-\\Delta t / (S \\cdot \\alpha_{\\text{subject}})}$ که در آن $\\alpha_{\\text{subject}}$ با گرادیان نزولی آنلاین روی خطای پیش‌بینی (MAE) جلسات مرور هر درس به‌روز می‌شود.",
    agentImplementationHint:
      "به جای یک forgettingScale سراسری، یک نقشه JSONB به شکل { 'زیست‌شناسی': 0.82, 'فیزیک': 1.15, 'شیمی': 0.94 } در پروفایل داوطلب نگه دارید.",
  },
  {
    id: "UPGRADE-05-THINK-ALOUD-DIAGNOSTIC",
    title: "۵. ممیزی خودکار استدلال «بلند فکر کن» برای تفکیک حدس شانسی از فهم عمیق",
    badge: "هسته اصیل LearnHarness",
    scientificBasis: "Self-Explanation Effect (Chi et al., 1994) & LearnHarness Thinking Field Doctrine",
    problemSolved:
      "در تست‌های چهارگزینه‌ای، شانس حدس زدن ۲۵٪ (و با حذف دو گزینه ۵۰٪) است. داوطلب ممکن است با استدلال کاملاً غلط به گزینه درست برسد (False Positive).",
    mathematicalFormulation:
      "تحلیل فیلد thinkingTrace پیش از ثبت نهایی BKT: اگر گزینه انتخاب‌شده درست باشد اما استدلال نوشته‌شده فاقد کلیدواژه‌های اصل پایه (Principle i) باشد، ضریب $p_{\\text{guess}}$ در فرمول بیز از ۰.۲۰ به ۰.۵۵ افزایش می‌یابد.",
    agentImplementationHint:
      "در اندپوینت /api/learn/attempt، وجود استدلال مکتوب در فیلد بلند فکر کن را بررسی کرده و به استدلال‌های مستند پاداش پایداری (Stability Bonus) بدهید.",
  },
  {
    id: "UPGRADE-06-EXAM-STRATEGY-SIMULATOR",
    title: "۶. بهینه‌ساز استراتژی تکنیک «ضربدر و منها» و ریسک نمره منفی (Optimal Stopping & Risk Policy)",
    badge: "مهندسی جلسه آزمون",
    scientificBasis: "Expected Utility Theory under -1/3 Negative Marking",
    problemSolved:
      "داوطلبان نمی‌دانند در چه ضریب اطمینانی زدن تستِ شک‌دار به نفع ترازشان است و کی باید از تست رد شوند.",
    mathematicalFormulation:
      "امید ریاضی نمره یک تست با ضریب اطمینان ذهنی $c$ برابر است با $E[S] = c(+1) + (1-c)(-\\frac{1}{3}) = \\frac{4c - 1}{3}$. تنها زمانی زدن تست امید ریاضی مثبت دارد که $c_{\\text{calibrated}} > 0.25$ (و با احتساب ریسک انحراف معیار تراز، $c > 0.45$). سیستم با مقایسه confidencePct داوطلب با درصد درستی واقعی او (Calibration Curve)، به او هشدار «بیش‌اطمینانی خطرناک» می‌دهد!",
    agentImplementationHint:
      "منحنی کالیبراسیون اطمینان (Confidence vs Actual Accuracy) را از جدول learning_evidence استخراج کرده و در داشبورد آزمون به داوطلب نشان دهید.",
  },
];
