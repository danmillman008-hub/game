import { count } from "drizzle-orm";
import { db } from "@/db";
import {
  agentCompilationLogs,
  konkurCourses,
  konkurLessons,
  konkurSteps,
  type KonkurStepContent,
  type PedagogicalBlueprint,
  type StepKind,
} from "@/db/schema";
import {
  countPersianWords,
  evaluatePedagogicalFidelity,
} from "@/lib/pedagogy-engine";

type SeedLessonDef = {
  slug: string;
  title: string;
  chapterReference: string;
  rawTextbookExcerpt: string;
  xpReward: number;
  estimatedMinutes: number;
  pedagogicalBlueprint: PedagogicalBlueprint;
  steps: {
    type: StepKind;
    conceptNodeId: string;
    scaffoldingLevel: number;
    content: KonkurStepContent;
  }[];
};

type SeedCourseDef = {
  slug: string;
  title: string;
  subject: string;
  grade: string;
  reshte: string;
  icon: string;
  color: string;
  tagline: string;
  description: string;
  lessons: SeedLessonDef[];
};

export const PRESET_TEXTBOOK_SAMPLES = [
  {
    id: "bio-transcription",
    subject: "زیست‌شناسی",
    grade: "دوازدهم تجربی",
    topicTitle: "رونویسی: از راه‌انداز تا پایان (نقش RNA پلی‌مراز)",
    chapterReference: "زیست‌شناسی دوازدهم - فصل ۲ (جریان اطلاعات در یاخته) - گفتار ۱",
    rawTextbookExcerpt:
      "فرآیند رونویسی با اتصال آنزیم RNA پلی‌مراز به بخشی از رشته DNA به نام راه‌انداز آغاز می‌شود. راه‌انداز توالی ویژه‌ای از نوکلئوتیدها در DNA است که به RNA پلی‌مراز امکان می‌دهد رونویسی را از محل صحیح آغاز کند. برخلاف همانندسازی که به آنزیم هلیکاز نیاز دارد، در مرحله آغاز رونویسی خودِ آنزیم RNA پلی‌مراز دو رشته DNA را از هم باز می‌کند. در پروکاریوت‌ها تنها یک نوع RNA پلی‌مراز همه انواع RNA را رونویسی می‌کند، اما در یوکاریوت‌ها سه نوع RNA پلی‌مراز (I، II و III) فعالیت دارند که RNA پلی‌مراز II مسئول رونویسی پیش‌سازهای mRNA است.",
  },
  {
    id: "physics-kinematics",
    subject: "فیزیک",
    grade: "دوازدهم ریاضی و تجربی",
    topicTitle: "حرکت با شتاب ثابت: تشخیص تندشونده، کندشونده و معادله مستقل از زمان",
    chapterReference: "فیزیک دوازدهم - فصل ۱ (حرکت بر خط راست) - بخش ۳",
    rawTextbookExcerpt:
      "در حرکت بر خط راست با شتاب ثابت، صرفاً منفی بودن علامت شتاب (a < 0) به معنای کندشونده بودن حرکت نیست؛ بلکه هرگاه بردار سرعت (v) و بردار شتاب (a) هم‌جهت باشند (حصل‌ضرب v × a > 0)، حرکت تندشونده است و هرگاه خلاف جهت یکدیگر باشند (v × a < 0)، حرکت کندشونده خواهد بود. همچنین زمانی که در صورت مسئله زمان (t) داده نشده و خواسته هم نشده باشد، استفاده از معادله مستقل از زمان v² - v₀² = 2aΔx کوتاه‌ترین مسیر حل تست است.",
  },
  {
    id: "chem-stoichiometry",
    subject: "شیمی",
    grade: "یازدهم و دوازدهم",
    topicTitle: "خط لوله استوکیومتری، شرایط STP و بازده درصدی واکنش",
    chapterReference: "شیمی یازدهم فصل ۱ و شیمی دوازدهم - استوکیومتری واکنش‌ها",
    rawTextbookExcerpt:
      "در محاسبات استوکیومتری، نسبت ضرایب موازنه در معادله شیمیایی تنها بیانگر نسبت مولی مواد شرکت‌کننده است و هرگز مستقیماً نسبت جرمی را نشان نمی‌دهد. حجم مولی هر گاز ایده‌آل تنها در شرایط استاندارد (STP: دمای صفر درجه سانتی‌گراد و فشار ۱ اتمسفر) برابر ۲۲/۴ لیتر بر مول است و برای مایعات یا جامدات استفاده از عدد ۲۲/۴ خطای علمی است. همچنین در واکنش‌های واقعی، مقدار فرآورده عملی کمتر از مقدار نظری بوده و در محاسبه باید ضریب خلوص واکنش‌دهنده و بازده درصدی در خط تبدیل ضرب شوند.",
  },
  {
    id: "math-derivability",
    subject: "ریاضی و حسابان",
    grade: "دوازدهم ریاضی و تجربی",
    topicTitle: "رابطه پیوستگی و مشتق‌پذیری: شکار نقاط گوشه و قدرمطلق",
    chapterReference: "حسابان دوازدهم / ریاضی تجربی - فصل مشتق - مشتق‌پذیری",
    rawTextbookExcerpt:
      "هر تابع مشتق‌پذیر در یک نقطه، الزاماً در آن نقطه پیوسته است؛ اما عکس این قضیه همواره برقرار نیست، یعنی تابع می‌تواند در نقطه x=a پیوسته باشد ولی مشتق‌پذیر نباشد (مانند نقاط گوشه در ریشه‌های ساده عبارت داخل قدرمطلق). هرگاه عبارت داخل قدرمطلق در نقطه x=a ریشه ساده داشته باشد و ضریب پشت قدرمطلق در آن نقطه صفر نشود، مشتق چپ و راست نابرابر بوده و نقطه گوشه داریم.",
  },
];

const SEED_COURSES: SeedCourseDef[] = [
  {
    slug: "zist-12-molecular-flow",
    title: "زیست دوازدهم: جریان اطلاعات در یاخته (تراز سنجش)",
    subject: "زیست‌شناسی",
    grade: "دوازدهم",
    reshte: "تجربی",
    icon: "🧬",
    color: "emerald",
    tagline: "تبدیل متن سنگین زیست دوازدهم به چیدمان بلوکی مسیرهای آنزیمی و شکار قیدهای سنجش.",
    description:
      "در این دوره، گفتارهای فصل ۲ زیست دوازدهم با الگوریتم هم‌ریخت میمو خرده‌سازی شده‌اند: به جای حفظ کردن طوطی‌وار، مسیر فعالیت RNA پلی‌مراز را بلوک‌به‌بلوک می‌چینید و تله‌های قیدی طراحان کنکور را دیباگ می‌کنید.",
    lessons: [
      {
        slug: "transcription-rna-polymerase",
        title: "رونویسی: از راه‌انداز تا پایان (نقش RNA پلی‌مراز)",
        chapterReference: "زیست‌شناسی دوازدهم - فصل ۲ - گفتار ۱: رونویسی",
        rawTextbookExcerpt: PRESET_TEXTBOOK_SAMPLES[0].rawTextbookExcerpt,
        xpReward: 50,
        estimatedMinutes: 5,
        pedagogicalBlueprint: {
          atomicConcepts: [
            {
              id: "C1_PROMOTER_INIT",
              title: "شناسایی راه‌انداز و باز کردن DNA توسط خود RNA پلی‌مراز",
              textbookQuote:
                "رونویسی با اتصال آنزیم RNA پلی‌مراز به راه‌انداز آغاز می‌شود و خود آنزیم دو رشته DNA را باز می‌کند.",
              cognitiveLevel: "understand",
              isPrerequisite: true,
              targetMechanic: "concept_bite",
            },
            {
              id: "C2_PROKARYOTE_VS_EUKARYOTE",
              title: "تفاوت انواع RNA پلی‌مراز در پروکاریوت و یوکاریوت",
              textbookQuote:
                "در پروکاریوت‌ها تنها یک نوع RNA پلی‌مراز همه انواع RNA را می‌سازد اما در یوکاریوت‌ها سه نوع وجود دارد.",
              cognitiveLevel: "apply",
              isPrerequisite: false,
              targetMechanic: "guided_cloze",
            },
            {
              id: "C3_TRANSCRIPTION_CHAIN",
              title: "توالی مراحل آغاز و طویل شدن رونویسی بدون دخالت هلیکاز",
              textbookQuote:
                "اتصال به راه‌انداز ← باز شدن دو رشته DNA توسط RNA پلی‌مراز ← تشکیل پیوند فسفودی‌استر",
              cognitiveLevel: "apply",
              isPrerequisite: false,
              targetMechanic: "token_assembly",
            },
            {
              id: "C4_HELICASE_AND_PROMOTER_TRAP",
              title: "تله دخالت هلیکاز در رونویسی و تله رونویسی شدن خود راه‌انداز",
              textbookQuote:
                "برخلاف همانندسازی، در رونویسی هلیکاز نقش ندارد و راه‌انداز فقط محل اتصال است.",
              cognitiveLevel: "analyze",
              isPrerequisite: false,
              targetMechanic: "trap_detector",
            },
          ],
          prerequisiteChain: [
            {
              fromId: "C1_PROMOTER_INIT",
              toId: "C2_PROKARYOTE_VS_EUKARYOTE",
              relation: "شناخت عملکرد پایه RNA پلی‌مراز پیش‌نیاز مقایسه انواع آن است",
            },
            {
              fromId: "C2_PROKARYOTE_VS_EUKARYOTE",
              toId: "C3_TRANSCRIPTION_CHAIN",
              relation: "شناخت آنزیم پیش‌نیاز چیدن مراحل فعالیت آن روی رشته الگو است",
            },
            {
              fromId: "C3_TRANSCRIPTION_CHAIN",
              toId: "C4_HELICASE_AND_PROMOTER_TRAP",
              relation: "تسلط بر زنجیره صحیح پیش‌نیاز شکار تله هلیکاز در گزاره‌های کنکور است",
            },
          ],
          konkurModifiersAndFormulas: [
            {
              id: "MOD_HELICASE_ZERO",
              phrase: "بدون نیاز به آنزیم هلیکاز (توسط خود RNA پلی‌مراز)",
              category: "استثنای کتاب درسی",
              explanation:
                "در همانندسازی هلیکاز دو رشته را باز می‌کند، اما در رونویسی شکستن پیوند هیدروژنی ابتدایی کار خود RNA پلی‌مراز است.",
            },
            {
              id: "MOD_PROK_ONE_ALL",
              phrase: "قید «همه انواع RNA توسط یک نوع RNA پلی‌مراز» در پروکاریوت‌ها",
              category: "قید کمّی (همه/برخی/اغلب)",
              explanation:
                "در باکتری‌ها تنوع RNA پلی‌مراز وجود ندارد (فقط ۱ نوع)، ولی در یوکاریوت‌ها RNA پلی‌مراز II اختصاصاً پیش‌ساز mRNA را می‌سازد.",
            },
          ],
          designerTraps: [
            {
              id: "TRAP_BIO_1",
              trapTitle: "تله خلط همانندسازی و رونویسی (دخالت هلیکاز)",
              trapCategory: "تله خلط مفاهیم مشابه",
              commonWrongBelief:
                "هر جا دو رشته DNA از هم باز می‌شوند حتماً آنزیم هلیکاز فعالیت کرده است.",
              scientificTruth:
                "در رونویسی، هلیکاز هیچ نقشی ندارد و خود RNA پلی‌مراز دو رشته DNA را از هم باز می‌کند.",
            },
            {
              id: "TRAP_BIO_2",
              trapTitle: "تله تعمیم انواع RNA پلی‌مراز به همه جانداران",
              trapCategory: "تله قیدی",
              commonWrongBelief: "در همه یاخته‌های زنده، mRNA توسط RNA پلی‌مراز II ساخته می‌شود.",
              scientificTruth:
                "یاخته‌های پروکاریوتی اصلاً RNA پلی‌مراز شماره‌گذاری‌شده (I, II, III) ندارند و فقط یک نوع RNA پلی‌مراز دارند.",
            },
          ],
          missingLinkMapping: {
            mimoOriginalMechanic: "چیدمان بلوک‌های کد پایتون و کشف خطای سینتکس (Code & Debug)",
            konkurIsomorphicMechanic:
              "چیدمان بلوکی مراحل مولکولی رونویسی (`causal_chain`) با بلوک تله هلیکاز + دیباگ گزاره ۴ بخشی سنجش",
            bridgingRationale:
              "فرآیند رونویسی دقیقاً مانند اجرای یک الگوریتم دارای ترتیب تقدم-تاخر و شروط آنزیمی است؛ چیدن بلوک‌ها حافظه تصویری و علّی داوطلب را قفل می‌کند.",
          },
        },
        steps: [
          {
            type: "concept_bite",
            conceptNodeId: "C1_PROMOTER_INIT",
            scaffoldingLevel: 1,
            content: {
              kind: "concept_bite",
              title: "لقمه مفهومی: کلید استارت رونویسی و راز بی‌نیازی از هلیکاز",
              hookAnalogy:
                "آنزیم RNA پلی‌مراز مثل یک قطار همه‌کاره است: اول باید تابلوی «ایستگاه راه‌انداز» را ببیند تا سوار ریل شود، و خودش هم درِ ریل (پیوند هیدروژنی DNA) را باز می‌کند!",
              bodyMarkdown:
                "رونویسی با اتصال **RNA پلی‌مراز** به توالی ویژه‌ای در DNA به نام **راه‌انداز** آغاز می‌شود. نکته طلایی کنکور اینجاست: برخلاف همانندسازی، در رونویسی **آنزیم هلیکاز نقشی ندارد** و خودِ RNA پلی‌مراز دو رشته DNA را در محل آغاز از هم باز می‌کند.",
              highlightedModifiers: ["راه‌انداز", "آنزیم هلیکاز نقشی ندارد", "خودِ RNA پلی‌مراز"],
              coreFormulaOrRule:
                "شناسایی راه‌انداز توسط RNA پلی‌مراز ← باز شدن دو رشته DNA توسط خود آنزیم (بدون هلیکاز) ← ساخت RNA",
              interactiveCheckQuestion:
                "آیا در فرآیند رونویسی ژن، باز شدن دو رشته DNA توسط آنزیم هلیکاز انجام می‌شود؟",
              interactiveCheckAnswer: false,
              interactiveCheckExplanation:
                "آفرین! در رونویسی آنزیم هلیکاز اصلاً حضور ندارد و خودِ آنزیم RNA پلی‌مراز دو رشته DNA را از هم باز می‌کند.",
            },
          },
          {
            type: "guided_cloze",
            conceptNodeId: "C2_PROKARYOTE_VS_EUKARYOTE",
            scaffoldingLevel: 2,
            content: {
              kind: "guided_cloze",
              prompt:
                "با توجه به تفاوت پروکاریوت‌ها و یوکاریوت‌ها در کتاب درسی، جای خالی را با گزینه دقیق پر کنید:",
              templateWithBlank:
                "در باکتری‌ها (پروکاریوت‌ها) تنها یک نوع RNA پلی‌مراز رونویسیِ ___ انواع RNA را بر عهده دارد، در حالی که در یوکاریوت‌ها رونویسی پیش‌ساز mRNA کارِ ___ است.",
              correctAnswer: "همه — RNA پلی‌مراز II",
              chipOptions: [
                "همه — RNA پلی‌مراز II",
                "برخی — RNA پلی‌مراز I",
                "همه — RNA پلی‌مراز III",
                "اغلب — هلیکاز و پلی‌مراز",
              ],
              targetedModifierId: "MOD_PROK_ONE_ALL",
              nudgeHint:
                "به یاد بیاورید باکتری فقط ۱ نوع آنزیم رونویسی دارد؛ و در هسته‌داران کدام شماره مسئول پیک (mRNA) است؟",
              deepExplanation:
                "در پروکاریوت‌ها ۱ نوع RNA پلی‌مراز «همه» انواع RNA (پیک، ناقل، ریبوزومی) را می‌سازد؛ اما در یوکاریوت‌ها نوع I برای rRNA، نوع II برای پیش‌ساز mRNA و نوع III برای tRNA است.",
            },
          },
          {
            type: "token_assembly",
            conceptNodeId: "C3_TRANSCRIPTION_CHAIN",
            scaffoldingLevel: 3,
            content: {
              kind: "token_assembly",
              prompt:
                "معادل گام Code میمو: مراحل مولکولی آغاز و ادامه رونویسی را به ترتیب صحیح بچینید (بلوک‌های تله طراح را وارد زنجیره نکنید!):",
              assemblyMode: "causal_chain",
              orderedTokens: [
                "۱. شناسایی و اتصال RNA پلی‌مراز به توالی راه‌انداز در DNA",
                "۲. باز شدن دو رشته DNA در محل آغاز توسط خود RNA پلی‌مراز",
                "۳. قرارگیری ریبونوکلئوتیدهای مکمل در برابر رشته الگوی DNA",
                "۴. تشکیل پیوند فسفودی‌استر بین ریبونوکلئوتیدها و حرکت آنزیم",
              ],
              distractorTokens: [
                {
                  token: "تله: باز شدن پیوندهای هیدروژنی دو رشته DNA توسط آنزیم هلیکاز",
                  trapReason:
                    "هلیکاز مخصوص همانندسازی DNA است و در رونویسی هیچ نقشی ندارد!",
                },
                {
                  token: "تله: مصرف دئوکسی‌ریبونوکلئوتید (dATP) برای ساخت رشته RNA",
                  trapReason:
                    "در ساخت RNA از ریبونوکلئوتید (دارای قند ریبوز و باز یوراسیل) استفاده می‌شود نه دئوکسی‌ریبونوکلئوتید.",
                },
              ],
              nudgeHint:
                "همیشه ابتدا اتصال به راه‌انداز رخ می‌دهد، سپس باز شدن دو رشته توسط خود آنزیم، بعد جفت‌شدن مکمل و در نهایت پیوند فسفودی‌استر.",
              assemblyExplanation:
                "با چیدن این ۴ بلوک و حذف تله هلیکاز، ترتیب دقیق مراحل آغاز و طویل‌شدن رونویسی در ذهن شما قفل شد.",
            },
          },
          {
            type: "trap_detector",
            conceptNodeId: "C4_HELICASE_AND_PROMOTER_TRAP",
            scaffoldingLevel: 4,
            content: {
              kind: "trap_detector",
              prompt:
                "دیباگر کنکوری (معادل کشف باگ کد در میمو): در گزاره ۴ بخشی زیر که به سبک آزمون‌های سنجش طراحی شده، روی بخش دارای «تله علمی» ضربه بزنید:",
              contextType: "statement_autopsy",
              segments: [
                "بخش ۱: در فرآیند رونویسی یاخته کبد انسان، آنزیم RNA پلی‌مراز II به راه‌انداز ژن متصل می‌شود",
                "بخش ۲: راه‌انداز توالی نوکلئوتیدی ویژه‌ای در DNA است که محل صحیح آغاز رونویسی را مشخص می‌کند",
                "بخش ۳: به محض اتصال آنزیم، هلیکاز پیوندهای هیدروژنی بین دو رشته DNA را می‌شکند",
                "بخش ۴: در ادامه، ریبونوکلئوتیدها با تشکیل پیوند فسفودی‌استر به رشته‌ای در حال رشد متصل می‌شوند",
              ],
              flawedSegmentIndex: 2,
              trapCategory: "تله خلط همانندسازی و رونویسی (نسبت دادن هلیکاز به رونویسی)",
              fixOptions: [
                "اصلاحیه صحیح: خودِ آنزیم RNA پلی‌مراز (بدون دخالت هلیکاز) دو رشته DNA را از هم باز کرده و پیوندهای هیدروژنی را می‌شکند.",
                "اصلاحیه غلط ۱: آنزیم DNA پلی‌مراز پیوندهای هیدروژنی را در رونویسی می‌شکند.",
                "اصلاحیه غلط ۲: راه‌انداز در رشته RNA قرار دارد نه در رشته DNA.",
              ],
              correctFixIndex: 0,
              diagnosticAutopsy:
                "این پرتکرارترین تله کنکور سراسری در فصل ۲ زیست دوازدهم است! بخش‌های ۱، ۲ و ۴ کاملاً صحیح‌اند، اما در بخش ۳ نام «هلیکاز» به جای خود «RNA پلی‌مراز» قرار داده شده است.",
            },
          },
          {
            type: "step_solver",
            conceptNodeId: "C2_PROKARYOTE_VS_EUKARYOTE",
            scaffoldingLevel: 5,
            content: {
              kind: "step_solver",
              problemStatement:
                "حل پله‌ای تست ترکیبی: «چند مورد از عبارات زیر در مورد رونویسی در همه یاخته‌های زنده دارای دنا (DNA) صحیح است؟» بیایید در ۲ گام قفل آن را باز کنیم:",
              subSteps: [
                {
                  stageLabel: "گام اول: رمزگشایی از قید «همه یاخته‌های زنده»",
                  question:
                    "وقتی صورت سوال قید «در همه یاخته‌های زنده» را به کار می‌برد، یعنی ویژگی مورد نظر باید در کدام گروه‌ها مشترک باشد؟",
                  options: [
                    "هم در پروکاریوت‌ها (باکتری‌ها) و هم در یوکاریوت‌ها (هسته‌داران)",
                    "فقط در یاخته‌های بدن انسان و جانوران پریاخته‌ای",
                    "فقط در یاخته‌هایی که سه نوع RNA پلی‌مراز در هسته دارند",
                  ],
                  correctIndex: 0,
                  microFeedback:
                    "دقیقاً! هر گزاره‌ای که فقط مختص یوکاریوت باشد (مثل وجود هسته یا RNA پلی‌مراز II)، به خاطر قید «همه یاخته‌ها» رد می‌شود.",
                },
                {
                  stageLabel: "گام دوم: غربالگری ویژگی مشترک واقعی",
                  question:
                    "کدام ویژگی واقعاً بین باکتری اشریشیاکلای و یاخته عصبی انسان در مرحله آغاز رونویسی مشترک است؟",
                  options: [
                    "شناسایی راه‌انداز و باز شدن دو رشته DNA توسط خود آنزیم RNA پلی‌مراز",
                    "ساخته شدن پیش‌ساز mRNA توسط آنزیم RNA پلی‌مراز II در هسته",
                    "باز شدن دو رشته DNA توسط هلیکاز پیش از ورود RNA پلی‌مراز",
                  ],
                  correctIndex: 0,
                  microFeedback:
                    "فوق‌العاده! اتصال به راه‌انداز و باز کردن DNA توسط خود RNA پلی‌مراز در هر دو گروه پروکاریوت و یوکاریوت یکسان است.",
                },
              ],
              finalTakeaway:
                "کلید طلایی: «قید همه یاخته‌ها = اشتراک پروکاریوت و یوکاریوت». هر جا شماره آنزیم (I, II, III) یا کلمه «هسته» دیدید، برای پروکاریوت غلط است!",
            },
          },
          {
            type: "konkur_test",
            conceptNodeId: "C4_HELICASE_AND_PROMOTER_TRAP",
            scaffoldingLevel: 6,
            content: {
              kind: "konkur_test",
              questionStem:
                "کدام گزینه، عبارت زیر را درباره فرآیند رونویسی در یک یاخته زنده به درستی تکمیل می‌کند؟ «در مرحله آغاز رونویسیِ هر ژن، آنزیمِ مسؤلِ ساختِ رنا (RNA) .................»",
              sourceBadge: "کنکور سراسری تجربی - تیپ استاندارد سنجش",
              targetTimeSeconds: 45,
              options: [
                "بدون کمک آنزیم هلیکاز، موجب گسسته شدن پیوندهای هیدروژنی بین دو رشته دنا (DNA) در محل آغاز می‌شود.",
                "همواره در درون هسته یاخته به توالی ویژه‌ای از نوکلئوتیدها به نام راه‌انداز متصل می‌گردد.",
                "در همه جانداران، تنها قادر به ساخت یک نوع خاص از مولکول‌های رنا (RNA) در یاخته است.",
                "پس از باز شدن دو رشته دنا توسط هلیکاز، تشکیل پیوندهای فسفودی‌استر را آغاز می‌کند.",
              ],
              correctIndex: 0,
              optionDiagnostics: [
                {
                  optionIndex: 0,
                  isCorrect: true,
                  trapOrMisconceptionLabel: "پاسخ صحیح (مشترک در پروکاریوت و یوکاریوت)",
                  detailedAnalysis:
                    "در تمامی یاخته‌ها (پروکاریوت و یوکاریوت)، باز کردن دو رشته DNA و شکستن پیوندهای هیدروژنی در مرحله آغاز بر عهده خودِ RNA پلی‌مراز بوده و هلیکاز نقشی ندارد.",
                },
                {
                  optionIndex: 1,
                  isCorrect: false,
                  trapOrMisconceptionLabel: "تله قیدی «همواره در درون هسته» (حذف پروکاریوت‌ها)",
                  detailedAnalysis:
                    "در باکتری‌ها (پروکاریوت‌ها) هسته وجود ندارد و رونویسی در سیتوپلاسم انجام می‌شود؛ بنابراین قید «همواره در درون هسته» برای «هر ژن در یاخته زنده» نادرست است.",
                },
                {
                  optionIndex: 2,
                  isCorrect: false,
                  trapOrMisconceptionLabel: "تله تعمیم ویژگی یوکاریوت به پروکاریوت",
                  detailedAnalysis:
                    "در پروکاریوت‌ها تنها یک نوع RNA پلی‌مراز وجود دارد که «همه انواع RNA» (نه یک نوع خاص) را رونویسی می‌کند.",
                },
                {
                  optionIndex: 3,
                  isCorrect: false,
                  trapOrMisconceptionLabel: "تله خلط همانندسازی با رونویسی (نام بردن از هلیکاز)",
                  detailedAnalysis:
                    "هلیکاز در همانندسازی فعالیت دارد و در رونویسی هیچ نقشی در باز کردن دو رشته دنا ایفا نمی‌کند.",
                },
              ],
              eliminationShortcut:
                "تکنیک رد گزینه زیر ۱۵ ثانیه: گزینه ۴ به خاطر کلمه «هلیکاز» فوراً حذف می‌شود؛ گزینه ۲ به خاطر «همواره در هسته» و گزینه ۳ به خاطر «در همه جانداران» با مثال نقض باکتری رد می‌شوند؛ گزینه ۱ صددرصد صحیح است.",
            },
          },
        ],
      },
    ],
  },
  {
    slug: "physics-12-kinematics-mastery",
    title: "فیزیک دوازدهم: حرکت‌شناسی و دینامیک به سبک میمو",
    subject: "فیزیک",
    grade: "دوازدهم",
    reshte: "ریاضی و تجربی",
    icon: "⚡",
    color: "indigo",
    tagline: "ساخت بلوکی فرمول‌های حرکت با شتاب ثابت و کشف باگ‌های علامت برداری در حل تست.",
    description:
      "در فیزیک کنکور، حفظ کردن فرمول کافی نیست! در این ماژول یاد می‌گیرید چطور مثل دیباگ کردن کد در میمو، خطای علامت شتاب و سرعت را در راه‌حل‌ها شکار کنید و معادله مستقل از زمان را بلوک‌به‌بلوک بسازید.",
    lessons: [
      {
        slug: "constant-acceleration-time-independent",
        title: "حرکت با شتاب ثابت: تندشونده/کندشونده و معادله مستقل از زمان",
        chapterReference: "فیزیک دوازدهم - فصل ۱ (حرکت بر خط راست) - بخش ۳",
        rawTextbookExcerpt: PRESET_TEXTBOOK_SAMPLES[1].rawTextbookExcerpt,
        xpReward: 50,
        estimatedMinutes: 5,
        pedagogicalBlueprint: {
          atomicConcepts: [
            {
              id: "C1_SPEEDUP_SLOWDOWN_SIGN",
              title: "شرط تندشونده و کندشونده بودن بر اساس علامت حاصل‌ضرب v × a",
              textbookQuote:
                "صرفاً منفی بودن شتاب به معنای کندشونده بودن نیست؛ هم‌جهتی v و a (v×a > 0) تندشونده و خلاف‌جهتی (v×a < 0) کندشونده است.",
              cognitiveLevel: "understand",
              isPrerequisite: true,
              targetMechanic: "concept_bite",
            },
            {
              id: "C2_NEGATIVE_AXIS_TRAP",
              title: "تشخیص علامت شتاب در حرکت کندشونده در خلاف جهت محور",
              textbookQuote:
                "اگر متحرک در خلاف جهت محور حرکت کند (v < 0) و حرکت کندشونده باشد، بردار شتاب مثبت (a > 0) است.",
              cognitiveLevel: "apply",
              isPrerequisite: false,
              targetMechanic: "guided_cloze",
            },
            {
              id: "C3_TIME_INDEPENDENT_FORMULA",
              title: "ساخت بلوکی معادله مستقل از زمان برای مسائل مسافت ترمز",
              textbookQuote: "زمانی که t در مسئله نیست، معادله v² - v₀² = 2aΔx کوتاه‌ترین مسیر است.",
              cognitiveLevel: "apply",
              isPrerequisite: false,
              targetMechanic: "token_assembly",
            },
            {
              id: "C4_SOLUTION_SIGN_BUG",
              title: "شکار باگ علامت شتاب و عدم تبدیل واحد km/h به m/s در حل تست ترمز",
              textbookQuote:
                "در محاسبه مسافت توقف، جایگذاری شتاب با علامت نادرست یا سرعت برحسب km/h خطای مهلک است.",
              cognitiveLevel: "analyze",
              isPrerequisite: false,
              targetMechanic: "trap_detector",
            },
          ],
          prerequisiteChain: [
            {
              fromId: "C1_SPEEDUP_SLOWDOWN_SIGN",
              toId: "C2_NEGATIVE_AXIS_TRAP",
              relation: "درک قاعده علامت v×a پیش‌نیاز تعیین علامت a در جهت منفی محور است",
            },
            {
              fromId: "C2_NEGATIVE_AXIS_TRAP",
              toId: "C3_TIME_INDEPENDENT_FORMULA",
              relation: "تعیین علامت دقیق شتاب پیش‌نیاز جایگذاری در معادله مستقل از زمان است",
            },
            {
              fromId: "C3_TIME_INDEPENDENT_FORMULA",
              toId: "C4_SOLUTION_SIGN_BUG",
              relation: "تسلط بر فرمول مستقل از زمان پیش‌نیاز دیباگ کردن راه‌حل تست ترمز است",
            },
          ],
          konkurModifiersAndFormulas: [
            {
              id: "MOD_VA_PRODUCT",
              phrase: "قاعده علامت: v × a > 0 تندشونده و v × a < 0 کندشونده",
              category: "فرمول و رابطه کلیدی",
              explanation:
                "شتاب منفی وقتی با سرعت منفی همراه شود (هر دو در جهت منفی محور)، حرکت تندشونده ایجاد می‌کند نه کندشونده!",
            },
            {
              id: "MOD_NO_TIME_EQ",
              phrase: "معادله مستقل از زمان: v² - v₀² = 2aΔx (در توقف کامل: Δx = -v₀² / 2a)",
              category: "فرمول و رابطه کلیدی",
              explanation:
                "مسافت توقف با مجذور تندی اولیه (v₀²) رابطه مستقیم دارد؛ یعنی ۲ برابر شدن سرعت، مسافت ترمز را ۴ برابر می‌کند.",
            },
          ],
          designerTraps: [
            {
              id: "TRAP_PHYS_1",
              trapTitle: "تله یکی گرفتن شتاب منفی (a < 0) با حرکت کندشونده",
              trapCategory: "تله واحد و علامت",
              commonWrongBelief: "هرگاه شتاب منفی باشد (a < 0)، تندی متحرک در حال کاهش است.",
              scientificTruth:
                "اگر متحرک در جهت منفی محور حرکت کند (v < 0) و شتاب هم منفی باشد (a < 0)، تندی آن افزایش می‌یابد (تندشونده).",
            },
            {
              id: "TRAP_PHYS_2",
              trapTitle: "تله رابطه خطی مسافت ترمز با سرعت اولیه",
              trapCategory: "تله واحد و علامت",
              commonWrongBelief: "اگر سرعت خودرو ۲ برابر شود، مسافت ترمز هم ۲ برابر می‌شود.",
              scientificTruth:
                "به دلیل توان دوم در v₀²، با ۲ برابر شدن سرعت اولیه، مسافت ترمز ۴ برابر می‌شود.",
            },
          ],
          missingLinkMapping: {
            mimoOriginalMechanic: "ساخت عبارت کد از توکن‌ها و دیباگ کردن خط کد دارای باگ منطقی",
            konkurIsomorphicMechanic:
              "چیدمان بلوک‌های جبری معادله مستقل از زمان (`formula_derivation`) + دیباگ ۴ سطر حل مسئله ترمز خودرو (`math_solution_bug`)",
            bridgingRationale:
              "در فیزیک، فرمول‌نویسی و حل معادله دقیقاً معادل کدنویسی است؛ دانش‌آموز به جای دیدن فرمول آماده، ساختار آن را می‌چیند و باگ علامت/واحد را کشف می‌کند.",
          },
        },
        steps: [
          {
            type: "concept_bite",
            conceptNodeId: "C1_SPEEDUP_SLOWDOWN_SIGN",
            scaffoldingLevel: 1,
            content: {
              kind: "concept_bite",
              title: "لقمه مفهومی: شتاب منفی همیشه ترمز نیست!",
              hookAnalogy:
                "فرض کنید دارید دنده‌عقب (جهت منفی) حرکت می‌کنید و پایتان را بیشتر روی گاز فشار می‌دهید (شتاب هم در جهت منفی)؛ آیا سرعتتان کم می‌شود؟ نه، دارید با سرعت بیشتر دنده‌عقب می‌روید!",
              bodyMarkdown:
                "در فیزیک کنکور، **منفی بودن شتاب ($a < 0$) به تنهایی به معنای کندشونده بودن نیست!** معیار قطعی، علامت حاصل‌ضرب سرعت در شتاب است:\n- اگر **$v \\times a > 0$** (هم‌جهت): حرکت **تندشونده**\n- اگر **$v \\times a < 0$** (خلاف جهت): حرکت **کندشونده**",
              highlightedModifiers: ["منفی بودن شتاب", "v × a > 0", "v × a < 0"],
              coreFormulaOrRule: "هم‌جهت (v·a > 0) ⇐ تندشونده | خلاف‌جهت (v·a < 0) ⇐ کندشونده",
              interactiveCheckQuestion:
                "اگر متحرکی با سرعت v = -10 m/s و شتاب a = -2 m/s² حرکت کند، آیا حرکت آن کندشونده است؟",
              interactiveCheckAnswer: false,
              interactiveCheckExplanation:
                "خیر! چون سرعت و شتاب هر دو منفی (هم‌جهت) هستند، حاصل‌ضرب v×a مثبت (+20) بوده و حرکت تندشونده در جهت منفی محور است.",
            },
          },
          {
            type: "guided_cloze",
            conceptNodeId: "C2_NEGATIVE_AXIS_TRAP",
            scaffoldingLevel: 2,
            content: {
              kind: "guided_cloze",
              prompt: "شرط علامت بردار شتاب را در گزاره کنکوری زیر کامل کنید:",
              templateWithBlank:
                "هرگاه خودرویی در خلاف جهت محور x (یعنی v < 0) در حال حرکت باشد و راننده ترمز بگیرد (حرکت کندشونده)، علامت شتاب خودرو الزاماً ___ است.",
              correctAnswer: "مثبت (a > 0)",
              chipOptions: [
                "مثبت (a > 0)",
                "منفی (a < 0)",
                "صفر (a = 0)",
                "ابتدا منفی سپس صفر",
              ],
              targetedModifierId: "MOD_VA_PRODUCT",
              nudgeHint:
                "در حرکت کندشونده باید v و a خلاف جهت هم باشند؛ وقتی v منفی است، a باید چه علامتی داشته باشد؟",
              deepExplanation:
                "چون حرکت در خلاف جهت محور است ($v < 0$) و ترمز گرفته شده (کندشونده: $v \\times a < 0$)، بردار شتاب باید خلاف جهت سرعت یعنی در جهت مثبت محور ($a > 0$) باشد!",
            },
          },
          {
            type: "token_assembly",
            conceptNodeId: "C3_TIME_INDEPENDENT_FORMULA",
            scaffoldingLevel: 3,
            content: {
              kind: "token_assembly",
              prompt:
                "معادل Code میمو: زمانی که زمان (t) در مسئله داده نشده و متحرک تا توقف کامل ترمز می‌کند، بلوک‌های استنتاج فرمول «مسافت توقف» را به ترتیب بچینید:",
              assemblyMode: "formula_derivation",
              orderedTokens: [
                "۱. انتخاب معادله مستقل از زمان: v² - v₀² = 2aΔx",
                "۲. جایگذاری شرط توقف کامل در انتهای مسیر: v = 0",
                "۳. ساده‌سازی رابطه به فرم: -v₀² = 2aΔx",
                "۴. استخراج مسافت توقف: Δx = -v₀² / (2a)  (متناسب با مجذور سرعت اولیه)",
              ],
              distractorTokens: [
                {
                  token: "تله: استفاده از رابطه Δx = v₀t بدون داشتن زمان توقف",
                  trapReason:
                    "در حرکت شتاب‌دار نمی‌توان از فرمول سرعت ثابت Δx = vt استفاده کرد و زمان t هم مجهول است.",
                },
                {
                  token: "تله: نتیجه‌گیری رابطه خطی Δx ∝ v₀ (دو برابر شدن مسافت با دو برابر شدن سرعت)",
                  trapReason:
                    "سرعت اولیه دارای توان ۲ است؛ پس با ۲ برابر شدن v₀، مسافت توقف ۴ برابر می‌شود.",
                },
              ],
              nudgeHint:
                "از معادله مستقل از زمان شروع کنید، سرعت نهایی را صفر بگذارید و Δx را برحسب v₀² تنها کنید.",
              assemblyExplanation:
                "این زنجیره ۴ مرحله‌ای به شما نشان می‌دهد چرا در تمام تست‌های ترمز کنکور که زمان مطرح نیست، رابطه Δx با v₀² کلید حل ۱0 ثانیه‌ای است.",
            },
          },
          {
            type: "trap_detector",
            conceptNodeId: "C4_SOLUTION_SIGN_BUG",
            scaffoldingLevel: 4,
            content: {
              kind: "trap_detector",
              prompt:
                "دیباگر راه‌حل فیزیک: خودرویی با تندی 72 km/h ترمز کرده و با شتاب ثابت به بزرگی 4 m/s² متوقف می‌شود. در ۴ سطر راه‌حل زیر، کدام سطر دارای باگ محاسباتی/مفهومی است؟",
              contextType: "math_solution_bug",
              segments: [
                "سطر ۱ (تبدیل واحد): v₀ = 72 km/h ÷ 3.6 = 20 m/s و سرعت نهایی توقف v = 0",
                "سطر ۲ (معادله مستقل از زمان): v² - v₀² = 2aΔx",
                "سطر ۳ (جایگذاری مقادیر): 0 - (20)² = 2 × (+4) × Δx  ⇒  -400 = 8 Δx",
                "سطر ۴ (پاسخ نهایی): Δx = -50 m (خودرو ۵۰ متر به عقب حرکت کرده است!)",
              ],
              flawedSegmentIndex: 2,
              trapCategory: "تله علامت شتاب در حرکت کندشونده (جایگذاری +4 به جای -4)",
              fixOptions: [
                "اصلاحیه صحیح: چون سرعت اولیه مثبت (+20) و حرکت کندشونده است، شتاب باید منفی (a = -4 m/s²) جایگذاری شود: -400 = 2(-4)Δx ⇒ Δx = +50 m.",
                "اصلاحیه غلط ۱: تبدیل واحد 72 km/h باید ضرب در 3.6 شود نه تقسیم بر 3.6.",
                "اصلاحیه غلط ۲: سرعت نهایی در توقف کامل برابر 20 m/s است.",
              ],
              correctFixIndex: 0,
              diagnosticAutopsy:
                "در سطر سوم، عبارت «شتاب به بزرگی ۴ در ترمز» بدون علامت منفی (+4) در فرمول گذاشته شده که منجر به جابه‌جایی منفی در سطر چهارم شده است! در ترمز در جهت مثبت محور، حتماً a = -4 m/s² است.",
            },
          },
          {
            type: "step_solver",
            conceptNodeId: "C3_TIME_INDEPENDENT_FORMULA",
            scaffoldingLevel: 5,
            content: {
              kind: "step_solver",
              problemStatement:
                "حل پله‌ای تست نسبتی کنکور: «خودرویی با تندی v₀ ترمز کرده و پس از طی مسافت d متوقف می‌شود. اگر تندی اولیه آن ۳ برابر شود (3v₀) و با همان شتاب ترمز کند، مسافت توقف چند d می‌شود؟»",
              subSteps: [
                {
                  stageLabel: "گام اول: تشخیص رابطه متغیرها و حذف ثابت‌ها",
                  question:
                    "طبق فرمول Δx = -v₀² / (2a)، وقتی شتاب ترمز (a) ثابت است، مسافت توقف (d) با کدام توان از تندی اولیه متناسب است؟",
                  options: [
                    "متناسب با توان دوم تندی اولیه (d ∝ v₀²)",
                    "متناسب با توان اول تندی اولیه (d ∝ v₀)",
                    "متناسب با جذر تندی اولیه (d ∝ √v₀)",
                  ],
                  correctIndex: 0,
                  microFeedback: "عالی! چون شتاب ثابت است، تنها متغیر اثرگذار مجذور سرعت اولیه است.",
                },
                {
                  stageLabel: "گام دوم: اعمال ضریب تغییر",
                  question: "حالا که تندی اولیه ۳ برابر شده است، مسافت توقف جدید چند برابر d خواهد شد؟",
                  options: [
                    "۹ برابر (3² = 9d)",
                    "۳ برابر (3d)",
                    "۶ برابر (2 × 3 = 6d)",
                  ],
                  correctIndex: 0,
                  microFeedback:
                    "دقیقاً! سه به توان دو برابر ۹ می‌شود؛ بنابراین مسافت ترمز ۹ برابر (9d) خواهد شد.",
                },
              ],
              finalTakeaway:
                "در تست‌های نسبتی کنکور، به جای عددگذاری طولانی، متغیرهای ثابت را خط بزنید و فقط نسبت توان متغیر تغییریافته را حساب کنید.",
            },
          },
          {
            type: "konkur_test",
            conceptNodeId: "C4_SOLUTION_SIGN_BUG",
            scaffoldingLevel: 6,
            content: {
              kind: "konkur_test",
              questionStem:
                "متحرکی روی محور x با تندی اولیه 108 km/h در جهت مثبت محور در حال حرکت است. اگر متحرک با شتاب ثابت ترمز کند و پس از طی مسافت 90 متر متوقف شود، بردار شتاب حرکت در SI کدام است؟",
              sourceBadge: "کنکور سراسری ریاضی و تجربی - حرکت بر خط راست",
              targetTimeSeconds: 45,
              options: [
                "-5 i (پنج متر بر مجذور ثانیه در خلاف جهت محور)",
                "+5 i (پنج متر بر مجذور ثانیه در جهت محور)",
                "-64.8 i (شصت و چهار ممیز هشت در خلاف جهت محور)",
                "-10 i (ده متر بر مجذور ثانیه در خلاف جهت محور)",
              ],
              correctIndex: 0,
              optionDiagnostics: [
                {
                  optionIndex: 0,
                  isCorrect: true,
                  trapOrMisconceptionLabel: "پاسخ صحیح (تبدیل واحد + علامت برداری صحیح)",
                  detailedAnalysis:
                    "تندی اولیه 108 ÷ 3.6 = 30 m/s است. از رابطه 0 - 30² = 2a(90) نتیجه می‌شود -900 = 180a و بنابراین a = -5 m/s² (یعنی -5 i).",
                },
                {
                  optionIndex: 1,
                  isCorrect: false,
                  trapOrMisconceptionLabel: "تله علامت بردار شتاب در حرکت کندشونده",
                  detailedAnalysis:
                    "بزرگی شتاب درست محاسبه شده (5 m/s²)، اما چون حرکت در جهت مثبت محور و کندشونده است، جهت بردار شتاب باید منفی (-5 i) باشد نه مثبت.",
                },
                {
                  optionIndex: 2,
                  isCorrect: false,
                  trapOrMisconceptionLabel: "تله عدم تبدیل واحد km/h به m/s",
                  detailedAnalysis:
                    "این گزینه حاصل جایگذاری مستقیم عدد 108 بدون تقسیم بر 3.6 در معادله مستقل از زمان است!",
                },
                {
                  optionIndex: 3,
                  isCorrect: false,
                  trapOrMisconceptionLabel: "تله فراموش کردن ضریب ۲ در فرمول 2aΔx",
                  detailedAnalysis:
                    "اگر در مخرج کسر Δx ضریب ۲ در 2aΔx فراموش شود (-900 / 90)، عدد -10 به دست می‌آید که تله رایج محاسباتی است.",
                },
              ],
              eliminationShortcut:
                "تکنیک رد گزینه زیر ۱۵ ثانیه: حرکت در جهت +x و ترمزی است، پس شتاب حتماً منفی است (رد گزینه ۲). با تبدیل سریع 108/3.6 = 30 و تقسیم ذهنی 900 بر 180، عدد -5 در چند ثانیه به دست می‌آید.",
            },
          },
        ],
      },
    ],
  },
  {
    slug: "chem-konkur-stoichiometry",
    title: "شیمی کنکور: استوکیومتری و مفاهیم به روش خط لوله میمو",
    subject: "شیمی",
    grade: "یازدهم و دوازدهم",
    reshte: "ریاضی و تجربی",
    icon: "🧪",
    color: "amber",
    tagline: "تبدیل مسائل چندمرحله‌ای استوکیومتری به بلوک‌های زنجیره‌ای بدون حفظ کردن فرمول.",
    description:
      "در شیمی کنکور، مسائل استوکیومتری با درصد خلوص و بازده درصدی کابوس داوطلبان است. با متدولوژی بلوکی میمو، هر مسئله استوکیومتری را به یک خط لوله ۴ تکه تبدیل می‌کنیم.",
    lessons: [
      {
        slug: "stoichiometry-pipeline-stp",
        title: "خط لوله استوکیومتری، تله شرایط STP و بازده درصدی",
        chapterReference: "شیمی یازدهم فصل ۱ و شیمی دوازدهم - استوکیومتری واکنش‌ها",
        rawTextbookExcerpt: PRESET_TEXTBOOK_SAMPLES[2].rawTextbookExcerpt,
        xpReward: 50,
        estimatedMinutes: 5,
        pedagogicalBlueprint: {
          atomicConcepts: [
            {
              id: "C1_MOLE_RATIO_CORE",
              title: "ضرایب استوکیومتری به عنوان نسبت مولی (نه نسبت جرمی)",
              textbookQuote:
                "نسبت ضرایب موازنه تنها بیانگر نسبت مولی مواد است و هرگز مستقیماً نسبت جرمی را نشان نمی‌دهد.",
              cognitiveLevel: "understand",
              isPrerequisite: true,
              targetMechanic: "concept_bite",
            },
            {
              id: "C2_STP_GAS_CONDITION",
              title: "شرط استفاده از حجم مولی ۲۲/۴ لیتر (فقط گاز و فقط در STP)",
              textbookQuote:
                "حجم مولی هر گاز تنها در شرایط STP برابر ۲۲/۴ لیتر بر مول است و برای مایعات یا جامدات خطای علمی است.",
              cognitiveLevel: "apply",
              isPrerequisite: false,
              targetMechanic: "guided_cloze",
            },
            {
              id: "C3_STOICH_PIPELINE",
              title: "ساخت خط لوله کسرهای تبدیل استوکیومتری با خلوص و بازده",
              textbookQuote:
                "گرم ناخالص × ضریب خلوص ÷ جرم مولی × نسبت ضرایب موازنه × ضریب بازده × ۲۲/۴",
              cognitiveLevel: "apply",
              isPrerequisite: false,
              targetMechanic: "token_assembly",
            },
            {
              id: "C4_STP_LIQUID_TRAP",
              title: "شکار تله استفاده از ۲۲/۴ برای آب مایع (H2O(l)) یا شرایط غیر STP",
              textbookQuote: "برای مایعات یا شرایط غیر استاندارد استفاده از ۲۲/۴ لیتر بر مول غلط است.",
              cognitiveLevel: "analyze",
              isPrerequisite: false,
              targetMechanic: "trap_detector",
            },
          ],
          prerequisiteChain: [
            {
              fromId: "C1_MOLE_RATIO_CORE",
              toId: "C2_STP_GAS_CONDITION",
              relation: "درک مفهوم مول پیش‌نیاز تبدیل مول به حجم گاز در STP است",
            },
            {
              fromId: "C2_STP_GAS_CONDITION",
              toId: "C3_STOICH_PIPELINE",
              relation: "شناخت کسر تبدیل حجم مولی پیش‌نیاز چیدن کل خط لوله استوکیومتری است",
            },
            {
              fromId: "C3_STOICH_PIPELINE",
              toId: "C4_STP_LIQUID_TRAP",
              relation: "تسلط بر خط لوله استاندارد پیش‌نیاز کشف تله حالت فیزیکی مایع/گاز است",
            },
          ],
          konkurModifiersAndFormulas: [
            {
              id: "MOD_STP_ONLY_GAS",
              phrase: "۲۲/۴ لیتر بر مول: منحصراً برای حالت گازی (g) و منحصراً در شرایط STP",
              category: "استثنای کتاب درسی",
              explanation:
                "طراح کنکور زیر فرمول آب یا گوگرد تری‌اکسید علامت (l) یا (s) می‌گذارد تا داوطلب به اشتباه حجم را بر ۲۲/۴ تقسیم کند!",
            },
            {
              id: "MOD_YIELD_PURITY",
              phrase: "ضریب خلوص و ضریب بازده درصدی هنگام حرکت از واکنش‌دهنده به فرآورده در صورت کسر ضرب می‌شوند",
              category: "فرمول و رابطه کلیدی",
              explanation:
                "ناخالصی و بازده کمتر از ۱۰۰٪ هر دو باعث کاهش مقدار فرآورده عملی نسبت به مقدار نظری می‌شوند.",
            },
          ],
          designerTraps: [
            {
              id: "TRAP_CHEM_1",
              trapTitle: "تله حالت فیزیکی (استفاده از ۲۲/۴ برای مایعات یا جامدات در STP)",
              trapCategory: "تله قیدی",
              commonWrongBelief: "در شرایط STP حجم ۱ مول از هر ماده‌ای برابر ۲۲/۴ لیتر است.",
              scientificTruth:
                "عدد ۲۲/۴ لیتر در STP فقط برای گازها (g) صادق است؛ ۱ مول آب مایع (H₂O(l)) فقط ۱۸ میلی‌لیتر حجم دارد نه ۲۲/۴ لیتر!",
            },
            {
              id: "TRAP_CHEM_2",
              trapTitle: "تله نسبت جرمی گرفتن ضرایب موازنه",
              trapCategory: "تله واحد و علامت",
              commonWrongBelief: "در واکنش N₂ + 3H₂ → 2NH₃، هر ۱ گرم نیتروژن با ۳ گرم هیدروژن واکنش می‌دهد.",
              scientificTruth:
                "ضرایب ۱ و ۳ نسبت مولی هستند نه نسبت جرمی؛ باید ابتدا گرم را با تقسیم بر جرم مولی به مول تبدیل کرد.",
            },
          ],
          missingLinkMapping: {
            mimoOriginalMechanic: "ساخت پایپ‌لاین کوئری SQL و دیباگ کردن شرط WHERE",
            konkurIsomorphicMechanic:
              "چیدمان بلوکی کسرهای تبدیل استوکیومتری (`stoichiometry_pipeline`) + دیباگ راه‌حل مسئله دارای تله حالت فیزیکی (`chemistry_exception`)",
            bridgingRationale:
              "کسرهای تبدیل استوکیومتری دقیقاً یک خط لوله (Pipeline) تابعی هستند که خروجی هر بلوک واحد بلوک قبلی را ساده می‌کند.",
          },
        },
        steps: [
          {
            type: "concept_bite",
            conceptNodeId: "C1_MOLE_RATIO_CORE",
            scaffoldingLevel: 1,
            content: {
              kind: "concept_bite",
              title: "لقمه مفهومی: پل مولی و تله ۲۲/۴ لیتر!",
              hookAnalogy:
                "ضرایب معادله شیمیایی مثل «تعداد نفرات» در یک تیم است نه «وزن افراد»! برای رد شدن از واکنش‌دهنده به فرآورده، تنها پل مجاز «مول» است نه گرم.",
              bodyMarkdown:
                "در معادله موازنه‌شده، ضرایب استوکیومتری **فقط نسبت مولی** را نشان می‌دهند نه نسبت جرمی. همچنین عدد طلایی **۲۲/۴ لیتر بر مول** دو شرط قفل‌شده دارد:\n۱. ماده حتماً در **حالت گازی `(g)`** باشد.\n۲. دما و فشار حتماً **شرایط `STP`** باشد.",
              highlightedModifiers: ["فقط نسبت مولی", "۲۲/۴ لیتر بر مول", "حالت گازی (g)", "شرایط STP"],
              coreFormulaOrRule:
                "گرم A ÷ جرم مولی A ⇐ مول A × (ضریب B / ضریب A) ⇐ مول B",
              interactiveCheckQuestion:
                "آیا در شرایط استاندارد (STP)، حجم ۱ مول آب مایع H₂O(l) برابر ۲۲/۴ لیتر است؟",
              interactiveCheckAnswer: false,
              interactiveCheckExplanation:
                "هرگز! آب در شرایط STP مایع `(l)` است نه گاز `(g)`. عدد ۲۲/۴ لیتر فقط و فقط برای گازها در STP برقرار است.",
            },
          },
          {
            type: "guided_cloze",
            conceptNodeId: "C2_STP_GAS_CONDITION",
            scaffoldingLevel: 2,
            content: {
              kind: "guided_cloze",
              prompt: "قید دقیق شیمی کنکور را در جای خالی قرار دهید:",
              templateWithBlank:
                "در محاسبه حجم فرآورده از روی مول آن، ضرب کردن در عدد ۲۲/۴ لیتر تنها زمانی مجاز است که فرآورده به حالت ___ بوده و واکنش در شرایط ___ سنجیده شود.",
              correctAnswer: "گازی (g) — استاندارد (STP)",
              chipOptions: [
                "گازی (g) — استاندارد (STP)",
                "مایع یا گاز — دمای اتاق",
                "هر حالت فیزیکی — استاندارد (STP)",
                "محلول آبی (aq) — فشار ۱ اتمسفر",
              ],
              targetedModifierId: "MOD_STP_ONLY_GAS",
              nudgeHint: "به زیروند حالت فیزیکی ماده در معادله واکنش و دما/فشار استاندارد فکر کنید.",
              deepExplanation:
                "طراحان شیمی کنکور بارها با قرار دادن زیروند `(l)` یا `(aq)` یا تغییر دما به ۲۵ درجه (دمای اتاق که حجم مولی گاز حدود ۲۴ لیتر است)، داوطلبان را در تله ۲۲/۴ انداخته‌اند.",
            },
          },
          {
            type: "token_assembly",
            conceptNodeId: "C3_STOICH_PIPELINE",
            scaffoldingLevel: 3,
            content: {
              kind: "token_assembly",
              prompt:
                "معادل Code میمو: می‌خواهیم از «جرم نمونه ناخالص واکنش‌دهنده A» به «حجم گاز فرآورده B در شرایط STP» (با بازده درصدی مشخص) برسیم. کسرهای خط لوله استوکیومتری را به ترتیب بچینید:",
              assemblyMode: "stoichiometry_pipeline",
              orderedTokens: [
                "۱. ضرب جرم نمونه ناخالص A در (درصد خلوص ÷ ۱۰۰) برای یافتن جرم خالص A",
                "۲. تقسیم جرم خالص A بر جرم مولی A برای تبدیل به مول A",
                "۳. ضرب در نسبت ضرایب موازنه (ضریب B ÷ ضریب A) و ضرب در (بازده درصدی ÷ ۱۰۰)",
                "۴. ضرب مول عملی گاز B در ۲۲/۴ لیتر برای رسیدن به حجم گاز در STP",
              ],
              distractorTokens: [
                {
                  token: "تله: ضرب کردن جرم ناخالص در ضریب موازنه پیش از تقسیم بر جرم مولی",
                  trapReason:
                    "ضرایب موازنه نسبت مولی هستند و ضرب مستقیم جرم در ضریب موازنه بدون تبدیل به مول غلط است.",
                },
                {
                  token: "تله: تقسیم بر درصد خلوص و بازده درصدی هنگام حرکت از واکنش‌دهنده به فرآورده",
                  trapReason:
                    "ناخالصی و بازده زیر ۱۰۰٪ مقدار فرآورده عملی را کاهش می‌دهند، پس هنگام رفتن به سمت فرآورده باید در صورت ضرب شوند نه تقسیم!",
                },
              ],
              nudgeHint:
                "ابتدا ناخالصی را حذف کنید، سپس گرم را به مول تبدیل کنید، بعد از پل ضرایب و بازده بگذرید و در پایان مول گاز را به لیتر تبدیل نمایید.",
              assemblyExplanation:
                "این خط لوله ۴ تکه تمام مسائل استوکیومتری کنکور را بدون نیاز به تناسب‌های طولانی در یک خط حل می‌کند.",
            },
          },
          {
            type: "trap_detector",
            conceptNodeId: "C4_STP_LIQUID_TRAP",
            scaffoldingLevel: 4,
            content: {
              kind: "trap_detector",
              prompt:
                "دیباگر شیمی کنکور: در واکنش سوختن کامل ۱ مول گاز متان در شرایط STP طبق معادله `CH₄(g) + 2O₂(g) → CO₂(g) + 2H₂O(l)`، کدام بخش از تحلیل زیر دارای باگ علمی است؟",
              contextType: "chemistry_exception",
              segments: [
                "بخش ۱: به ازای مصرف ۱ مول متان، ۲ مول گاز اکسیژن (۴۴/۸ لیتر در STP) مصرف می‌شود",
                "بخش ۲: در این واکنش ۱ مول گاز کربن دی‌اکسید تولید می‌شود که حجم آن در STP برابر ۲۲/۴ لیتر است",
                "بخش ۳: همچنین ۲ مول آب تولید می‌شود که حجم آن در شرایط STP برابر ۲ × ۲۲/۴ = ۴۴/۸ لیتر است",
                "بخش ۴: مجموع ضرایب استوکیومتری مواد شرکت‌کننده در معادله موازنه‌شده برابر ۶ است",
              ],
              flawedSegmentIndex: 2,
              trapCategory: "تله حالت فیزیکی: استفاده از ۲۲/۴ لیتر برای آب مایع H₂O(l) در STP",
              fixOptions: [
                "اصلاحیه صحیح: چون آب در شرایط STP مایع `H₂O(l)` است، حجم ۲ مول آن برابر ۳۶ گرم (۳۶ میلی‌لیتر) است نه ۴۴/۸ لیتر!",
                "اصلاحیه غلط ۱: ضریب آب در معادله موازنه‌شده باید ۱ باشد نه ۲.",
                "اصلاحیه غلط ۲: کربن دی‌اکسید در شرایط STP جامد است.",
              ],
              correctFixIndex: 0,
              diagnosticAutopsy:
                "به زیروند `H₂O(l)` در معادله دقت کنید! در دمای صفر درجه سانتی‌گراد (STP)، آب به صورت مایع است نه بخار؛ بنابراین ضرب کردن مول آب در ۲۲/۴ لیتر بزرگ‌ترین تله این تست است.",
            },
          },
          {
            type: "step_solver",
            conceptNodeId: "C3_STOICH_PIPELINE",
            scaffoldingLevel: 5,
            content: {
              kind: "step_solver",
              problemStatement:
                "حل پله‌ای تست استوکیومتری: «از تجزیه گرمایی ۲۰۰ گرم کلسیم کربنات (`CaCO₃` با جرم مولی ۱۰۰) با خلوص ۸۰٪ و بازده واکنش ۵۰٪ طبق معادله `CaCO₃(s) → CaO(s) + CO₂(g)` چند لیتر گاز در STP تولید می‌شود؟»",
              subSteps: [
                {
                  stageLabel: "گام اول: محاسبه مول خالص و اعمال بازده",
                  question:
                    "۲۰۰ گرم کلسیم کربنات با جرم مولی ۱۰۰ معادل ۲ مول ناخالص است. با ضرب در خلوص (۰/۸) و بازده (۰/۵)، چند مول گاز CO₂ عملاً تولید می‌شود؟",
                  options: [
                    "۰/۸ مول (2 × 0.8 × 0.5 = 0.8 mol)",
                    "۲ مول (بدون تغییر)",
                    "۵ مول (تقسیم بر ۰/۸ و ۰/۵)",
                  ],
                  correctIndex: 0,
                  microFeedback:
                    "عالی! ضرب کردن ۲ مول در ۰/۸ و ۰/۵ به سرعت عدد ۰/۸ مول گاز CO₂ را می‌دهد.",
                },
                {
                  stageLabel: "گام دوم: تبدیل مول گاز به حجم در STP",
                  question: "حالا حجم ۰/۸ مول گاز CO₂ در شرایط STP چند لیتر است؟",
                  options: [
                    "۱۷/۹۲ لیتر (0.8 × 22.4 = 17.92 L)",
                    "۲۲/۴ لیتر",
                    "۴۴/۸ لیتر",
                  ],
                  correctIndex: 0,
                  microFeedback: "دقیقاً! ضرب ۰/۸ در ۲۲/۴ لیتر عدد ۱۷/۹۲ لیتر را بدون خطا به دست می‌دهد.",
                },
              ],
              finalTakeaway:
                "فرمول یک‌خطی طلایی: مول فرآورده عملی = (مول ناخالص × درصد خلوص × بازده درصدی × نسبت ضرایب).",
            },
          },
          {
            type: "konkur_test",
            conceptNodeId: "C4_STP_LIQUID_TRAP",
            scaffoldingLevel: 6,
            content: {
              kind: "konkur_test",
              questionStem:
                "اگر ۰/۵ مول گاز پروپان (`C₃H₈`) با مقدار کافی اکسیژن در شرایط STP با بازده ۸۰٪ طبق معادله موازنه‌شده `C₃H₈(g) + 5O₂(g) → 3CO₂(g) + 4H₂O(l)` بسوزد، مجموع حجم فرآورده‌های گازی تولیدشده در شرایط STP چند لیتر است؟",
              sourceBadge: "کنکور سراسری تجربی و ریاضی - استوکیومتری",
              targetTimeSeconds: 50,
              options: [
                "۲۶/۸۸ لیتر",
                "۶۲/۷۲ لیتر",
                "۳۳/۶۰ لیتر",
                "۷۸/۴۰ لیتر",
              ],
              correctIndex: 0,
              optionDiagnostics: [
                {
                  optionIndex: 0,
                  isCorrect: true,
                  trapOrMisconceptionLabel: "پاسخ صحیح (فقط CO₂ گازی است + اعمال بازده ۸۰٪)",
                  detailedAnalysis:
                    "تنها فرآورده گازی CO₂ است (چون H₂O مایع است). مول CO₂ برابر 0.5 × 3 × 0.8 = 1.2 مول است و حجم آن در STP برابر 1.2 × 22.4 = 26.88 لیتر می‌شود.",
                },
                {
                  optionIndex: 1,
                  isCorrect: false,
                  trapOrMisconceptionLabel: "تله جمع زدن آب مایع H₂O(l) به عنوان فرآورده گازی!",
                  detailedAnalysis:
                    "اگر داوطلب به زیروند `H₂O(l)` دقت نکند و مجموع ضرایب فرآورده‌ها را 3 + 4 = 7 بگیرد، به عدد 0.5 × 7 × 0.8 × 22.4 = 62.72 لیتر می‌رسد!",
                },
                {
                  optionIndex: 2,
                  isCorrect: false,
                  trapOrMisconceptionLabel: "تله فراموش کردن ضرب بازده ۸۰٪",
                  detailedAnalysis:
                    "اگر فقط CO₂ حساب شود اما بازده ۸۰٪ اعمال نشود (0.5 × 3 × 22.4)، عدد ۳۳/۶۰ لیتر به دست می‌آید.",
                },
                {
                  optionIndex: 3,
                  isCorrect: false,
                  trapOrMisconceptionLabel: "تله دوگانه: هم حساب کردن آب مایع به عنوان گاز و هم فراموشی بازده",
                  detailedAnalysis:
                    "این گزینه حاصل 0.5 × 7 × 22.4 = 78.40 لیتر است که هر دو تله حالت فیزیکی و بازده را هم‌زمان دارد.",
                },
              ],
              eliminationShortcut:
                "تکنیک رد گزینه سریع: به زیروند `H₂O(l)` نگاه کنید! آب مایع است پس ضریب ۴ آب حذف می‌شود (رد فوری گزینه‌های ۲ و ۴). با اعمال بازده ۰/۸ روی ۳۳/۶، گزینه ۱ (۲۶/۸۸) به دست می‌آید.",
            },
          },
        ],
      },
    ],
  },
  {
    slug: "math-konkur-calculus",
    title: "ریاضی و حسابان کنکور: مشتق‌پذیری و نقاط بحرانی به سبک میمو",
    subject: "ریاضیات",
    grade: "دوازدهم",
    reshte: "ریاضی و تجربی",
    icon: "📐",
    color: "rose",
    tagline: "مهندسی معکوس قضایای حد، پیوستگی و مشتق‌پذیری با شکارچی مغالطه‌های جبری.",
    description:
      "قضایای مشتق‌پذیری و نقاط گوشه قدرمطلق از مباحث قطعی هر سال کنکور هستند. در این دوره، شروط قضایا را بلوک‌به‌بلوک می‌سازید و مغالطه‌های رایج در حل تست‌های قدرمطلق را شکار می‌کنید.",
    lessons: [
      {
        slug: "continuity-vs-differentiability-corner-points",
        title: "رابطه پیوستگی و مشتق‌پذیری: شکار نقاط گوشه در قدرمطلق",
        chapterReference: "حسابان دوازدهم / ریاضی تجربی - فصل مشتق",
        rawTextbookExcerpt: PRESET_TEXTBOOK_SAMPLES[3].rawTextbookExcerpt,
        xpReward: 50,
        estimatedMinutes: 5,
        pedagogicalBlueprint: {
          atomicConcepts: [
            {
              id: "C1_DIFF_IMPLIES_CONT",
              title: "شرط لازم مشتق‌پذیری (مشتق‌پذیری ⇐ پیوستگی، اما عکس آن کاذب است)",
              textbookQuote:
                "هر تابع مشتق‌پذیر در یک نقطه الزاماً پیوسته است، اما عکس این قضیه همواره برقرار نیست.",
              cognitiveLevel: "understand",
              isPrerequisite: true,
              targetMechanic: "concept_bite",
            },
            {
              id: "C2_CORNER_POINT_RULE",
              title: "شرط ایجاد نقطه گوشه در ریشه ساده داخل قدرمطلق",
              textbookQuote:
                "هرگاه عبارت داخل قدرمطلق ریشه ساده داشته باشد و ضریب بیرون قدرمطلق صفر نشود، نقطه گوشه داریم.",
              cognitiveLevel: "apply",
              isPrerequisite: false,
              targetMechanic: "guided_cloze",
            },
            {
              id: "C3_ABS_DIFF_ALGORITHM",
              title: "الگوریتم ۳ مرحله‌ای تشخیص مشتق‌پذیری توابع قدرمطلقی f(x) = g(x)|h(x)|",
              textbookQuote:
                "یافتن ریشه داخل قدرمطلق ← بررسی مرتبه ریشه ← بررسی صفر شدن ضریب بیرون قدرمطلق",
              cognitiveLevel: "apply",
              isPrerequisite: false,
              targetMechanic: "token_assembly",
            },
            {
              id: "C4_CONVERSE_FALLACY_TRAP",
              title: "شکار مغالطه نتیجه گرفتن مشتق‌پذیری از پیوستگی یا ضرب در عامل صفرشونده",
              textbookQuote:
                "اگر ضریب بیرون قدرمطلق در ریشه داخل قدرمطلق صفر شود، نقطه گوشه از بین رفته و تابع مشتق‌پذیر می‌شود.",
              cognitiveLevel: "analyze",
              isPrerequisite: false,
              targetMechanic: "trap_detector",
            },
          ],
          prerequisiteChain: [
            {
              fromId: "C1_DIFF_IMPLIES_CONT",
              toId: "C2_CORNER_POINT_RULE",
              relation: "شناخت تفاوت پیوستگی و مشتق‌پذیری پیش‌نیاز درک مفهوم نقطه گوشه است",
            },
            {
              fromId: "C2_CORNER_POINT_RULE",
              toId: "C3_ABS_DIFF_ALGORITHM",
              relation: "شناخت نقطه گوشه پیش‌نیاز اجرای الگوریتم بررسی توابع قدرمطلقی است",
            },
            {
              fromId: "C3_ABS_DIFF_ALGORITHM",
              toId: "C4_CONVERSE_FALLACY_TRAP",
              relation: "تسلط بر الگوریتم ضریب بیرون قدرمطلق پیش‌نیاز کشف تله‌های کنکور است",
            },
          ],
          konkurModifiersAndFormulas: [
            {
              id: "MOD_ONE_WAY_THM",
              phrase: "مشتق‌پذیری ⇐ پیوستگی (رابطه یک‌طرفه؛ پیوستگی ⇏ مشتق‌پذیری)",
              category: "فرمول و رابطه کلیدی",
              explanation:
                "تابع y = |x| در x = 0 پیوسته است اما مشتق چپ (-1) و راست (+1) آن نابرابر است (نقطه گوشه).",
            },
            {
              id: "MOD_SMOOTHING_FACTOR",
              phrase: "در f(x) = g(x)|x - a|، اگر g(a) = 0 باشد، تابع در x = a مشتق‌پذیر و مشتق آن صفر است",
              category: "فرمول و رابطه کلیدی",
              explanation:
                "عامل بیرونی g(x) زمانی که در x=a صفر شود، شکستگی قدرمطلق را نرم (Smooth) کرده و مشتق‌پذیر می‌سازد.",
            },
          ],
          designerTraps: [
            {
              id: "TRAP_MATH_1",
              trapTitle: "تله اعلام ناپیوستگی در نقاط گوشه",
              trapCategory: "تله خلط مفاهیم مشابه",
              commonWrongBelief: "هر جا تابع مشتق‌پذیر نباشد، حتماً ناپیوسته است.",
              scientificTruth:
                "در نقاط گوشه و عطف قائم، تابع کاملاً پیوسته است اما به دلیل نابرابری مشتق چپ و راست یا بی‌نهایت شدن شیب، مشتق‌پذیر نیست.",
            },
            {
              id: "TRAP_MATH_2",
              trapTitle: "تله نادیده گرفتن ضریب بیرون قدرمطلق در ریشه",
              trapCategory: "تله تعمیم افراطی",
              commonWrongBelief: "در هر تابعی که |x - a| وجود داشته باشد، نقطه x = a حتماً مشتق‌ناپذیر است.",
              scientificTruth:
                "اگر |x - a| در عاملی ضرب شود که خود در x = a برابر صفر است (مثل x|x| در x=0)، تابع کاملاً مشتق‌پذیر می‌شود!",
            },
          ],
          missingLinkMapping: {
            mimoOriginalMechanic: "چیدمان درخت تصمیم (if/else) و دیباگ کردن خطای منطقی کد",
            konkurIsomorphicMechanic:
              "چیدمان الگوریتم تصمیم‌گیری مشتق‌پذیری قدرمطلق (`formula_derivation`) + کشف مغالطه جبری در حل تست (`math_solution_bug`)",
            bridgingRationale:
              "بررسی مشتق‌پذیری تابع قدرمطلقی در نقطه ریشه دقیقاً یک فلوچارت شرطی ۳ مرحله‌ای است.",
          },
        },
        steps: [
          {
            type: "concept_bite",
            conceptNodeId: "C1_DIFF_IMPLIES_CONT",
            scaffoldingLevel: 1,
            content: {
              kind: "concept_bite",
              title: "لقمه مفهومی: خیابان یک‌طرفه مشتق‌پذیری و پیوستگی!",
              hookAnalogy:
                "برای اینکه جاده‌ای «نرم و بدون شکستگی» (مشتق‌پذیر) باشد، اول باید «بدون چاله و بریدگی» (پیوسته) باشد؛ اما جاده‌ای که پیوسته است ممکن است یک «پیچ تند نوک‌تیز» (نقطه گوشه) داشته باشد!",
              bodyMarkdown:
                "قضیه طلایی مشتق یک خیابان **یک‌طرفه** است:\n- **مشتق‌پذیری $\\implies$ پیوستگی** (همواره درست)\n- **پیوستگی $\\not\\implies$ مشتق‌پذیری** (عکس قضیه برقرار نیست!)\n\nمثال نقض مشهور کنکور: تابع $f(x) = |x|$ در $x = 0$ **پیوسته است**، اما به دلیل ایجاد **نقطه گوشه** (مشتق راست $+1$ و مشتق چپ $-1$) مشتق‌پذیر نیست.",
              highlightedModifiers: ["یک‌طرفه", "عکس قضیه برقرار نیست", "نقطه گوشه"],
              coreFormulaOrRule:
                "مشتق‌پذیر در x=a ⇐ حتماً پیوسته در x=a | ناپیوسته در x=a ⇐ حتماً مشتق‌ناپذیر در x=a",
              interactiveCheckQuestion:
                "اگر بدانیم تابعی در نقطه x = 2 پیوسته است، آیا می‌توان نتیجه گرفت که الزاماً در x = 2 مشتق‌پذیر نیز هست؟",
              interactiveCheckAnswer: false,
              interactiveCheckExplanation:
                "خیر! پیوستگی شرط لازم است نه شرط کافی؛ ممکن است تابع در x = 2 دارای نقطه گوشه (مثل |x - 2|) باشد و مشتق نداشته باشد.",
            },
          },
          {
            type: "guided_cloze",
            conceptNodeId: "C2_CORNER_POINT_RULE",
            scaffoldingLevel: 2,
            content: {
              kind: "guided_cloze",
              prompt: "قاعده تشخیص سریع مشتق‌پذیری در ریشه قدرمطلق را کامل کنید:",
              templateWithBlank:
                "در تابع پیوسته f(x) = g(x) · |x - a|، نقطه x = a (ریشه ساده داخل قدرمطلق) تنها زمانی مشتق‌پذیر می‌شود که مقدار ضریب بیرونی در آن نقطه برابر ___ باشد.",
              correctAnswer: "صفر (g(a) = 0)",
              chipOptions: [
                "صفر (g(a) = 0)",
                "یک (g(a) = 1)",
                "عددی مثبت (g(a) > 0)",
                "بی‌نهایت",
              ],
              targetedModifierId: "MOD_SMOOTHING_FACTOR",
              nudgeHint:
                "وقتی مشتق راست +g(a) و مشتق چپ -g(a) است، در چه صورتی +g(a) و -g(a) با هم برابر می‌شوند؟",
              deepExplanation:
                "مشتق راست در نقطه x = a برابر +g(a) و مشتق چپ برابر -g(a) است؛ این دو تنها زمانی با هم برابر می‌شوند که +g(a) = -g(a) یعنی g(a) = 0 باشد!",
            },
          },
          {
            type: "token_assembly",
            conceptNodeId: "C3_ABS_DIFF_ALGORITHM",
            scaffoldingLevel: 3,
            content: {
              kind: "token_assembly",
              prompt:
                "معادل Code میمو: الگوریتم تستی تعیین مشتق‌پذیری تابع `f(x) = (x² - 4)|x - 2|` در نقطه `x = 2` را به ترتیب منطقی بچینید:",
              assemblyMode: "formula_derivation",
              orderedTokens: [
                "۱. یافتن ریشه ساده عبارت داخل قدرمطلق: x - 2 = 0 ⇒ x = 2",
                "۲. بررسی ضریب بیرون قدرمطلق یعنی g(x) = x² - 4 در نقطه x = 2",
                "۳. محاسبه g(2) = 2² - 4 = 0 (صفر شدن ضریب بیرونی در ریشه قدرمطلق)",
                "۴. نتیجه‌گیری نهایی: حذف شکستگی گوشه و مشتق‌پذیر بودن تابع با f'(2) = 0",
              ],
              distractorTokens: [
                {
                  token: "تله: اعلام فوری مشتق‌ناپذیری به محض دیدن ریشه x = 2 در داخل |x - 2|",
                  trapReason:
                    "دیدن ریشه ساده داخل قدرمطلق کافی نیست؛ حتماً باید صفر شدن یا نشدن ضریب بیرون قدرمطلق بررسی شود!",
                },
                {
                  token: "تله: اعلام ناپیوستگی تابع در نقطه x = 2 به دلیل وجود قدرمطلق",
                  trapReason: "حاصل‌ضرب چندجمله‌ای در قدرمطلقِ چندجمله‌ای در تمام اعداد حقیقی پیوسته است.",
                },
              ],
              nudgeHint:
                "ابتدا ریشه داخل قدرمطلق را پیدا کنید، سپس آن را در ضریب بیرونی جایگذاری نمایید و در نهایت حکم مشتق‌پذیری را صادر کنید.",
              assemblyExplanation:
                "با این الگوریتم ۴ مرحله‌ای، هر تست مشتق‌پذیری قدرمطلق در کنکور را زیر ۱۰ ثانیه بدون نوشتن تعریف حدی مشتق حل می‌کنید.",
            },
          },
          {
            type: "trap_detector",
            conceptNodeId: "C4_CONVERSE_FALLACY_TRAP",
            scaffoldingLevel: 4,
            content: {
              kind: "trap_detector",
              prompt:
                "دیباگر ریاضی کنکور: دانش‌آموزی برای یافتن تعداد نقاط مشتق‌ناپذیر تابع `f(x) = (x - 1) · |x² - 1|` استدلال ۴ سطری زیر را نوشته است. کدام سطر حاوی مغالطه ریاضی است؟",
              contextType: "math_solution_bug",
              segments: [
                "سطر ۱: عبارت داخل قدرمطلق x² - 1 = 0 دارای دو ریشه ساده x = 1 و x = -1 است",
                "سطر ۲: در نقطه x = -1، ضریب بیرون قدرمطلق (x - 1) برابر -2 (مخالف صفر) است پس x = -1 نقطه گوشه و مشتق‌ناپذیر است",
                "سطر ۳: در نقطه x = +1 نیز چون ریشه داخل قدرمطلق است، تابع حتماً دارای نقطه گوشه و مشتق‌ناپذیر است",
                "سطر ۴: بنابراین تابع در ۲ نقطه (x = 1 و x = -1) مشتق‌ناپذیر است",
              ],
              flawedSegmentIndex: 2,
              trapCategory: "تله نادیده گرفتن صفر شدن ضریب بیرون قدرمطلق در x = 1",
              fixOptions: [
                "اصلاحیه صحیح: در x = +1، ضریب بیرون قدرمطلق یعنی (x - 1) برابر صفر می‌شود، پس شکستگی از بین رفته و تابع در x = 1 مشتق‌پذیر است (فقط ۱ نقطه مشتق‌ناپذیر داریم).",
                "اصلاحیه غلط ۱: عبارت x² - 1 اصلاً ریشه حقیقی ندارد.",
                "اصلاحیه غلط ۲: در نقطه x = -1 نیز تابع مشتق‌پذیر است.",
              ],
              correctFixIndex: 0,
              diagnosticAutopsy:
                "در سطر سوم، دانش‌آموز فراموش کرده که x = 1 ریشه ضریب بیرونی (x - 1) نیز هست! بنابراین در همسایگی x = 1 عبارت از مرتبه (x - 1)² بوده و مشتق آن صفر است؛ پس تابع فقط در x = -1 مشتق‌ناپذیر است.",
            },
          },
          {
            type: "step_solver",
            conceptNodeId: "C3_ABS_DIFF_ALGORITHM",
            scaffoldingLevel: 5,
            content: {
              kind: "step_solver",
              problemStatement:
                "حل پله‌ای تست کنکور: «تابع f(x) = (x + 3) · |x² - 9| در کدام نقطه یا نقاط پیوسته است ولی مشتق‌پذیر نیست؟»",
              subSteps: [
                {
                  stageLabel: "گام اول: استخراج کاندیداهای نقطه گوشه",
                  question: "ریشه‌های عبارت داخل قدرمطلق |x² - 9| کدام‌اند؟",
                  options: [
                    "x = 3 و x = -3",
                    "فقط x = 3",
                    "x = 0 و x = 9",
                  ],
                  correctIndex: 0,
                  microFeedback: "درست است! x = 3 و x = -3 دو کاندیدای اولیه ما هستند.",
                },
                {
                  stageLabel: "گام دوم: تست ضریب بیرون قدرمطلق g(x) = x + 3",
                  question:
                    "کدام‌یک از دو ریشه بالا ضریب بیرونی (x + 3) را صفر نمی‌کند و بنابراین نقطه گوشه باقی می‌ماند؟",
                  options: [
                    "فقط x = 3 (چون 3 + 3 = 6 ≠ 0، اما در x = -3 ضریب بیرونی صفر می‌شود)",
                    "هر دو نقطه x = 3 و x = -3",
                    "فقط x = -3",
                  ],
                  correctIndex: 0,
                  microFeedback:
                    "بی‌نظیر! در x = -3 ضریب بیرونی صفر شده و تابع را مشتق‌پذیر می‌کند، پس تنها نقطه گوشه x = 3 است.",
                },
              ],
              finalTakeaway:
                "تکنیک ۱۰ ثانیه‌ای: «ریشه‌های ساده داخل قدرمطلق منهای ریشه‌های ضریب بیرون قدرمطلق = نقاط گوشه!»",
            },
          },
          {
            type: "konkur_test",
            conceptNodeId: "C4_CONVERSE_FALLACY_TRAP",
            scaffoldingLevel: 6,
            content: {
              kind: "konkur_test",
              questionStem:
                "اگر تابع `f(x) = (x² + ax + 2) · |x² - 4|` در تمام نقاط مجموعه اعداد حقیقی (ℝ) مشتق‌پذیر باشد، مقدار ثابت `a` و مقدار مشتق تابع در نقطه `x = 2` (یعنی `f'(2)`) به ترتیب از راست به چپ کدام است؟",
              sourceBadge: "کنکور سراسری ریاضی و تجربی - مشتق‌پذیری",
              targetTimeSeconds: 50,
              options: [
                "a = -3 و f'(2) = 0",
                "a = +3 و f'(2) = 0",
                "a = -3 و f'(2) = 4",
                "تابع به ازای هیچ مقداری از a در x = -2 مشتق‌پذیر نیست (سوال شرط انحرافی دارد)",
              ],
              correctIndex: 0,
              optionDiagnostics: [
                {
                  optionIndex: 0,
                  isCorrect: true,
                  trapOrMisconceptionLabel: "پاسخ صحیح در نقطه x = 2 (صفر شدن ضریب بیرونی)",
                  detailedAnalysis:
                    "برای مشتق‌پذیری در ریشه x = 2 باید ضریب بیرونی در x = 2 صفر شود: 2² + 2a + 2 = 0 ⇒ 2a = -6 ⇒ a = -3. و هرگاه ضریب بیرونی در ریشه ساده قدرمطلق صفر شود، مشتق در آن نقطه برابر f'(2) = 0 است.",
                },
                {
                  optionIndex: 1,
                  isCorrect: false,
                  trapOrMisconceptionLabel: "تله علامت در حل معادله 6 + 2a = 0",
                  detailedAnalysis:
                    "داوطلب معادله 4 + 2a + 2 = 0 را تشکیل داده اما در انتقال 6 به سمت راست، علامت منفی را جا انداخته و a = +3 به دست آورده است.",
                },
                {
                  optionIndex: 2,
                  isCorrect: false,
                  trapOrMisconceptionLabel: "تله مشتق‌گیری بدون توجه به صفر شدن کل عبارت در ریشه",
                  detailedAnalysis:
                    "مقدار a = -3 درست است، اما وقتی g(2) = 0 باشد، مشتق راست (+g(2)) و مشتق چپ (-g(2)) هر دو برابر صفر هستند نه ۴!",
                },
                {
                  optionIndex: 3,
                  isCorrect: false,
                  trapOrMisconceptionLabel: "تله انحرافی در هدف سوال",
                  detailedAnalysis:
                    "با جایگذاری x = 2 در ضریب بیرونی معادله خطی برحسب a به سرعت مقدار یکتای a = -3 و f'(2) = 0 را مشخص می‌کند.",
                },
              ],
              eliminationShortcut:
                "تکنیک زیر ۱۰ ثانیه: هرگاه ضریب بیرون قدرمطلق ریشه ساده داخل قدرمطلق را خنثی کند، مقدار مشتق در آن ریشه همواره صفر است (رد فوری گزینه‌های ۳ و ۴). جایگذاری x=2 در x²+ax+2=0 فوراً a = -3 را می‌دهد.",
            },
          },
        ],
      },
    ],
  },
];

let seedPromise: Promise<void> | null = null;

export function ensureKonkurSeeded(): Promise<void> {
  if (!seedPromise) {
    seedPromise = runKonkurSeed().catch((err) => {
      seedPromise = null;
      console.error("[konkur-seed] error:", err);
    });
  }
  return seedPromise;
}

async function runKonkurSeed() {
  const [{ value: existingCourses }] = await db
    .select({ value: count() })
    .from(konkurCourses);

  if (existingCourses > 0) {
    return;
  }

  let firstLessonId: number | null = null;

  for (const [cIdx, courseDef] of SEED_COURSES.entries()) {
    const [insertedCourse] = await db
      .insert(konkurCourses)
      .values({
        slug: courseDef.slug,
        title: courseDef.title,
        subject: courseDef.subject,
        grade: courseDef.grade,
        reshte: courseDef.reshte,
        icon: courseDef.icon,
        color: courseDef.color,
        tagline: courseDef.tagline,
        description: courseDef.description,
        position: cIdx,
      })
      .returning();

    for (const [lIdx, lessonDef] of courseDef.lessons.entries()) {
      const stepsWithMeta = lessonDef.steps.map((s) => ({
        ...s,
        cognitiveLoadWords:
          s.content.kind === "concept_bite"
            ? countPersianWords(s.content.bodyMarkdown)
            : 45,
      }));

      const audit = evaluatePedagogicalFidelity(
        lessonDef.pedagogicalBlueprint,
        stepsWithMeta,
      );

      const [insertedLesson] = await db
        .insert(konkurLessons)
        .values({
          courseId: insertedCourse.id,
          slug: lessonDef.slug,
          title: lessonDef.title,
          chapterReference: lessonDef.chapterReference,
          rawTextbookExcerpt: lessonDef.rawTextbookExcerpt,
          xpReward: lessonDef.xpReward,
          estimatedMinutes: lessonDef.estimatedMinutes,
          status: "published",
          pedagogicalBlueprint: lessonDef.pedagogicalBlueprint,
          qualityAudit: audit,
          position: lIdx,
        })
        .returning();

      if (!firstLessonId) {
        firstLessonId = insertedLesson.id;
      }

      await db.insert(konkurSteps).values(
        stepsWithMeta.map((s, sIdx) => ({
          lessonId: insertedLesson.id,
          position: sIdx,
          type: s.type,
          conceptNodeId: s.conceptNodeId,
          scaffoldingLevel: s.scaffoldingLevel,
          cognitiveLoadWords: s.cognitiveLoadWords,
          content: s.content,
        })),
      );
    }
  }

  // Seed initial Agent Compilation & Guardrail Audit Log
  if (firstLessonId) {
    const sampleLesson = SEED_COURSES[0].lessons[0];
    const sampleAudit = evaluatePedagogicalFidelity(
      sampleLesson.pedagogicalBlueprint,
      sampleLesson.steps,
    );
    await db.insert(agentCompilationLogs).values({
      subject: "زیست‌شناسی",
      topicTitle: sampleLesson.title,
      rawExcerpt: sampleLesson.rawTextbookExcerpt,
      initialScore: 34,
      finalScore: sampleAudit.overallScore,
      passedGuardrail: true,
      violationsCount: 0,
      autoRepaired: true,
      createdLessonId: firstLessonId,
      auditSnapshot: sampleAudit,
    });
  }
}
