// ============================================================================
// MIMO 9.35 UNIFIED ENGINE — Deterministic Konkur Curriculum, 9 Renderer
// Families, A6–A11 Validators, 11-Field LessonProgress, andHonesty Contract
// SERVER CONFIRMED = 0 · externalProvider = 'not-configured' · No LLM/Network
// ============================================================================

export const HONESTY_FLAGS = {
  serverConfirmed: 0,
  llm: false,
  network: false,
  generatedText: false,
  externalProvider: "not-configured" as const,
  publishSetVersion: 753,
};

const PERSIAN_DIGITS = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];

export function faNum(val: string | number | null | undefined): string {
  if (val === null || val === undefined) return "";
  return String(val).replace(/\d/g, (d) => PERSIAN_DIGITS[Number(d)] || d);
}

export type RendererFamily =
  | "noninteractiveSlide"
  | "MultipleChoice"
  | "SingleChoice"
  | "FillTheGap"
  | "ValidatedInput"
  | "Spell"
  | "InteractiveWebView"
  | "executableFiles"
  | "Reveal"
  | "feedback"
  | "text"
  | "strong";

export type PedagogicalRole =
  | "hook"
  | "explain"
  | "do"
  | "check"
  | "feedback"
  | "practice"
  | "challenge"
  | "recap";

export const ROLE_FA: Record<PedagogicalRole, string> = {
  hook: "ورود به مفهوم",
  explain: "درسنامه",
  do: "آزمایش تعاملی",
  check: "بازیابی چهارگزینه‌ای",
  feedback: "پاسخنامهٔ تشریحی",
  practice: "تکمیل جای خالی",
  challenge: "ورودی و فرمول‌آزما",
  recap: "جمع‌بندی و تثبیت",
};

export const CHAPTER_TYPE_FA: Record<string, string> = {
  practiceLevel1: "سطح ۱ · تمرین هدایت‌شده",
  practiceLevel2: "سطح ۲ · تمرین کاربردی",
  practiceLevel3: "سطح ۳ · بازیابی پیشرفته",
  challengeLevel2: "چالش کنکوری · ترکیبی",
};

// ----------------------------------------------------------------------------
// 1. Exact Mimo 9.35 DSL Parser (Lte/c.b @14378108) & Interaction Classifier
// ----------------------------------------------------------------------------
export interface DslModule {
  kind:
    | "Paragraph"
    | "Code"
    | "Selection"
    | "Image"
    | "Webview"
    | "Interaction"
    | "Database"
    | "Output";
  text?: string;
  html?: string;
  name?: string;
  lang?: string;
  multiple?: boolean;
  items?: { text: string; correct: boolean }[];
  src?: string;
  content?: string;
  type?: string;
  visibleIf?: string;
}

export function parseDSL(dsl: string): DslModule[] {
  if (typeof dsl !== "string" || !dsl.trim()) return [];
  if (typeof DOMParser === "undefined") return [];
  try {
    const doc = new DOMParser().parseFromString(dsl, "text/html");
    const root = doc.body || doc.documentElement;
    if (!root) return [];
    const modules: DslModule[] = [];
    const walk = (node: Element) => {
      for (const el of Array.from(node.children || [])) {
        const tag = (el.tagName || "").toLowerCase();
        if (tag === "p") {
          modules.push({
            kind: "Paragraph",
            html: el.innerHTML,
            text: el.textContent || "",
            visibleIf: el.getAttribute("visible-if") || "always",
          });
        } else if (tag === "code") {
          modules.push({
            kind: "Code",
            name: el.getAttribute("name") || "",
            lang: el.getAttribute("codelang") || "",
            text: el.textContent || "",
            visibleIf: el.getAttribute("visible-if") || "always",
          });
        } else if (tag === "selection") {
          const items = Array.from(el.querySelectorAll("item")).map((it) => ({
            text: it.textContent || "",
            correct: it.getAttribute("correct") === "true",
          }));
          modules.push({
            kind: "Selection",
            multiple: el.getAttribute("multiple") === "multiple",
            items,
            visibleIf: el.getAttribute("visible-if") || "always",
          });
        } else if (tag === "img") {
          modules.push({
            kind: "Image",
            src: el.getAttribute("src") || "",
            visibleIf: el.getAttribute("visible-if") || "always",
          });
        } else if (tag === "webview") {
          modules.push({
            kind: "Webview",
            content: el.getAttribute("content") || "",
            visibleIf: el.getAttribute("visible-if") || "always",
          });
        } else if (tag === "interaction") {
          modules.push({
            kind: "Interaction",
            type: el.getAttribute("type") || "",
            text: el.textContent || "",
            visibleIf: el.getAttribute("visible-if") || "always",
          });
        } else if (tag === "database" || tag === "output") {
          modules.push({
            kind: tag === "database" ? "Database" : "Output",
            text: el.textContent || "",
          });
        } else {
          walk(el);
        }
      }
    };
    walk(root);
    return modules;
  } catch {
    return [];
  }
}

// ----------------------------------------------------------------------------
// 2. Exact Validators A6..A11 (COMPLETE_LESSON_ENGINE_SPEC.md §4)
// ----------------------------------------------------------------------------
const KEEP_CHARS = new Set(["<", ">", "(", ")", ":", "{", "}", ",", "."]);
const PERSIAN_TO_ASCII: Record<string, string> = {
  "۰": "0",
  "۱": "1",
  "۲": "2",
  "۳": "3",
  "۴": "4",
  "۵": "5",
  "۶": "6",
  "۷": "7",
  "۸": "8",
  "۹": "9",
};

export function normalizeValidatedInput(s: string | null | undefined): string {
  const raw = String(s || "")
    .replace(/[۰-۹]/g, (d) => PERSIAN_TO_ASCII[d] || d)
    .toLowerCase();
  let out = "";
  for (const c of raw) {
    if (
      /[a-z0-9]/.test(c) ||
      KEEP_CHARS.has(c) ||
      /[\u0600-\u06ff]/.test(c)
    ) {
      out += c;
    }
  }
  return out;
}

export type ValidationOutcome = {
  ok: boolean;
  matchKind: "EXACT" | "PARTIAL" | "WRONG";
  validatorCode: "A6" | "A7" | "A8" | "A9/A10" | "A11" | "SLIDE";
};

export function validateLessonBlock(
  family: RendererFamily,
  userInput: {
    selected?: number[];
    tokens?: string[];
    text?: string;
    files?: string[];
    webviewCompleted?: boolean;
  },
  block: LessonBlock
): ValidationOutcome {
  switch (family) {
    case "FillTheGap": {
      // A6: ordered equality
      const chosen = userInput.tokens || [];
      const expected =
        block.correctTokens ||
        (block.options && typeof block.correctIndex === "number"
          ? [block.options[block.correctIndex]]
          : []);
      const ok =
        chosen.length === expected.length &&
        chosen.every((t, i) => String(t).trim() === String(expected[i]).trim());
      return { ok, matchKind: ok ? "EXACT" : "WRONG", validatorCode: "A6" };
    }
    case "MultipleChoice":
    case "SingleChoice": {
      // A7: all { selected == isCorrect }
      const selected = userInput.selected || [];
      const ok =
        selected.length === 1 && selected[0] === Number(block.correctIndex);
      return { ok, matchKind: ok ? "EXACT" : "WRONG", validatorCode: "A7" };
    }
    case "Spell": {
      // A8: ordered sequence of tokens
      const typed = userInput.tokens || [];
      const expected = block.correctTokens || [];
      const ok =
        typed.length === expected.length &&
        typed.every((t, i) => String(t).trim() === String(expected[i]).trim());
      return { ok, matchKind: ok ? "EXACT" : "WRONG", validatorCode: "A8" };
    }
    case "ValidatedInput": {
      // A9 + A10: exact -> qm/e (V), normalized equal -> qm/f (W), else -> qm/g (X)
      const userRaw = String(userInput.text || "").trim();
      const expectedRaw = String(
        block.expectedText ??
          (block.options && typeof block.correctIndex === "number"
            ? block.options[block.correctIndex]
            : "")
      ).trim();
      const normUser = normalizeValidatedInput(userRaw);
      const normExp = normalizeValidatedInput(expectedRaw);
      const acceptableNorms = (block.acceptedAnswers || [expectedRaw]).map(
        normalizeValidatedInput
      );
      if (!normUser || !acceptableNorms.includes(normUser)) {
        return { ok: false, matchKind: "WRONG", validatorCode: "A9/A10" };
      }
      if (userRaw === expectedRaw) {
        return { ok: true, matchKind: "EXACT", validatorCode: "A9/A10" };
      }
      return { ok: true, matchKind: "PARTIAL", validatorCode: "A9/A10" };
    }
    case "executableFiles": {
      // A11: userFiles == solvedContent
      const files = (userInput.files || []).map(normalizeValidatedInput);
      const solved = (block.solvedContent || []).map(normalizeValidatedInput);
      const ok =
        files.length === solved.length &&
        files.every((f, i) => f === solved[i]);
      return { ok, matchKind: ok ? "EXACT" : "WRONG", validatorCode: "A11" };
    }
    case "InteractiveWebView": {
      const ok = Boolean(userInput.webviewCompleted);
      return { ok, matchKind: ok ? "EXACT" : "WRONG", validatorCode: "A7" };
    }
    default:
      return { ok: true, matchKind: "EXACT", validatorCode: "SLIDE" };
  }
}

// ----------------------------------------------------------------------------
// 3. Core Data Interfaces
// ----------------------------------------------------------------------------
export interface LessonBlock {
  id: string;
  renderer: RendererFamily;
  contentFa: string;
  hintFa?: string;
  options?: string[];
  correctIndex?: number;
  correctTokens?: string[];
  expectedText?: string;
  acceptedAnswers?: string[];
  fileName?: string;
  initialFileContent?: string;
  solvedContent?: string[];
  webviewPromptFa?: string;
  webviewActionLabel?: string;
  webviewResultFa?: string;
  explanationFa?: string;
  questionId?: string;
}

export interface MicroLesson {
  id: number;
  title: string;
  contentType: "interactive" | "executableFiles";
  pedagogicalRole: PedagogicalRole;
  blocks: LessonBlock[];
  hardModeSelected?: boolean;
  hardModePromptFa?: string;
  questionRefs: string[];
  trace: {
    sourceRef: string;
    contentStatus: "structured";
    reviewStatus: "unreviewed";
  };
}

export interface TutorialChapter {
  id: number;
  title: string;
  type:
    | "practiceLevel1"
    | "practiceLevel2"
    | "practiceLevel3"
    | "challengeLevel2";
  lessons: MicroLesson[];
  practiceQuestionIds: string[];
}

export interface MimoTutorial {
  id: number;
  version: number;
  type: "course";
  subject: "زیست" | "شیمی" | "فیزیک" | "ریاضی";
  topic: string;
  title: string;
  descriptionContent: string;
  shortDescriptionContent: string;
  learningObjectives: string[];
  chapters: TutorialChapter[];
  questionId: string;
}

export interface KonkurQuestion {
  id: string;
  number: number;
  subject: "زیست" | "شیمی" | "فیزیک" | "ریاضی";
  topic: string;
  difficultyLabel: "آسان" | "متوسط" | "سخت";
  difficulty: "easy" | "medium" | "hard";
  stemFa: string;
  options: string[];
  correctIndex: number;
  explanationFa: string;
  keyTermFa: string;
  sequenceStepsFa: string[];
  labFormulaFa: string;
  sourceRef: string;
}

export interface LessonProgressRow {
  lessonId: number;
  lessonIndex: number;
  chapterId: number;
  tutorialId: number;
  tutorialVersion: number;
  trackId: number;
  tutorialTitle: string;
  courseKey: string;
  tries: number; // Rule A5: isSolvedCorrectly ≡ tries >= 1
  attempts: number;
  isPracticeProgress: boolean;
  inQueue: boolean;
  publishSetVersion: number;
  startedAt: number;
  completedAt: number;
}

export interface MistakeItem {
  questionKey: string;
  topicId: string;
  subject: string;
  difficulty: string;
  userChoice?: number;
  correctIndex: number;
  consecutiveCorrect: number;
  resolved: boolean;
  createdAt: number;
}

// ----------------------------------------------------------------------------
// 4. The 20 Approved Konkur Questions (QRAW verbatim + pedagogical metadata)
// ----------------------------------------------------------------------------
export const KONKUR_QUESTIONS: KonkurQuestion[] = [
  {
    id: "proto-q-01",
    number: 1,
    subject: "زیست",
    topic: "سم‌ها",
    difficultyLabel: "متوسط",
    difficulty: "medium",
    stemFa: "کدام‌یک از گزینه‌های زیر دربارهٔ «سم‌ها» درست است؟",
    options: [
      "سم‌ها همواره تنها در کبد ساخته می‌شوند",
      "سم‌ها می‌توانند با اتصال به آنزیم‌ها، فعالیت آن‌ها را مهار کنند",
      "همهٔ سم‌ها در بدن به گلوکز تبدیل می‌شوند",
      "سم‌ها فقط از راه پوست وارد بدن می‌شوند",
    ],
    correctIndex: 1,
    explanationFa:
      "سم‌ها با اتصال به جایگاه فعال آنزیم‌ها می‌توانند آن‌ها را مهار کنند؛ زیست یازدهم، فصل سم‌ها و بیماری‌ها.",
    keyTermFa: "جایگاه فعال آنزیم",
    sequenceStepsFa: ["ورود سم", "اتصال به جایگاه فعال", "مهار آنزیم"],
    labFormulaFa: "آنزیم + مهارکننده (سم) → کمپلکس غیرفعال",
    sourceRef: "prototype:v12.5-fa:qbank-01",
  },
  {
    id: "proto-q-02",
    number: 2,
    subject: "شیمی",
    topic: "تعادل شیمیایی",
    difficultyLabel: "متوسط",
    difficulty: "medium",
    stemFa:
      "ثابت تعادل یک واکنش برگشت‌پذیر در دمای ثابت، با افزایش غلظت یکی از واکنش‌دهنده‌ها…",
    options: ["کاهش می‌یابد", "افزایش می‌یابد", "تغییر نمی‌کند", "صفر می‌شود"],
    correctIndex: 2,
    explanationFa:
      "Kc فقط تابع دماست؛ تغییر غلظت سامانه را جابه‌جا می‌کند ولی مقدار ثابت تعادل ثابت می‌ماند (اصل لوشاتلیه).",
    keyTermFa: "فقط تابع دما",
    sequenceStepsFa: ["افزایش غلظت", "جابه‌جایی تعادل", "ثابت ماندن Kc"],
    labFormulaFa: "T = ثابت  ⇒  Kc = ثابت",
    sourceRef: "prototype:v12.5-fa:qbank-02",
  },
  {
    id: "proto-q-03",
    number: 3,
    subject: "فیزیک",
    topic: "ترمودینامیک",
    difficultyLabel: "سخت",
    difficulty: "hard",
    stemFa: "کار انجام‌شده توسط گاز در یک فرایند هم‌حجم برابر است با…",
    options: ["PΔV", "صفر", "nRΔT", "ΔU"],
    correctIndex: 1,
    explanationFa:
      "در فرایند هم‌حجم ΔV=۰ است، پس W=PΔV=۰ و تمام گرما صرف تغییر انرژی درونی می‌شود.",
    keyTermFa: "صفر",
    sequenceStepsFa: ["فرایند هم‌حجم", "ΔV = ۰", "W = ۰"],
    labFormulaFa: "ΔV = 0  ⇒  W = PΔV = 0",
    sourceRef: "prototype:v12.5-fa:qbank-03",
  },
  {
    id: "proto-q-04",
    number: 4,
    subject: "ریاضی",
    topic: "مشتق",
    difficultyLabel: "متوسط",
    difficulty: "medium",
    stemFa: "مشتق تابع f(x)=x³−3x در x=۱ کدام است؟",
    options: ["۰", "۱", "۳", "۶"],
    correctIndex: 0,
    explanationFa: "f′(x)=3x²−3، پس f′(1)=0؛ نقطهٔ بحرانی و اکسترمم نسبی.",
    keyTermFa: "۰",
    sequenceStepsFa: ["f'(x) = 3x² - 3", "جایگذاری x = 1", "f'(1) = 0"],
    labFormulaFa: "f'(1) = 3(1)² - 3 = 0",
    sourceRef: "prototype:v12.5-fa:qbank-04",
  },
  {
    id: "proto-q-05",
    number: 5,
    subject: "زیست",
    topic: "ژنتیک",
    difficultyLabel: "آسان",
    difficulty: "easy",
    stemFa:
      "در قانون دوم مندل (تفکیک)، نسبت ژنوتیپی نسل F₂ برای یک صفت تک‌ژنی چیست؟",
    options: ["۳:۱", "۱:۲:۱", "۹:۳:۳:۱", "۱:۱"],
    correctIndex: 1,
    explanationFa: "نسبت فنوتیپی ۳:۱ و نسبت ژنوتیپی ۱:۲:۱ است (AA:Aa:aa).",
    keyTermFa: "۱:۲:۱",
    sequenceStepsFa: ["آمیزش Aa × Aa", "تشکیل گامت‌ها", "نسبت ۱:۲:۱"],
    labFormulaFa: "AA : 2Aa : aa  ⇒  1:2:1",
    sourceRef: "prototype:v12.5-fa:qbank-05",
  },
  {
    id: "proto-q-06",
    number: 6,
    subject: "شیمی",
    topic: "پیوند شیمیایی",
    difficultyLabel: "آسان",
    difficulty: "easy",
    stemFa: "کدام عنصر الکترونگاتیوی‌تر است؟",
    options: ["سدیم", "منیزیم", "کلر", "پتاسیم"],
    correctIndex: 2,
    explanationFa:
      "الکترونگاتیوی در یک دوره از چپ به راست افزایش و در یک گروه از بالا به پایین کاهش می‌یابد؛ کلر بیشینه است.",
    keyTermFa: "کلر",
    sequenceStepsFa: ["حرکت چپ به راست", "کاهش شعاع اتمی", "بیشینه بودن کلر"],
    labFormulaFa: "EN(Cl) > EN(Mg) > EN(Na) > EN(K)",
    sourceRef: "prototype:v12.5-fa:qbank-06",
  },
  {
    id: "proto-q-07",
    number: 7,
    subject: "فیزیک",
    topic: "نور و پرتو",
    difficultyLabel: "متوسط",
    difficulty: "medium",
    stemFa: "هنگام گذر نور از هوا به شیشه، کدام کمیت ثابت می‌ماند؟",
    options: ["سرعت نور", "طول موج", "بسامد", "جهت پرتو"],
    correctIndex: 2,
    explanationFa:
      "بسامد نور هنگام تغییر محیط ثابت است؛ سرعت و طول موج تغییر می‌کنند و پرتو می‌شکند.",
    keyTermFa: "بسامد",
    sequenceStepsFa: ["ورود به شیشه", "کاهش سرعت و طول موج", "ثابت ماندن بسامد"],
    labFormulaFa: "f₁ = f₂ (بسامد فقط تابع چشمه است)",
    sourceRef: "prototype:v12.5-fa:qbank-07",
  },
  {
    id: "proto-q-08",
    number: 8,
    subject: "ریاضی",
    topic: "دنباله‌ها",
    difficultyLabel: "متوسط",
    difficulty: "medium",
    stemFa: "حد دنبالهٔ aₙ=(2n+1)/(3n−1) کدام است؟",
    options: ["۰", "۲/۳", "۱", "∞"],
    correctIndex: 1,
    explanationFa: "با تقسیم صورت و مخرج بر n، حد برابر ۲/۳ می‌شود.",
    keyTermFa: "۲/۳",
    sequenceStepsFa: ["تقسیم بر n", "حذف جملات 1/n", "حد برابر ۲/۳"],
    labFormulaFa: "lim (2 + 1/n) / (3 - 1/n) = 2/3",
    sourceRef: "prototype:v12.5-fa:qbank-08",
  },
  {
    id: "proto-q-09",
    number: 9,
    subject: "زیست",
    topic: "سلول",
    difficultyLabel: "متوسط",
    difficulty: "medium",
    stemFa: "کدام اندامک مسئول ساخت ATP در یاختهٔ یوکاریوتی است؟",
    options: ["ریبوزوم", "میتوکندری", "دستگاه گلژی", "شبکهٔ آندوپلاسمی"],
    correctIndex: 1,
    explanationFa:
      "میتوکندری با تنفس یاخته‌ای ATP می‌سازد؛ ریبوزوم محل ساخت پروتئین است.",
    keyTermFa: "میتوکندری",
    sequenceStepsFa: ["ورود پیرووات به میتوکندری", "تنفس یاخته‌ای", "تولید ATP"],
    labFormulaFa: "گلوکز + O₂  →(میتوکندری)→  CO₂ + H₂O + ATP",
    sourceRef: "prototype:v12.5-fa:qbank-09",
  },
  {
    id: "proto-q-10",
    number: 10,
    subject: "شیمی",
    topic: "استوکیومتری",
    difficultyLabel: "متوسط",
    difficulty: "medium",
    stemFa:
      "چند مولکول آب از واکنش کامل ۲ مول هیدروژن با اکسیژن کافی به‌دست می‌آید؟",
    options: ["۱ مول", "۲ مول", "۳ مول", "۴ مول"],
    correctIndex: 1,
    explanationFa:
      "2H₂+O₂→2H₂O؛ نسبت مولی H₂ به H₂O برابر ۱:۱ است، پس ۲ مول آب.",
    keyTermFa: "۲ مول",
    sequenceStepsFa: ["موازنهٔ واکنش", "نسبت مولی ۱ به ۱", "تولید ۲ مول آب"],
    labFormulaFa: "2H₂ + O₂ → 2H₂O  (2 mol H₂O)",
    sourceRef: "prototype:v12.5-fa:qbank-10",
  },
  {
    id: "proto-q-11",
    number: 11,
    subject: "فیزیک",
    topic: "مکانیک",
    difficultyLabel: "سخت",
    difficulty: "hard",
    stemFa:
      "نیروی ۱۲ نیوتونی به جسمی به جرم ۳ کیلوگرم وارد می‌شود؛ شتاب چند متر بر مجذور ثانیه است؟",
    options: ["۲", "۳", "۴", "۱۲"],
    correctIndex: 2,
    explanationFa: "قانون دوم نیوتون: a=F/m=۱۲/۳=۴ m/s².",
    keyTermFa: "۴",
    sequenceStepsFa: ["قانون دوم نیوتون", "تقسیم F بر m", "a = 4 m/s²"],
    labFormulaFa: "a = F / m = 12 / 3 = 4",
    sourceRef: "prototype:v12.5-fa:qbank-11",
  },
  {
    id: "proto-q-12",
    number: 12,
    subject: "ریاضی",
    topic: "احتمال",
    difficultyLabel: "متوسط",
    difficulty: "medium",
    stemFa: "در پرتاب یک تاس سالم، احتمال آمدن عدد زوج چقدر است؟",
    options: ["۱/۶", "۱/۳", "۱/۲", "۲/۳"],
    correctIndex: 2,
    explanationFa: "اعداد زوج ۲، ۴ و ۶اند؛ ۳ حالت مطلوب از ۶ حالت، یعنی ۱/۲.",
    keyTermFa: "۱/۲",
    sequenceStepsFa: ["فضای نمونه ۶تایی", "۳ عدد زوج (۲،۴،۶)", "احتمال ۳/۶ = ۱/۲"],
    labFormulaFa: "P(E) = 3 / 6 = 1/2",
    sourceRef: "prototype:v12.5-fa:qbank-12",
  },
  {
    id: "proto-q-13",
    number: 13,
    subject: "زیست",
    topic: "فتوسنتز",
    difficultyLabel: "متوسط",
    difficulty: "medium",
    stemFa: "واکنش‌های نوری فتوسنتز در کدام بخش کلروپلاست رخ می‌دهند؟",
    options: ["استروما", "تیلاکوئید", "دیوارهٔ یاخته", "واکوئول"],
    correctIndex: 1,
    explanationFa:
      "واکنش‌های نوری در غشای تیلاکوئید و چرخهٔ کالوین در استروما انجام می‌شود.",
    keyTermFa: "تیلاکوئید",
    sequenceStepsFa: ["جذب نور در تیلاکوئید", "تولید ATP و NADPH", "چرخهٔ کالوین در استروما"],
    labFormulaFa: "نور + H₂O →(غشای تیلاکوئید)→ O₂ + ATP + NADPH",
    sourceRef: "prototype:v12.5-fa:qbank-13",
  },
  {
    id: "proto-q-14",
    number: 14,
    subject: "شیمی",
    topic: "محلول‌ها",
    difficultyLabel: "آسان",
    difficulty: "easy",
    stemFa: "افزایش دما معمولاً انحلال‌پذیری نمک‌های جامد در آب را…",
    options: ["کاهش می‌دهد", "افزایش می‌دهد", "تغییر نمی‌دهد", "صفر می‌کند"],
    correctIndex: 1,
    explanationFa:
      "انحلال اغلب نمک‌های جامد گرماگیر است؛ با افزایش دما انحلال‌پذیری بیشتر می‌شود.",
    keyTermFa: "افزایش می‌دهد",
    sequenceStepsFa: ["انحلال گرماگیر نمک", "افزایش دما", "افزایش انحلال‌پذیری"],
    labFormulaFa: "ΔH_sol > 0  ⇒  افزایش دما = افزایش انحلال‌پذیری",
    sourceRef: "prototype:v12.5-fa:qbank-14",
  },
  {
    id: "proto-q-15",
    number: 15,
    subject: "فیزیک",
    topic: "الکتریسیته",
    difficultyLabel: "متوسط",
    difficulty: "medium",
    stemFa: "دو مقاومت ۶ و ۳ اهمی به‌صورت موازی بسته شوند؛ مقاومت معادل چقدر است؟",
    options: ["۹ اهم", "۴٫۵ اهم", "۲ اهم", "۱ اهم"],
    correctIndex: 2,
    explanationFa: "1/R=1/6+1/3=1/2، پس R=۲ اهم.",
    keyTermFa: "۲ اهم",
    sequenceStepsFa: ["فرمول مدار موازی", "1/R = 1/6 + 1/3 = 1/2", "R = 2 اهم"],
    labFormulaFa: "R_eq = (6 × 3) / (6 + 3) = 2",
    sourceRef: "prototype:v12.5-fa:qbank-15",
  },
  {
    id: "proto-q-16",
    number: 16,
    subject: "ریاضی",
    topic: "مثلثات",
    difficultyLabel: "متوسط",
    difficulty: "medium",
    stemFa: "مقدار sin²x+cos²x برای هر زاویهٔ x کدام است؟",
    options: ["۰", "۱/۲", "۱", "۲"],
    correctIndex: 2,
    explanationFa: "اتحاد بنیادی مثلثات: sin²x+cos²x=۱.",
    keyTermFa: "۱",
    sequenceStepsFa: ["دایرهٔ مثلثاتی شعاع ۱", "قضیهٔ فیثاغورس", "sin²x + cos²x = 1"],
    labFormulaFa: "sin²(x) + cos²(x) = 1",
    sourceRef: "prototype:v12.5-fa:qbank-16",
  },
  {
    id: "proto-q-17",
    number: 17,
    subject: "زیست",
    topic: "گردش خون",
    difficultyLabel: "آسان",
    difficulty: "easy",
    stemFa: "خون سرشار از اکسیژن از شش‌ها به کدام حفرهٔ قلب بازمی‌گردد؟",
    options: ["دهلیز راست", "بطن راست", "دهلیز چپ", "بطن چپ"],
    correctIndex: 2,
    explanationFa: "سیاهرگ‌های ششی خون اکسیژن‌دار را به دهلیز چپ می‌آورند.",
    keyTermFa: "دهلیز چپ",
    sequenceStepsFa: ["تبادل گاز در شش‌ها", "سیاهرگ‌های ششی", "ورود به دهلیز چپ"],
    labFormulaFa: "شش‌ها → سیاهرگ ششی → دهلیز چپ → بطن چپ",
    sourceRef: "prototype:v12.5-fa:qbank-17",
  },
  {
    id: "proto-q-18",
    number: 18,
    subject: "شیمی",
    topic: "سینتیک",
    difficultyLabel: "سخت",
    difficulty: "hard",
    stemFa: "کاتالیزگر در یک واکنش شیمیایی چه می‌کند؟",
    options: [
      "آنتروپی را تغییر می‌دهد",
      "انرژی فعال‌سازی را کاهش می‌دهد",
      "تعادل را جابه‌جا می‌کند",
      "دمای واکنش را افزایش می‌دهد",
    ],
    correctIndex: 1,
    explanationFa:
      "کاتالیزگر مسیری با انرژی فعال‌سازی کمتر فراهم می‌کند؛ ثابت تعادل و ΔG را تغییر نمی‌دهد.",
    keyTermFa: "انرژی فعال‌سازی را کاهش می‌دهد",
    sequenceStepsFa: ["مسیر جایگزین واکنش", "کاهش انرژی فعال‌سازی Ea", "افزایش سرعت رفت و برگشت"],
    labFormulaFa: "Ea(با کاتالیزگر) < Ea(بدون کاتالیزگر)",
    sourceRef: "prototype:v12.5-fa:qbank-18",
  },
  {
    id: "proto-q-19",
    number: 19,
    subject: "فیزیک",
    topic: "موج",
    difficultyLabel: "متوسط",
    difficulty: "medium",
    stemFa: "اگر بسامد موجی دو برابر شود و سرعت ثابت بماند، طول موج…",
    options: [
      "دو برابر می‌شود",
      "نصف می‌شود",
      "ثابت می‌ماند",
      "چهار برابر می‌شود",
    ],
    correctIndex: 1,
    explanationFa: "v=fλ؛ با ثابت بودن v، دو برابر شدن f یعنی نصف شدن λ.",
    keyTermFa: "نصف می‌شود",
    sequenceStepsFa: ["رابطهٔ v = fλ", "ثابت بودن سرعت v", "نصف شدن طول موج λ"],
    labFormulaFa: "λ₂ = v / (2f₁) = λ₁ / 2",
    sourceRef: "prototype:v12.5-fa:qbank-19",
  },
  {
    id: "proto-q-20",
    number: 20,
    subject: "ریاضی",
    topic: "انتگرال",
    difficultyLabel: "سخت",
    difficulty: "hard",
    stemFa: "∫(2x+1)dx کدام است؟",
    options: ["x²+x+C", "2x²+x+C", "x²+C", "2+C"],
    correctIndex: 0,
    explanationFa: "انتگرال جزءبه‌جزء: x²+x+C (C ثابت انتگرال‌گیری).",
    keyTermFa: "x²+x+C",
    sequenceStepsFa: ["انتگرال 2x برابر x²", "انتگرال 1 برابر x", "افزودن ثابت C"],
    labFormulaFa: "∫(2x + 1)dx = x² + x + C",
    sourceRef: "prototype:v12.5-fa:qbank-20",
  },
];

// ----------------------------------------------------------------------------
// 5. Build the 20 Structured Tutorials with 8 Micro-Lessons Each (160 total)
//    covering all 9 Mimo 9.35 Renderer Families
// ----------------------------------------------------------------------------
export const MIMO_TUTORIALS: MimoTutorial[] = KONKUR_QUESTIONS.map((q, idx) => {
  const tutId = 1001 + idx;
  const chId = 2001 + idx;
  const baseLessonId = 30000 + idx * 10;
  const chType =
    q.difficulty === "easy"
      ? "practiceLevel1"
      : q.difficulty === "medium"
      ? "practiceLevel2"
      : "practiceLevel3";

  const optionNotes = q.options.map((opt, oi) => {
    const status = oi === q.correctIndex ? "گزینهٔ درست" : "گزینهٔ نادرست";
    return `گزینهٔ ${faNum(oi + 1)} (${status}): ${opt}`;
  });

  const lessons: MicroLesson[] = [
    // 1. HOOK (noninteractiveSlide: text + strong)
    {
      id: baseLessonId + 1,
      title: `ورود به مفهوم: ${q.topic}`,
      contentType: "interactive",
      pedagogicalRole: "hook",
      blocks: [
        {
          id: `b-${baseLessonId + 1}-1`,
          renderer: "text",
          contentFa: q.stemFa,
          hintFa: `${q.subject} · مبحث ${q.topic}`,
        },
        {
          id: `b-${baseLessonId + 1}-2`,
          renderer: "strong",
          contentFa: `کلیدواژهٔ کانونی: ${q.topic} — ${q.keyTermFa}`,
        },
      ],
      hardModeSelected: false,
      hardModePromptFa: `نکتهٔ ترکیبی کنکور: در مبحث «${q.topic}»، چرا «${q.keyTermFa}» شرط لازم و کافی پاسخ است؟`,
      questionRefs: [q.id],
      trace: {
        sourceRef: `${q.sourceRef}:hook`,
        contentStatus: "structured",
        reviewStatus: "unreviewed",
      },
    },
    // 2. EXPLAIN (درسنامه قبل از آزمایش)
    {
      id: baseLessonId + 2,
      title: `درسنامه: ${q.topic}`,
      contentType: "interactive",
      pedagogicalRole: "explain",
      blocks: [
        {
          id: `b-${baseLessonId + 2}-1`,
          renderer: "text",
          contentFa: q.explanationFa,
          explanationFa: q.explanationFa,
        },
        {
          id: `b-${baseLessonId + 2}-2`,
          renderer: "strong",
          contentFa: `رابطه و قاعدهٔ اصلی: ${q.labFormulaFa}`,
        },
      ],
      hardModeSelected: false,
      hardModePromptFa: `تحلیل مفهومی: ${q.explanationFa}`,
      questionRefs: [q.id],
      trace: {
        sourceRef: `${q.sourceRef}:explain`,
        contentStatus: "structured",
        reviewStatus: "unreviewed",
      },
    },
    // 3. DO — InteractiveWebView (Local Micro-Simulation, R5)
    {
      id: baseLessonId + 3,
      title: `شبیه‌ساز تعاملی: ${q.topic}`,
      contentType: "interactive",
      pedagogicalRole: "do",
      blocks: [
        {
          id: `b-${baseLessonId + 3}-1`,
          renderer: "InteractiveWebView",
          contentFa: `در شبیه‌ساز محلی «${q.topic}»، واکنش سامانه را بررسی و خروجی درست را فعال کنید:`,
          webviewPromptFa: q.labFormulaFa,
          webviewActionLabel: `اجرای آزمایش ${q.topic}`,
          webviewResultFa: `Correct! نتیجهٔ آزمایش تأیید شد: ${q.options[q.correctIndex]}`,
          options: q.options,
          correctIndex: q.correctIndex,
          explanationFa: q.explanationFa,
          questionId: q.id,
        },
      ],
      hardModeSelected: false,
      hardModePromptFa: `در حالت چالشی، خروجی شبیه‌ساز را پیش از اجرا با رابطهٔ ${q.labFormulaFa} مقایسه کنید.`,
      questionRefs: [q.id],
      trace: {
        sourceRef: `${q.sourceRef}:webview`,
        contentStatus: "structured",
        reviewStatus: "unreviewed",
      },
    },
    // 4. CHECK — MultipleChoice (Validator A7)
    {
      id: baseLessonId + 4,
      title: `تست چهارگزینه‌ای: ${q.topic}`,
      contentType: "interactive",
      pedagogicalRole: "check",
      blocks: [
        {
          id: `b-${baseLessonId + 4}-1`,
          renderer: "MultipleChoice",
          contentFa: q.stemFa,
          options: q.options,
          correctIndex: q.correctIndex,
          explanationFa: q.explanationFa,
          questionId: q.id,
          hintFa: `دشواری: ${q.difficultyLabel}`,
        },
      ],
      hardModeSelected: false,
      hardModePromptFa: `تست زمان‌دار کنکور (${q.difficultyLabel}): پیش از انتخاب گزینه، علت رد سایر گزینه‌ها را مشخص کنید.`,
      questionRefs: [q.id],
      trace: {
        sourceRef: `${q.sourceRef}:check`,
        contentStatus: "structured",
        reviewStatus: "unreviewed",
      },
    },
    // 5. FEEDBACK — پاسخنامه تشریحی و تحلیل گزینه‌ها
    {
      id: baseLessonId + 5,
      title: `پاسخنامهٔ تشریحی: ${q.topic}`,
      contentType: "interactive",
      pedagogicalRole: "feedback",
      blocks: [
        {
          id: `b-${baseLessonId + 5}-1`,
          renderer: "feedback",
          contentFa: q.explanationFa,
          options: optionNotes,
          questionId: q.id,
        },
      ],
      hardModeSelected: false,
      questionRefs: [q.id],
      trace: {
        sourceRef: `${q.sourceRef}:feedback`,
        contentStatus: "structured",
        reviewStatus: "unreviewed",
      },
    },
    // 6. PRACTICE — Interactive FillTheGap (Validator A6)
    {
      id: baseLessonId + 6,
      title: `تکمیل جای خالی: ${q.topic}`,
      contentType: "interactive",
      pedagogicalRole: "practice",
      blocks: [
        {
          id: `b-${baseLessonId + 6}-1`,
          renderer: "FillTheGap",
          contentFa: `${q.stemFa} پاسخ درست « [ ＿＿＿ ] » است.`,
          options: q.options,
          correctIndex: q.correctIndex,
          correctTokens: [q.options[q.correctIndex]],
          explanationFa: q.explanationFa,
          questionId: q.id,
        },
      ],
      hardModeSelected: false,
      hardModePromptFa: `جای خالی را بدون نگاه کردن به درسنامه و بر اساس کلیدواژهٔ «${q.keyTermFa}» تکمیل کنید.`,
      questionRefs: [q.id],
      trace: {
        sourceRef: `${q.sourceRef}:practice`,
        contentStatus: "structured",
        reviewStatus: "unreviewed",
      },
    },
    // 7. CHALLENGE — ValidatedInput (A9/A10) + Spell Sequence (A8) + ExecutableFiles (A11)
    {
      id: baseLessonId + 7,
      title: `چالش ترتیب و ورودی: ${q.topic}`,
      contentType: "executableFiles",
      pedagogicalRole: "challenge",
      blocks: [
        {
          id: `b-${baseLessonId + 7}-1`,
          renderer: "Spell",
          contentFa: `مراحل استدلال مبحث «${q.topic}» را به ترتیب درست بچینید:`,
          options: [...q.sequenceStepsFa],
          correctTokens: [...q.sequenceStepsFa],
          explanationFa: q.explanationFa,
          questionId: q.id,
        },
        {
          id: `b-${baseLessonId + 7}-2`,
          renderer: "ValidatedInput",
          contentFa: `پاسخ کلیدی برای «${q.stemFa}» را بنویسید یا از کلیدهای کمکی انتخاب کنید:`,
          expectedText: q.options[q.correctIndex],
          acceptedAnswers: [
            q.options[q.correctIndex],
            q.keyTermFa,
            String(q.correctIndex + 1),
          ],
          options: q.options,
          correctIndex: q.correctIndex,
          explanationFa: q.explanationFa,
          questionId: q.id,
        },
      ],
      hardModeSelected: true,
      hardModePromptFa: `چالش سطح کنکور (Validator A8 + A9/A10): هم ترتیب گام‌ها و هم عبارت نهایی را بدون خطا وارد کنید.`,
      questionRefs: [q.id],
      trace: {
        sourceRef: `${q.sourceRef}:challenge`,
        contentStatus: "structured",
        reviewStatus: "unreviewed",
      },
    },
    // 8. RECAP — Reveal + Executable Lab Summary
    {
      id: baseLessonId + 8,
      title: `جمع‌بندی نهایی: ${q.topic}`,
      contentType: "interactive",
      pedagogicalRole: "recap",
      blocks: [
        {
          id: `b-${baseLessonId + 8}-1`,
          renderer: "Reveal",
          contentFa: `پاسخ قطعی: ${q.options[q.correctIndex]}`,
          explanationFa: q.explanationFa,
          hintFa: q.labFormulaFa,
        },
      ],
      hardModeSelected: false,
      questionRefs: [q.id],
      trace: {
        sourceRef: `${q.sourceRef}:recap`,
        contentStatus: "structured",
        reviewStatus: "unreviewed",
      },
    },
  ];

  return {
    id: tutId,
    version: 1,
    type: "course",
    subject: q.subject,
    topic: q.topic,
    title: q.topic,
    descriptionContent: `درسنامه و تمرین گام‌به‌گام «${q.topic}» از درس ${q.subject}`,
    shortDescriptionContent: `۱ فصل · ${faNum(lessons.length)} ریزدرس · سطح ${q.difficultyLabel}`,
    learningObjectives: [
      `تسلط مفهومی بر ${q.topic}`,
      "حل تست چهارگزینه‌ای با پاسخنامهٔ تشریحی",
      "بازیابی فعال با جای خالی، چیدمان مراحل و ورودی استاندارد",
    ],
    chapters: [
      {
        id: chId,
        title: `${q.topic} · دشواری ${q.difficultyLabel}`,
        type: chType,
        lessons,
        practiceQuestionIds: [q.id],
      },
    ],
    questionId: q.id,
  };
});

// ----------------------------------------------------------------------------
// 6. KONKUR Curriculum (3 Program Tracks + 12 Courses / 60 Chapters / 180 Lessons)
//    with DETERMINISTIC mapping to MIMO_TUTORIALS (Fixes R2 & R10!)
// ----------------------------------------------------------------------------
export interface KonkurLessonItem {
  id: string; // e.g., "bio12:c1:l1"
  title: string;
  chapterId: string;
  chapterOrdinal: number;
  chapterName: string;
  courseKey: string;
  courseName: string;
  subject: "زیست" | "شیمی" | "فیزیک" | "ریاضی";
  grade: string;
  tutorialId: number; // DETERMINISTIC tutorial ID (Never hashCode!)
}

export interface KonkurChapterItem {
  id: string;
  ordinal: number;
  name: string;
  tutorialId: number;
  lessons: KonkurLessonItem[];
}

export interface KonkurCourseItem {
  key: string;
  name: string;
  subject: "زیست" | "شیمی" | "فیزیک" | "ریاضی";
  grade: string;
  icon: string;
  chapters: KonkurChapterItem[];
}

export interface KonkurProgramItem {
  key: string;
  label: string;
  icon: string;
  grade: string;
}

export const KONKUR_PROGRAMS: KonkurProgramItem[] = [
  {
    key: "grade12",
    label: "یادگیری همگام با برنامه آزمون دوازدهم",
    icon: "ic_cap_filled",
    grade: "دوازدهم",
  },
  {
    key: "grade11",
    label: "یادگیری همگام با برنامه آزمون یازدهم",
    icon: "ic_cap",
    grade: "یازدهم",
  },
  {
    key: "grade10",
    label: "یادگیری همگام با برنامه آزمون دهم",
    icon: "ic_target",
    grade: "دهم",
  },
];

export const KONKUR_FORTNIGHT_DATES = [
  "۱ آبان",
  "۱۵ آبان",
  "۱ آذر",
  "۱۵ آذر",
  "۱ دی",
  "۱۵ دی",
  "۱ بهمن",
  "۱۵ بهمن",
  "۱ اسفند",
  "۱۵ اسفند",
];

// Subject-specific tutorial ID pools (5 tutorials per subject)
const SUBJECT_TUTORIAL_IDS: Record<"زیست" | "شیمی" | "فیزیک" | "ریاضی", number[]> = {
  زیست: MIMO_TUTORIALS.filter((t) => t.subject === "زیست").map((t) => t.id),
  شیمی: MIMO_TUTORIALS.filter((t) => t.subject === "شیمی").map((t) => t.id),
  فیزیک: MIMO_TUTORIALS.filter((t) => t.subject === "فیزیک").map((t) => t.id),
  ریاضی: MIMO_TUTORIALS.filter((t) => t.subject === "ریاضی").map((t) => t.id),
};

interface RawCourseSpec {
  key: string;
  name: string;
  subject: "زیست" | "شیمی" | "فیزیک" | "ریاضی";
  grade: string;
  icon: string;
  chapters: { ordinal: number; name: string; lessons: string[]; tutorialIdx: number }[];
}

const RAW_COURSES: RawCourseSpec[] = [
  {
    key: "bio12",
    name: "زیست دوازدهم",
    subject: "زیست",
    grade: "دوازدهم",
    icon: "img_brain",
    chapters: [
      { ordinal: 1, name: "مولکول‌های زیستی", lessons: ["کربوهیدرات‌ها و لیپیدها", "پروتئین‌ها و آنزیم‌ها", "اسیدهای نوکلئیک و ATP"], tutorialIdx: 0 },
      { ordinal: 2, name: "ژنتیک مولکولی", lessons: ["همانندسازی DNA", "رونویسی و ترجمه", "جهش و تنظیم بیان ژن"], tutorialIdx: 1 },
      { ordinal: 3, name: "مهندسی ژنتیک و یاخته", lessons: ["آنزیم‌های برش‌دهنده و یاخته", "همسانه‌سازی و میتوکندری", "کاربردهای زیست‌فناوری"], tutorialIdx: 2 },
      { ordinal: 4, name: "تبدیل انرژی و فتوسنتز", lessons: ["واکنش‌های نوری تیلاکوئید", "چرخهٔ کالوین در استروما", "تنفس یاخته‌ای و تخمیر"], tutorialIdx: 3 },
      { ordinal: 5, name: "تکامل، گردش مواد و بوم‌شناسی", lessons: ["دستگاه گردش خون و قلب", "جمعیت و جامعه", "شارش انرژی در اکوسیستم"], tutorialIdx: 4 },
    ],
  },
  {
    key: "chem12",
    name: "شیمی دوازدهم",
    subject: "شیمی",
    grade: "دوازدهم",
    icon: "ic_sparks_alt",
    chapters: [
      { ordinal: 1, name: "تعادل‌های شیمیایی و اسیدها", lessons: ["تعادل و ثابت Kc", "اصل لوشاتلیه و دما", "یونش اسید و باز"], tutorialIdx: 0 },
      { ordinal: 2, name: "الکتروشیمی و پیوندها", lessons: ["الکترونگاتیوی و قطبیت", "پیل گالوانی و پتانسیل", "الکترولیز و خوردگی"], tutorialIdx: 1 },
      { ordinal: 3, name: "استوکیومتری و صنایع شیمیایی", lessons: ["نسبت مولی در واکنش‌ها", "واکنش‌دهندهٔ محدودکننده", "بازده درصدی واکنش"], tutorialIdx: 2 },
      { ordinal: 4, name: "انحلال‌پذیری و محلول‌ها", lessons: ["اثر دما بر انحلال نمک‌ها", "غلظت مولی و درصد جرمی", "خواص کولیگاتیو"], tutorialIdx: 3 },
      { ordinal: 5, name: "سینتیک و کاتالیزگرها", lessons: ["انرژی فعال‌سازی Ea", "نقش کاتالیزگر و مبدل‌ها", "شیمی سبز و پلیمرها"], tutorialIdx: 4 },
    ],
  },
  {
    key: "phys12",
    name: "فیزیک دوازدهم",
    subject: "فیزیک",
    grade: "دوازدهم",
    icon: "ic_flash_filled",
    chapters: [
      { ordinal: 1, name: "دینامیک و حرکت‌شناسی", lessons: ["قانون دوم نیوتون (F=ma)", "تکانه و نیروی اصطکاک", "حرکت دایره‌ای"], tutorialIdx: 2 },
      { ordinal: 2, name: "نوسان و موج مکانیکی", lessons: ["رابطهٔ سرعت، بسامد و طول موج", "نوسانگر هماهنگ ساده", "تداخل و امواج ایستاده"], tutorialIdx: 4 },
      { ordinal: 3, name: "برهم‌کنش‌های موج و نور", lessons: ["شکست نور و ثبات بسامد", "پراش و قطبش نور", "طیف امواج الکترومغناطیسی"], tutorialIdx: 1 },
      { ordinal: 4, name: "الکتریسیته و مدارها", lessons: ["مقاومت معادل مدار موازی", "قانون اهم و توان الکتریکی", "القا و شار مغناطیسی"], tutorialIdx: 3 },
      { ordinal: 5, name: "ترمودینامیک و فیزیک اتمی", lessons: ["کار در فرایند هم‌حجم (W=0)", "قانون اول ترمودینامیک", "فوتوالکتریک و مدل بور"], tutorialIdx: 0 },
    ],
  },
  {
    key: "math12",
    name: "ریاضی دوازدهم",
    subject: "ریاضی",
    grade: "دوازدهم",
    icon: "ic_target",
    chapters: [
      { ordinal: 1, name: "حد و دنباله‌ها", lessons: ["حد دنباله‌های کسری در بی‌نهایت", "قواعد حد توابع", "پیوستگی تابع"], tutorialIdx: 1 },
      { ordinal: 2, name: "مشتق و کاربرد آن", lessons: ["فرمول‌های مشتق‌گیری و نقاط بحرانی", "اکسترمم نسبی و مطلق", "بهینه‌سازی"], tutorialIdx: 0 },
      { ordinal: 3, name: "مثلثات و توابع متناوب", lessons: ["اتحاد بنیادی sin²x+cos²x=1", "معادلات مثلثاتی", "نمودار توابع مثلثاتی"], tutorialIdx: 3 },
      { ordinal: 4, name: "احتمال و ترکیبیات", lessons: ["فضای نمونه و احتمال کلاسیک", "احتمال شرطی و پیشامدهای مستقل", "توزیع دوجمله‌ای"], tutorialIdx: 2 },
      { ordinal: 5, name: "انتگرال و مساحت", lessons: ["انتگرال نامعین و پادفرشتق", "انتگرال معین و قضیهٔ اساسی", "محاسبهٔ سطح زیر نمودار"], tutorialIdx: 4 },
    ],
  },
  {
    key: "bio11",
    name: "زیست یازدهم",
    subject: "زیست",
    grade: "یازدهم",
    icon: "img_brain",
    chapters: [
      { ordinal: 1, name: "ایمنی، سم‌ها و بیماری‌ها", lessons: ["نحوهٔ اثر سم‌ها بر آنزیم‌ها", "دفاع غیراختصاصی و اختصاصی", "واکسن و سرم"], tutorialIdx: 0 },
      { ordinal: 2, name: "ژنتیک و وراثت مندل", lessons: ["قانون تفکیک و نسبت ۱:۲:۱", "آمیزش دی‌هیبریدی", "صفات وابسته به جنس"], tutorialIdx: 1 },
      { ordinal: 3, name: "یاخته و تقسیم سلولی", lessons: ["اندامک‌ها و ساخت ATP", "چرخهٔ یاخته‌ای و میتوز", "میوز و گامت‌زایی"], tutorialIdx: 2 },
      { ordinal: 4, name: "گیاهی و فتوسنتز", lessons: ["ساختار کلروپلاست و تیلاکوئید", "تغذیه و ترابری گیاهی", "هورمون‌های گیاهی"], tutorialIdx: 3 },
      { ordinal: 5, name: "تنظیم عصبی و گردش خون", lessons: ["سیاهرگ ششی و دهلیز چپ", "نورون و پتانسیل عمل", "غدد درون‌ریز"], tutorialIdx: 4 },
    ],
  },
  {
    key: "chem11",
    name: "شیمی یازدهم",
    subject: "شیمی",
    grade: "یازدهم",
    icon: "ic_sparks_alt",
    chapters: [
      { ordinal: 1, name: "سینتیک شیمیایی", lessons: ["کاتالیزگر و انرژی فعال‌سازی", "عوامل مؤثر بر سرعت واکنش", "سرعت متوسط و لحظه‌ای"], tutorialIdx: 4 },
      { ordinal: 2, name: "تعادل شیمیایی", lessons: ["ثابت تعادل و اثر دما", "جابه‌جایی تعادل با غلظت", "تولید آمونیاک (هابر)"], tutorialIdx: 0 },
      { ordinal: 3, name: "قدر هدایای زمینی و پیوند", lessons: ["روندهای تناوبی و الکترونگاتیوی", "هیدروکربن‌ها و آلکان‌ها", "ایزومری در شیمی آلی"], tutorialIdx: 1 },
      { ordinal: 4, name: "استوکیومتری واکنش‌ها", lessons: ["محاسبات مولی واکنش آب", "درصد خلوص مواد", "گرمای واکنش و آنتالپی"], tutorialIdx: 2 },
      { ordinal: 5, name: "محلول‌ها و انحلال", lessons: ["انحلال گرماگیر و گرماده", "ضریب انحلال‌پذیری", "گروه عاملی الکل و استر"], tutorialIdx: 3 },
    ],
  },
  {
    key: "phys11",
    name: "فیزیک یازدهم",
    subject: "فیزیک",
    grade: "یازدهم",
    icon: "ic_flash_filled",
    chapters: [
      { ordinal: 1, name: "الکتریسیتهٔ جاری و مدارها", lessons: ["بستن موازی و سری مقاومت‌ها", "قانون کولن و میدان الکتریکی", "خازن و انرژی ذخیره‌شده"], tutorialIdx: 3 },
      { ordinal: 2, name: "مغناطیس و القا", lessons: ["نیروی مغناطیسی و قانون لنز", "قانون دوم نیوتون در میدان", "جریان متناوب"], tutorialIdx: 2 },
      { ordinal: 3, name: "نور و شکست پرتو", lessons: ["ثبات بسامد در گذر نور از هوا به شیشه", "قانون اسنل و زاویهٔ حد", "عدسی‌های همگرا و واگرا"], tutorialIdx: 1 },
      { ordinal: 4, name: "موج و طول موج", lessons: ["رابطهٔ بسامد و طول موج (v=fλ)", "امواج صوتی و تراز شدت", "اثر دوپلر"], tutorialIdx: 4 },
      { ordinal: 5, name: "گرما و ترمودینامیک", lessons: ["کار گاز در فرایند هم‌حجم", "فرایندهای همدما و بی‌دررو", "بازده ماشین گرمایی"], tutorialIdx: 0 },
    ],
  },
  {
    key: "math11",
    name: "ریاضی یازدهم",
    subject: "ریاضی",
    grade: "یازدهم",
    icon: "ic_target",
    chapters: [
      { ordinal: 1, name: "مثلثات", lessons: ["اتحادهای مثلثاتی اصلی", "دایرهٔ مثلثاتی و نسبت‌ها", "قانون سینوس‌ها و کسینوس‌ها"], tutorialIdx: 3 },
      { ordinal: 2, name: "حد و پیوستگی", lessons: ["حد دنباله‌ها و توابع گویا", "رفع ابهام ۰/۰", "مجانب‌های افقی و قائم"], tutorialIdx: 1 },
      { ordinal: 3, name: "مشتق مقدماتی", lessons: ["آهنگ تغییر و شیب خط مماس", "مشتق چندجمله‌ای‌ها", "نقاط بحرانی تابع"], tutorialIdx: 0 },
      { ordinal: 4, name: "آمار و احتمال", lessons: ["احتمال پیشامد در پرتاب تاس", "قوانین شمارش و جایگشت", "امید ریاضی"], tutorialIdx: 2 },
      { ordinal: 5, name: "پادفرشتق و مساحت", lessons: ["مفهوم پادفرشتق و انتگرال", "توابع نمایی و لگاریتمی", "معادلات لگاریتمی"], tutorialIdx: 4 },
    ],
  },
  {
    key: "bio10",
    name: "زیست دهم",
    subject: "زیست",
    grade: "دهم",
    icon: "img_brain",
    chapters: [
      { ordinal: 1, name: "ساختار سلول و بافت", lessons: ["میتوکندری و تولید ATP", "غشای یاخته‌ای و انتقال مواد", "بافت‌های جانوری"], tutorialIdx: 2 },
      { ordinal: 2, name: "فرایندهای سلولی و آنزیم", lessons: ["آنزیم‌ها و مهارکننده‌های سمی", "متابولیسم یاخته‌ای", "عوامل مؤثر بر آنزیم"], tutorialIdx: 0 },
      { ordinal: 3, name: "گردش مواد در بدن", lessons: ["قلب، شش‌ها و دهلیز چپ", "رگ‌های خونی و لنف", "خون و ایمنی"], tutorialIdx: 4 },
      { ordinal: 4, name: "گیاهان و فتوسنتز", lessons: ["کلروپلاست و تیلاکوئید", "ساختار برگ و روزنه", "جذب آب و املاح"], tutorialIdx: 3 },
      { ordinal: 5, name: "مبانی وراثت", lessons: ["ژنوتیپ و فنوتیپ مندل", "میتوز و کروموزوم‌ها", "تنوع زیستی"], tutorialIdx: 1 },
    ],
  },
  {
    key: "chem10",
    name: "شیمی دهم",
    subject: "شیمی",
    grade: "دهم",
    icon: "ic_sparks_alt",
    chapters: [
      { ordinal: 1, name: "جدول تناوبی و پیوند", lessons: ["مقایسهٔ الکترونگاتیوی عناصر", "آرایش الکترونی اتم‌ها", "پیوند یونی و کووالانسی"], tutorialIdx: 1 },
      { ordinal: 2, name: "واکنش‌ها و استوکیومتری", lessons: ["موازنه و تولید ۲ مول آب", "مول و عدد آووگادرو", "محاسبات جرمی"], tutorialIdx: 2 },
      { ordinal: 3, name: "آب، آهنگ زندگی و محلول‌ها", lessons: ["اثر دما بر انحلال‌پذیری نمک‌ها", "غلظت ppm و مولاریته", "نیروهای بین‌مولکولی"], tutorialIdx: 3 },
      { ordinal: 4, name: "سرعت و کاتالیزگر", lessons: ["مفهوم انرژی فعال‌سازی", "واکنش‌های سریع و کند", "اکسایش و احتراق"], tutorialIdx: 4 },
      { ordinal: 5, name: "واکنش‌های برگشت‌پذیر", lessons: ["مفهوم تعادل شیمیایی", "عوامل مؤثر بر تعادل", "شیمی هواکره"], tutorialIdx: 0 },
    ],
  },
  {
    key: "phys10",
    name: "فیزیک دهم",
    subject: "فیزیک",
    grade: "دهم",
    icon: "ic_flash_filled",
    chapters: [
      { ordinal: 1, name: "حرکت و قوانین نیوتن", lessons: ["محاسبهٔ شتاب از F=ma", "کار و انرژی جنبشی", "پایستگی انرژی مکانیکی"], tutorialIdx: 2 },
      { ordinal: 2, name: "دما، گرما و ترمودینامیک", lessons: ["فرایند هم‌حجم و کار صفر", "ظرفیت گرمایی ویژه", "تغییر حالت ماده"], tutorialIdx: 0 },
      { ordinal: 3, name: "ویژگی‌های نور و موج", lessons: ["گذر نور از هوا به شیشه", "طول موج و بسامد", "فشار در شاره‌ها"], tutorialIdx: 1 },
      { ordinal: 4, name: "الکتریسیتهٔ مقدماتی", lessons: ["مقاومت‌های موازی و معادل", "جریان و اختلاف پتانسیل", "توان مصرفی"], tutorialIdx: 3 },
      { ordinal: 5, name: "موج و نوسان مقدماتی", lessons: ["رابطهٔ تندی، بسامد و طول موج", "امواج طولی و عرضی", "پدیده‌های موجی"], tutorialIdx: 4 },
    ],
  },
  {
    key: "math10",
    name: "ریاضی دهم",
    subject: "ریاضی",
    grade: "دهم",
    icon: "ic_target",
    chapters: [
      { ordinal: 1, name: "مثلثات", lessons: ["اتحاد sin²x+cos²x=1", "نسبت‌های مثلثاتی در مثلث قائم‌الزاویه", "معادلات درجهٔ دوم"], tutorialIdx: 3 },
      { ordinal: 2, name: "شمارش و احتمال", lessons: ["احتمال آمدن عدد زوج در تاس", "مجموعه‌ها و نمودار ون", "اصل ضرب و جمع"], tutorialIdx: 2 },
      { ordinal: 3, name: "دنباله‌ها و الگوها", lessons: ["رفتار دنبالهٔ کسری در بی‌نهایت", "دنبالهٔ حسابی", "دنبالهٔ هندسی"], tutorialIdx: 1 },
      { ordinal: 4, name: "تابع و آهنگ تغییر", lessons: ["شیب خط و مشتق در نقطه", "دامنه و برد تابع", "توابع چندضابطه‌ای"], tutorialIdx: 0 },
      { ordinal: 5, name: "مساحت و جمع جملات", lessons: ["مفهوم مساحت و پادفرشتق", "نامعادلات و تعیین علامت", "عبارات گویا"], tutorialIdx: 4 },
    ],
  },
];

export const KONKUR_COURSES: KonkurCourseItem[] = RAW_COURSES.map((rc) => {
  const tutPool = SUBJECT_TUTORIAL_IDS[rc.subject];
  return {
    key: rc.key,
    name: rc.name,
    subject: rc.subject,
    grade: rc.grade,
    icon: rc.icon,
    chapters: rc.chapters.map((ch) => {
      const chId = `${rc.key}:c${ch.ordinal}`;
      const tutId = tutPool[ch.tutorialIdx % tutPool.length];
      return {
        id: chId,
        ordinal: ch.ordinal,
        name: ch.name,
        tutorialId: tutId,
        lessons: ch.lessons.map((lTitle, li) => ({
          id: `${chId}:l${li + 1}`,
          title: lTitle,
          chapterId: chId,
          chapterOrdinal: ch.ordinal,
          chapterName: ch.name,
          courseKey: rc.key,
          courseName: rc.name,
          subject: rc.subject,
          grade: rc.grade,
          // Lesson 1 -> chapter primary tutorial, Lesson 2 -> next tutorial in SAME subject, Lesson 3 -> next tutorial in SAME subject!
          tutorialId: tutPool[(ch.tutorialIdx + li) % tutPool.length],
        })),
      };
    }),
  };
});

// Build fast lookup indexes so chapterRefFor(id) is 100% deterministic (Fixes R2 & R10!)
const LESSON_ITEM_BY_ID = new Map<string, KonkurLessonItem>();
const CHAPTER_ITEM_BY_ID = new Map<string, KonkurChapterItem>();
for (const c of KONKUR_COURSES) {
  for (const ch of c.chapters) {
    CHAPTER_ITEM_BY_ID.set(ch.id, ch);
    for (const l of ch.lessons) {
      LESSON_ITEM_BY_ID.set(l.id, l);
    }
  }
}
const TUTORIAL_BY_ID = new Map<number, MimoTutorial>(
  MIMO_TUTORIALS.map((t) => [t.id, t])
);

export interface ResolvedChapterRef {
  lessonId: string;
  lessonTitle: string;
  courseKey: string;
  courseName: string;
  chapterId: string;
  chapterOrdinal: number;
  chapterName: string;
  subject: "زیست" | "شیمی" | "فیزیک" | "ریاضی";
  tutorial: MimoTutorial;
  chapter: TutorialChapter;
  question: KonkurQuestion;
}

/**
 * DETERMINISTIC chapterRefFor(id) — Fixes RoadMap R2 & R10!
 * Never sums character codes (`key % tuts.length`). Always resolves a Biology
 * lesson to its exact Biology tutorial, Chemistry to Chemistry, Physics to
 * Physics, and Math to Math!
 */
export function chapterRefFor(lessonOrChapterId?: string | null): ResolvedChapterRef {
  const rawId = String(lessonOrChapterId || "bio12:c1:l1");
  let lessonItem = LESSON_ITEM_BY_ID.get(rawId);

  if (!lessonItem) {
    const chItem = CHAPTER_ITEM_BY_ID.get(rawId);
    if (chItem && chItem.lessons.length > 0) {
      lessonItem = chItem.lessons[0];
    }
  }

  if (!lessonItem) {
    // Check if rawId matches a course prefix like "chem12"
    const prefixCourse = KONKUR_COURSES.find((c) => rawId.startsWith(c.key));
    if (prefixCourse) {
      lessonItem = prefixCourse.chapters[0].lessons[0];
    } else {
      lessonItem = KONKUR_COURSES[0].chapters[0].lessons[0];
    }
  }

  const tut =
    TUTORIAL_BY_ID.get(lessonItem.tutorialId) || MIMO_TUTORIALS[0];
  const ch = tut.chapters[0];
  const q =
    KONKUR_QUESTIONS.find((x) => x.id === tut.questionId) ||
    KONKUR_QUESTIONS[0];

  return {
    lessonId: lessonItem.id,
    lessonTitle: lessonItem.title,
    courseKey: lessonItem.courseKey,
    courseName: lessonItem.courseName,
    chapterId: lessonItem.chapterId,
    chapterOrdinal: lessonItem.chapterOrdinal,
    chapterName: lessonItem.chapterName,
    subject: lessonItem.subject,
    tutorial: tut,
    chapter: ch,
    question: q,
  };
}

// ----------------------------------------------------------------------------
// 7. Three-Meaning Token Definitions (Design / Economy / AI Context — D4)
// ----------------------------------------------------------------------------
export const DESIGN_TOKEN_LIST = [
  { name: "--bg", day: "#F6F7FB", night: "#252746", role: "پس‌زمینهٔ اصلی اپ (ARSC background)" },
  { name: "--card", day: "#FFFFFF", night: "#3F4273", role: "سطح کارت‌ها و شیت‌ها (card_enabled)" },
  { name: "--card-pressed", day: "#F6F7FB", night: "#333661", role: "حالت فشرده‌شدهٔ کارت" },
  { name: "--text", day: "#252746", night: "#FFFFFF", role: "متن اصلی سرمه‌ای/سفید (TextH1/TextP2)" },
  { name: "--text-weak", day: "#4A4D85", night: "rgba(255,255,255,0.8)", role: "متن فرعی و زیرنویس‌ها" },
  { name: "--primary", day: "#7E4BDE", night: "#885BDE", role: "بنفش اصلی دکمه‌های میمو (button_primary)" },
  { name: "--primary-hi", day: "#6E3EC8", night: "#7E4BDE", role: "لبهٔ سه‌بعدی دکمه و گره (button_primary_highlight)" },
  { name: "--progress", day: "#8D60E2", night: "#B89CED", role: "نوار پیشرفت ۶dp و گرهٔ تکمیل‌شده" },
  { name: "--progress-bg", day: "#E4E6F1", night: "#3F4273", role: "پس‌زمینهٔ نوار پیشرفت و مسیر بعدی" },
  { name: "--progress-weak", day: "#D8C9F5", night: "#6954B2", role: "حلقهٔ بیرونی گرهٔ جاری و پنل شبیه‌ساز" },
  { name: "--success", day: "#66BC5A", night: "#A4E59B", role: "سبز پاسخ صحیح (feedback correct)" },
  { name: "--error", day: "#F05A6E", night: "#F6A0AC", role: "قرمز پاسخ نادرست (feedback wrong)" },
  { name: "--yellow", day: "#F4D055", night: "#FBDF83", role: "زرد امتیاز، سکه و استریک" },
  { name: "--blue", day: "#3890FA", night: "#00C5FF", role: "آبی وضعیت من و لینک‌ها" },
  { name: "--toolbar", day: "56px", night: "56px", role: "ارتفاع نوار ابزار اصلی میمو (56dp)" },
  { name: "--progressbar", day: "6px", night: "6px", role: "ضخامت نوار پیشرفت فصل (6dp)" },
  { name: "--radius-card", day: "12px", night: "12px", role: "شعاع گوشهٔ کارت‌ها و گزینه‌ها (12dp)" },
];

export const ECONOMY_RULES_LIST = [
  { id: "lesson-complete", fa: "تکمیل هر درس (۶ تا ۸ ریزدرس)", formula: "+۲۰ XP · +۱۰ سکه (محلی، مستقل از سرور)" },
  { id: "answer-correct", fa: "پاسخ صحیح در اولین تلاش (tries=1)", formula: "+۱۰ XP · +۵ سکه" },
  { id: "hard-mode-bonus", fa: "پاداش تکمیل در حالت چالشی (Hard Mode)", formula: "+۱۵ XP · +۸ سکه" },
  { id: "exam-complete", fa: "ثبت و پایان آزمون کنکور", formula: "+۳۰ XP · +۱۵ سکه" },
  { id: "daily-goal", fa: "رسیدن به هدف روزانه (۵۰ XP)", formula: "+۱ روز استریک · +۲۵ سکه" },
  { id: "keys-policy", fa: "سیاست کلیدها در نسخهٔ آفلاین (G-KEYS)", formula: "همیشه ∞ (بدون قفل و بدون پرداخت)" },
];

// ----------------------------------------------------------------------------
// 8. Exam Hub 7 Sections & Policy Contract (F39–F46, EXAM_TEMPLATE.json)
// ----------------------------------------------------------------------------
export type ExamKind =
  | "comprehensive"
  | "timed"
  | "normal"
  | "analytical"
  | "review";

export interface ExamPolicySpec {
  label: string;
  shortLabel: string;
  defaultMinutes: number;
  allowSheetDuring: boolean; // پاسخبرگ
  allowKeyDuring: boolean; // پاسخنامه
}

export const EXAM_POLICIES: Record<ExamKind, ExamPolicySpec> = {
  comprehensive: {
    label: "جامع · زمان خالص آزمون · پاسخنامه در پایان",
    shortLabel: "جامع",
    defaultMinutes: 270,
    allowSheetDuring: false,
    allowKeyDuring: false,
  },
  review: {
    label: "جمع‌بندی / نهایی · زمان خالص آزمون · پاسخنامه در پایان",
    shortLabel: "جمع‌بندی",
    defaultMinutes: 45,
    allowSheetDuring: false,
    allowKeyDuring: false,
  },
  timed: {
    label: "زمان‌دار · پاسخبرگ + پاسخنامه حین آزمون",
    shortLabel: "زمان‌دار",
    defaultMinutes: 30,
    allowSheetDuring: true,
    allowKeyDuring: true,
  },
  normal: {
    label: "عادی · پاسخبرگ + پاسخنامه حین آزمون",
    shortLabel: "عادی",
    defaultMinutes: 30,
    allowSheetDuring: true,
    allowKeyDuring: true,
  },
  analytical: {
    label: "تحلیلی · پاسخبرگ + پاسخنامه حین و بعد + شبیه‌سازی نمرهٔ منفی",
    shortLabel: "تحلیلی",
    defaultMinutes: 45,
    allowSheetDuring: true,
    allowKeyDuring: true,
  },
};

export interface ExamHubSection {
  index: number;
  filterKey: string;
  titleFa: string;
  metaHtmlFa: string;
  items: {
    examTitle: string;
    labelLines: [string, string];
    kind: ExamKind;
    icon: string;
    badge: string;
    subjectFilter?: "زیست" | "شیمی" | "فیزیک" | "ریاضی";
    topicFilter?: string;
    minutesPreset?: number;
    mistakesOnly?: boolean;
  }[];
}

export const EXAM_HUB_SECTIONS: ExamHubSection[] = [
  {
    index: 0,
    filterKey: "0",
    titleFa: "۱ · آزمون‌های جامع",
    metaHtmlFa:
      "قالب: زمان پیش‌فرض ۲۷۰ دقیقه (در تنظیم زمان برای همهٔ آزمون‌ها قابل تغییر است) · ۲۰ سؤال استاندارد ۴ درس · نمرهٔ منفی ⅓ · «زمان خالص آزمون» · پاسخنامه در پایان آزمون باز می‌شود",
    items: [
      {
        examTitle: "آزمون جامع کنکور",
        labelLines: ["آزمون جامع", "کنکور"],
        kind: "comprehensive",
        icon: "ic_trophy",
        badge: "۲۰ سؤال",
        minutesPreset: 270,
      },
      {
        examTitle: "آزمون جامع تجربی",
        labelLines: ["جامع", "تجربی"],
        kind: "comprehensive",
        icon: "ic_trophy",
        badge: "۲۷۰ دقیقه",
        minutesPreset: 270,
      },
      {
        examTitle: "آزمون جامع ریاضی و فیزیک",
        labelLines: ["جامع", "ریاضی"],
        kind: "comprehensive",
        icon: "ic_trophy",
        badge: "قابل تغییر",
        minutesPreset: 270,
      },
    ],
  },
  {
    index: 1,
    filterKey: "1",
    titleFa: "۲ · آزمون‌های زمان‌دار",
    metaHtmlFa:
      "قالب: مدت قابل‌تنظیم (کلیک روی تایمر داخل آزمون ← عدد ← شروع) · پاسخبرگ + پاسخنامه حین آزمون",
    items: [
      {
        examTitle: "آزمون زمان‌دار ۳۰ دقیقه",
        labelLines: ["زمان‌دار", "۳۰ دقیقه"],
        kind: "timed",
        icon: "ic_clock_black_24dp",
        badge: "۳۰ د",
        minutesPreset: 30,
      },
      {
        examTitle: "آزمون سرعتی ۱۰ دقیقه",
        labelLines: ["سرعتی", "۱۰ دقیقه"],
        kind: "timed",
        icon: "ic_clock_black_24dp",
        badge: "۱۰ د",
        minutesPreset: 10,
      },
      {
        examTitle: "پومودورو تست ۲۵ دقیقه",
        labelLines: ["پومودورو", "تست"],
        kind: "timed",
        icon: "ic_clock_black_24dp",
        badge: "۲۵ د",
        minutesPreset: 25,
      },
    ],
  },
  {
    index: 2,
    filterKey: "2",
    titleFa: "۳ · تک‌درسی و مبحثی",
    metaHtmlFa:
      "قالب: تفکیک درس و مبحث · ضریب درس ×۲ · پاسخبرگ + پاسخنامه حین آزمون · نتیجه و تحلیل",
    items: [
      {
        examTitle: "آزمون تک‌درسی زیست",
        labelLines: ["تک‌درسی", "زیست"],
        kind: "normal",
        icon: "img_brain",
        badge: "زیست",
        subjectFilter: "زیست",
        minutesPreset: 25,
      },
      {
        examTitle: "آزمون تک‌درسی شیمی",
        labelLines: ["تک‌درسی", "شیمی"],
        kind: "normal",
        icon: "ic_sparks_alt",
        badge: "شیمی",
        subjectFilter: "شیمی",
        minutesPreset: 25,
      },
      {
        examTitle: "آزمون فیزیک و ریاضی",
        labelLines: ["فیزیک و", "ریاضی"],
        kind: "normal",
        icon: "ic_flash_filled",
        badge: "محاسباتی",
        subjectFilter: "فیزیک",
        minutesPreset: 30,
      },
    ],
  },
  {
    index: 3,
    filterKey: "3",
    titleFa: "۴ · آزمون‌های این ماه",
    metaHtmlFa:
      "قالب: تقویم ماه · محاسبهٔ تراز تخمینی محلی · پاسخبرگ و پاسخنامه کامل",
    items: [
      {
        examTitle: "آزمون این ماه",
        labelLines: ["آزمون", "این ماه"],
        kind: "normal",
        icon: "ic_calendar",
        badge: "جدید",
        minutesPreset: 45,
      },
      {
        examTitle: "آزمون هفتهٔ سوم",
        labelLines: ["هفتهٔ", "سوم"],
        kind: "normal",
        icon: "ic_file",
        badge: "تراز",
        minutesPreset: 30,
      },
      {
        examTitle: "آزمون ماه قبل",
        labelLines: ["ماه", "قبل"],
        kind: "normal",
        icon: "ic_task_completed",
        badge: "مرور",
        minutesPreset: 45,
      },
    ],
  },
  {
    index: 4,
    filterKey: "4",
    titleFa: "۵ · آزمون‌های تحلیلی",
    metaHtmlFa:
      "قالب: پاسخبرگ + پاسخنامه حین و بعد · شبیه‌سازی «اگر غلط‌ها نزده می‌ذاشتی» · تحلیل مبحث‌به‌مبحث",
    items: [
      {
        examTitle: "آزمون تحلیلی زیست",
        labelLines: ["تحلیلی", "زیست"],
        kind: "analytical",
        icon: "ic_target",
        badge: "تحلیل",
        subjectFilter: "زیست",
        minutesPreset: 30,
      },
      {
        examTitle: "تحلیل آزمون جامع",
        labelLines: ["تحلیل", "جامع"],
        kind: "analytical",
        icon: "ic_target",
        badge: "گزارش",
        minutesPreset: 45,
      },
      {
        examTitle: "تحلیل محاسبات شیمی و فیزیک",
        labelLines: ["تحلیل", "محاسبات"],
        kind: "analytical",
        icon: "ic_target",
        badge: "گزارش",
        subjectFilter: "شیمی",
        minutesPreset: 30,
      },
    ],
  },
  {
    index: 5,
    filterKey: "5",
    titleFa: "۶ · جمع‌بندی و دوره",
    metaHtmlFa:
      "قالب: بدون پاسخنامه حین آزمون (زمان خالص آزمون) · پاسخنامه در پایان آزمون باز می‌شود",
    items: [
      {
        examTitle: "آزمون جمع‌بندی فصل‌ها",
        labelLines: ["جمع‌بندی", "فصل‌ها"],
        kind: "review",
        icon: "ic_sparks_alt",
        badge: "زمان خالص",
        minutesPreset: 45,
      },
      {
        examTitle: "دورهٔ فشرده کنکور",
        labelLines: ["دورهٔ", "فشرده"],
        kind: "review",
        icon: "ic_sparks_alt",
        badge: "فشرده",
        minutesPreset: 30,
      },
      {
        examTitle: "آزمون دو هفتگی برنامه‌ای",
        labelLines: ["آزمون", "دو هفتگی"],
        kind: "review",
        icon: "ic_cap_filled",
        badge: "برنامه‌ای",
        minutesPreset: 60,
      },
    ],
  },
  {
    index: 6,
    filterKey: "6",
    titleFa: "۷ · مرور غلط‌ها و نشان‌شده‌ها",
    metaHtmlFa:
      "قالب: استخراج هوشمند از جدول اشتباهات شما (FSRS-lite: دو بار پاسخ صحیح متوالی = خروج از صف غلط‌ها)",
    items: [
      {
        examTitle: "مرور غلط‌های من",
        labelLines: ["مرور", "غلط‌ها"],
        kind: "analytical",
        icon: "ic_flag",
        badge: "صف مرور",
        mistakesOnly: true,
        minutesPreset: 20,
      },
      {
        examTitle: "تثبیت زیست و شیمی",
        labelLines: ["تثبیت", "زیست/شیمی"],
        kind: "normal",
        icon: "img_brain",
        badge: "تثبیت",
        subjectFilter: "زیست",
        minutesPreset: 20,
      },
      {
        examTitle: "تثبیت ریاضی و فیزیک",
        labelLines: ["تثبیت", "ریاضی/فیزیک"],
        kind: "normal",
        icon: "ic_target",
        badge: "تثبیت",
        subjectFilter: "ریاضی",
        minutesPreset: 20,
      },
    ],
  },
];
