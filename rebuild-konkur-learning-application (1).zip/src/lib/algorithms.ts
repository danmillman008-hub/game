import type { MimoBeatStep } from "@/db/schema";

export interface BKTParams {
  pInit: number;
  pLearn: number;
  pSlip: number;
  pGuess: number;
}

export const DEFAULT_BKT_PARAMS: BKTParams = {
  pInit: 0.25,
  pLearn: 0.28, // Calibrated per Gramophone EVAL-QUALITATIVE F4 fix so mastery (0.85) is reachable in 3-4 unaided steps
  pSlip: 0.1,
  pGuess: 0.2,
};

export const MASTERY_THRESHOLD = 0.82;

/**
 * Calibrated Bayesian Knowledge Tracing (BKT) + Aided/Unaided Distinction
 * Synthesizes Gramophone M2 (`adapt.py`) + `my-first` Decision #5 & #10:
 * - Aided attempts (hints/worked examples) discount `pLearn` so a skill cannot reach
 *   `mastered` without unaided retrieval.
 * - Confidence calibration adjusts slip/guess weighting slightly.
 */
export function updateBKTMastery(
  priorMastery: number,
  isCorrect: boolean,
  supportUsed: "unaided" | "hint_1" | "hint_2" | "worked_example" = "unaided",
  confidencePct = 75,
  params: BKTParams = DEFAULT_BKT_PARAMS
): number {
  const p = Math.max(0.02, Math.min(0.99, priorMastery));
  const supportMultiplier =
    supportUsed === "unaided"
      ? 1.0
      : supportUsed === "hint_1"
        ? 0.55
        : supportUsed === "hint_2"
          ? 0.3
          : 0.12;

  const pSlip = params.pSlip;
  const pGuess =
    confidencePct < 40 && isCorrect
      ? Math.min(0.45, params.pGuess * 1.45) // Low-confidence lucky guess guard
      : params.pGuess;

  let posteriorGivenObs: number;
  if (isCorrect) {
    const num = p * (1 - pSlip);
    const den = num + (1 - p) * pGuess;
    posteriorGivenObs = den > 0 ? num / den : p;
  } else {
    const num = p * pSlip;
    const den = num + (1 - p) * (1 - pGuess);
    posteriorGivenObs = den > 0 ? num / den : p;
  }

  const effectiveLearn = isCorrect ? params.pLearn * supportMultiplier : params.pLearn * 0.2;
  const updated = posteriorGivenObs + (1 - posteriorGivenObs) * effectiveLearn;

  // Guard from `my-first` Bug #2: aided attempts cannot cross mastery threshold alone
  if (supportUsed !== "unaided" && updated >= MASTERY_THRESHOLD) {
    return Math.min(MASTERY_THRESHOLD - 0.04, Number(updated.toFixed(4)));
  }

  return Number(Math.max(0.03, Math.min(0.99, updated)).toFixed(4));
}

/**
 * FSRS-5 / DSR Spaced Repetition Update
 * Synthesizes `open-spaced-repetition/ts-fsrs` + Gramophone `srs.py` + `my-first` Bug #3 fix (massed cap).
 */
export function updateFSRSState(
  currentStabilityDays: number,
  currentDifficulty: number,
  isCorrect: boolean,
  confidencePct: number,
  supportUsed: "unaided" | "hint_1" | "hint_2" | "worked_example",
  elapsedDays = 0.5
): {
  stabilityDays: number;
  difficulty: number;
  retrievability: number;
  nextDueHours: number;
} {
  // Rating: 1=Again, 2=Hard, 3=Good, 4=Easy
  const rating: 1 | 2 | 3 | 4 = !isCorrect
    ? 1
    : supportUsed !== "unaided"
      ? 2
      : confidencePct >= 85
        ? 4
        : 3;

  // Difficulty update D' in [1..10]
  const deltaD = rating === 1 ? 1.1 : rating === 2 ? 0.35 : rating === 3 ? -0.15 : -0.45;
  const nextDifficulty = Number(
    Math.max(1.0, Math.min(10.0, currentDifficulty + deltaD)).toFixed(2)
  );

  // Retrievability R = (1 + (19/81) * (t / S))^(-0.5)
  const sSafe = Math.max(0.2, currentStabilityDays);
  const currentR = Math.pow(1 + (19 / 81) * (elapsedDays / sSafe), -0.5);

  // Desirable difficulty bonus: growth is higher when R was lower (spaced), capped when massed
  const spacingFactor = elapsedDays < 0.15 ? 0.35 : Math.min(1.8, 0.7 + (1 - currentR) * 1.6);

  let nextStability: number;
  if (rating === 1) {
    // Lapse shrinks stability
    nextStability = Math.max(0.25, sSafe * 0.38);
  } else {
    const gradeMultiplier = rating === 2 ? 1.22 : rating === 3 ? 1.85 : 2.45;
    const growth = 1 + (gradeMultiplier - 1) * spacingFactor * ((11 - nextDifficulty) / 6.5);
    nextStability = Math.min(180, sSafe * Math.max(1.08, growth));
  }

  const roundedStability = Number(nextStability.toFixed(2));
  const nextRetrievability = Number(
    Math.pow(1 + (19 / 81) * (0.1 / roundedStability), -0.5).toFixed(3)
  );
  // Target retention r = 0.85 => interval ~ S * ((0.85^(-2) - 1) * (81/19)) ≈ S * 1.63 days
  const nextDueHours = Math.max(2, Math.round(roundedStability * 1.63 * 24));

  return {
    stabilityDays: roundedStability,
    difficulty: nextDifficulty,
    retrievability: nextRetrievability,
    nextDueHours,
  };
}

/**
 * Knowledge Space Theory (KST) Outer Fringe & State Computation
 * Ported from `newlearning/gramophone_m1/spacing.py`:
 * Outer Fringe(S) = { q not in S | all prerequisites of q are in S }
 * Inner Fringe(S) = { q in S | there is no q' in S that requires q }
 */
export function computeKSTStates<
  T extends { slug: string; masteryP: number; prerequisites: string[] }
>(
  nodes: T[]
): Map<
  string,
  {
    kstState: "mastered" | "outer_fringe" | "learning" | "locked";
    inInnerFringe: boolean;
    missingPrereqs: string[];
  }
> {
  const masteredSet = new Set(
    nodes.filter((n) => n.masteryP >= MASTERY_THRESHOLD).map((n) => n.slug)
  );

  // Inner fringe: mastered items that are not a prerequisite of another mastered item
  const dependedOnByMastered = new Set<string>();
  for (const n of nodes) {
    if (masteredSet.has(n.slug)) {
      for (const pre of n.prerequisites || []) {
        dependedOnByMastered.add(pre);
      }
    }
  }

  const result = new Map<
    string,
    {
      kstState: "mastered" | "outer_fringe" | "learning" | "locked";
      inInnerFringe: boolean;
      missingPrereqs: string[];
    }
  >();

  for (const n of nodes) {
    const prereqs = n.prerequisites || [];
    const missingPrereqs = prereqs.filter((p) => !masteredSet.has(p));

    if (masteredSet.has(n.slug)) {
      result.set(n.slug, {
        kstState: "mastered",
        inInnerFringe: !dependedOnByMastered.has(n.slug),
        missingPrereqs: [],
      });
    } else if (missingPrereqs.length === 0) {
      result.set(n.slug, {
        kstState: "outer_fringe",
        inInnerFringe: false,
        missingPrereqs: [],
      });
    } else if (n.masteryP >= 0.45) {
      result.set(n.slug, {
        kstState: "learning",
        inInnerFringe: false,
        missingPrereqs,
      });
    } else {
      result.set(n.slug, {
        kstState: "locked",
        inInnerFringe: false,
        missingPrereqs,
      });
    }
  }

  return result;
}

/**
 * Konkur Scoring & Taraz Calculator
 * Standard Sanjesh / Ghalamchi formula:
 * Raw % = ((3 * Correct - Wrong) / (3 * Total)) * 100
 */
export function calculateKonkurMetrics(
  correctCount: number,
  wrongCount: number,
  totalCount: number,
  negativeRatio = 3
): {
  rawPercent: number;
  withoutNegativePercent: number;
  estimatedTaraz: number;
  rankBracket: string;
} {
  if (totalCount <= 0) {
    return {
      rawPercent: 0,
      withoutNegativePercent: 0,
      estimatedTaraz: 4500,
      rankBracket: "نیاز به داده بیشتر",
    };
  }

  const rawPercent = Number(
    (((negativeRatio * correctCount - wrongCount) / (negativeRatio * totalCount)) * 100).toFixed(1)
  );
  const withoutNegativePercent = Number(((correctCount / totalCount) * 100).toFixed(1));

  // Psychometric Taraz mapping (Mean ~ 32% in hard Konkur exams -> 5600 Taraz)
  const normalized = (rawPercent - 28) / 24;
  const estimatedTaraz = Math.round(
    Math.max(3400, Math.min(8350, 5650 + normalized * 1250))
  );

  let rankBracket = "رتبه کشوری بالای ۵۰۰۰";
  if (estimatedTaraz >= 7400) rankBracket = "رتبه زیر ۱۰۰ کشوری (نخبه کنکور)";
  else if (estimatedTaraz >= 6800) rankBracket = "رتبه ۱۰۰ تا ۵۰۰ (دانشگاه‌های برتر تهران)";
  else if (estimatedTaraz >= 6200) rankBracket = "رتبه ۵۰۰ تا ۲۰۰۰ (قبولی روزانه تراز اول)";
  else if (estimatedTaraz >= 5500) rankBracket = "رتبه ۲۰۰۰ تا ۵۰۰۰ (منطقه امن قبولی)";

  return {
    rawPercent,
    withoutNegativePercent,
    estimatedTaraz,
    rankBracket,
  };
}

/**
 * Textbook / Jozve to LearnHarness + Mimo Quest Compiler
 * Fixes Q1 (extraction recall), Q2 (check-kind schema), and Q5 (multi-DOK checks)
 * from `newlearning/EVAL-QUALITATIVE.md`.
 */
export function compileJozveToQuest(params: {
  track: string;
  subject: string;
  chapter: string;
  title: string;
  rawText: string;
}): {
  nodeSlug: string;
  unconditionalTruth: string;
  discoveryMotivation: string;
  commonTrap: string;
  mermaidPlan: string;
  beats: MimoBeatStep[];
} {
  const cleanLines = params.rawText
    .split(/\n+/)
    .map((l) => l.trim())
    .filter((l) => l.length > 12);

  const firstPrinciple =
    cleanLines[0] ||
    `هر مسئله در مبحث «${params.title}» بر پایه یک رابطه علیتی تغییرناپذیر میان متغیرهای اصلی تعریف می‌شود.`;
  const secondLine =
    cleanLines[1] ||
    `طراح کنکور با تغییر ظاهر صورت سوال، تشخیص متغیر مستقل از وابسته را به چالش می‌کشد.`;
  const thirdLine =
    cleanLines[2] ||
    `برای حل سریع تست‌های زمان‌دار «${params.title}»، ابتدا شرط مرزی را بررسی کرده و گزینه‌های ناهمساز را حذف می‌کنیم.`;

  const slugBase = `custom-${Date.now().toString(36)}`;

  const mermaidPlan = `graph TD
  root["اصل بدیهی (Principle i): ${params.title}"] --> derive["گام اکتشافی (Principle ii): استنتاج رابطه"]
  derive --> trap["دام‌شناسی طراح کنکور در ${params.subject}"]
  trap --> target["تسلط کامل تستی بر ${params.title}"]`;

  const beats: MimoBeatStep[] = [
    {
      id: `${slugBase}-b1`,
      phase: "probe",
      kind: "probe_diagnostic",
      nodeSlug: slugBase,
      title: `سنجش لبه دانش (Probe): ${params.title}`,
      principleBadge: "LearnHarness Probe • Binary Search",
      contentMarkdown: `پیش از شروع درسنامه، طبق معماری **LearnHarness** ابتدا مرز دقیق دانش فعلی شما (Floor & Ceiling) را در مبحث **${params.title}** می‌سنجیم تا وقتتان روی مطالب بدیهی تلف نشود.`,
      promptQuestion: `کدام گزاره، هسته اصلی و شرط بنیادین مبحث «${params.title}» را دقیق‌تر بیان می‌کند؟`,
      options: [
        { id: "a", label: firstPrinciple.slice(0, 110) },
        {
          id: "b",
          label: "صرفاً حفظ کردن فرمول نهایی بدون بررسی شرایط مرزی کافی است.",
          isTrap: true,
          trapReason: "تله حفظ طوطی‌وار: در تست‌های ترکیبی سنجش، بدون شرط مرزی به گزینه دام می‌رسید.",
        },
        {
          id: "c",
          label: "این مبحث هیچ ارتباط پیشنیازی با سایر فصل‌های کتاب درسی ندارد.",
          isTrap: true,
          trapReason: "تله جزیره‌ای دیدن مباحث: این گره در گراف دانش به مفاهیم پایه متصل است.",
        },
      ],
      correctAnswer: "a",
      hints: [
        "به جمله اول متن جزوه و قاعده بدون استثنای آن دقت کنید.",
        "گزینه‌ای که اصل پایه و تغییرناپذیر مبحث را بیان می‌کند انتخاب کنید.",
      ],
      modelSolution: `طبق اصل اول LearnHarness (Unconditional Truth): ${firstPrinciple}`,
      dokLevel: 2,
    },
    {
      id: `${slugBase}-b2`,
      phase: "teach",
      kind: "unconditional_truth",
      nodeSlug: slugBase,
      title: `اصل بدیهی و استنتاج مفهومی (Teach): ${params.title}`,
      principleBadge: "Principle i & ii • Unconditional Truth → Discovery",
      contentMarkdown: `### ۱. اصل بدیهی پایه (Unconditional Truth)\n> ${firstPrinciple}\n\n### ۲. چطور خودمان می‌توانستیم به این نکته برسیم؟ (Principle ii)\n${secondLine}\n\n### ۳. تکنیک تستی و دام طراح\n${thirdLine}`,
      promptQuestion: `در مبحث «${params.title}»، نخستین اقدام پیش از جایگذاری عددی یا رد گزینه چیست؟`,
      fillTemplate: "ابتدا باید ___ را بر اساس اصل بدیهی مبحث مشخص کنیم.",
      fillChoices: ["شرط مرزی و متغیر اصلی", "شماره صفحه کتاب", "طولانی‌ترین گزینه"],
      correctAnswer: "شرط مرزی و متغیر اصلی",
      hints: ["به گام سوم درسنامه بالا نگاه کنید."],
      modelSolution: thirdLine,
      dokLevel: 2,
    },
    {
      id: `${slugBase}-b3`,
      phase: "practice",
      kind: "practice_problem",
      nodeSlug: slugBase,
      title: `بازیابی فعال گزاره غیرفعال (Practice): تست شبیه‌ساز ${params.title}`,
      principleBadge: "LearnHarness Practice • Inactive Retrieval",
      contentMarkdown: `اکنون در فاز **Practice**، بدون اینکه فرمول یا نکته مستقیماً نام برده شود، باید از حافظه فعال خود برای تشخیص دام طراح در مبحث **${params.title}** استفاده کنید.`,
      promptQuestion: `اگر طراح کنکور در تست «${params.title}» ظاهر صورت سوال را تغییر دهد، کدام زنجیره استدلال شما را از تله تستی نجات می‌دهد؟`,
      options: [
        {
          id: "opt1",
          label: `تشخیص اصل پایه (${firstPrinciple.slice(0, 55)}...) ← بررسی شرط مرزی ← حذف گزینه دام`,
        },
        {
          id: "opt2",
          label: "انتخاب سریع‌ترین عددی که از ضرب مستقیم اعداد صورت سوال به دست می‌آید",
          isTrap: true,
          trapReason: "دام کلاسیک طراح کنکور سراسری (گزینه سراب محاسباتی).",
        },
        {
          id: "opt3",
          label: "رد کردن سوال بدون بررسی ساختار مفهومی",
        },
      ],
      correctAnswer: "opt1",
      hints: [
        "نردبان راهنمایی ۱: ابتدا اصل بدون استثنای مبحث را به یاد بیاورید.",
        "نردبان راهنمایی ۲: زنجیره‌ای که از اصل پایه به شرط مرزی می‌رسد صحیح است.",
      ],
      modelSolution: `زنجیره استدلال استاندارد: ۱) فراخوانی اصل پایه: «${firstPrinciple}» ۲) تحلیل تغییر طراح: «${secondLine}» ۳) اجرای تکنیک: «${thirdLine}».`,
      dokLevel: 3,
    },
  ];

  return {
    nodeSlug: slugBase,
    unconditionalTruth: firstPrinciple,
    discoveryMotivation: secondLine,
    commonTrap: thirdLine,
    mermaidPlan,
    beats,
  };
}
