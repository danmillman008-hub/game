import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import {
  konkurExams,
  examSubmissions,
  knowledgeNodes,
  learnerProfiles,
  learningEvidence,
  type ExamQuestionLog,
} from "@/db/schema";
import {
  calculateKonkurMetrics,
  updateBKTMastery,
  updateFSRSState,
  computeKSTStates,
} from "@/lib/algorithms";
import { eq } from "drizzle-orm";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      examSlug,
      answers = {},
      flags = {},
      timeSpentSec = 240,
    } = body as {
      examSlug: string;
      answers: Record<string, 1 | 2 | 3 | 4 | null>;
      flags: Record<string, "none" | "doubt" | "time_consuming" | "trap_alert">;
      timeSpentSec: number;
    };

    const [exam] = await db
      .select()
      .from(konkurExams)
      .where(eq(konkurExams.slug, examSlug));

    if (!exam) {
      return NextResponse.json({ error: "آزمون یافت نشد" }, { status: 404 });
    }

    let correctCount = 0;
    let wrongCount = 0;
    let blankCount = 0;
    let trapFallCount = 0;
    const questionLogs: ExamQuestionLog[] = [];
    const remediationSet = new Set<string>();

    for (const q of exam.questions) {
      const selected = answers[q.id] ?? null;
      const flag = flags[q.id] ?? "none";

      let status: "correct" | "wrong" | "blank" = "blank";
      let fellForTrap = false;
      let errorCategory: ExamQuestionLog["errorCategory"] = undefined;

      if (selected === null) {
        blankCount++;
        errorCategory = "prerequisite_gap";
        remediationSet.add(q.linkedNodeSlug);
      } else if (selected === q.correctOption) {
        status = "correct";
        correctCount++;
      } else {
        status = "wrong";
        wrongCount++;
        remediationSet.add(q.linkedNodeSlug);
        if (selected === q.trapOption) {
          fellForTrap = true;
          trapFallCount++;
          errorCategory = "designer_trap";
        } else {
          errorCategory = "conceptual_gap";
        }
      }

      questionLogs.push({
        questionId: q.id,
        number: q.number,
        selectedOption: selected,
        correctOption: q.correctOption,
        status,
        fellForTrap,
        flag,
        linkedNodeSlug: q.linkedNodeSlug,
        errorCategory,
      });

      // Synchronize exam evidence directly into the LearnHarness + FSRS knowledge node!
      const [node] = await db
        .select()
        .from(knowledgeNodes)
        .where(eq(knowledgeNodes.slug, q.linkedNodeSlug));

      if (node && selected !== null) {
        const isRight = status === "correct";
        const nextM = updateBKTMastery(node.masteryP, isRight, "unaided", isRight ? 85 : 70);
        const nextFsrs = updateFSRSState(
          node.stabilityDays,
          node.difficulty,
          isRight,
          isRight ? 85 : 70,
          "unaided",
          0.8
        );

        await db
          .update(knowledgeNodes)
          .set({
            masteryP: nextM,
            stabilityDays: nextFsrs.stabilityDays,
            difficulty: nextFsrs.difficulty,
            retrievability: nextFsrs.retrievability,
            unaidedSuccesses: isRight ? node.unaidedSuccesses + 1 : node.unaidedSuccesses,
            lapses: !isRight ? node.lapses + 1 : node.lapses,
            lastReviewedAt: new Date(),
          })
          .where(eq(knowledgeNodes.id, node.id));

        await db.insert(learningEvidence).values({
          nodeSlug: node.slug,
          lessonSlug: exam.slug,
          phase: "exam",
          stepKind: "konkur_exam_question",
          isCorrect: isRight,
          confidencePct: flag === "doubt" ? 45 : 80,
          thinkingTrace: fellForTrap
            ? `شکار شده در دام طراح: ${q.trapName}`
            : isRight
              ? "پاسخ صحیح در شرایط زمان‌دار آزمون"
              : "پاسخ نادرست در آزمون شبیه‌ساز",
          supportUsed: "unaided",
          detectedTrap: fellForTrap ? q.trapName : null,
          masteryBefore: node.masteryP,
          masteryAfter: nextM,
          stabilityAfter: nextFsrs.stabilityDays,
          xapiVerb: isRight ? "passed" : "failed",
        });
      }
    }

    // Recompute KST states across the graph
    const allNodes = await db.select().from(knowledgeNodes);
    const kstMap = computeKSTStates(allNodes);
    for (const n of allNodes) {
      const k = kstMap.get(n.slug);
      if (k && k.kstState !== n.kstState) {
        await db
          .update(knowledgeNodes)
          .set({ kstState: k.kstState })
          .where(eq(knowledgeNodes.id, n.id));
      }
    }

    const metrics = calculateKonkurMetrics(
      correctCount,
      wrongCount,
      exam.questions.length,
      exam.negativeMarkingRatio
    );

    const [inserted] = await db
      .insert(examSubmissions)
      .values({
        examSlug: exam.slug,
        examTitle: exam.title,
        organizer: exam.organizer,
        rawPercent: metrics.rawPercent,
        withoutNegativePercent: metrics.withoutNegativePercent,
        estimatedTaraz: metrics.estimatedTaraz,
        correctCount,
        wrongCount,
        blankCount,
        trapFallCount,
        timeSpentSec,
        questionLogs,
        remediationSlugs: Array.from(remediationSet),
      })
      .returning();

    const [profile] = await db.select().from(learnerProfiles).limit(1);
    if (profile) {
      await db
        .update(learnerProfiles)
        .set({
          xp: profile.xp + Math.max(25, correctCount * 20),
          updatedAt: new Date(),
        })
        .where(eq(learnerProfiles.id, profile.id));
    }

    return NextResponse.json({
      ok: true,
      submission: inserted,
      rankBracket: metrics.rankBracket,
    });
  } catch (error) {
    console.error("Error in POST /api/exams/submit:", error);
    return NextResponse.json(
      { error: "خطا در تصحیح پاسخ‌برگ کنکور" },
      { status: 500 }
    );
  }
}
