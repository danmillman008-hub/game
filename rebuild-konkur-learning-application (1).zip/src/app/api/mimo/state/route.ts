import { NextRequest, NextResponse } from "next/server";
import { getFullAppState } from "@/lib/mimo/server-service";
import {
  getTutorialById,
  RUNTIME_EVIDENCE,
  ENDPOINT_CATALOG,
  EVIDENCE_DATABASE,
  FINAL_TEST_MATRIX,
} from "@/lib/mimo/corpus";
import { runAllVerificationVectors } from "@/lib/mimo/engine";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const sectionIndex = Number(searchParams.get("sectionIndex") || 0);
    const trackIdParam = searchParams.get("trackId");
    const tutorialIdParam = searchParams.get("tutorialId");
    const includeEvidence = searchParams.get("includeEvidence") === "1";

    const trackIdOverride = trackIdParam ? Number(trackIdParam) : undefined;
    const state = await getFullAppState(sectionIndex, trackIdOverride);

    const activeTutorialId = tutorialIdParam
      ? Number(tutorialIdParam)
      : state.pathState.nodes.find((n) => n.status === "CURRENT")?.tutorialId ??
        state.pathState.nodes[0]?.tutorialId ??
        904;

    const activeTutorial = getTutorialById(activeTutorialId);
    const verification = runAllVerificationVectors();

    return NextResponse.json({
      ok: true,
      ...state,
      activeTutorial,
      verification,
      evidenceBundle: includeEvidence
        ? {
            runtimeEvidence: RUNTIME_EVIDENCE,
            endpointCatalog: ENDPOINT_CATALOG,
            evidenceDatabase: EVIDENCE_DATABASE,
            finalTestMatrix: FINAL_TEST_MATRIX,
          }
        : undefined,
    });
  } catch (err) {
    console.error("GET /api/mimo/state error:", err);
    return NextResponse.json(
      { ok: false, error: err instanceof Error ? err.message : "Internal error" },
      { status: 500 }
    );
  }
}
