import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import {
  knowledgeNodes,
  mimoLessons,
  blueprintPhases,
} from "@/db/schema";
import { compileJozveToQuest } from "@/lib/algorithms";
import { eq } from "drizzle-orm";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      track = "tajrobi",
      subject = "زیست‌شناسی",
      chapter = "فصل انتخابی داوطلب",
      title = "مبحث استخراج‌شده از جزوه",
      rawText = "",
      prerequisiteSlug = "",
    } = body as {
      track?: string;
      subject?: string;
      chapter?: string;
      title?: string;
      rawText?: string;
      prerequisiteSlug?: string;
    };

    if (!title.trim() || !rawText.trim()) {
      return NextResponse.json(
        { error: "عنوان مبحث و متن جزوه یا کتاب درسی الزامی است" },
        { status: 400 }
      );
    }

    const compiled = compileJozveToQuest({
      track,
      subject,
      chapter,
      title: title.trim(),
      rawText: rawText.trim(),
    });

    const [createdNode] = await db
      .insert(knowledgeNodes)
      .values({
        slug: compiled.nodeSlug,
        track,
        subject,
        chapter,
        title: title.trim(),
        unconditionalTruth: compiled.unconditionalTruth,
        discoveryMotivation: compiled.discoveryMotivation,
        commonTrap: compiled.commonTrap,
        nodeType: "concept",
        bloomLevel: "Analyze",
        dokLevel: 2,
        prerequisites: prerequisiteSlug ? [prerequisiteSlug] : [],
        masteryP: 0.3,
        stabilityDays: 1.5,
        difficulty: 5.0,
        retrievability: 0.9,
        kstState: "outer_fringe",
      })
      .returning();

    const [createdLesson] = await db
      .insert(mimoLessons)
      .values({
        slug: `quest-${compiled.nodeSlug}`,
        track,
        subject,
        chapter,
        title: `کوئست میمو × لرن‌هارنس: ${title.trim()}`,
        subtitle: "ساخته‌شده توسط کامپایلر جزوه به کوئست (Gramophone M1–M6 + LearnHarness)",
        estimatedMinutes: 5,
        xpReward: 70,
        konkurWeight: "استخراج مستقیم از متن کتاب/جزوه شما",
        mermaidPlan: compiled.mermaidPlan,
        beats: compiled.beats,
        completedCount: 0,
      })
      .returning();

    return NextResponse.json({
      ok: true,
      node: createdNode,
      lesson: createdLesson,
    });
  } catch (error) {
    console.error("Error in POST /api/ingest:", error);
    return NextResponse.json(
      { error: "خطا در کامپایل متن به کوئست میمو" },
      { status: 500 }
    );
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const body = await req.json();
    const { phaseNumber, status } = body as {
      phaseNumber: number;
      status: "completed" | "in_progress" | "ready";
    };

    const [updated] = await db
      .update(blueprintPhases)
      .set({ status })
      .where(eq(blueprintPhases.phaseNumber, phaseNumber))
      .returning();

    return NextResponse.json({ ok: true, phase: updated });
  } catch (error) {
    console.error("Error in PATCH /api/ingest:", error);
    return NextResponse.json(
      { error: "خطا در به‌روزرسانی وضعیت مرحله نقشه راه" },
      { status: 500 }
    );
  }
}
