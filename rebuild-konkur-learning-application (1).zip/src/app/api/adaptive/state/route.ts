import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  learnerProfiles,
  knowledgeNodes,
  mimoLessons,
  learningEvidence,
  konkurExams,
  examSubmissions,
  weeklyStudyPlans,
  blueprintPhases,
} from "@/db/schema";
import { ensureSeeded } from "@/lib/seed";
import { computeKSTStates } from "@/lib/algorithms";
import { desc, asc } from "drizzle-orm";

export async function GET() {
  try {
    await ensureSeeded();

    const [
      profiles,
      nodes,
      lessons,
      evidence,
      exams,
      submissions,
      studyPlans,
      phases,
    ] = await Promise.all([
      db.select().from(learnerProfiles).limit(1),
      db.select().from(knowledgeNodes).orderBy(asc(knowledgeNodes.id)),
      db.select().from(mimoLessons).orderBy(asc(mimoLessons.id)),
      db.select().from(learningEvidence).orderBy(desc(learningEvidence.id)).limit(25),
      db.select().from(konkurExams).orderBy(asc(konkurExams.id)),
      db.select().from(examSubmissions).orderBy(desc(examSubmissions.id)).limit(10),
      db.select().from(weeklyStudyPlans).orderBy(asc(weeklyStudyPlans.id)),
      db.select().from(blueprintPhases).orderBy(asc(blueprintPhases.phaseNumber)),
    ]);

    const kstMap = computeKSTStates(nodes);
    const enrichedNodes = nodes.map((n) => {
      const kst = kstMap.get(n.slug);
      return {
        ...n,
        kstState: kst?.kstState ?? n.kstState,
        inInnerFringe: kst?.inInnerFringe ?? false,
        missingPrereqs: kst?.missingPrereqs ?? [],
      };
    });

    return NextResponse.json({
      profile: profiles[0] ?? null,
      nodes: enrichedNodes,
      lessons,
      evidence,
      exams,
      submissions,
      studyPlans,
      blueprintPhases: phases,
    });
  } catch (error) {
    console.error("Error in GET /api/state:", error);
    return NextResponse.json(
      { error: "خطا در بارگذاری وضعیت سیستم کنکور-میمو" },
      { status: 500 }
    );
  }
}
