import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  konkurLessons,
  konkurSteps,
  type KonkurStepContent,
  type PedagogicalBlueprint,
  type StepKind,
} from "@/db/schema";
import {
  countPersianWords,
  evaluatePedagogicalFidelity,
} from "@/lib/pedagogy-engine";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const lessonId = body.lessonId ? Number(body.lessonId) : null;
    const blueprint = body.pedagogicalBlueprint as PedagogicalBlueprint;
    const rawSteps = body.steps as {
      id?: number;
      type: StepKind;
      conceptNodeId: string;
      scaffoldingLevel: number;
      content: KonkurStepContent;
    }[];
    const persistIfValid = Boolean(body.persistIfValid ?? false);

    if (!blueprint || !Array.isArray(rawSteps)) {
      return NextResponse.json(
        { error: "ساختار نقشه پداگوژیک یا آرایه گام‌ها نامعتبر است." },
        { status: 400 },
      );
    }

    const normalizedSteps = rawSteps.map((s) => ({
      ...s,
      cognitiveLoadWords:
        s.content.kind === "concept_bite"
          ? countPersianWords(s.content.bodyMarkdown)
          : 45,
    }));

    const audit = evaluatePedagogicalFidelity(blueprint, normalizedSteps);

    let persisted = false;
    if (persistIfValid && lessonId && audit.passedGate) {
      await db
        .update(konkurLessons)
        .set({
          pedagogicalBlueprint: blueprint,
          qualityAudit: audit,
          status: "published",
        })
        .where(eq(konkurLessons.id, lessonId));

      await db.delete(konkurSteps).where(eq(konkurSteps.lessonId, lessonId));
      await db.insert(konkurSteps).values(
        normalizedSteps.map((s, idx) => ({
          lessonId,
          position: idx,
          type: s.type,
          conceptNodeId: s.conceptNodeId,
          scaffoldingLevel: s.scaffoldingLevel,
          cognitiveLoadWords: s.cognitiveLoadWords,
          content: s.content,
        })),
      );
      persisted = true;
    }

    return NextResponse.json({
      audit,
      persisted,
      blockedReason: !audit.passedGate
        ? `گاردریل پداگوژیک اجازه انتشار نداد: عیار فعلی ${audit.overallScore}/100 (حداقل مجاز: ۸۵/۱۰۰ بدون خطای بحرانی).`
        : null,
    });
  } catch (error) {
    console.error("[POST /api/konkur/validate-custom] error:", error);
    return NextResponse.json(
      { error: "خطا در اعتبارسنجی پداگوژیک" },
      { status: 500 },
    );
  }
}
