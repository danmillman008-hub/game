import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  agentCompilationLogs,
  konkurCourses,
  konkurLessons,
  konkurSteps,
} from "@/db/schema";
import { compileTextbookToMimoLesson } from "@/lib/pedagogy-engine";
import { ensureKonkurSeeded } from "@/lib/pedagogy-seed";

export async function POST(request: Request) {
  try {
    await ensureKonkurSeeded();
    const body = await request.json();

    const subject = String(body.subject || "زیست‌شناسی").trim();
    const grade = String(body.grade || "دوازدهم کنکور").trim();
    const topicTitle = String(body.topicTitle || "").trim();
    const chapterReference = String(
      body.chapterReference || `${subject} - ${grade}`,
    ).trim();
    const rawTextbookExcerpt = String(body.rawTextbookExcerpt || "").trim();
    const saveToDatabase = Boolean(body.saveToDatabase ?? true);
    const simulateNaiveAgentFirst = Boolean(body.simulateNaiveAgentFirst ?? true);
    const requestedCourseId = body.courseId ? Number(body.courseId) : null;

    if (!topicTitle || rawTextbookExcerpt.length < 25) {
      return NextResponse.json(
        {
          error:
            "لطفاً عنوان مبحث و حداقل یک پاراگراف (۲۵ کاراکتر) از متن کتاب درسی یا جزوه کنکور را وارد کنید.",
        },
        { status: 400 },
      );
    }

    const compiled = compileTextbookToMimoLesson({
      subject,
      grade,
      topicTitle,
      chapterReference,
      rawTextbookExcerpt,
      simulateNaiveAgentFirst,
    });

    let createdLessonId: number | null = null;

    if (saveToDatabase && compiled.finalAudit.passedGate) {
      // Find matching course or fallback to first course
      const allCourses = await db.select().from(konkurCourses);
      let targetCourseId = requestedCourseId;
      if (!targetCourseId) {
        const matched = allCourses.find((c) =>
          c.subject.includes(subject.slice(0, 4)),
        );
        targetCourseId = matched?.id ?? allCourses[0]?.id ?? null;
      }

      if (targetCourseId) {
        const slug = `compiled-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
        const [insertedLesson] = await db
          .insert(konkurLessons)
          .values({
            courseId: targetCourseId,
            slug,
            title: compiled.title,
            chapterReference: compiled.chapterReference,
            rawTextbookExcerpt: compiled.rawTextbookExcerpt,
            xpReward: compiled.xpReward,
            estimatedMinutes: compiled.estimatedMinutes,
            status: "published",
            pedagogicalBlueprint: compiled.pedagogicalBlueprint,
            qualityAudit: compiled.finalAudit,
            position: 99,
          })
          .returning();

        createdLessonId = insertedLesson.id;

        await db.insert(konkurSteps).values(
          compiled.steps.map((s, idx) => ({
            lessonId: insertedLesson.id,
            position: idx,
            type: s.type,
            conceptNodeId: s.conceptNodeId,
            scaffoldingLevel: s.scaffoldingLevel,
            cognitiveLoadWords: s.cognitiveLoadWords,
            content: s.content,
          })),
        );
      }
    }

    await db.insert(agentCompilationLogs).values({
      subject,
      topicTitle,
      rawExcerpt: rawTextbookExcerpt,
      initialScore: compiled.initialNaiveAudit?.overallScore ?? compiled.finalAudit.overallScore,
      finalScore: compiled.finalAudit.overallScore,
      passedGuardrail: compiled.finalAudit.passedGate,
      violationsCount: compiled.finalAudit.violations.length,
      autoRepaired: simulateNaiveAgentFirst,
      createdLessonId,
      auditSnapshot: compiled.finalAudit,
    });

    const createdSteps = createdLessonId
      ? await db
          .select()
          .from(konkurSteps)
          .where(eq(konkurSteps.lessonId, createdLessonId))
      : [];

    return NextResponse.json({
      compiled,
      createdLessonId,
      createdSteps,
    });
  } catch (error) {
    console.error("[POST /api/konkur/compile] error:", error);
    return NextResponse.json(
      { error: "خطا در اجرای کامپایلر پداگوژیک ایجنت" },
      { status: 500 },
    );
  }
}
