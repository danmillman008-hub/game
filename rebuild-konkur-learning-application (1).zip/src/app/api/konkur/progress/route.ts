import { NextResponse } from "next/server";
import { db } from "@/db";
import { learnerProgress } from "@/db/schema";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const stepId = Number(body.stepId);
    const lessonId = Number(body.lessonId);
    const correctFirstTry = Boolean(body.correctFirstTry ?? true);
    const attempts = Number(body.attempts ?? 1);
    const xpEarned = Number(body.xpEarned ?? (correctFirstTry ? 10 : 5));

    if (!stepId || !lessonId) {
      return NextResponse.json(
        { error: "شناسه گام و درس الزامی است." },
        { status: 400 },
      );
    }

    const [inserted] = await db
      .insert(learnerProgress)
      .values({
        stepId,
        lessonId,
        correctFirstTry,
        attempts,
        xpEarned,
      })
      .returning();

    return NextResponse.json({ progress: inserted });
  } catch (error) {
    console.error("[POST /api/konkur/progress] error:", error);
    return NextResponse.json(
      { error: "خطا در ثبت پیشرفت یادگیرنده" },
      { status: 500 },
    );
  }
}
