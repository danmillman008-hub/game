import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { weeklyStudyPlans } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      dayOfWeek = "شنبه",
      subject = "زیست‌شناسی",
      topic = "",
      linkedNodeSlug = "bio-action-potential",
      studyType = "میمو-درس (LearnHarness) + تست زمان‌دار",
      targetMinutes = 90,
      targetTests = 35,
      advisorNote = "",
    } = body;

    if (!topic.trim()) {
      return NextResponse.json({ error: "عنوان مبحث الزامی است" }, { status: 400 });
    }

    const [created] = await db
      .insert(weeklyStudyPlans)
      .values({
        dayOfWeek,
        subject,
        topic: topic.trim(),
        linkedNodeSlug,
        studyType,
        targetMinutes: Number(targetMinutes) || 90,
        actualMinutes: 0,
        targetTests: Number(targetTests) || 30,
        completedTests: 0,
        correctTests: 0,
        wrongTests: 0,
        satisfaction: "good",
        advisorNote: advisorNote || "اضافه‌شده به برنامه هفتگی Swiss Konkur",
        isCompleted: false,
      })
      .returning();

    return NextResponse.json({ ok: true, plan: created });
  } catch (error) {
    console.error("Error in POST /api/planner:", error);
    return NextResponse.json(
      { error: "خطا در ثبت ردیف برنامه هفتگی" },
      { status: 500 }
    );
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      id,
      isCompleted,
      actualMinutes,
      completedTests,
      correctTests,
      wrongTests,
      satisfaction,
    } = body as {
      id: number;
      isCompleted?: boolean;
      actualMinutes?: number;
      completedTests?: number;
      correctTests?: number;
      wrongTests?: number;
      satisfaction?: string;
    };

    const [existing] = await db
      .select()
      .from(weeklyStudyPlans)
      .where(eq(weeklyStudyPlans.id, id));

    if (!existing) {
      return NextResponse.json({ error: "ردیف برنامه یافت نشد" }, { status: 404 });
    }

    const nextCompleted = isCompleted ?? !existing.isCompleted;
    const [updated] = await db
      .update(weeklyStudyPlans)
      .set({
        isCompleted: nextCompleted,
        actualMinutes:
          actualMinutes !== undefined
            ? actualMinutes
            : nextCompleted && existing.actualMinutes === 0
              ? existing.targetMinutes
              : existing.actualMinutes,
        completedTests:
          completedTests !== undefined
            ? completedTests
            : nextCompleted && existing.completedTests === 0
              ? existing.targetTests
              : existing.completedTests,
        correctTests:
          correctTests !== undefined
            ? correctTests
            : nextCompleted && existing.correctTests === 0
              ? Math.round(existing.targetTests * 0.8)
              : existing.correctTests,
        wrongTests:
          wrongTests !== undefined
            ? wrongTests
            : nextCompleted && existing.wrongTests === 0
              ? Math.round(existing.targetTests * 0.12)
              : existing.wrongTests,
        satisfaction: satisfaction ?? (nextCompleted ? "excellent" : existing.satisfaction),
      })
      .where(eq(weeklyStudyPlans.id, id))
      .returning();

    return NextResponse.json({ ok: true, plan: updated });
  } catch (error) {
    console.error("Error in PATCH /api/planner:", error);
    return NextResponse.json(
      { error: "خطا در به‌روزرسانی گزارش کار" },
      { status: 500 }
    );
  }
}
