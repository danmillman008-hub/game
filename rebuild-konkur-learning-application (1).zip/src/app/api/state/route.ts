import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import {
  lessonProgress,
  mistakeQueue,
  examSessions,
  learnerProfile,
} from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export async function GET() {
  try {
    let profiles = await db
      .select()
      .from(learnerProfile)
      .where(eq(learnerProfile.profileKey, "default"));

    if (profiles.length === 0) {
      const inserted = await db
        .insert(learnerProfile)
        .values({
          profileKey: "default",
          displayName: "داوطلب کنکور تجربی",
          isGuest: false,
          selectionKind: "course",
          programKey: "grade12",
          courseKey: "bio12",
          activeChapterIdx: 0,
          coins: 1272,
          keysLabel: "∞",
          streak: 1,
          xp: 480,
          weeklyXp: 480,
          dailyGoalXp: 50,
          nightMode: false,
          completedNodesJson: JSON.stringify(["bio12:c1:l1"]),
          ledgerJson: JSON.stringify([
            {
              id: "init-1",
              reasonFa: "موجودی اولیهٔ مسیر یادگیری میمو",
              deltaXp: 480,
              deltaCoins: 1272,
              ts: Date.now(),
            },
          ]),
          aiSessionsJson: JSON.stringify([]),
          updatedAt: Date.now(),
        })
        .returning();
      profiles = inserted;
    }

    const progressRows = await db
      .select()
      .from(lessonProgress)
      .orderBy(desc(lessonProgress.completedAt));

    const mistakes = await db
      .select()
      .from(mistakeQueue)
      .orderBy(desc(mistakeQueue.createdAt));

    const exams = await db
      .select()
      .from(examSessions)
      .orderBy(desc(examSessions.createdAt));

    return NextResponse.json({
      ok: true,
      profile: profiles[0],
      lessonProgress: progressRows,
      mistakes,
      exams,
      honest: {
        serverConfirmed: 0,
        llm: false,
        network: false,
        generatedText: false,
        externalProvider: "not-configured",
      },
    });
  } catch (err) {
    return NextResponse.json(
      {
        ok: false,
        error: err instanceof Error ? err.message : "Database error",
      },
      { status: 200 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const action = body?.action;

    if (action === "sync_profile" && body.profile) {
      const p = body.profile;
      const existing = await db
        .select()
        .from(learnerProfile)
        .where(eq(learnerProfile.profileKey, "default"));

      if (existing.length > 0) {
        await db
          .update(learnerProfile)
          .set({
            displayName: p.displayName ?? existing[0].displayName,
            isGuest: p.isGuest ?? existing[0].isGuest,
            selectionKind: p.selectionKind ?? existing[0].selectionKind,
            programKey: p.programKey ?? existing[0].programKey,
            courseKey: p.courseKey ?? existing[0].courseKey,
            activeChapterIdx: p.activeChapterIdx ?? existing[0].activeChapterIdx,
            coins: p.coins ?? existing[0].coins,
            streak: p.streak ?? existing[0].streak,
            xp: p.xp ?? existing[0].xp,
            weeklyXp: p.weeklyXp ?? existing[0].weeklyXp,
            dailyGoalXp: p.dailyGoalXp ?? existing[0].dailyGoalXp,
            nightMode: p.nightMode ?? existing[0].nightMode,
            completedNodesJson:
              typeof p.completedNodes === "object"
                ? JSON.stringify(p.completedNodes)
                : existing[0].completedNodesJson,
            ledgerJson:
              typeof p.ledger === "object"
                ? JSON.stringify(p.ledger)
                : existing[0].ledgerJson,
            aiSessionsJson:
              typeof p.aiSessions === "object"
                ? JSON.stringify(p.aiSessions)
                : existing[0].aiSessionsJson,
            updatedAt: Date.now(),
          })
          .where(eq(learnerProfile.profileKey, "default"));
      }
      return NextResponse.json({ ok: true });
    }

    if (action === "upsert_lesson_progress" && body.row) {
      const r = body.row;
      const existing = await db
        .select()
        .from(lessonProgress)
        .where(eq(lessonProgress.lessonId, Number(r.lessonId)));

      if (existing.length > 0) {
        await db
          .update(lessonProgress)
          .set({
            tries: Number(r.tries),
            attempts: Number(r.attempts),
            completedAt: Number(r.completedAt || Date.now()),
            inQueue: true,
          })
          .where(eq(lessonProgress.lessonId, Number(r.lessonId)));
      } else {
        await db.insert(lessonProgress).values({
          lessonId: Number(r.lessonId),
          lessonIndex: Number(r.lessonIndex || 0),
          chapterId: Number(r.chapterId || 2001),
          tutorialId: Number(r.tutorialId || 1001),
          tutorialVersion: Number(r.tutorialVersion || 1),
          trackId: Number(r.trackId || 1),
          tutorialTitle: String(r.tutorialTitle || ""),
          courseKey: String(r.courseKey || "bio12"),
          tries: Number(r.tries || 0),
          attempts: Number(r.attempts || 1),
          isPracticeProgress: Boolean(r.isPracticeProgress),
          inQueue: true,
          publishSetVersion: 753,
          startedAt: Number(r.startedAt || Date.now()),
          completedAt: Number(r.completedAt || Date.now()),
        });
      }
      return NextResponse.json({ ok: true });
    }

    if (action === "upsert_mistake" && body.mistake) {
      const m = body.mistake;
      const existing = await db
        .select()
        .from(mistakeQueue)
        .where(eq(mistakeQueue.questionKey, String(m.questionKey)));

      if (existing.length > 0) {
        await db
          .update(mistakeQueue)
          .set({
            userChoice: m.userChoice ?? existing[0].userChoice,
            consecutiveCorrect: Number(m.consecutiveCorrect || 0),
            resolved: Boolean(m.resolved),
            createdAt: Date.now(),
          })
          .where(eq(mistakeQueue.questionKey, String(m.questionKey)));
      } else {
        await db.insert(mistakeQueue).values({
          questionKey: String(m.questionKey),
          topicId: String(m.topicId || ""),
          subject: String(m.subject || ""),
          difficulty: String(m.difficulty || "medium"),
          userChoice: m.userChoice !== undefined ? Number(m.userChoice) : null,
          correctIndex: Number(m.correctIndex || 0),
          consecutiveCorrect: Number(m.consecutiveCorrect || 0),
          resolved: Boolean(m.resolved),
          createdAt: Date.now(),
        });
      }
      return NextResponse.json({ ok: true });
    }

    if (action === "save_exam" && body.exam) {
      const ex = body.exam;
      await db.insert(examSessions).values({
        examTitle: String(ex.examTitle || "آزمون"),
        examKind: String(ex.examKind || "comprehensive"),
        status: String(ex.status || "completed_full"),
        questionCount: Number(ex.questionCount || 20),
        correctCount: Number(ex.correctCount || 0),
        wrongCount: Number(ex.wrongCount || 0),
        blankCount: Number(ex.blankCount || 0),
        pctWithNeg: Number(ex.pctWithNeg || 0),
        pctNoNeg: Number(ex.pctNoNeg || 0),
        durationMinutes: Number(ex.durationMinutes || 270),
        remainingSeconds: Number(ex.remainingSeconds || 0),
        currentQuestionIndex: Number(ex.currentQuestionIndex || 0),
        answersJson: JSON.stringify(ex.answers || {}),
        checkedJson: JSON.stringify(ex.checked || {}),
        marksJson: JSON.stringify(ex.marks || {}),
        createdAt: Date.now(),
      });
      return NextResponse.json({ ok: true });
    }

    if (action === "reset_all") {
      await db.delete(lessonProgress);
      await db.delete(mistakeQueue);
      await db.delete(examSessions);
      await db.delete(learnerProfile);
      return NextResponse.json({ ok: true });
    }

    return NextResponse.json({ ok: true });
  } catch (err) {
    return NextResponse.json(
      {
        ok: false,
        error: err instanceof Error ? err.message : "Database error",
      },
      { status: 200 }
    );
  }
}
