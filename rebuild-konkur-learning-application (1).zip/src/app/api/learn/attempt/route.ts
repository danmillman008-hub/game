import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import {
  learnerProfiles,
  knowledgeNodes,
  mimoLessons,
  learningEvidence,
} from "@/db/schema";
import {
  updateBKTMastery,
  updateFSRSState,
  computeKSTStates,
  MASTERY_THRESHOLD,
} from "@/lib/algorithms";
import { eq } from "drizzle-orm";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      nodeSlug,
      lessonSlug,
      phase = "teach",
      stepKind = "check_mcq",
      isCorrect = false,
      confidencePct = 75,
      thinkingTrace = "",
      supportUsed = "unaided",
      detectedTrap = null,
      lessonCompleted = false,
    } = body as {
      nodeSlug: string;
      lessonSlug: string;
      phase?: string;
      stepKind?: string;
      isCorrect: boolean;
      confidencePct?: number;
      thinkingTrace?: string;
      supportUsed?: "unaided" | "hint_1" | "hint_2" | "worked_example";
      detectedTrap?: string | null;
      lessonCompleted?: boolean;
    };

    const [node] = await db
      .select()
      .from(knowledgeNodes)
      .where(eq(knowledgeNodes.slug, nodeSlug));

    const masteryBefore = node?.masteryP ?? 0.3;
    const currentStability = node?.stabilityDays ?? 1.5;
    const currentDifficulty = node?.difficulty ?? 5.2;

    // 1. Calibrated BKT update with Aided/Unaided guard
    // Also apply LearnHarness Upgrade #5: if correct with written reasoning, slightly reward confidence
    const effectiveConfidence =
      thinkingTrace && thinkingTrace.trim().length > 15
        ? Math.min(100, confidencePct + 10)
        : confidencePct;

    const masteryAfter = updateBKTMastery(
      masteryBefore,
      isCorrect,
      supportUsed,
      effectiveConfidence
    );

    // 2. FSRS-5 Spaced Repetition update
    const fsrsNext = updateFSRSState(
      currentStability,
      currentDifficulty,
      isCorrect,
      effectiveConfidence,
      supportUsed,
      0.4
    );

    if (node) {
      await db
        .update(knowledgeNodes)
        .set({
          masteryP: masteryAfter,
          stabilityDays: fsrsNext.stabilityDays,
          difficulty: fsrsNext.difficulty,
          retrievability: fsrsNext.retrievability,
          aidedSuccesses:
            isCorrect && supportUsed !== "unaided"
              ? node.aidedSuccesses + 1
              : node.aidedSuccesses,
          unaidedSuccesses:
            isCorrect && supportUsed === "unaided"
              ? node.unaidedSuccesses + 1
              : node.unaidedSuccesses,
          lapses: !isCorrect ? node.lapses + 1 : node.lapses,
          lastReviewedAt: new Date(),
        })
        .where(eq(knowledgeNodes.id, node.id));
    }

    // 3. Recompute KST states across all nodes so newly unlocked Outer Fringe nodes update
    const allNodes = await db.select().from(knowledgeNodes);
    const kstMap = computeKSTStates(allNodes);
    for (const n of allNodes) {
      const k = kstMap.get(n.slug);
      if (k && k.kstState !== n.kstState) {
        await db
          .update(knowledgeNodes)
          .set({ kstState: k.kstState })
          .where(eq(knowledgeNodes.id, n.id));
      }
    }

    // 4. Append xAPI Evidence Log
    const xapiVerb =
      masteryAfter >= MASTERY_THRESHOLD && masteryBefore < MASTERY_THRESHOLD
        ? "mastered"
        : isCorrect
          ? "passed"
          : "failed";

    await db.insert(learningEvidence).values({
      nodeSlug,
      lessonSlug,
      phase,
      stepKind,
      isCorrect,
      confidencePct,
      thinkingTrace: thinkingTrace.slice(0, 600),
      supportUsed,
      detectedTrap,
      masteryBefore,
      masteryAfter,
      stabilityAfter: fsrsNext.stabilityDays,
      xapiVerb,
    });

    // 5. Update Learner Profile (XP, Level, Hearts, Flow-Band 70-85%)
    const [profile] = await db.select().from(learnerProfiles).limit(1);
    let xpDelta = isCorrect ? (supportUsed === "unaided" ? 20 : 12) : 4;
    if (lessonCompleted) {
      xpDelta += 50;
      const [lesson] = await db
        .select()
        .from(mimoLessons)
        .where(eq(mimoLessons.slug, lessonSlug));
      if (lesson) {
        await db
          .update(mimoLessons)
          .set({ completedCount: lesson.completedCount + 1 })
          .where(eq(mimoLessons.id, lesson.id));
      }
    }

    if (profile) {
      const newXp = profile.xp + xpDelta;
      const newLevel = Math.max(1, Math.floor(newXp / 140) + 1);
      const nextHearts = isCorrect
        ? Math.min(profile.maxHearts, profile.hearts + (lessonCompleted ? 1 : 0))
        : Math.max(1, profile.hearts - 1);
      const nextFlow = Number(
        (profile.flowBandAccuracy * 0.85 + (isCorrect ? 1 : 0) * 0.15).toFixed(2)
      );

      await db
        .update(learnerProfiles)
        .set({
          xp: newXp,
          level: newLevel,
          hearts: nextHearts,
          flowBandAccuracy: nextFlow,
          updatedAt: new Date(),
        })
        .where(eq(learnerProfiles.id, profile.id));
    }

    return NextResponse.json({
      ok: true,
      masteryBefore,
      masteryAfter,
      stabilityDays: fsrsNext.stabilityDays,
      nextDueHours: fsrsNext.nextDueHours,
      xapiVerb,
      xpDelta,
    });
  } catch (error) {
    console.error("Error in POST /api/learn/attempt:", error);
    return NextResponse.json(
      { error: "خطا در ثبت گام یادگیری" },
      { status: 500 }
    );
  }
}
