import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title:
    "میمو کنکور ۹٫۳۵ | پلتفرم جامع یادگیری کنکور (اپ بومی v12.5-fa + کامپایلر پداگوژیک + موتور تطبیقی LearnHarness + هستهٔ DEX)",
  description:
    "تلفیق صفر تا صد ۶ آرشیو و ریپوی گیت‌هاب: اپ بومی میمو ۹٫۳۵ کنکور (v12.5-fa)، کامپایلر پداگوژیک و گاردریل ۹ قانون، موتور تطبیقی BKT/KST/FSRS-5، و بازسازی مهندسی معکوس هستهٔ DEX و Room SQLite",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fa" dir="rtl">
      <body className="antialiased">{children}</body>
    </html>
  );
}
