"use client";

import React, { useState, useEffect } from "react";
import type { MimoBeatStep } from "@/db/schema";
import {
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  HelpCircle,
  ArrowUp,
  ArrowDown,
  Brain,
  Lock,
  Unlock,
  Flame,
  Zap,
  ChevronLeft,
  RotateCcw,
  ShieldAlert,
  GitMerge,
} from "lucide-react";

export interface EnrichedKnowledgeNode {
  id: number;
  slug: string;
  track: string;
  subject: string;
  chapter: string;
  title: string;
  unconditionalTruth: string;
  discoveryMotivation: string;
  commonTrap: string;
  nodeType: string;
  bloomLevel: string;
  dokLevel: number;
  prerequisites: string[];
  masteryP: number;
  stabilityDays: number;
  difficulty: number;
  retrievability: number;
  kstState: "mastered" | "outer_fringe" | "learning" | "locked";
  inInnerFringe?: boolean;
  missingPrereqs?: string[];
  aidedSuccesses: number;
  unaidedSuccesses: number;
  lapses: number;
}

export interface MimoLessonItem {
  id: number;
  slug: string;
  track: string;
  subject: string;
  chapter: string;
  title: string;
  subtitle: string;
  estimatedMinutes: number;
  xpReward: number;
  konkurWeight: string;
  mermaidPlan: string;
  beats: MimoBeatStep[];
  completedCount: number;
}

interface Props {
  nodes: EnrichedKnowledgeNode[];
  lessons: MimoLessonItem[];
  initialLessonSlug?: string | null;
  onRefreshState: () => Promise<void>;
}

export default function MimoLearnPlayer({
  nodes,
  lessons,
  initialLessonSlug,
  onRefreshState,
}: Props) {
  const [trackFilter, setTrackFilter] = useState<string>("all");
  const [selectedLessonSlug, setSelectedLessonSlug] = useState<string>(
    initialLessonSlug || lessons[0]?.slug || ""
  );
  const [beatIndex, setBeatIndex] = useState<number>(0);
  const [showPlanModal, setShowPlanModal] = useState<boolean>(false);
  const [inspectedNodeSlug, setInspectedNodeSlug] = useState<string | null>(
    nodes[1]?.slug || nodes[0]?.slug || null
  );

  // Per-beat interaction states
  const [selectedOption, setSelectedOption] = useState<string>("");
  const [orderingState, setOrderingState] = useState<string[]>([]);
  const [confidencePct, setConfidencePct] = useState<number>(80);
  const [thinkingTrace, setThinkingTrace] = useState<string>("");
  const [hintRung, setHintRung] = useState<number>(0); // 0=unaided, 1=hint_1, 2=hint_2
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [feedback, setFeedback] = useState<{
    checked: boolean;
    isCorrect: boolean;
    trapTriggered?: string | null;
    masteryBefore: number;
    masteryAfter: number;
    stabilityDays: number;
    nextDueHours: number;
    xpDelta: number;
  } | null>(null);
  const [questCompletedBanner, setQuestCompletedBanner] = useState<boolean>(false);

  useEffect(() => {
    if (initialLessonSlug && lessons.some((l) => l.slug === initialLessonSlug)) {
      setSelectedLessonSlug(initialLessonSlug);
      setBeatIndex(0);
      setQuestCompletedBanner(false);
    }
  }, [initialLessonSlug, lessons]);

  const filteredLessons = lessons.filter(
    (l) => trackFilter === "all" || l.track === trackFilter
  );

  const activeLesson =
    lessons.find((l) => l.slug === selectedLessonSlug) ||
    filteredLessons[0] ||
    lessons[0];

  const currentBeat: MimoBeatStep | undefined =
    activeLesson?.beats[beatIndex] ?? activeLesson?.beats[0];

  useEffect(() => {
    if (!currentBeat) return;
    setSelectedOption("");
    setHintRung(0);
    setFeedback(null);
    setConfidencePct(80);
    setThinkingTrace("");
    if (currentBeat.kind === "ordering_chain" && currentBeat.orderingItems) {
      // Create a deterministic swap so the learner actually reorders
      const arr = [...currentBeat.orderingItems];
      if (arr.length >= 3) {
        const tmp = arr[1];
        arr[1] = arr[2];
        arr[2] = tmp;
      }
      setOrderingState(arr);
    } else {
      setOrderingState([]);
    }
    setInspectedNodeSlug(currentBeat.nodeSlug);
  }, [beatIndex, selectedLessonSlug, currentBeat?.id]);

  const inspectedNode =
    nodes.find((n) => n.slug === inspectedNodeSlug) || nodes[0];

  const moveOrderingItem = (index: number, direction: -1 | 1) => {
    if (feedback?.checked) return;
    const target = index + direction;
    if (target < 0 || target >= orderingState.length) return;
    const copy = [...orderingState];
    const temp = copy[index];
    copy[index] = copy[target];
    copy[target] = temp;
    setOrderingState(copy);
  };

  const handleCheckAnswer = async () => {
    if (!currentBeat || !activeLesson) return;

    let isCorrect = false;
    let trapTriggered: string | null = null;

    if (currentBeat.kind === "ordering_chain") {
      const joined = orderingState.join("|");
      isCorrect = joined === currentBeat.correctAnswer;
    } else if (currentBeat.kind === "fill_blank") {
      isCorrect = selectedOption === currentBeat.correctAnswer;
    } else {
      isCorrect = selectedOption === currentBeat.correctAnswer;
      const chosenObj = currentBeat.options?.find((o) => o.id === selectedOption);
      if (!isCorrect && chosenObj?.isTrap) {
        trapTriggered = chosenObj.trapReason || "شکار شده در گزینه دام طراح کنکور!";
      }
    }

    const supportUsed: "unaided" | "hint_1" | "hint_2" =
      hintRung === 0 ? "unaided" : hintRung === 1 ? "hint_1" : "hint_2";

    const isLastBeat = beatIndex === activeLesson.beats.length - 1;

    setSubmitting(true);
    try {
      const res = await fetch("/api/learn/attempt", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          nodeSlug: currentBeat.nodeSlug,
          lessonSlug: activeLesson.slug,
          phase: currentBeat.phase,
          stepKind: currentBeat.kind,
          isCorrect,
          confidencePct,
          thinkingTrace,
          supportUsed,
          detectedTrap: trapTriggered,
          lessonCompleted: isCorrect && isLastBeat,
        }),
      });
      const data = await res.json();
      setFeedback({
        checked: true,
        isCorrect,
        trapTriggered,
        masteryBefore: data.masteryBefore ?? 0.3,
        masteryAfter: data.masteryAfter ?? 0.45,
        stabilityDays: data.stabilityDays ?? 2.0,
        nextDueHours: data.nextDueHours ?? 48,
        xpDelta: data.xpDelta ?? 15,
      });
      await onRefreshState();
    } finally {
      setSubmitting(false);
    }
  };

  const handleNextBeat = () => {
    if (!activeLesson) return;
    if (beatIndex < activeLesson.beats.length - 1) {
      setBeatIndex(beatIndex + 1);
    } else {
      setQuestCompletedBanner(true);
    }
  };

  const handleRetryBeat = () => {
    setFeedback(null);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      {/* RIGHT COLUMN (in RTL): Quest Selector & KST Dependency Graph */}
      <div className="lg:col-span-4 space-y-5">
        {/* Track Filter + Lesson List */}
        <div className="bg-white border-2 border-[#1A1C1A] rounded-2xl p-4 shadow-[3px_3px_0px_#1A1C1A]">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-extrabold text-[#1A1C1A] flex items-center gap-1.5">
              <Zap className="w-4 h-4 text-[#059669]" />
              <span>کوئست‌های میمو × لرن‌هارنس</span>
            </h2>
            <select
              value={trackFilter}
              onChange={(e) => setTrackFilter(e.target.value)}
              className="text-xs font-bold bg-[#FAF9F5] border border-[#1A1C1A] rounded-lg px-2.5 py-1 text-[#1A1C1A]"
            >
              <option value="all">همه رشته‌ها</option>
              <option value="tajrobi">علوم تجربی</option>
              <option value="riazi">ریاضی و فیزیک</option>
              <option value="ensani">علوم انسانی</option>
            </select>
          </div>

          <div className="space-y-2.5">
            {filteredLessons.map((lesson) => {
              const isSelected = lesson.slug === activeLesson?.slug;
              return (
                <button
                  key={lesson.slug}
                  onClick={() => {
                    setSelectedLessonSlug(lesson.slug);
                    setBeatIndex(0);
                    setQuestCompletedBanner(false);
                  }}
                  className={`w-full text-right p-3 rounded-xl border-2 transition cursor-pointer ${
                    isSelected
                      ? "bg-[#001551] text-white border-[#1A1C1A] shadow-[2px_2px_0px_#1A1C1A]"
                      : "bg-[#FAF9F5] hover:bg-[#F4F4F0] text-[#1A1C1A] border-[#C7C6CB]"
                  }`}
                >
                  <div className="flex items-center justify-between text-[11px] mb-1">
                    <span
                      className={`px-2 py-0.5 rounded font-bold ${
                        isSelected
                          ? "bg-white/20 text-white"
                          : "bg-[#1A1C1A]/10 text-[#1A1C1A]"
                      }`}
                    >
                      {lesson.subject}
                    </span>
                    <span className="font-mono">
                      +{lesson.xpReward} XP • {lesson.beats.length} گام
                    </span>
                  </div>
                  <div className="text-xs sm:text-sm font-extrabold leading-snug">
                    {lesson.title}
                  </div>
                  <div
                    className={`text-[11px] mt-1 ${
                      isSelected ? "text-blue-200" : "text-[#46464B]"
                    }`}
                  >
                    اهمیت کنکور: {lesson.konkurWeight}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Live Knowledge Space Theory (KST) Outer Fringe Map */}
        <div className="bg-white border-2 border-[#1A1C1A] rounded-2xl p-4 shadow-[3px_3px_0px_#1A1C1A]">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-extrabold text-[#1A1C1A] flex items-center gap-1.5">
              <GitMerge className="w-4 h-4 text-[#001551]" />
              <span>گراف فضای دانش (KST Outer Fringe)</span>
            </h3>
            <span className="text-[10px] font-mono bg-[#F4F4F0] px-2 py-0.5 rounded border border-[#C7C6CB]">
              Gramophone + LearnHarness
            </span>
          </div>
          <p className="text-[11px] text-[#46464B] mb-3 leading-relaxed">
            گره‌های <strong>آبی (لبه بیرونی / Outer Fringe)</strong> تمام پیشنیازهایشان پاس شده و در منطقه طلایی یادگیری شما هستند:
          </p>

          <div className="space-y-2 max-h-[380px] overflow-y-auto pr-1">
            {nodes.map((node) => {
              const isInspected = node.slug === inspectedNode?.slug;
              const badge =
                node.kstState === "mastered"
                  ? {
                      text: "تسلط کامل (Mastered)",
                      cls: "bg-emerald-100 text-emerald-900 border-emerald-600",
                      icon: <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700" />,
                    }
                  : node.kstState === "outer_fringe"
                    ? {
                        text: "لبه بیرونی (آماده یادگیری)",
                        cls: "bg-blue-100 text-[#001551] border-[#001551]",
                        icon: <Unlock className="w-3.5 h-3.5 text-[#001551]" />,
                      }
                    : node.kstState === "learning"
                      ? {
                          text: "در حال یادگیری",
                          cls: "bg-amber-100 text-amber-900 border-amber-600",
                          icon: <Flame className="w-3.5 h-3.5 text-amber-700" />,
                        }
                      : {
                          text: "قفل (نقص پیشنیاز)",
                          cls: "bg-slate-200 text-slate-700 border-slate-400",
                          icon: <Lock className="w-3.5 h-3.5 text-slate-600" />,
                        };

              return (
                <button
                  key={node.slug}
                  onClick={() => setInspectedNodeSlug(node.slug)}
                  className={`w-full text-right p-2.5 rounded-xl border transition cursor-pointer ${
                    isInspected
                      ? "bg-[#FAF9F5] border-2 border-[#1A1C1A]"
                      : "bg-white hover:bg-[#FAF9F5] border-[#E2E3DF]"
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[11px] font-bold text-[#46464B]">
                      {node.subject}
                    </span>
                    <span
                      className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold border ${badge.cls}`}
                    >
                      {badge.icon}
                      <span>{badge.text}</span>
                    </span>
                  </div>
                  <div className="text-xs font-extrabold text-[#1A1C1A] mt-1">
                    {node.title}
                  </div>
                  <div className="flex items-center justify-between text-[11px] font-mono text-[#46464B] mt-1.5">
                    <span>BKT: {Math.round(node.masteryP * 100)}%</span>
                    <span>FSRS S: {node.stabilityDays}d</span>
                    <span>Unaided: {node.unaidedSuccesses}</span>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Inspected Node Deep-Dive Card */}
          {inspectedNode && (
            <div className="mt-3 pt-3 border-t-2 border-[#1A1C1A] bg-[#FAF9F5] rounded-xl p-3 text-xs space-y-2">
              <div className="font-extrabold text-[#001551]">
                کالبدشکافی گزاره: {inspectedNode.title}
              </div>
              <div>
                <span className="font-bold text-[#059669]">اصل بدیهی اول (Principle i): </span>
                <span className="text-[#1A1C1A]">{inspectedNode.unconditionalTruth}</span>
              </div>
              <div>
                <span className="font-bold text-[#BC000A]">دام طراح کنکور: </span>
                <span className="text-[#1A1C1A]">{inspectedNode.commonTrap}</span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* LEFT COLUMN (in RTL): Active Mimo × LearnHarness Interactive Step Player */}
      <div className="lg:col-span-8 space-y-5">
        {activeLesson && currentBeat ? (
          <div className="bg-white border-2 border-[#1A1C1A] rounded-2xl p-5 sm:p-6 shadow-[4px_4px_0px_#1A1C1A]">
            {/* Mimo Top Progress Bar & Phase Indicator */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-[#E2E3DF]">
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-extrabold bg-[#001551] text-white">
                    {activeLesson.subject}
                  </span>
                  <span className="text-xs font-mono bg-[#F4F4F0] px-2.5 py-0.5 rounded border border-[#C7C6CB]">
                    {currentBeat.principleBadge}
                  </span>
                </div>
                <h2 className="text-lg sm:text-xl font-extrabold text-[#1A1C1A] mt-1.5">
                  {activeLesson.title}
                </h2>
              </div>

              <button
                onClick={() => setShowPlanModal(!showPlanModal)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#FAF9F5] hover:bg-[#E8E8E4] border border-[#1A1C1A] text-xs font-bold cursor-pointer self-start"
              >
                <GitMerge className="w-3.5 h-3.5 text-[#001551]" />
                <span>{showPlanModal ? "بستن نقشه درختی" : "مشاهده نقشه درختی (plan_init)"}</span>
              </button>
            </div>

            {/* LearnHarness 4-Phase Ribbon + Mimo Step Progress */}
            <div className="mt-4">
              <div className="grid grid-cols-4 gap-2 text-center text-[11px] font-bold mb-2">
                {[
                  { key: "probe", label: "۱. سنجش لبه دانش (Probe)" },
                  { key: "plan", label: "۲. نقشه درختی (Plan)" },
                  { key: "teach", label: "۳. تدریس اصولی (Teach)" },
                  { key: "practice", label: "۴. بازیابی فعال (Practice)" },
                ].map((ph) => {
                  const isActive =
                    currentBeat.phase === ph.key ||
                    (ph.key === "plan" && showPlanModal);
                  return (
                    <div
                      key={ph.key}
                      className={`py-1.5 px-2 rounded-lg border ${
                        isActive
                          ? "bg-[#1A1C1A] text-white border-[#1A1C1A]"
                          : "bg-[#FAF9F5] text-[#46464B] border-[#C7C6CB]"
                      }`}
                    >
                      {ph.label}
                    </div>
                  );
                })}
              </div>

              {/* Mimo Step Segmented Bar */}
              <div className="flex items-center gap-2 mt-3">
                {activeLesson.beats.map((b, idx) => (
                  <button
                    key={b.id}
                    onClick={() => {
                      setBeatIndex(idx);
                      setQuestCompletedBanner(false);
                    }}
                    className={`h-2.5 flex-1 rounded-full transition-all cursor-pointer ${
                      idx < beatIndex
                        ? "bg-[#059669]"
                        : idx === beatIndex
                          ? "bg-[#001551]"
                          : "bg-[#E2E3DF]"
                    }`}
                    title={b.title}
                  />
                ))}
                <span className="text-xs font-mono font-bold text-[#1A1C1A] mr-1">
                  {beatIndex + 1} / {activeLesson.beats.length}
                </span>
              </div>
            </div>

            {/* Optional Mermaid Plan Tree Drawer */}
            {showPlanModal && (
              <div className="mt-4 bg-[#1A1C1A] text-white rounded-xl p-4">
                <div className="text-xs font-bold text-amber-300 mb-2">
                  نقشه درختی وابستگی این درس در LearnHarness (`plan_init` Mermaid DAG):
                </div>
                <pre
                  dir="ltr"
                  className="text-xs font-mono text-emerald-300 whitespace-pre-wrap leading-relaxed"
                >
                  {activeLesson.mermaidPlan}
                </pre>
              </div>
            )}

            {/* Quest Completed Celebration Card */}
            {questCompletedBanner ? (
              <div className="mt-6 bg-emerald-50 border-2 border-[#059669] rounded-2xl p-6 text-center space-y-4">
                <CheckCircle2 className="w-12 h-12 text-[#059669] mx-auto" />
                <h3 className="text-xl font-extrabold text-[#1A1C1A]">
                  تبریک! کوئست «{activeLesson.title}» با موفقیت کامل شد!
                </h3>
                <p className="text-sm text-[#46464B] max-w-xl mx-auto leading-relaxed">
                  تمام تلاش‌های شما در جدول <code className="font-mono">learning_evidence</code> ثبت شد، ضریب تسلط BKT و پایداری حافظه FSRS به‌روزرسانی گردید و لبه بیرونی گراف دانش (KST Outer Fringe) بازمحاسبه شد.
                </p>
                <div className="flex justify-center gap-3">
                  <button
                    onClick={() => {
                      setBeatIndex(0);
                      setQuestCompletedBanner(false);
                    }}
                    className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#1A1C1A] text-white text-xs sm:text-sm font-bold cursor-pointer"
                  >
                    <RotateCcw className="w-4 h-4" />
                    <span>مرور مجدد این کوئست</span>
                  </button>
                </div>
              </div>
            ) : (
              /* Active Mimo Beat Card */
              <div className="mt-5 space-y-5">
                <div className="bg-[#FAF9F5] border-2 border-[#1A1C1A] rounded-2xl p-4 sm:p-5">
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span className="text-xs font-extrabold text-[#001551]">
                      {currentBeat.title}
                    </span>
                    <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-white border border-[#C7C6CB]">
                      DOK Level {currentBeat.dokLevel}
                    </span>
                  </div>

                  {/* Lesson Bite Text */}
                  <div className="text-sm text-[#1A1C1A] leading-relaxed whitespace-pre-line">
                    {currentBeat.contentMarkdown}
                  </div>

                  {currentBeat.formulaLatex && (
                    <div
                      dir="ltr"
                      className="mt-3 bg-[#1A1C1A] text-emerald-300 font-mono text-xs sm:text-sm px-4 py-2.5 rounded-xl overflow-x-auto"
                    >
                      {currentBeat.formulaLatex}
                    </div>
                  )}
                </div>

                {/* Question Prompt */}
                <div className="space-y-3">
                  <div className="text-sm sm:text-base font-extrabold text-[#1A1C1A] flex items-start gap-2">
                    <Brain className="w-5 h-5 text-[#BC000A] shrink-0 mt-0.5" />
                    <span>{currentBeat.promptQuestion}</span>
                  </div>

                  {/* KIND 1: FILL IN THE BLANK (Mimo Chip Style) */}
                  {currentBeat.kind === "fill_blank" && (
                    <div className="space-y-3">
                      <div className="bg-[#F4F4F0] border-2 border-dashed border-[#1A1C1A] rounded-xl p-4 text-sm font-bold text-[#1A1C1A] leading-relaxed">
                        {currentBeat.fillTemplate?.split("___").map((part, idx, arr) => (
                          <React.Fragment key={idx}>
                            <span>{part}</span>
                            {idx < arr.length - 1 && (
                              <span className="inline-block mx-1.5 px-3 py-1 rounded-lg bg-[#001551] text-white font-extrabold">
                                {selectedOption || "؟ (یکی از تگ‌های زیر را انتخاب کنید)"}
                              </span>
                            )}
                          </React.Fragment>
                        ))}
                      </div>

                      <div className="flex flex-wrap gap-2">
                        {(currentBeat.fillChoices || []).map((choice) => (
                          <button
                            key={choice}
                            disabled={feedback?.checked}
                            onClick={() => setSelectedOption(choice)}
                            className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold border-2 transition cursor-pointer ${
                              selectedOption === choice
                                ? "bg-[#1A1C1A] text-white border-[#1A1C1A]"
                                : "bg-white hover:bg-[#FAF9F5] text-[#1A1C1A] border-[#C7C6CB]"
                            }`}
                          >
                            {choice}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* KIND 2: ORDERING CHAIN (Principle ii Discovery Sequence) */}
                  {currentBeat.kind === "ordering_chain" && (
                    <div className="space-y-2">
                      <p className="text-xs text-[#46464B]">
                        با دکمه‌های بالا و پایین، زنجیره استدلال علمی را به ترتیب درست مرتب کنید:
                      </p>
                      {orderingState.map((item, idx) => (
                        <div
                          key={item}
                          className="flex items-center justify-between gap-3 bg-white border-2 border-[#1A1C1A] rounded-xl p-3"
                        >
                          <span className="text-xs sm:text-sm font-bold text-[#1A1C1A]">
                            {item}
                          </span>
                          <div className="flex items-center gap-1 shrink-0">
                            <button
                              type="button"
                              disabled={idx === 0 || feedback?.checked}
                              onClick={() => moveOrderingItem(idx, -1)}
                              className="p-1.5 rounded-lg bg-[#FAF9F5] hover:bg-[#E8E8E4] border border-[#C7C6CB] disabled:opacity-40 cursor-pointer"
                            >
                              <ArrowUp className="w-4 h-4" />
                            </button>
                            <button
                              type="button"
                              disabled={
                                idx === orderingState.length - 1 || feedback?.checked
                              }
                              onClick={() => moveOrderingItem(idx, 1)}
                              className="p-1.5 rounded-lg bg-[#FAF9F5] hover:bg-[#E8E8E4] border border-[#C7C6CB] disabled:opacity-40 cursor-pointer"
                            >
                              <ArrowDown className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* KIND 3: MULTIPLE CHOICE (Probe / Check / Practice) */}
                  {currentBeat.options && currentBeat.options.length > 0 && (
                    <div className="space-y-2.5">
                      {currentBeat.options.map((opt, idx) => {
                        const isChosen = selectedOption === opt.id;
                        const isRightOpt = opt.id === currentBeat.correctAnswer;
                        let cardStyle =
                          "bg-white hover:bg-[#FAF9F5] text-[#1A1C1A] border-[#C7C6CB]";
                        if (feedback?.checked) {
                          if (isRightOpt) {
                            cardStyle =
                              "bg-emerald-50 text-emerald-950 border-[#059669]";
                          } else if (isChosen && !isRightOpt) {
                            cardStyle = "bg-rose-50 text-rose-950 border-[#BC000A]";
                          }
                        } else if (isChosen) {
                          cardStyle =
                            "bg-[#001551] text-white border-[#1A1C1A] shadow-[2px_2px_0px_#1A1C1A]";
                        }

                        return (
                          <button
                            key={opt.id}
                            type="button"
                            disabled={feedback?.checked}
                            onClick={() => setSelectedOption(opt.id)}
                            className={`w-full text-right p-3.5 rounded-xl border-2 transition flex items-start gap-3 cursor-pointer ${cardStyle}`}
                          >
                            <span
                              className={`w-6 h-6 rounded-lg font-mono text-xs font-bold flex items-center justify-center shrink-0 mt-0.5 ${
                                isChosen && !feedback?.checked
                                  ? "bg-white text-[#001551]"
                                  : "bg-[#F4F4F0] text-[#1A1C1A]"
                              }`}
                            >
                              {idx + 1}
                            </span>
                            <span className="text-xs sm:text-sm font-bold leading-relaxed">
                              {opt.label}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>

                {/* LearnHarness Confidence Calibration + Think-Out-Loud Box + Hint Ladder */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-3 border-t border-[#E2E3DF]">
                  <div className="bg-[#FAF9F5] border border-[#C7C6CB] rounded-xl p-3">
                    <div className="flex items-center justify-between text-xs font-bold mb-1.5">
                      <span className="text-[#1A1C1A]">
                        ضریب اطمینان شما (LearnHarness Confidence):
                      </span>
                      <span className="font-mono text-[#001551]">{confidencePct}%</span>
                    </div>
                    <input
                      type="range"
                      min={20}
                      max={100}
                      step={5}
                      disabled={feedback?.checked}
                      value={confidencePct}
                      onChange={(e) => setConfidencePct(Number(e.target.value))}
                      className="w-full accent-[#001551] cursor-pointer"
                    />
                    <div className="flex justify-between text-[10px] text-[#46464B] mt-1">
                      <span>۲۰٪ (حدس / شک‌دار)</span>
                      <span>۶۰٪ (مطمئن نسبی)</span>
                      <span>۱۰۰٪ (یقین کامل)</span>
                    </div>
                  </div>

                  <div className="bg-[#FAF9F5] border border-[#C7C6CB] rounded-xl p-3">
                    <label className="block text-xs font-bold text-[#1A1C1A] mb-1">
                      فیلد «بلند فکر کن» (Think Out Loud — استدلال شما):
                    </label>
                    <input
                      type="text"
                      disabled={feedback?.checked}
                      value={thinkingTrace}
                      onChange={(e) => setThinkingTrace(e.target.value)}
                      placeholder="چرا این گزینه را انتخاب کردید؟ (مثلاً: چون کانال ATP مصرف نمی‌کند...)"
                      className="w-full bg-white border border-[#C7C6CB] rounded-lg px-2.5 py-1.5 text-xs text-[#1A1C1A]"
                    />
                  </div>
                </div>

                {/* Progressive Hint Ladder */}
                {currentBeat.hints && currentBeat.hints.length > 0 && (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <button
                        type="button"
                        disabled={hintRung >= currentBeat.hints.length || feedback?.checked}
                        onClick={() => setHintRung((r) => Math.min(currentBeat.hints.length, r + 1))}
                        className="inline-flex items-center gap-1.5 text-xs font-bold text-[#001551] hover:underline disabled:opacity-40 cursor-pointer"
                      >
                        <HelpCircle className="w-4 h-4" />
                        <span>
                          درخواست پله بعدی نردبان راهنمایی ({hintRung}/
                          {currentBeat.hints.length}) — ثبت به عنوان تلاش Aided
                        </span>
                      </button>

                      <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-[#F4F4F0] text-[#46464B]">
                        حالت فعلی:{" "}
                        {hintRung === 0
                          ? "Unaided (مستقل — پاداش کامل BKT)"
                          : `Aided (راهنمایی پله ${hintRung})`}
                      </span>
                    </div>

                    {hintRung > 0 && (
                      <div className="bg-amber-50 border border-amber-500 rounded-xl p-3 space-y-1">
                        {currentBeat.hints.slice(0, hintRung).map((h, i) => (
                          <div key={i} className="text-xs text-amber-950 font-medium">
                            💡 {h}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                {/* Instant Mimo Feedback & Trap Remediation Drawer */}
                {feedback?.checked && (
                  <div
                    className={`rounded-2xl p-4 border-2 space-y-2.5 ${
                      feedback.isCorrect
                        ? "bg-emerald-50 border-[#059669]"
                        : "bg-rose-50 border-[#BC000A]"
                    }`}
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        {feedback.isCorrect ? (
                          <CheckCircle2 className="w-5 h-5 text-[#059669]" />
                        ) : (
                          <AlertTriangle className="w-5 h-5 text-[#BC000A]" />
                        )}
                        <span className="text-sm font-extrabold text-[#1A1C1A]">
                          {feedback.isCorrect
                            ? `آفرین! پاسخ کاملاً منطبق با اصل علمی است (+${feedback.xpDelta} XP)`
                            : "پاسخ نادرست — کالبدشکافی دام طراح کنکور را ببینید:"}
                        </span>
                      </div>

                      <div className="flex flex-wrap items-center gap-2 text-xs font-mono">
                        <span className="px-2.5 py-0.5 rounded bg-white border border-[#C7C6CB]">
                          BKT: {Math.round(feedback.masteryBefore * 100)}% →{" "}
                          <strong>{Math.round(feedback.masteryAfter * 100)}%</strong>
                        </span>
                        <span className="px-2.5 py-0.5 rounded bg-white border border-[#C7C6CB]">
                          FSRS S: {feedback.stabilityDays}d (مرور بعدی: {feedback.nextDueHours}h)
                        </span>
                      </div>
                    </div>

                    {feedback.trapTriggered && (
                      <div className="bg-white border border-[#BC000A] rounded-xl p-3 text-xs text-[#BC000A] flex items-start gap-2">
                        <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5" />
                        <div>
                          <strong>رادار دام طراح کنکور: </strong>
                          {feedback.trapTriggered}
                        </div>
                      </div>
                    )}

                    <div className="text-xs text-[#1A1C1A] leading-relaxed bg-white/80 rounded-xl p-3 border border-[#C7C6CB]">
                      <strong>پاسخ تشریحی متعهدشده (Committed Model Solution): </strong>
                      {currentBeat.modelSolution}
                    </div>
                  </div>
                )}

                {/* Bottom Action Bar */}
                <div className="flex items-center justify-between pt-2">
                  <div className="text-xs text-[#46464B]">
                    گام {beatIndex + 1} از {activeLesson.beats.length}
                  </div>

                  {!feedback?.checked ? (
                    <button
                      type="button"
                      disabled={
                        submitting ||
                        (currentBeat.kind !== "ordering_chain" && !selectedOption)
                      }
                      onClick={handleCheckAnswer}
                      className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-[#059669] hover:bg-[#047857] disabled:opacity-40 text-white text-xs sm:text-sm font-extrabold transition cursor-pointer shadow-[2px_2px_0px_#1A1C1A]"
                    >
                      <Sparkles className="w-4 h-4" />
                      <span>
                        {submitting
                          ? "در حال ثبت در موتور BKT + FSRS..."
                          : "بررسی پاسخ و ثبت در گراف دانش"}
                      </span>
                    </button>
                  ) : (
                    <div className="flex items-center gap-2.5">
                      {!feedback.isCorrect && (
                        <button
                          type="button"
                          onClick={handleRetryBeat}
                          className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-white hover:bg-[#FAF9F5] border-2 border-[#1A1C1A] text-xs font-extrabold cursor-pointer"
                        >
                          <RotateCcw className="w-4 h-4" />
                          <span>تلاش مجدد روی این گام</span>
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={handleNextBeat}
                        className="inline-flex items-center gap-1.5 px-6 py-3 rounded-xl bg-[#1A1C1A] hover:bg-[#001551] text-white text-xs sm:text-sm font-extrabold cursor-pointer shadow-[2px_2px_0px_#059669]"
                      >
                        <span>
                          {beatIndex < activeLesson.beats.length - 1
                            ? "ادامه به گام بعدی میمو"
                            : "تکمیل کوئست و دریافت پاداش"}
                        </span>
                        <ChevronLeft className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        ) : null}
      </div>
    </div>
  );
}
