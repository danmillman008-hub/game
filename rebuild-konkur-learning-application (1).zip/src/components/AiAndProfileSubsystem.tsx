"use client";

import React, { useState } from "react";
import { MimoIcon } from "./MimoIcon";
import {
  KONKUR_QUESTIONS,
  MIMO_TUTORIALS,
  DESIGN_TOKEN_LIST,
  ECONOMY_RULES_LIST,
  LessonProgressRow,
  MistakeItem,
  faNum,
} from "@/lib/mimo-engine";
import { CompletedExamResult } from "./ExamSubsystem";

export interface ChatMessage {
  id: string;
  sender: "user" | "bot" | "ctx";
  text: string;
  html?: string;
  sourceRef?: string;
}

export interface LedgerEntry {
  id: string;
  reasonFa: string;
  deltaXp: number;
  deltaCoins: number;
  ts: number;
}

export interface AiAndProfileProps {
  screen:
    | "ai"
    | "native-studio"
    | "leaderboard"
    | "user-profile"
    | "profile"
    | "native-tokens"
    | "native-output";
  nightMode: boolean;
  displayName: string;
  activeCourseName: string;
  courseCompletionPct: number;
  coins: number;
  streak: number;
  xp: number;
  weeklyXp: number;
  dailyGoalXp: number;
  lessonProgress: LessonProgressRow[];
  mistakes: MistakeItem[];
  examHistory: CompletedExamResult[];
  ledger: LedgerEntry[];
  aiContextBanner: string | null;
  chatMessages: ChatMessage[];
  onSendChatMessage: (text: string, mode: "TEACH" | "PRACTICE") => void;
  onClearChat: () => void;
  onNavigate: (target: string) => void;
  onOpenLessonByTopic: (topic: string) => void;
  onToggleNightMode: () => void;
  onClaimDailyGoal: () => void;
  onOpenPlaygroundSheet: () => void;
  onResetAllData: () => void;
  onToast: (msg: string) => void;
}

export function AiAndProfileSubsystem({
  screen,
  nightMode,
  displayName,
  activeCourseName,
  courseCompletionPct,
  coins,
  streak,
  xp,
  weeklyXp,
  dailyGoalXp,
  lessonProgress,
  mistakes,
  examHistory,
  ledger,
  aiContextBanner,
  chatMessages,
  onSendChatMessage,
  onClearChat,
  onNavigate,
  onOpenLessonByTopic,
  onToggleNightMode,
  onClaimDailyGoal,
  onOpenPlaygroundSheet,
  onResetAllData,
  onToast,
}: AiAndProfileProps) {
  // Chat local state
  const [chatInput, setChatInput] = useState("");
  const [chatMode, setChatMode] = useState<"TEACH" | "PRACTICE">("TEACH");
  const [showHistorySheet, setShowHistorySheet] = useState(false);

  // Studio 4-phase local state (measure -> plan -> teach -> practice)
  const [studioPhase, setStudioPhase] = useState<
    "measure" | "plan" | "teach" | "practice"
  >("measure");
  const [measureAnswers, setMeasureAnswers] = useState<Record<number, number>>(
    {}
  );
  const [studioTeachIdx, setStudioTeachIdx] = useState(0);
  const [studioPracticePick, setStudioPracticePick] = useState<number | null>(
    null
  );

  // Tokens explorer tab state
  const [tokenTab, setTokenTab] = useState<"design" | "economy" | "ai">(
    "design"
  );

  const diagnosticQuestions = KONKUR_QUESTIONS.slice(0, 5);
  const contextUnits =
    lessonProgress.length * 8 +
    Object.keys(measureAnswers).length * 6 +
    chatMessages.length * 4 +
    24;

  const triggerDownloadText = (
    filename: string,
    content: string,
    mime = "application/json"
  ) => {
    try {
      const blob = new Blob([content], { type: `${mime};charset=utf-8` });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      onToast(`فایل «${filename}» با موفقیت دانلود شد`);
    } catch {
      onToast("دانلود فایل در این مرورگر مسدود شد");
    }
  };

  // ==========================================================================
  // SCREEN 1: AI CHAT (Local Content-Driven Tutor + Context Receiver)
  // ==========================================================================
  if (screen === "ai") {
    return (
      <div className="flex flex-col h-full w-full relative" dir="rtl">
        {/* Appbar */}
        <div
          className="flex items-center justify-between px-4 shrink-0 border-b"
          style={{
            height: "var(--toolbar)",
            background: "var(--card)",
            borderColor: "var(--line)",
          }}
        >
          <div className="flex items-center gap-2.5">
            <div
              className="w-9 h-9 rounded-xl flex items-center justify-center"
              style={{ background: "var(--progress-weak)" }}
            >
              <MimoIcon name="ic_ai_tutor" size={22} />
            </div>
            <div>
              <b className="text-base block leading-tight">دستیار هوشمند محلی</b>
              <span className="text-[11px]" style={{ color: "var(--text-weak)" }}>
                موتور محتوای محلی · بدون LLM و بدون اینترنت
              </span>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => onNavigate("native-studio")}
              className="px-3 py-1.5 rounded-full text-xs font-bold border cursor-pointer"
              style={{
                background: "var(--primary)",
                borderColor: "var(--primary)",
                color: "#FFFFFF",
              }}
            >
              ✦ استودیو ۴فازی
            </button>
            <button
              type="button"
              onClick={() => setShowHistorySheet(true)}
              aria-label="تاریخچه"
              className="w-9 h-9 rounded-xl border flex items-center justify-center cursor-pointer"
              style={{
                background: "var(--card-pressed)",
                borderColor: "var(--line)",
              }}
            >
              <MimoIcon name="ic_clock_black_24dp" size={18} mono />
            </button>
          </div>
        </div>

        {/* Sub-toolbar with quick topic chips & 0.00 cost indicator */}
        <div
          className="px-3.5 py-2 border-b flex items-center justify-between gap-2 overflow-x-auto"
          style={{
            background: "var(--card-pressed)",
            borderColor: "var(--line)",
          }}
        >
          <div className="flex items-center gap-1.5 shrink-0">
            {["سم‌ها", "مشتق", "تعادل شیمیایی", "ترمودینامیک", "فتوسنتز", "مدار موازی"].map(
              (kw) => (
                <button
                  key={kw}
                  type="button"
                  onClick={() => onSendChatMessage(kw, chatMode)}
                  className="px-2.5 py-1 rounded-full text-[11px] font-bold border cursor-pointer"
                  style={{
                    background: "var(--card)",
                    borderColor: "var(--line)",
                    color: "var(--text)",
                  }}
                >
                  {kw}
                </button>
              )
            )}
          </div>
          <span
            className="text-[11px] font-bold shrink-0 px-2 py-0.5 rounded"
            style={{
              background: "var(--progress-weak)",
              color: "var(--primary)",
            }}
          >
            ۰٫۰۰ دلار · آفلاین
          </span>
        </div>

        {/* Context Banner if transferred from Lesson or Exam */}
        {aiContextBanner && (
          <div
            className="mx-3.5 mt-2.5 p-2.5 rounded-xl border text-xs flex items-center justify-between gap-2"
            style={{
              background: "var(--progress-weak)",
              borderColor: "var(--primary)",
              color: "var(--text)",
            }}
          >
            <span className="truncate font-medium">{aiContextBanner}</span>
            <span
              className="text-[10px] font-bold px-2 py-0.5 rounded-full shrink-0"
              style={{ background: "var(--primary)", color: "#FFFFFF" }}
            >
              زمینهٔ فعال
            </span>
          </div>
        )}

        {/* Chat Thread */}
        <div className="flex-1 overflow-y-auto mimo-scroll p-3.5 space-y-2.5">
          {chatMessages.map((msg) => (
            <div
              key={msg.id}
              className={`max-w-[88%] p-3 rounded-2xl text-xs leading-relaxed ${
                msg.sender === "user" ? "mr-auto" : "ml-auto border"
              }`}
              style={{
                background:
                  msg.sender === "user"
                    ? "var(--primary)"
                    : msg.sender === "ctx"
                    ? "var(--progress-weak)"
                    : "var(--card)",
                color: msg.sender === "user" ? "#FFFFFF" : "var(--text)",
                borderColor:
                  msg.sender === "ctx" ? "var(--primary)" : "var(--line)",
              }}
            >
              {msg.html ? (
                <div dangerouslySetInnerHTML={{ __html: msg.html }} />
              ) : (
                <p>{msg.text}</p>
              )}
              {msg.sourceRef && (
                <div
                  className="mt-1.5 pt-1.5 border-t text-[10.5px] opacity-80 flex items-center justify-between"
                  style={{ borderColor: "var(--line)" }}
                >
                  <span>منبع: {msg.sourceRef} · بدون تولید متن</span>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Composer */}
        <div
          className="p-3 border-t space-y-2"
          style={{
            background: "var(--card)",
            borderColor: "var(--line)",
          }}
        >
          <div className="flex items-center gap-2">
            <input
              type="text"
              value={chatInput}
              onChange={(e) => setChatInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && chatInput.trim()) {
                  onSendChatMessage(chatInput.trim(), chatMode);
                  setChatInput("");
                }
              }}
              placeholder="نام مبحث یا صورت سؤال را بنویسید (مثلاً: ژنتیک، مشتق، کلر)…"
              className="flex-1 px-3.5 py-2.5 rounded-xl border text-xs outline-none"
              style={{
                background: "var(--card-pressed)",
                borderColor: "var(--line)",
                color: "var(--text)",
              }}
            />
            <button
              type="button"
              onClick={() => {
                if (!chatInput.trim()) {
                  onToast("یک مبحث یا پرسش بنویسید");
                  return;
                }
                onSendChatMessage(chatInput.trim(), chatMode);
                setChatInput("");
              }}
              className="w-10 h-10 rounded-xl flex items-center justify-center text-white cursor-pointer shrink-0"
              style={{ background: "var(--primary)" }}
            >
              <MimoIcon name="ic_arrow_left" size={16} mono />
            </button>
          </div>

          <div className="flex items-center justify-between text-[11px]">
            <div
              className="inline-flex rounded-full p-0.5 border"
              style={{
                background: "var(--card-pressed)",
                borderColor: "var(--line)",
              }}
            >
              <button
                type="button"
                onClick={() => {
                  setChatMode("TEACH");
                  onToast("حالت آموزش (درسنامه + فرمول) انتخاب شد");
                }}
                className="px-3 py-1 rounded-full font-bold cursor-pointer"
                style={{
                  background:
                    chatMode === "TEACH" ? "var(--primary)" : "transparent",
                  color: chatMode === "TEACH" ? "#FFFFFF" : "var(--text-weak)",
                }}
              >
                آموزش
              </button>
              <button
                type="button"
                onClick={() => {
                  setChatMode("PRACTICE");
                  onToast("حالت تمرین (تست + پاسخ تشریحی) انتخاب شد");
                }}
                className="px-3 py-1 rounded-full font-bold cursor-pointer"
                style={{
                  background:
                    chatMode === "PRACTICE" ? "var(--primary)" : "transparent",
                  color:
                    chatMode === "PRACTICE" ? "#FFFFFF" : "var(--text-weak)",
                }}
              >
                تمرین
              </button>
            </div>

            <div className="flex items-center gap-1.5" style={{ color: "var(--text-weak)" }}>
              <span>مدل: local-content</span>
              <span>·</span>
              <span>externalProvider: not-configured</span>
            </div>
          </div>
        </div>

        {/* History Sheet */}
        {showHistorySheet && (
          <div
            className="absolute inset-0 z-40 flex flex-col justify-end"
            style={{ background: "rgba(37, 39, 70, 0.55)" }}
          >
            <div
              className="w-full rounded-t-3xl p-5 space-y-3 border-t"
              style={{
                background: "var(--sheet)",
                borderColor: "var(--line)",
              }}
            >
              <h4 className="font-bold text-base">تاریخچه و مبحث‌های آماده</h4>
              <div className="space-y-2 max-h-[240px] overflow-y-auto mimo-scroll">
                {MIMO_TUTORIALS.slice(0, 6).map((t) => (
                  <button
                    key={t.id}
                    type="button"
                    onClick={() => {
                      setShowHistorySheet(false);
                      onSendChatMessage(t.title, chatMode);
                    }}
                    className="w-full p-3 rounded-xl border text-right flex items-center justify-between cursor-pointer"
                    style={{
                      background: "var(--card-pressed)",
                      borderColor: "var(--line)",
                    }}
                  >
                    <div>
                      <b className="text-xs block">
                        {t.subject} · {t.title}
                      </b>
                      <small className="text-[11px]" style={{ color: "var(--text-weak)" }}>
                        {t.shortDescriptionContent}
                      </small>
                    </div>
                    <MimoIcon name="ic_arrow_left" size={16} mono />
                  </button>
                ))}
              </div>
              <div className="flex gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => {
                    onClearChat();
                    setShowHistorySheet(false);
                  }}
                  className="mimo-cta flex-1"
                >
                  ＋ گفتگوی تازه
                </button>
                <button
                  type="button"
                  onClick={() => setShowHistorySheet(false)}
                  className="mimo-cta secondary flex-1"
                >
                  بستن
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  // ==========================================================================
  // SCREEN 2: NATIVE STUDIO (4-Phase Local LearnHarness — D3)
  // ==========================================================================
  if (screen === "native-studio") {
    const phases: { key: "measure" | "plan" | "teach" | "practice"; label: string }[] = [
      { key: "measure", label: "۱. سنجش" },
      { key: "plan", label: "۲. برنامه‌ریزی" },
      { key: "teach", label: "۳. آموزش" },
      { key: "practice", label: "۴. تمرین" },
    ];

    const currentTeachQ =
      KONKUR_QUESTIONS[studioTeachIdx % KONKUR_QUESTIONS.length];

    return (
      <div className="flex flex-col h-full overflow-y-auto mimo-scroll pb-6" dir="rtl">
        {/* Toolbar */}
        <div
          className="flex items-center gap-3 px-4 shrink-0 border-b"
          style={{
            height: "var(--toolbar)",
            background: "var(--card)",
            borderColor: "var(--line)",
          }}
        >
          <button
            type="button"
            onClick={() => onNavigate("ai")}
            className="w-9 h-9 flex items-center justify-center rounded-lg cursor-pointer"
          >
            <MimoIcon name="ic_arrow_back_24" size={22} mono />
          </button>
          <b className="text-base flex-1">استودیو یادگیری محلی (LearnHarness)</b>
        </div>

        <div className="p-4 space-y-4">
          {/* 4 Phase Pills */}
          <div className="grid grid-cols-4 gap-1.5">
            {phases.map((p) => {
              const on = studioPhase === p.key;
              return (
                <button
                  key={p.key}
                  type="button"
                  onClick={() => setStudioPhase(p.key)}
                  className="py-2 px-2 rounded-xl text-xs font-bold border text-center cursor-pointer"
                  style={{
                    background: on ? "var(--primary)" : "var(--card)",
                    borderColor: on ? "var(--primary)" : "var(--line)",
                    color: on ? "#FFFFFF" : "var(--text-weak)",
                  }}
                >
                  {p.label}
                </button>
              );
            })}
          </div>

          {/* Token Context Chips */}
          <div className="flex flex-wrap gap-1.5">
            <span
              className="px-2.5 py-1 rounded-full text-[11px] font-bold"
              style={{
                background: "var(--progress-weak)",
                color: "var(--primary)",
              }}
            >
              مدل: local-content (بدون LLM)
            </span>
            <span
              className="px-2.5 py-1 rounded-full text-[11px] font-bold"
              style={{
                background: "var(--progress-weak)",
                color: "var(--primary)",
              }}
            >
              زمینه: {faNum(contextUnits)} واحد محلی
            </span>
            <span
              className="px-2.5 py-1 rounded-full text-[11px] font-bold"
              style={{
                background: "var(--progress-weak)",
                color: "var(--primary)",
              }}
            >
              هزینه: ۰٫۰۰ دلار
            </span>
          </div>

          {/* PHASE 1: MEASURE */}
          {studioPhase === "measure" && (
            <div className="space-y-3">
              <div
                className="p-4 rounded-xl border space-y-1"
                style={{
                  background: "var(--card)",
                  borderColor: "var(--line)",
                }}
              >
                <span className="text-xs font-bold" style={{ color: "var(--primary)" }}>
                  فاز ۱ · سنجش سطح پایه
                </span>
                <h3 className="text-base font-bold">از کجا شروع کنیم؟</h3>
                <p className="text-xs leading-relaxed" style={{ color: "var(--text-weak)" }}>
                  به این ۵ پرسش شاخص پاسخ دهید تا ترتیب اولویت درسنامه‌ها برایتان چیده شود.
                </p>
              </div>

              {diagnosticQuestions.map((q, qi) => (
                <div
                  key={q.id}
                  className="p-3.5 rounded-xl border space-y-2"
                  style={{
                    background: "var(--card)",
                    borderColor: "var(--line)",
                  }}
                >
                  <b className="text-xs block">
                    {faNum(qi + 1)}. ({q.subject} · {q.topic}) {q.stemFa}
                  </b>
                  <div className="grid gap-1.5">
                    {q.options.map((opt, oi) => {
                      const picked = measureAnswers[qi] === oi;
                      return (
                        <button
                          key={oi}
                          type="button"
                          onClick={() =>
                            setMeasureAnswers((prev) => ({
                              ...prev,
                              [qi]: oi,
                            }))
                          }
                          className="p-2.5 rounded-xl border text-right text-xs flex items-center gap-2 cursor-pointer"
                          style={{
                            background: picked
                              ? "var(--progress-weak)"
                              : "var(--card-pressed)",
                            borderColor: picked
                              ? "var(--primary)"
                              : "var(--line)",
                            fontWeight: picked ? 700 : 500,
                          }}
                        >
                          <span
                            className="w-5 h-5 rounded flex items-center justify-center text-[11px] font-bold"
                            style={{
                              background: picked
                                ? "var(--primary)"
                                : "var(--card)",
                              color: picked ? "#FFFFFF" : "var(--text)",
                            }}
                          >
                            {faNum(oi + 1)}
                          </span>
                          <span>{opt}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}

              <button
                type="button"
                onClick={() => setStudioPhase("plan")}
                className="mimo-cta"
              >
                ساخت برنامهٔ یادگیری (فاز ۲) ←
              </button>
            </div>
          )}

          {/* PHASE 2: PLAN */}
          {studioPhase === "plan" && (
            <div className="space-y-3">
              <div
                className="p-4 rounded-xl border space-y-2"
                style={{
                  background: "var(--card)",
                  borderColor: "var(--line)",
                }}
              >
                <span className="text-xs font-bold" style={{ color: "var(--primary)" }}>
                  فاز ۲ · برنامه‌ریزی مبتنی بر وابستگی
                </span>
                <h3 className="text-base font-bold">
                  مسیر پیشنهادی از بستهٔ ساختاریافته
                </h3>
                <p className="text-xs" style={{ color: "var(--text-weak)" }}>
                  {faNum(MIMO_TUTORIALS.length)} مبحث استاندارد · با اولویت مباحثی که در سنجش یا آزمون نیاز به مرور داشته‌اند:
                </p>
              </div>

              <div className="space-y-2">
                {KONKUR_QUESTIONS.slice(0, 8).map((q, idx) => {
                  const ans = measureAnswers[idx];
                  const needsFocus =
                    ans !== undefined && ans !== q.correctIndex;
                  return (
                    <div
                      key={q.id}
                      className="p-3 rounded-xl border flex items-center justify-between gap-2"
                      style={{
                        background: "var(--card)",
                        borderColor: needsFocus
                          ? "var(--error)"
                          : "var(--line)",
                      }}
                    >
                      <div className="flex items-center gap-2.5">
                        <span
                          className="w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold text-white"
                          style={{
                            background: needsFocus
                              ? "var(--error)"
                              : "var(--primary)",
                          }}
                        >
                          {faNum(idx + 1)}
                        </span>
                        <div>
                          <b className="text-xs block">
                            {q.subject} · {q.topic}
                          </b>
                          <small
                            className="text-[11px]"
                            style={{ color: "var(--text-weak)" }}
                          >
                            {needsFocus
                              ? "اولویت بالا (نیازمند تثبیت)"
                              : `دشواری ${q.difficultyLabel} · ۸ ریزدرس`}
                          </small>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setStudioTeachIdx(idx);
                          setStudioPhase("teach");
                        }}
                        className="px-2.5 py-1 rounded-lg text-xs font-bold border cursor-pointer"
                        style={{
                          background: "var(--card-pressed)",
                          borderColor: "var(--primary)",
                          color: "var(--primary)",
                        }}
                      >
                        آموزش
                      </button>
                    </div>
                  );
                })}
              </div>

              <button
                type="button"
                onClick={() => setStudioPhase("teach")}
                className="mimo-cta"
              >
                شروع فاز ۳ (آموزش) ←
              </button>
            </div>
          )}

          {/* PHASE 3: TEACH */}
          {studioPhase === "teach" && (
            <div className="space-y-3">
              <div
                className="p-4 rounded-xl border space-y-2.5"
                style={{
                  background: "var(--card)",
                  borderColor: "var(--line)",
                }}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold" style={{ color: "var(--primary)" }}>
                    فاز ۳ · آموزش عینی از بستهٔ محتوا
                  </span>
                  <span className="text-xs" style={{ color: "var(--text-weak)" }}>
                    مبحث {faNum(studioTeachIdx + 1)} از{" "}
                    {faNum(KONKUR_QUESTIONS.length)}
                  </span>
                </div>
                <h3 className="text-base font-bold">
                  {currentTeachQ.subject} · {currentTeachQ.topic}
                </h3>
                <p className="text-sm leading-relaxed">
                  {currentTeachQ.explanationFa}
                </p>
                <div
                  className="p-3 rounded-xl font-mono text-xs font-bold"
                  style={{
                    background: "var(--code-bg)",
                    color: "var(--primary)",
                    direction: "ltr",
                  }}
                >
                  {currentTeachQ.labFormulaFa}
                </div>
                <div className="text-[11px]" style={{ color: "var(--text-weak)" }}>
                  منبع: {currentTeachQ.sourceRef} · هیچ جمله‌ای توسط مدل زبانی تولید نشده است.
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => onOpenLessonByTopic(currentTeachQ.topic)}
                  className="mimo-cta flex-1"
                >
                  ورود به پلیر درس (۸ ریزدرس)
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setStudioPracticePick(null);
                    setStudioPhase("practice");
                  }}
                  className="mimo-cta secondary flex-1"
                >
                  فاز ۴ (تمرین) ←
                </button>
              </div>
            </div>
          )}

          {/* PHASE 4: PRACTICE */}
          {studioPhase === "practice" && (
            <div className="space-y-3">
              <div
                className="p-4 rounded-xl border space-y-3"
                style={{
                  background: "var(--card)",
                  borderColor: "var(--line)",
                }}
              >
                <span className="text-xs font-bold" style={{ color: "var(--primary)" }}>
                  فاز ۴ · بازیابی و تثبیت ({currentTeachQ.subject} ·{" "}
                  {currentTeachQ.topic})
                </span>
                <h3 className="text-sm font-bold leading-relaxed">
                  {currentTeachQ.stemFa}
                </h3>
                <div className="grid gap-2">
                  {currentTeachQ.options.map((opt, oi) => {
                    const isPicked = studioPracticePick === oi;
                    const isRight =
                      studioPracticePick !== null &&
                      oi === currentTeachQ.correctIndex;
                    const isWrong =
                      isPicked && oi !== currentTeachQ.correctIndex;
                    return (
                      <button
                        key={oi}
                        type="button"
                        onClick={() => setStudioPracticePick(oi)}
                        className="p-3 rounded-xl border-2 text-right text-xs font-bold flex items-center gap-2.5 cursor-pointer"
                        style={{
                          background: isRight
                            ? "rgba(102, 188, 90, 0.14)"
                            : isWrong
                            ? "rgba(240, 90, 110, 0.14)"
                            : "var(--card-pressed)",
                          borderColor: isRight
                            ? "var(--success)"
                            : isWrong
                            ? "var(--error)"
                            : "var(--line)",
                        }}
                      >
                        <span className="w-6 h-6 rounded flex items-center justify-center bg-white/80 text-slate-900">
                          {faNum(oi + 1)}
                        </span>
                        <span>{opt}</span>
                      </button>
                    );
                  })}
                </div>

                {studioPracticePick !== null && (
                  <div
                    className="p-3 rounded-xl text-xs leading-relaxed"
                    style={{
                      background: "var(--progress-weak)",
                      color: "var(--text)",
                    }}
                  >
                    <b>
                      {studioPracticePick === currentTeachQ.correctIndex
                        ? "✓ درست پاسخ دادید!"
                        : `✕ پاسخ درست گزینهٔ ${faNum(
                            currentTeachQ.correctIndex + 1
                          )} است:`}
                    </b>{" "}
                    {currentTeachQ.explanationFa}
                  </div>
                )}
              </div>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setStudioTeachIdx((i) => i + 1);
                    setStudioPracticePick(null);
                    setStudioPhase("teach");
                  }}
                  className="mimo-cta flex-1"
                >
                  مبحث بعدی ←
                </button>
                <button
                  type="button"
                  onClick={() =>
                    triggerDownloadText(
                      "mimo-learnharness-session.json",
                      JSON.stringify(
                        {
                          generatedAt: new Date().toISOString(),
                          phase: studioPhase,
                          measureAnswers,
                          contextUnits,
                          honest: {
                            llm: false,
                            network: false,
                            generatedText: false,
                            externalProvider: "not-configured",
                            serverConfirmed: false,
                          },
                        },
                        null,
                        2
                      )
                    )
                  }
                  className="mimo-cta secondary flex-1"
                >
                  ذخیرهٔ گزارش JSON
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  // ==========================================================================
  // SCREEN 3: LEADERBOARD ("وضعیت من" — F35, R11)
  // ==========================================================================
  if (screen === "leaderboard" || screen === "user-profile") {
    const solvedCount = lessonProgress.filter((r) => r.tries >= 1).length;
    const unresolvedMistakes = mistakes.filter((m) => !m.resolved);

    return (
      <div className="flex flex-col h-full overflow-y-auto mimo-scroll pb-6" dir="rtl">
        <div
          className="flex items-center justify-between px-4 shrink-0 border-b"
          style={{
            height: "var(--toolbar)",
            background: "var(--card)",
            borderColor: "var(--line)",
          }}
        >
          <b className="text-lg">امتیازها و وضعیت من</b>
          <span
            className="text-xs font-bold px-2.5 py-1 rounded-full"
            style={{
              background: "var(--progress-weak)",
              color: "var(--primary)",
            }}
          >
            {displayName}
          </span>
        </div>

        <div className="p-4 space-y-4">
          {/* 3 Stat Cards (F35) */}
          <div className="grid grid-cols-3 gap-2.5">
            <div
              className="p-3.5 rounded-xl border text-center space-y-1"
              style={{
                background: "var(--card)",
                borderColor: "var(--line)",
              }}
            >
              <div className="flex justify-center">
                <MimoIcon name="ic_streak_active" size={30} />
              </div>
              <b className="text-lg block">{faNum(streak)}</b>
              <small
                className="text-[11px] font-bold block"
                style={{ color: "var(--text-weak)" }}
              >
                روز متوالی
              </small>
            </div>

            <div
              className="p-3.5 rounded-xl border text-center space-y-1"
              style={{
                background: "var(--card)",
                borderColor: "var(--line)",
              }}
            >
              <div
                className="flex justify-center"
                style={{ color: "var(--yellow)" }}
              >
                <MimoIcon name="ic_flash_filled" size={30} mono />
              </div>
              <b className="text-lg block">{faNum(xp)}</b>
              <small
                className="text-[11px] font-bold block"
                style={{ color: "var(--text-weak)" }}
              >
                امتیاز کل (XP)
              </small>
            </div>

            <div
              className="p-3.5 rounded-xl border text-center space-y-1"
              style={{
                background: "var(--card)",
                borderColor: "var(--line)",
              }}
            >
              <div className="flex justify-center">
                <MimoIcon name="ic_trophy" size={30} />
              </div>
              <b className="text-lg block">{faNum(examHistory.length)}</b>
              <small
                className="text-[11px] font-bold block"
                style={{ color: "var(--text-weak)" }}
              >
                آزمون‌های من
              </small>
            </div>
          </div>

          {/* Room/SQLite LessonProgress Summary Card */}
          <div
            className="p-4 rounded-xl border space-y-2.5"
            style={{
              background: "var(--card)",
              borderColor: "var(--line)",
            }}
          >
            <div className="flex items-center justify-between">
              <b className="text-sm">جدول ۱۱فیلدی LessonProgress (M09)</b>
              <span
                className="text-xs font-bold"
                style={{ color: "var(--primary)" }}
              >
                {faNum(solvedCount)} حل‌شده
              </span>
            </div>
            <p className="text-xs" style={{ color: "var(--text-weak)" }}>
              قاعدهٔ A5: <code dir="ltr">isSolvedCorrectly ≡ tries &gt;= 1</code> · نسخهٔ انتشار:{" "}
              {faNum(753)}
            </p>
            {lessonProgress.length === 0 ? (
              <div
                className="p-3 rounded-xl text-xs text-center"
                style={{
                  background: "var(--card-pressed)",
                  color: "var(--text-weak)",
                }}
              >
                هنوز ریزدرسی ثبت نشده است. از تب «یادگیری» اولین درس را شروع کنید.
              </div>
            ) : (
              <div className="space-y-1.5 max-h-[190px] overflow-y-auto mimo-scroll">
                {lessonProgress.slice(0, 8).map((row) => (
                  <div
                    key={row.lessonId}
                    className="p-2.5 rounded-lg border text-xs flex items-center justify-between"
                    style={{
                      background: "var(--card-pressed)",
                      borderColor: "var(--line)",
                    }}
                  >
                    <span>
                      ریزدرس #{faNum(row.lessonId)} · {row.tutorialTitle || row.courseKey}
                    </span>
                    <span
                      className="font-bold"
                      style={{
                        color:
                          row.tries >= 1 ? "var(--success)" : "var(--error)",
                      }}
                    >
                      tries={faNum(row.tries)} · تلاش {faNum(row.attempts)}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Exam History Box */}
          <div
            className="p-4 rounded-xl border space-y-2.5"
            style={{
              background: "var(--card)",
              borderColor: "var(--line)",
            }}
          >
            <b className="text-sm block">آزمون‌ها و کارنامه‌های ثبت‌شدهٔ من</b>
            {examHistory.length === 0 ? (
              <div
                className="p-3 rounded-xl text-xs text-center"
                style={{
                  background: "var(--card-pressed)",
                  color: "var(--text-weak)",
                }}
              >
                هنوز آزمونی به پایان نرسیده است. از تب «تمرین» وارد یکی از آزمون‌ها شوید.
              </div>
            ) : (
              <div className="space-y-2">
                {examHistory.map((ex, i) => (
                  <div
                    key={i}
                    className="p-2.5 rounded-xl border text-xs flex items-center justify-between"
                    style={{
                      background: "var(--card-pressed)",
                      borderColor: "var(--line)",
                    }}
                  >
                    <span>
                      {ex.examTitle} ({ex.partial ? "تا این لحظه" : "کامل"})
                    </span>
                    <b style={{ color: "var(--primary)" }}>
                      {faNum(ex.pctWithNeg)}٪ · {faNum(ex.correctCount)} درست
                    </b>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* FSRS-lite Review Queue */}
          <div
            className="p-4 rounded-xl border space-y-2"
            style={{
              background: "var(--card)",
              borderColor: "var(--line)",
            }}
          >
            <div className="flex items-center justify-between">
              <b className="text-sm">صف مرور غلط‌ها (FSRS-lite · R8)</b>
              <span
                className="text-xs font-bold"
                style={{
                  color:
                    unresolvedMistakes.length > 0
                      ? "var(--error)"
                      : "var(--success)",
                }}
              >
                {faNum(unresolvedMistakes.length)} مورد باز
              </span>
            </div>
            <p className="text-xs" style={{ color: "var(--text-weak)" }}>
              هر سؤال غلط با ۲ بار پاسخ صحیح متوالی از صف مرور خارج می‌شود.
            </p>
            {unresolvedMistakes.length > 0 && (
              <div className="space-y-1.5">
                {unresolvedMistakes.slice(0, 5).map((m, idx) => (
                  <div
                    key={idx}
                    className="p-2.5 rounded-lg border text-xs flex items-center justify-between"
                    style={{
                      background: "var(--card-pressed)",
                      borderColor: "var(--error)",
                    }}
                  >
                    <span>
                      {m.subject} · {m.topicId} ({m.questionKey})
                    </span>
                    <span>
                      پاسخ متوالی درست: {faNum(m.consecutiveCorrect)}/۲
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  // ==========================================================================
  // SCREEN 4: NATIVE TOKENS (Three Meanings of "Token" — D4)
  // ==========================================================================
  if (screen === "native-tokens") {
    return (
      <div className="flex flex-col h-full overflow-y-auto mimo-scroll pb-6" dir="rtl">
        <div
          className="flex items-center gap-3 px-4 shrink-0 border-b"
          style={{
            height: "var(--toolbar)",
            background: "var(--card)",
            borderColor: "var(--line)",
          }}
        >
          <button
            type="button"
            onClick={() => onNavigate("profile")}
            className="w-9 h-9 flex items-center justify-center rounded-lg cursor-pointer"
          >
            <MimoIcon name="ic_arrow_back_24" size={22} mono />
          </button>
          <b className="text-base">ساختار سه‌گانهٔ توکن‌ها (D4)</b>
        </div>

        <div className="p-4 space-y-4">
          <div className="grid grid-cols-3 gap-2">
            {[
              { k: "design" as const, l: "۱. توکن‌های طراحی" },
              { k: "economy" as const, l: "۲. توکن‌های پاداش" },
              { k: "ai" as const, l: "۳. توکن‌های زمینه AI" },
            ].map((t) => (
              <button
                key={t.k}
                type="button"
                onClick={() => setTokenTab(t.k)}
                className="py-2 px-2 rounded-xl text-xs font-bold border cursor-pointer"
                style={{
                  background:
                    tokenTab === t.k ? "var(--primary)" : "var(--card)",
                  borderColor:
                    tokenTab === t.k ? "var(--primary)" : "var(--line)",
                  color: tokenTab === t.k ? "#FFFFFF" : "var(--text-weak)",
                }}
              >
                {t.l}
              </button>
            ))}
          </div>

          {tokenTab === "design" && (
            <div className="space-y-2.5">
              <div className="text-xs font-bold" style={{ color: "var(--text-weak)" }}>
                توکن‌های رنگ و ابعاد استخراج‌شده از ARSC میمو ۹٫۳۵ (صفر هاردکد تازه — F2):
              </div>
              <div className="grid grid-cols-2 gap-2">
                {DESIGN_TOKEN_LIST.map((tk) => (
                  <div
                    key={tk.name}
                    className="p-3 rounded-xl border space-y-1.5"
                    style={{
                      background: "var(--card)",
                      borderColor: "var(--line)",
                    }}
                  >
                    <div className="flex items-center gap-2">
                      {tk.day.startsWith("#") && (
                        <span
                          className="w-5 h-5 rounded-md border shrink-0"
                          style={{
                            background: nightMode ? tk.night : tk.day,
                            borderColor: "var(--line)",
                          }}
                        />
                      )}
                      <b className="text-xs font-mono" dir="ltr">
                        {tk.name}
                      </b>
                    </div>
                    <div className="text-[11px]" style={{ color: "var(--text-weak)" }}>
                      {tk.role}
                    </div>
                    <div className="text-[10.5px] font-mono" dir="ltr">
                      Day: {tk.day} · Night: {tk.night}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {tokenTab === "economy" && (
            <div className="space-y-3">
              <div
                className="p-4 rounded-xl border space-y-2"
                style={{
                  background: "var(--card)",
                  borderColor: "var(--line)",
                }}
              >
                <b className="text-sm block">موجودی دفتر توکن‌های محلی</b>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="p-2.5 rounded-lg" style={{ background: "var(--card-pressed)" }}>
                    سکه: <b>{faNum(coins)}</b>
                  </div>
                  <div className="p-2.5 rounded-lg" style={{ background: "var(--card-pressed)" }}>
                    کلیدها: <b>∞ (نامحدود)</b>
                  </div>
                  <div className="p-2.5 rounded-lg" style={{ background: "var(--card-pressed)" }}>
                    امتیاز تجربه (XP): <b>{faNum(xp)}</b>
                  </div>
                  <div className="p-2.5 rounded-lg" style={{ background: "var(--card-pressed)" }}>
                    استریک روزانه: <b>{faNum(streak)} روز</b>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={onClaimDailyGoal}
                  className="mimo-cta mt-2"
                >
                  ثبت هدف روزانه (+۲۵ سکه · +۱ استریک)
                </button>
              </div>

              <div
                className="p-4 rounded-xl border space-y-2"
                style={{
                  background: "var(--card)",
                  borderColor: "var(--line)",
                }}
              >
                <b className="text-sm block">
                  قواعد پاداش محلی (SERVER CONFIRMED=0)
                </b>
                {ECONOMY_RULES_LIST.map((r) => (
                  <div
                    key={r.id}
                    className="flex justify-between items-center text-xs py-1.5 border-b last:border-0"
                    style={{ borderColor: "var(--line)" }}
                  >
                    <span>{r.fa}</span>
                    <b style={{ color: "var(--primary)" }}>{r.formula}</b>
                  </div>
                ))}
              </div>
            </div>
          )}

          {tokenTab === "ai" && (
            <div
              className="p-4 rounded-xl border space-y-2.5"
              style={{
                background: "var(--card)",
                borderColor: "var(--line)",
              }}
            >
              <b className="text-sm block">توکن‌های زمینه و گام‌های LearnHarness</b>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between py-1 border-b" style={{ borderColor: "var(--line)" }}>
                  <span>مدل</span>
                  <b>local-content (بدون LLM)</b>
                </div>
                <div className="flex justify-between py-1 border-b" style={{ borderColor: "var(--line)" }}>
                  <span>واحدهای زمینهٔ فعال</span>
                  <b>{faNum(contextUnits)} واحد محلی</b>
                </div>
                <div className="flex justify-between py-1 border-b" style={{ borderColor: "var(--line)" }}>
                  <span>هزینهٔ مصرفی API</span>
                  <b>۰٫۰۰ دلار</b>
                </div>
                <div className="flex justify-between py-1">
                  <span>ارائه‌دهندهٔ خارجی (externalProvider)</span>
                  <b>not-configured</b>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  // ==========================================================================
  // SCREEN 5: NATIVE OUTPUT (1-Click Offline Deliverables — D7)
  // ==========================================================================
  if (screen === "native-output") {
    return (
      <div className="flex flex-col h-full overflow-y-auto mimo-scroll pb-6" dir="rtl">
        <div
          className="flex items-center gap-3 px-4 shrink-0 border-b"
          style={{
            height: "var(--toolbar)",
            background: "var(--card)",
            borderColor: "var(--line)",
          }}
        >
          <button
            type="button"
            onClick={() => onNavigate("profile")}
            className="w-9 h-9 flex items-center justify-center rounded-lg cursor-pointer"
          >
            <MimoIcon name="ic_arrow_back_24" size={22} mono />
          </button>
          <b className="text-base">خروجی یک‌کلیکه و دانلود فایل‌های آفلاین</b>
        </div>

        <div className="p-4 space-y-4">
          <div
            className="p-4 rounded-xl border space-y-1.5"
            style={{
              background: "var(--card)",
              borderColor: "var(--line)",
            }}
          >
            <span className="text-xs font-bold" style={{ color: "var(--primary)" }}>
              تحویل خودکفا (Self-Contained)
            </span>
            <h3 className="text-base font-bold">
              اجرای آفلاین بدون نیاز به سرور یا اینترنت
            </h3>
            <p className="text-xs leading-relaxed" style={{ color: "var(--text-weak)" }}>
              فایل تک‌صفحه‌ای <code dir="ltr">Mimo.html</code> و بستهٔ{" "}
              <code dir="ltr">Mimo.zip</code> با اصلاح باگ نگاشت{" "}
              <code dir="ltr">chapterRefFor()</code> و <code dir="ltr">#curNode</code> آمادهٔ دانلود مستقیم هستند.
            </p>
          </div>

          <div
            className="rounded-xl border overflow-hidden divide-y"
            style={{
              background: "var(--card)",
              borderColor: "var(--line)",
            }}
          >
            <a
              href="/Mimo.html"
              download="Mimo.html"
              onClick={() => onToast("دانلود فایل خودکفای Mimo.html آغاز شد")}
              className="flex items-center justify-between p-3.5 hover:opacity-90 transition-opacity"
              style={{ color: "var(--text)", textDecoration: "none" }}
            >
              <div className="flex items-center gap-3">
                <span
                  className="w-9 h-9 rounded-xl flex items-center justify-center font-bold text-white"
                  style={{ background: "var(--primary)" }}
                >
                  ↓
                </span>
                <div>
                  <b className="text-sm block">دانلود Mimo.html (تک‌فایل خودکفا)</b>
                  <small className="text-xs" style={{ color: "var(--text-weak)" }}>
                    ۱٫۸۶ مگابایت · دوبار کلیک کنید و بدون اینترنت اجرا کنید
                  </small>
                </div>
              </div>
              <MimoIcon name="ic_arrow_left" size={18} mono />
            </a>

            <a
              href="/Mimo.zip"
              download="Mimo.zip"
              onClick={() => onToast("دانلود بستهٔ کامل Mimo.zip آغاز شد")}
              className="flex items-center justify-between p-3.5 hover:opacity-90 transition-opacity"
              style={{ color: "var(--text)", textDecoration: "none" }}
            >
              <div className="flex items-center gap-3">
                <span
                  className="w-9 h-9 rounded-xl flex items-center justify-center font-bold text-white"
                  style={{ background: "var(--primary)" }}
                >
                  📦
                </span>
                <div>
                  <b className="text-sm block">دانلود Mimo.zip (بستهٔ PWA + آیکن‌ها)</b>
                  <small className="text-xs" style={{ color: "var(--text-weak)" }}>
                    شامل Mimo.html، index.html، manifest.webmanifest و sw.js
                  </small>
                </div>
              </div>
              <MimoIcon name="ic_arrow_left" size={18} mono />
            </a>

            <a
              href="/STRUCTURED_PACKAGE.json"
              download="STRUCTURED_PACKAGE.json"
              onClick={() =>
                onToast("دانلود بستهٔ محتوای STRUCTURED_PACKAGE.json آغاز شد")
              }
              className="flex items-center justify-between p-3.5 hover:opacity-90 transition-opacity"
              style={{ color: "var(--text)", textDecoration: "none" }}
            >
              <div className="flex items-center gap-3">
                <span
                  className="w-9 h-9 rounded-xl flex items-center justify-center font-bold"
                  style={{
                    background: "var(--progress-weak)",
                    color: "var(--primary)",
                  }}
                >
                  {}
                </span>
                <div>
                  <b className="text-sm block">
                    دانلود STRUCTURED_PACKAGE.json
                  </b>
                  <small className="text-xs" style={{ color: "var(--text-weak)" }}>
                    ساختار استاندارد درسنامه‌ها و سؤالات با sourceRef
                  </small>
                </div>
              </div>
              <MimoIcon name="ic_arrow_left" size={18} mono />
            </a>

            <button
              type="button"
              onClick={() =>
                triggerDownloadText(
                  "mimo-learner-state.json",
                  JSON.stringify(
                    {
                      exportedAt: new Date().toISOString(),
                      displayName,
                      activeCourseName,
                      coins,
                      streak,
                      xp,
                      lessonProgress,
                      mistakes,
                      examHistory,
                      ledger,
                      honest: {
                        serverConfirmed: 0,
                        llm: false,
                        network: false,
                        generatedText: false,
                        externalProvider: "not-configured",
                      },
                    },
                    null,
                    2
                  )
                )
              }
              className="w-full flex items-center justify-between p-3.5 text-right cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <span
                  className="w-9 h-9 rounded-xl flex items-center justify-center font-bold"
                  style={{
                    background: "var(--progress-weak)",
                    color: "var(--primary)",
                  }}
                >
                  💾
                </span>
                <div>
                  <b className="text-sm block">خروجی وضعیت یادگیرنده (JSON)</b>
                  <small className="text-xs" style={{ color: "var(--text-weak)" }}>
                    شامل ردیف‌های LessonProgress، صف غلط‌ها و کارنامه‌ها
                  </small>
                </div>
              </div>
              <MimoIcon name="ic_arrow_left" size={18} mono />
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ==========================================================================
  // SCREEN 6: PROFILE (profile_fragment.xml — Course Progress + Tools)
  // ==========================================================================
  return (
    <div className="flex flex-col h-full overflow-y-auto mimo-scroll pb-6" dir="rtl">
      <div
        className="flex items-center justify-between px-4 shrink-0 border-b"
        style={{
          height: "var(--toolbar)",
          background: "var(--card)",
          borderColor: "var(--line)",
        }}
      >
        <b className="text-lg">پروفایل</b>
        <button
          type="button"
          onClick={onToggleNightMode}
          className="px-3 py-1.5 rounded-full text-xs font-bold border cursor-pointer"
          style={{
            background: "var(--card-pressed)",
            borderColor: "var(--line)",
          }}
        >
          {nightMode ? "☀️ حالت روز" : "🌙 حالت شب"}
        </button>
      </div>

      <div className="p-4 space-y-4">
        {/* Course Progress Card */}
        <div
          className="p-4 rounded-xl border flex items-center justify-between gap-3"
          style={{
            background: "var(--card)",
            borderColor: "var(--line)",
          }}
        >
          <div className="flex items-center gap-3">
            <div
              className="w-12 h-12 rounded-2xl flex items-center justify-center"
              style={{
                background: "var(--progress-weak)",
                color: "var(--primary)",
              }}
            >
              <MimoIcon name="ic_cap_filled" size={34} />
            </div>
            <div>
              <b className="text-base block">{activeCourseName}</b>
              <span className="text-xs" style={{ color: "var(--text-weak)" }}>
                پیشرفت مسیر فعلی · هدف روزانه: {faNum(dailyGoalXp)} XP
              </span>
            </div>
          </div>
          <b className="text-lg" style={{ color: "var(--primary)" }}>
            {faNum(courseCompletionPct)}٪
          </b>
        </div>

        {/* Tools & Subscreens List */}
        <div
          className="rounded-xl border overflow-hidden divide-y"
          style={{
            background: "var(--card)",
            borderColor: "var(--line)",
          }}
        >
          <div className="px-3.5 py-2.5 font-bold text-xs" style={{ color: "var(--text-weak)" }}>
            ابزارهای یادگیری و معماری میمو ۹٫۳۵
          </div>

          <button
            type="button"
            onClick={() => onNavigate("path-overview")}
            className="w-full p-3.5 flex items-center justify-between text-right cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <span className="font-bold" style={{ color: "var(--primary)" }}>
                ▤
              </span>
              <div>
                <b className="text-sm block">نمای کلی مسیر آموزشی</b>
                <small className="text-xs" style={{ color: "var(--text-weak)" }}>
                  ۱۲ کتاب درسی · ۶۰ فصل · ۱۸۰ درس · ۱۶۰ ریزدرس
                </small>
              </div>
            </div>
            <MimoIcon name="ic_arrow_left" size={16} mono />
          </button>

          <button
            type="button"
            onClick={() => onNavigate("native-studio")}
            className="w-full p-3.5 flex items-center justify-between text-right cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <span className="font-bold" style={{ color: "var(--primary)" }}>
                ✦
              </span>
              <div>
                <b className="text-sm block">استودیو یادگیری محلی (LearnHarness)</b>
                <small className="text-xs" style={{ color: "var(--text-weak)" }}>
                  چهار فاز سنجش، برنامه‌ریزی، آموزش و تمرین · بدون مدل زبانی
                </small>
              </div>
            </div>
            <MimoIcon name="ic_arrow_left" size={16} mono />
          </button>

          <button
            type="button"
            onClick={() => onNavigate("native-tokens")}
            className="w-full p-3.5 flex items-center justify-between text-right cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <span className="font-bold" style={{ color: "var(--primary)" }}>
                ◈
              </span>
              <div>
                <b className="text-sm block">ساختار توکن‌ها</b>
                <small className="text-xs" style={{ color: "var(--text-weak)" }}>
                  توکن‌های طراحی ARSC · دفتر پاداش · توکن‌های زمینه
                </small>
              </div>
            </div>
            <MimoIcon name="ic_arrow_left" size={16} mono />
          </button>

          <button
            type="button"
            onClick={() => onNavigate("native-output")}
            className="w-full p-3.5 flex items-center justify-between text-right cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <span className="font-bold" style={{ color: "var(--primary)" }}>
                ↓
              </span>
              <div>
                <b className="text-sm block">خروجی گرفتن / دانلود Mimo.html</b>
                <small className="text-xs" style={{ color: "var(--text-weak)" }}>
                  فایل تک‌صفحه‌ای خودکفا، بستهٔ PWA و وضعیت JSON
                </small>
              </div>
            </div>
            <MimoIcon name="ic_arrow_left" size={16} mono />
          </button>
        </div>

        {/* Custom Exam Builder Card */}
        <div
          className="p-4 rounded-xl border flex items-center justify-between"
          style={{
            background: "var(--card)",
            borderColor: "var(--line)",
          }}
        >
          <div>
            <b className="text-sm block">آزمون‌های سفارشی من</b>
            <small className="text-xs" style={{ color: "var(--text-weak)" }}>
              ساخت آزمون جامع، تک‌درس، زمان‌دار یا تحلیلی
            </small>
          </div>
          <button
            type="button"
            onClick={onOpenPlaygroundSheet}
            className="px-3.5 py-2 rounded-xl text-xs font-bold text-white cursor-pointer"
            style={{ background: "var(--primary)" }}
          >
            ＋ ساخت آزمون
          </button>
        </div>

        {/* Reset Demo Data Button */}
        <button
          type="button"
          onClick={onResetAllData}
          className="w-full py-2.5 rounded-xl border text-xs font-bold cursor-pointer"
          style={{
            background: "var(--card)",
            borderColor: "var(--line)",
            color: "var(--text-weak)",
          }}
        >
          بازنشانی پیشرفت به حالت آغازین
        </button>
      </div>
    </div>
  );
}
