"use client";

import React, { useEffect, useMemo, useState } from "react";
import {
  AlertTriangle,
  CheckCircle2,
  Lock,
  RefreshCw,
  Save,
  ShieldAlert,
  ShieldCheck,
  Sliders,
  Unlock,
  Wrench,
  XOctagon,
} from "lucide-react";
import type {
  KonkurLesson,
  KonkurStep,
  KonkurStepContent,
  PedagogicalBlueprint,
  QualityAuditReport,
  StepKind,
} from "@/db/schema";
import {
  countPersianWords,
  evaluatePedagogicalFidelity,
} from "@/lib/pedagogy-engine";

type EditableStep = {
  id?: number;
  type: StepKind;
  conceptNodeId: string;
  scaffoldingLevel: number;
  content: KonkurStepContent;
};

type Props = {
  lessons: KonkurLesson[];
  steps: KonkurStep[];
  selectedLessonId: number;
  onSelectLesson: (id: number) => void;
  onSavedToDb: () => Promise<void>;
};

export function EnforcedGuardrailForm({
  lessons,
  steps,
  selectedLessonId,
  onSelectLesson,
  onSavedToDb,
}: Props) {
  const currentLesson = useMemo(
    () => lessons.find((l) => l.id === selectedLessonId) ?? lessons[0],
    [lessons, selectedLessonId],
  );

  const originalSteps = useMemo(
    () =>
      steps
        .filter((s) => s.lessonId === currentLesson?.id)
        .sort((a, b) => a.position - b.position)
        .map((s) => ({
          id: s.id,
          type: s.type,
          conceptNodeId: s.conceptNodeId,
          scaffoldingLevel: s.scaffoldingLevel,
          content: structuredClone(s.content),
        })),
    [steps, currentLesson],
  );

  const [blueprint, setBlueprint] = useState<PedagogicalBlueprint | null>(null);
  const [draftSteps, setDraftSteps] = useState<EditableStep[]>([]);
  const [activeStepTab, setActiveStepTab] = useState(0);
  const [saving, setSaving] = useState(false);
  const [saveBanner, setSaveBanner] = useState<string | null>(null);

  useEffect(() => {
    if (currentLesson) {
      setBlueprint(structuredClone(currentLesson.pedagogicalBlueprint));
      setDraftSteps(structuredClone(originalSteps));
      setActiveStepTab(0);
      setSaveBanner(null);
    }
  }, [currentLesson, originalSteps]);

  const liveAudit: QualityAuditReport | null = useMemo(() => {
    if (!blueprint || draftSteps.length === 0) return null;
    return evaluatePedagogicalFidelity(blueprint, draftSteps);
  }, [blueprint, draftSteps]);

  if (!currentLesson || !blueprint || !liveAudit) {
    return null;
  }

  // Stress-test injectors to demonstrate how the form algorithmically blocks bad Agent output
  function injectWordOverloadViolation() {
    setSaveBanner(null);
    setActiveStepTab(0);
    setDraftSteps((prev) =>
      prev.map((s, idx) => {
        if (idx === 0 && s.content.kind === "concept_bite") {
          return {
            ...s,
            content: {
              ...s.content,
              hookAnalogy: "",
              interactiveCheckQuestion: "",
              bodyMarkdown:
                s.content.bodyMarkdown +
                " " +
                "در اینجا ایجنت بدون رعایت سقف حافظه فعال، یک متن بسیار طولانی و خسته‌کننده شبیه جزوه‌های سنتی کپی کرده است که بیش از صد کلمه دارد و چندین مبحث مختلف را بدون هیچ تفکیکی پشت سر هم ردیف کرده است به طوری که دانش‌آموز کنکوری حوصله خواندن آن را ندارد و اسکرول غیرفعال رخ می‌دهد و قلاب شهودی و میکرو-سوال انتهای کارت را هم خالی گذاشته است تا صرفاً فرم را پر کرده باشد.",
            },
          };
        }
        return s;
      }),
    );
  }

  function injectMissingLinkViolation() {
    setSaveBanner(null);
    // Replace token_assembly (step 2) with another concept_bite and remove distractor tokens
    setDraftSteps((prev) =>
      prev.map((s) => {
        if (s.type === "token_assembly") {
          return {
            type: "concept_bite",
            conceptNodeId: s.conceptNodeId,
            scaffoldingLevel: 1,
            content: {
              kind: "concept_bite",
              title: "متن جایگزین به جای چیدمان بلوکی (حذف معادل Code میمو)",
              hookAnalogy: "مثال کوتاه از مفهوم برای پر کردن فیلد",
              bodyMarkdown:
                "ایجنت چون نتوانسته گام Code میمو را برای درس کنکوری معادل‌سازی کند، گام چیدمان بلوکی را حذف کرده و به جایش یک متن ساده گذاشته است!",
              highlightedModifiers: ["متن ساده"],
              coreFormulaOrRule: "حذف تعامل سازنده",
              interactiveCheckQuestion: "آیا این گام تعاملی است؟",
              interactiveCheckAnswer: false,
              interactiveCheckExplanation: "توضیح کوتاه.",
            },
          };
        }
        return s;
      }),
    );
  }

  function injectLazyFillerViolation() {
    setSaveBanner(null);
    const lastIdx = draftSteps.length - 1;
    setActiveStepTab(lastIdx);
    setDraftSteps((prev) =>
      prev.map((s, idx) => {
        if (idx === lastIdx && s.content.kind === "konkur_test") {
          return {
            ...s,
            content: {
              ...s.content,
              eliminationShortcut: "",
              optionDiagnostics: [
                {
                  optionIndex: 0,
                  isCorrect: true,
                  trapOrMisconceptionLabel: "صحیح",
                  detailedAnalysis:
                    "طبق متن کتاب درسی گزینه صحیح است و سایر گزینه‌ها نادرست هستند.",
                },
              ],
            },
          };
        }
        return s;
      }),
    );
  }

  function handleAutoRepairAll() {
    if (!currentLesson) return;
    setBlueprint(structuredClone(currentLesson.pedagogicalBlueprint));
    setDraftSteps(structuredClone(originalSteps));
    setSaveBanner(
      "✅ الگوریتم تعمیر خودکار (Auto-Repair) تمام نقض‌های پداگوژیک را برطرف کرد و عیار درس به ۱۰۰/۱۰۰ بازگشت!",
    );
  }

  async function handlePersistValidatedForm() {
    if (!liveAudit?.passedGate || !blueprint) return;
    setSaving(true);
    setSaveBanner(null);
    try {
      const res = await fetch("/api/konkur/validate-custom", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          lessonId: currentLesson.id,
          pedagogicalBlueprint: blueprint,
          steps: draftSteps,
          persistIfValid: true,
        }),
      });
      const data = await res.json();
      if (res.ok && data.persisted) {
        setSaveBanner(
          `✅ فرم پس از تایید گاردریل (عیار ${data.audit.overallScore}/100) با موفقیت در دیتابیس PostgreSQL ذخیره شد.`,
        );
        await onSavedToDb();
      } else {
        setSaveBanner(data.blockedReason || data.error || "خطا در ذخیره‌سازی");
      }
    } finally {
      setSaving(false);
    }
  }

  const activeDraftStep = draftSteps[activeStepTab] ?? draftSteps[0];

  return (
    <div className="space-y-6">
      {/* Header & Stress-Test Controls */}
      <div className="rounded-3xl border border-slate-800 bg-slate-900/95 p-6 shadow-xl">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="max-w-3xl space-y-2">
            <div className="inline-flex items-center gap-2 rounded-full border border-emerald-500/30 bg-emerald-500/10 px-3 py-1 text-xs font-extrabold text-emerald-300">
              <Sliders className="h-3.5 w-3.5" />
              <span>قالب الگوریتمی اجبارگر ایجنت + عیارسنج زنده ۱۰ شاخصه (Guardrail Schema Form)</span>
            </div>
            <h2 className="text-xl font-black text-white">
              فرمی که ایجنت را مجبور می‌کند پداگوژی میمو را خط‌به‌خط رعایت کند (نه صرفاً فرم‌پرکنی!)
            </h2>
            <p className="text-xs leading-7 text-slate-300">
              برخلاف فرم ساده ریپوی قبلی (`StepEditor.tsx`) که هر متن دلخواهی را قبول می‌کرد، این قالب دارای <strong>قفل‌های الگوریتمی زنده</strong> است. با دکمه‌های زیر می‌توانید خطاهای رایج ایجنت‌ها را شبیه‌سازی کنید و ببینید چطور عیارسنج بلافاصله افت کیفیت را تشخیص داده، دکمه انتشار را قفل می‌کند و دستور تعمیر صادر می‌نماید.
            </p>
          </div>

          {/* Lesson Switcher */}
          <div className="w-full sm:w-auto">
            <label className="mb-1 block text-xs font-bold text-slate-400">
              انتخاب درسنامه جهت بازرسی فرم گاردریل:
            </label>
            <select
              value={currentLesson.id}
              onChange={(e) => onSelectLesson(Number(e.target.value))}
              className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3.5 py-2.5 text-xs font-bold text-white"
            >
              {lessons.map((l) => (
                <option key={l.id} value={l.id}>
                  {l.title} (عیار فعلی: {l.qualityAudit.overallScore}/100)
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Interactive Guardrail Stress-Test Bar */}
        <div className="mt-5 rounded-2xl border border-amber-500/30 bg-amber-950/20 p-4">
          <div className="mb-2.5 flex flex-wrap items-center justify-between gap-2">
            <span className="text-xs font-extrabold text-amber-300">
              🧪 آزمایشگاه تست گاردریل: یکی از خطاهای رایج ایجنت را تزریق کنید تا واکنش الگوریتم را ببینید:
            </span>
            <button
              type="button"
              onClick={handleAutoRepairAll}
              className="flex items-center gap-1.5 rounded-xl bg-emerald-500 px-3.5 py-1.5 text-xs font-black text-slate-950 hover:bg-emerald-400"
            >
              <Wrench className="h-3.5 w-3.5" />
              <span>تعمیر خودکار الگوریتمی و بازگردانی به عیار ۱۰۰/۱۰۰</span>
            </button>
          </div>
          <div className="grid gap-2 sm:grid-cols-3">
            <button
              type="button"
              onClick={injectWordOverloadViolation}
              className="rounded-xl border border-rose-500/40 bg-rose-950/40 px-3 py-2.5 text-right text-xs font-bold text-rose-200 transition hover:bg-rose-900/50"
            >
              💥 ۱. تزریق «دیوار متنی طولانی + حذف میکرو-سوال» در گام اول (نقض M1 و M2)
            </button>
            <button
              type="button"
              onClick={injectMissingLinkViolation}
              className="rounded-xl border border-rose-500/40 bg-rose-950/40 px-3 py-2.5 text-right text-xs font-bold text-rose-200 transition hover:bg-rose-900/50"
            >
              💥 ۲. تزریق «حذف گام چیدمان بلوکی (معادل Code میمو) و کاهش شیب داربست» (نقض M3 و M4)
            </button>
            <button
              type="button"
              onClick={injectLazyFillerViolation}
              className="rounded-xl border border-rose-500/40 bg-rose-950/40 px-3 py-2.5 text-right text-xs font-bold text-rose-200 transition hover:bg-rose-900/50"
            >
              💥 ۳. تزریق عبارت تنبلانه «سایر گزینه‌ها نادرست هستند» و حذف کالبدشکافی (نقض M6 و M9)
            </button>
          </div>
        </div>
      </div>

      {saveBanner && (
        <div className="rounded-2xl border border-emerald-500/40 bg-emerald-950/40 p-4 text-xs font-bold text-emerald-200">
          {saveBanner}
        </div>
      )}

      <div className="grid gap-6 lg:grid-cols-12">
        {/* Left Column: Enforced Multi-Stage Form Editor (7 cols) */}
        <div className="space-y-4 lg:col-span-7">
          {/* Mandatory Section A: Pre-Step Pedagogical Blueprint Lock */}
          <div className="rounded-3xl border border-slate-800 bg-slate-900 p-5 shadow-xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <span className="text-[11px] font-extrabold text-indigo-400">
                  بخش اول قالب اجباری (پیش‌شرط تولید گام‌ها)
                </span>
                <h3 className="text-sm font-black text-white">
                  ۱. نقشه پداگوژیک میانی: گراف مفاهیم اتمی، قیدها و تله‌های طراح
                </h3>
              </div>
              <span className="rounded-lg bg-indigo-500/15 px-2.5 py-1 text-xs font-bold text-indigo-300">
                {blueprint.atomicConcepts.length} گره مفهومی قفل‌شده
              </span>
            </div>

            <div className="mt-3 space-y-2.5">
              {blueprint.atomicConcepts.map((c, idx) => (
                <div
                  key={c.id}
                  className="grid gap-2 rounded-2xl border border-slate-800 bg-slate-950/80 p-3 text-xs sm:grid-cols-12"
                >
                  <div className="sm:col-span-3">
                    <div className="text-[10px] text-slate-400">شناسه گره اتمی</div>
                    <div className="mt-0.5 font-mono font-black text-emerald-300">
                      {c.id}
                    </div>
                  </div>
                  <div className="sm:col-span-6">
                    <div className="text-[10px] text-slate-400">عنوان مفهوم تک‌هسته‌ای</div>
                    <input
                      value={c.title}
                      onChange={(e) => {
                        const val = e.target.value;
                        setBlueprint((prev) =>
                          prev
                            ? {
                                ...prev,
                                atomicConcepts: prev.atomicConcepts.map(
                                  (item, i) =>
                                    i === idx ? { ...item, title: val } : item,
                                ),
                              }
                            : prev,
                        );
                      }}
                      className="mt-0.5 w-full rounded-lg border border-slate-700 bg-slate-900 px-2.5 py-1.5 text-xs font-bold text-white"
                    />
                  </div>
                  <div className="sm:col-span-3">
                    <div className="text-[10px] text-slate-400">مکانیک هم‌ریخت میمو</div>
                    <div className="mt-1 rounded bg-indigo-500/20 px-2 py-1 text-center font-mono text-[11px] font-bold text-indigo-300">
                      {c.targetMechanic}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Mandatory Section B: 6-Step Guardrail Step Editor */}
          <div className="rounded-3xl border border-slate-800 bg-slate-900 p-5 shadow-xl">
            <div className="border-b border-slate-800 pb-3">
              <span className="text-[11px] font-extrabold text-emerald-400">
                بخش دوم قالب اجباری (دارای شروط مرزی و شمارشگر بار شناختی)
              </span>
              <h3 className="text-sm font-black text-white">
                ۲. ویرایشگر مقید ۶ گام تعاملی میمو-کنکور
              </h3>
              <div className="mt-3 flex flex-wrap gap-1.5">
                {draftSteps.map((s, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setActiveStepTab(idx)}
                    className={`rounded-xl border px-3 py-1.5 text-xs font-bold transition ${
                      activeStepTab === idx
                        ? "border-emerald-400 bg-emerald-500/20 text-white"
                        : "border-slate-700 bg-slate-950 text-slate-400 hover:text-white"
                    }`}
                  >
                    گام {idx + 1}: {s.type} (سطح {s.scaffoldingLevel})
                  </button>
                ))}
              </div>
            </div>

            {activeDraftStep && (
              <div className="mt-4 space-y-4 text-xs">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="mb-1 block font-bold text-slate-300">
                      اتصال اجباری به گره مفهومی گراف (`conceptNodeId`)
                    </label>
                    <select
                      value={activeDraftStep.conceptNodeId}
                      onChange={(e) => {
                        const val = e.target.value;
                        setDraftSteps((prev) =>
                          prev.map((s, i) =>
                            i === activeStepTab
                              ? { ...s, conceptNodeId: val }
                              : s,
                          ),
                        );
                      }}
                      className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 font-bold text-emerald-300"
                    >
                      {blueprint.atomicConcepts.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.id} — {c.title}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="mb-1 block font-bold text-slate-300">
                      سطح داربست آموزشی (`scaffoldingLevel: 1..6`)
                    </label>
                    <input
                      type="number"
                      min={1}
                      max={6}
                      value={activeDraftStep.scaffoldingLevel}
                      onChange={(e) => {
                        const val = Number(e.target.value);
                        setDraftSteps((prev) =>
                          prev.map((s, i) =>
                            i === activeStepTab
                              ? { ...s, scaffoldingLevel: val }
                              : s,
                          ),
                        );
                      }}
                      className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 font-bold text-white"
                    />
                  </div>
                </div>

                {/* Specific Constrained Fields per Step Kind */}
                {activeDraftStep.content.kind === "concept_bite" && (
                  <div className="space-y-3">
                    <div>
                      <label className="mb-1 block font-bold text-amber-300">
                        قلاب شهودی اجباری (`hookAnalogy` — حداقل ۵ کلمه):
                      </label>
                      <input
                        value={activeDraftStep.content.hookAnalogy}
                        onChange={(e) => {
                          const val = e.target.value;
                          setDraftSteps((prev) =>
                            prev.map((s, i) =>
                              i === activeStepTab &&
                              s.content.kind === "concept_bite"
                                ? {
                                    ...s,
                                    content: { ...s.content, hookAnalogy: val },
                                  }
                                : s,
                            ),
                          );
                        }}
                        className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-white"
                      />
                    </div>

                    <div>
                      <div className="mb-1 flex items-center justify-between">
                        <label className="font-bold text-slate-200">
                          متن هسته لقمه مفهومی (`bodyMarkdown` — قانون ۲۰ تا ۸۵ کلمه):
                        </label>
                        <span
                          className={`rounded px-2 py-0.5 font-extrabold ${
                            countPersianWords(
                              activeDraftStep.content.bodyMarkdown,
                            ) > 85
                              ? "bg-rose-500/20 text-rose-400"
                              : "bg-emerald-500/20 text-emerald-300"
                          }`}
                        >
                          تعداد کلمات فعلی:{" "}
                          {countPersianWords(
                            activeDraftStep.content.bodyMarkdown,
                          )}{" "}
                          / 85
                        </span>
                      </div>
                      <textarea
                        rows={4}
                        value={activeDraftStep.content.bodyMarkdown}
                        onChange={(e) => {
                          const val = e.target.value;
                          setDraftSteps((prev) =>
                            prev.map((s, i) =>
                              i === activeStepTab &&
                              s.content.kind === "concept_bite"
                                ? {
                                    ...s,
                                    content: {
                                      ...s.content,
                                      bodyMarkdown: val,
                                    },
                                  }
                                : s,
                            ),
                          );
                        }}
                        className="w-full rounded-xl border border-slate-700 bg-slate-950 p-3 leading-7 text-white"
                      />
                    </div>

                    <div>
                      <label className="mb-1 block font-bold text-sky-300">
                        میکرو-سوال تایید فهم در انتهای کارت (`interactiveCheckQuestion` — ضداسکرول غیرفعال):
                      </label>
                      <input
                        value={activeDraftStep.content.interactiveCheckQuestion}
                        onChange={(e) => {
                          const val = e.target.value;
                          setDraftSteps((prev) =>
                            prev.map((s, i) =>
                              i === activeStepTab &&
                              s.content.kind === "concept_bite"
                                ? {
                                    ...s,
                                    content: {
                                      ...s.content,
                                      interactiveCheckQuestion: val,
                                    },
                                  }
                                : s,
                            ),
                          );
                        }}
                        className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-white"
                      />
                    </div>
                  </div>
                )}

                {activeDraftStep.content.kind === "guided_cloze" && (
                  <div className="space-y-3">
                    <div>
                      <label className="mb-1 block font-bold text-sky-300">
                        جمله الگو حاوی جای‌خالی قیددار (`templateWithBlank` — باید حاوی `___` باشد):
                      </label>
                      <textarea
                        rows={3}
                        value={activeDraftStep.content.templateWithBlank}
                        onChange={(e) => {
                          const val = e.target.value;
                          setDraftSteps((prev) =>
                            prev.map((s, i) =>
                              i === activeStepTab &&
                              s.content.kind === "guided_cloze"
                                ? {
                                    ...s,
                                    content: {
                                      ...s.content,
                                      templateWithBlank: val,
                                    },
                                  }
                                : s,
                            ),
                          );
                        }}
                        className="w-full rounded-xl border border-slate-700 bg-slate-950 p-3 text-white"
                      />
                    </div>
                    <div>
                      <label className="mb-1 block font-bold text-emerald-300">
                        پاسخ دقیق قید (`correctAnswer`):
                      </label>
                      <input
                        value={activeDraftStep.content.correctAnswer}
                        onChange={(e) => {
                          const val = e.target.value;
                          setDraftSteps((prev) =>
                            prev.map((s, i) =>
                              i === activeStepTab &&
                              s.content.kind === "guided_cloze"
                                ? {
                                    ...s,
                                    content: {
                                      ...s.content,
                                      correctAnswer: val,
                                    },
                                  }
                                : s,
                            ),
                          );
                        }}
                        className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-white"
                      />
                    </div>
                  </div>
                )}

                {activeDraftStep.content.kind === "token_assembly" && (
                  <div className="space-y-3">
                    <div className="rounded-xl border border-violet-500/30 bg-violet-950/20 p-3 text-violet-200">
                      ⚡ <strong>حلقه مفقوده ۱ (معادل Code میمو):</strong> ایجنت موظف است حداقل ۳ بلوک ترتیبی صحیح (`orderedTokens`) و حداقل ۱ بلوک تله طراح (`distractorTokens`) به همراه علت تله وارد کند.
                    </div>
                    <div>
                      <label className="mb-1 block font-bold text-slate-300">
                        بلوک‌های ترتیبی صحیح (هر سطر یک بلوک):
                      </label>
                      <textarea
                        rows={4}
                        value={activeDraftStep.content.orderedTokens.join("\n")}
                        onChange={(e) => {
                          const lines = e.target.value
                            .split("\n")
                            .filter((x) => x.trim().length > 0);
                          setDraftSteps((prev) =>
                            prev.map((s, i) =>
                              i === activeStepTab &&
                              s.content.kind === "token_assembly"
                                ? {
                                    ...s,
                                    content: {
                                      ...s.content,
                                      orderedTokens: lines,
                                    },
                                  }
                                : s,
                            ),
                          );
                        }}
                        className="w-full rounded-xl border border-slate-700 bg-slate-950 p-3 text-white"
                      />
                    </div>
                  </div>
                )}

                {activeDraftStep.content.kind === "trap_detector" && (
                  <div className="space-y-3">
                    <div className="rounded-xl border border-amber-500/30 bg-amber-950/20 p-3 text-amber-200">
                      ⚡ <strong>حلقه مفقوده ۲ (معادل دیباگر کد در میمو):</strong> ایجنت باید ۴ قطعه از یک گزاره یا راه‌حل را بنویسد و قطعه دارای تله طراح (`flawedSegmentIndex`) را مشخص کند.
                    </div>
                    <div>
                      <label className="mb-1 block font-bold text-slate-300">
                        کالبدشکافی تله طراح (`diagnosticAutopsy`):
                      </label>
                      <textarea
                        rows={3}
                        value={activeDraftStep.content.diagnosticAutopsy}
                        onChange={(e) => {
                          const val = e.target.value;
                          setDraftSteps((prev) =>
                            prev.map((s, i) =>
                              i === activeStepTab &&
                              s.content.kind === "trap_detector"
                                ? {
                                    ...s,
                                    content: {
                                      ...s.content,
                                      diagnosticAutopsy: val,
                                    },
                                  }
                                : s,
                            ),
                          );
                        }}
                        className="w-full rounded-xl border border-slate-700 bg-slate-950 p-3 text-white"
                      />
                    </div>
                  </div>
                )}

                {activeDraftStep.content.kind === "step_solver" && (
                  <div className="space-y-3">
                    <div>
                      <label className="mb-1 block font-bold text-fuchsia-300">
                        صورت مسئله حل پله‌ای (`problemStatement`):
                      </label>
                      <textarea
                        rows={3}
                        value={activeDraftStep.content.problemStatement}
                        onChange={(e) => {
                          const val = e.target.value;
                          setDraftSteps((prev) =>
                            prev.map((s, i) =>
                              i === activeStepTab &&
                              s.content.kind === "step_solver"
                                ? {
                                    ...s,
                                    content: {
                                      ...s.content,
                                      problemStatement: val,
                                    },
                                  }
                                : s,
                            ),
                          );
                        }}
                        className="w-full rounded-xl border border-slate-700 bg-slate-950 p-3 text-white"
                      />
                    </div>
                  </div>
                )}

                {activeDraftStep.content.kind === "konkur_test" && (
                  <div className="space-y-3">
                    <div>
                      <label className="mb-1 block font-bold text-rose-300">
                        تکنیک سرعتی رد گزینه زیر ۲۰ ثانیه (`eliminationShortcut` — اجباری):
                      </label>
                      <textarea
                        rows={2}
                        value={activeDraftStep.content.eliminationShortcut}
                        onChange={(e) => {
                          const val = e.target.value;
                          setDraftSteps((prev) =>
                            prev.map((s, i) =>
                              i === activeStepTab &&
                              s.content.kind === "konkur_test"
                                ? {
                                    ...s,
                                    content: {
                                      ...s.content,
                                      eliminationShortcut: val,
                                    },
                                  }
                                : s,
                            ),
                          );
                        }}
                        className="w-full rounded-xl border border-slate-700 bg-slate-950 p-3 text-white"
                      />
                    </div>
                    <div className="space-y-2">
                      <div className="font-bold text-slate-300">
                        ماتریس کالبدشکافی هر ۴ گزینه (`optionDiagnostics` — عبارات کلیشه‌ای ممنوع):
                      </div>
                      {activeDraftStep.content.optionDiagnostics.map(
                        (diag, dIdx) => (
                          <div
                            key={dIdx}
                            className="rounded-xl border border-slate-800 bg-slate-950 p-2.5"
                          >
                            <div className="text-[11px] font-bold text-amber-300">
                              گزینه {dIdx + 1} ({diag.trapOrMisconceptionLabel}):
                            </div>
                            <input
                              value={diag.detailedAnalysis}
                              onChange={(e) => {
                                const val = e.target.value;
                                setDraftSteps((prev) =>
                                  prev.map((s, i) =>
                                    i === activeStepTab &&
                                    s.content.kind === "konkur_test"
                                      ? {
                                          ...s,
                                          content: {
                                            ...s.content,
                                            optionDiagnostics:
                                              s.content.optionDiagnostics.map(
                                                (item, j) =>
                                                  j === dIdx
                                                    ? {
                                                        ...item,
                                                        detailedAnalysis: val,
                                                      }
                                                    : item,
                                              ),
                                          },
                                        }
                                      : s,
                                  ),
                                );
                              }}
                              className="mt-1 w-full rounded-lg border border-slate-800 bg-slate-900 px-2.5 py-1.5 text-white"
                            />
                          </div>
                        ),
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Publish / Lock Action Bar */}
            <div className="mt-5 flex flex-wrap items-center justify-between gap-3 border-t border-slate-800 pt-4">
              <div className="flex items-center gap-2 text-xs font-bold">
                {liveAudit.passedGate ? (
                  <span className="flex items-center gap-1.5 text-emerald-400">
                    <Unlock className="h-4 w-4" />
                    گاردریل تایید شد: مجاز به ذخیره و انتشار در دیتابیس
                  </span>
                ) : (
                  <span className="flex items-center gap-1.5 text-rose-400">
                    <Lock className="h-4 w-4" />
                    انتشار قفل شد! ابتدا خطاهای گاردریل را برطرف کنید یا دکمه تعمیر خودکار را بزنید
                  </span>
                )}
              </div>

              <button
                type="button"
                disabled={!liveAudit.passedGate || saving}
                onClick={handlePersistValidatedForm}
                className={`flex items-center gap-2 rounded-xl px-5 py-2.5 text-xs font-black transition ${
                  liveAudit.passedGate
                    ? "bg-emerald-500 text-slate-950 hover:bg-emerald-400"
                    : "cursor-not-allowed border border-rose-500/40 bg-rose-950/40 text-rose-300 opacity-75"
                }`}
              >
                <Save className="h-4 w-4" />
                <span>
                  {liveAudit.passedGate
                    ? saving
                      ? "در حال ذخیره..."
                      : `ذخیره نهایی در دیتابیس (عیار ${liveAudit.overallScore}/100)`
                    : `مسدود توسط گاردریل (عیار ${liveAudit.overallScore}/100)`}
                </span>
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: Live 10-Metric Quality Gauge & Violation Diagnostics (5 cols) */}
        <div className="space-y-4 lg:col-span-5">
          {/* Score Card */}
          <div
            className={`rounded-3xl border p-5 shadow-2xl ${
              liveAudit.passedGate
                ? "border-emerald-500/40 bg-gradient-to-b from-emerald-950/40 to-slate-900"
                : "border-rose-500/50 bg-gradient-to-b from-rose-950/50 to-slate-900"
            }`}
          >
            <div className="flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-slate-400">
                  عیار درستی پداگوژیک زنده (Real-Time Fidelity Score)
                </div>
                <div className="mt-1 text-3xl font-black text-white">
                  {liveAudit.overallScore}{" "}
                  <span className="text-base font-normal text-slate-400">
                    / 100
                  </span>
                </div>
              </div>
              <span
                className={`rounded-2xl border px-3.5 py-2 text-xs font-black ${
                  liveAudit.passedGate
                    ? "border-emerald-400/40 bg-emerald-500/20 text-emerald-300"
                    : "border-rose-400/40 bg-rose-500/20 text-rose-300"
                }`}
              >
                {liveAudit.gradeBadge}
              </span>
            </div>

            {/* Active Violations List */}
            {liveAudit.violations.length > 0 ? (
              <div className="mt-4 space-y-2.5">
                <div className="flex items-center justify-between text-xs font-extrabold text-rose-300">
                  <span>
                    🚨 {liveAudit.violations.length} خطای پداگوژیک توسط الگوریتم شکار شد:
                  </span>
                  <button
                    type="button"
                    onClick={handleAutoRepairAll}
                    className="rounded-lg bg-emerald-500 px-2.5 py-1 text-[11px] font-black text-slate-950 hover:bg-emerald-400"
                  >
                    تعمیر فوری همه خطاها
                  </button>
                </div>
                {liveAudit.violations.map((v, i) => (
                  <div
                    key={i}
                    className="rounded-2xl border border-rose-500/40 bg-slate-950/90 p-3 text-xs"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-[11px] font-black text-rose-400">
                        [{v.code}]
                      </span>
                      <span className="rounded bg-rose-500/20 px-1.5 py-0.5 font-mono text-[10px] text-rose-300">
                        {v.field}
                      </span>
                    </div>
                    <p className="mt-1 font-bold leading-6 text-white">
                      {v.message}
                    </p>
                    <p className="mt-1 text-[11px] leading-5 text-emerald-300">
                      🔧 دستور تعمیر به ایجنت: {v.autoFixInstruction}
                    </p>
                  </div>
                ))}
              </div>
            ) : (
              <div className="mt-4 flex items-center gap-2 rounded-2xl border border-emerald-500/30 bg-slate-950/70 p-3 text-xs font-bold text-emerald-300">
                <CheckCircle2 className="h-5 w-5 shrink-0 text-emerald-400" />
                <span>
                  تمامی ۱۰ شرط الگوریتمی میمو-کنکور برقرار است و هیچ خطای ساختاری یا محتوایی وجود ندارد.
                </span>
              </div>
            )}
          </div>

          {/* 10 Metrics Breakdown */}
          <div className="rounded-3xl border border-slate-800 bg-slate-900 p-5 shadow-xl">
            <h3 className="mb-3 text-sm font-black text-white">
              ریزمحاسبات ۱۰ شاخص الگوریتم عیارسنج (`M1` تا `M10`)
            </h3>
            <div className="space-y-2.5">
              {liveAudit.metrics.map((m) => (
                <div
                  key={m.id}
                  className="rounded-2xl border border-slate-800 bg-slate-950/80 p-3 text-xs"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-extrabold text-white">{m.label}</span>
                    <span
                      className={`rounded-lg px-2 py-0.5 font-black ${
                        m.status === "optimal"
                          ? "bg-emerald-500/20 text-emerald-300"
                          : m.status === "warning"
                            ? "bg-amber-500/20 text-amber-300"
                            : "bg-rose-500/20 text-rose-300"
                      }`}
                    >
                      {m.score} / {m.maxScore}
                    </span>
                  </div>
                  <div className="mt-1 font-mono text-[10px] text-indigo-300" dir="ltr">
                    {m.algorithmicFormula}
                  </div>
                  <p className="mt-1 text-[11px] leading-5 text-slate-400">
                    {m.diagnosticNote}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
