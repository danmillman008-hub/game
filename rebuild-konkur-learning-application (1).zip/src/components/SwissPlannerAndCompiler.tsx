"use client";

import React, { useState } from "react";
import type { EnrichedKnowledgeNode } from "./MimoLearnPlayer";
import {
  Calendar,
  Sparkles,
  CheckCircle2,
  Circle,
  Plus,
  FileText,
  Play,
  Activity,
} from "lucide-react";

export interface StudyPlanRow {
  id: number;
  dayOfWeek: string;
  subject: string;
  topic: string;
  linkedNodeSlug: string;
  studyType: string;
  targetMinutes: number;
  actualMinutes: number;
  targetTests: number;
  completedTests: number;
  correctTests: number;
  wrongTests: number;
  satisfaction: string;
  advisorNote: string;
  isCompleted: boolean;
}

export interface EvidenceRow {
  id: number;
  nodeSlug: string;
  lessonSlug: string;
  phase: string;
  stepKind: string;
  isCorrect: boolean;
  confidencePct: number;
  thinkingTrace: string;
  supportUsed: string;
  detectedTrap: string | null;
  masteryBefore: number;
  masteryAfter: number;
  stabilityAfter: number;
  xapiVerb: string;
  createdAt: string;
}

interface Props {
  studyPlans: StudyPlanRow[];
  nodes: EnrichedKnowledgeNode[];
  evidence: EvidenceRow[];
  onRefreshState: () => Promise<void>;
  onPlayCompiledLesson: (lessonSlug: string) => void;
}

export default function SwissPlannerAndCompiler({
  studyPlans,
  nodes,
  evidence,
  onRefreshState,
  onPlayCompiledLesson,
}: Props) {
  // Textbook / Jozve Compiler Form State
  const [track, setTrack] = useState("tajrobi");
  const [subject, setSubject] = useState("زیست‌شناسی");
  const [chapter, setChapter] = useState("فصل ۳ دوازدهم — انتقال اطلاعات در نسل‌ها");
  const [title, setTitle] = useState("رابطه بارزیت ناقص و هم‌توانی در ژنتیک کنکور");
  const [rawText, setRawText] = useState(
    "در بارزیت ناقص (مانند گل میمونی)، فنوتیپ فرد ناخالص (RB) حد واسط دو والد خالص است و نسبت فنوتیپی و ژنوتیپی در آمیزش دو فرد ناخالص هر دو ۱:۲:۱ می‌شود.\nدر هم‌توانی (مانند گروه خونی AB)، هر دو دگره اثر خود را به طور کامل و مستقل نشان می‌دهند بدون اینکه فنوتیپ حد واسط بسازند.\nتله طراح کنکور: در بارزیت ناقص برای ایجاد ۳ نوع فنوتیپ فقط ۲ نوع دگره کافی است، اما در گروه خونی ABO، سه نوع دگره وجود دارد."
  );
  const [compiling, setCompiling] = useState(false);
  const [compiledResult, setCompiledResult] = useState<{
    lessonSlug: string;
    title: string;
  } | null>(null);

  // Add Planner Row State
  const [dayOfWeek, setDayOfWeek] = useState("چهارشنبه");
  const [planSubject, setPlanSubject] = useState("زیست‌شناسی");
  const [planTopic, setPlanTopic] = useState("");
  const [targetMinutes, setTargetMinutes] = useState(90);
  const [targetTests, setTargetTests] = useState(35);
  const [addingPlan, setAddingPlan] = useState(false);

  const handleCompileJozve = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !rawText.trim()) return;
    setCompiling(true);
    try {
      const res = await fetch("/api/ingest", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          track,
          subject,
          chapter,
          title,
          rawText,
        }),
      });
      const data = await res.json();
      if (data.lesson) {
        setCompiledResult({
          lessonSlug: data.lesson.slug,
          title: data.lesson.title,
        });
      }
      await onRefreshState();
    } finally {
      setCompiling(false);
    }
  };

  const handleTogglePlan = async (plan: StudyPlanRow) => {
    await fetch("/api/planner", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        id: plan.id,
        isCompleted: !plan.isCompleted,
      }),
    });
    await onRefreshState();
  };

  const handleAddPlanRow = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!planTopic.trim()) return;
    setAddingPlan(true);
    try {
      await fetch("/api/planner", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          dayOfWeek,
          subject: planSubject,
          topic: planTopic,
          targetMinutes,
          targetTests,
        }),
      });
      setPlanTopic("");
      await onRefreshState();
    } finally {
      setAddingPlan(false);
    }
  };

  const outerFringeNodes = nodes.filter((n) => n.kstState === "outer_fringe");

  return (
    <div className="space-y-6">
      {/* SECTION 1: JOZVE / TEXTBOOK TO MIMO QUEST COMPILER (Gramophone M1-M6 + LearnHarness) */}
      <div className="bg-white border-2 border-[#1A1C1A] rounded-2xl p-5 sm:p-6 shadow-[4px_4px_0px_#1A1C1A]">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-[#E2E3DF]">
          <div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-[#059669]/15 text-[#059669] text-xs font-extrabold mb-1">
              <FileText className="w-3.5 h-3.5" />
              <span>کامپایلر زنده کتاب درسی و جزوه به کوئست میمو (Gramophone M1–M6 Fixed)</span>
            </div>
            <h2 className="text-lg sm:text-xl font-extrabold text-[#1A1C1A]">
              تبدیل هر متن، جزوه یا مبحث کنکور به کوئست ۴ فازی LearnHarness × Mimo
            </h2>
          </div>
          <span className="text-xs font-mono bg-[#FAF9F5] px-3 py-1 rounded-lg border border-[#C7C6CB]">
            POST /api/ingest → PostgreSQL
          </span>
        </div>

        <form onSubmit={handleCompileJozve} className="mt-4 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            <div>
              <label className="block text-xs font-bold text-[#1A1C1A] mb-1">
                رشته کنکور:
              </label>
              <select
                value={track}
                onChange={(e) => setTrack(e.target.value)}
                className="w-full bg-[#FAF9F5] border border-[#1A1C1A] rounded-xl px-3 py-2 text-xs font-bold"
              >
                <option value="tajrobi">علوم تجربی</option>
                <option value="riazi">ریاضی و فیزیک</option>
                <option value="ensani">علوم انسانی</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-[#1A1C1A] mb-1">
                نام درس:
              </label>
              <input
                type="text"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                className="w-full bg-[#FAF9F5] border border-[#C7C6CB] rounded-xl px-3 py-2 text-xs font-bold"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-[#1A1C1A] mb-1">
                فصل / پایه:
              </label>
              <input
                type="text"
                value={chapter}
                onChange={(e) => setChapter(e.target.value)}
                className="w-full bg-[#FAF9F5] border border-[#C7C6CB] rounded-xl px-3 py-2 text-xs font-bold"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-[#1A1C1A] mb-1">
                عنوان مبحث / گره دانش:
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full bg-[#FAF9F5] border border-[#C7C6CB] rounded-xl px-3 py-2 text-xs font-bold"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-[#1A1C1A] mb-1">
              متن جزوه، نکات تستی یا پاراگراف کتاب درسی (حداقل ۳ خط برای استخراج اصل بدیهی، مسیر کشف و تله طراح):
            </label>
            <textarea
              rows={4}
              value={rawText}
              onChange={(e) => setRawText(e.target.value)}
              className="w-full bg-[#FAF9F5] border border-[#C7C6CB] rounded-xl p-3 text-xs leading-relaxed text-[#1A1C1A]"
            />
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3">
            <button
              type="submit"
              disabled={compiling}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#001551] hover:bg-[#1A1C1A] text-white text-xs sm:text-sm font-extrabold transition cursor-pointer shadow-[2px_2px_0px_#1A1C1A]"
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>
                {compiling
                  ? "در حال استخراج گزاره و ساخت گام‌های میمو..."
                  : "کامپایل متن به کوئست تعاملی میمو و ذخیره در دیتابیس"}
              </span>
            </button>

            {compiledResult && (
              <button
                type="button"
                onClick={() => onPlayCompiledLesson(compiledResult.lessonSlug)}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#059669] hover:bg-[#047857] text-white text-xs font-extrabold cursor-pointer"
              >
                <Play className="w-4 h-4" />
                <span>شروع فوری کوئست ساخته‌شده: «{compiledResult.title}»</span>
              </button>
            )}
          </div>
        </form>
      </div>

      {/* SECTION 2: SWISS KONKUR WEEKLY STUDY PLANNER (`moshavere-va-azmoon` Stitch UI) */}
      <div className="bg-white border-2 border-[#1A1C1A] rounded-2xl p-5 sm:p-6 shadow-[4px_4px_0px_#1A1C1A]">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 pb-4 border-b-2 border-[#1A1C1A]">
          <div>
            <div className="text-xs font-extrabold text-[#BC000A] uppercase tracking-wider">
              SWISS KONKUR PLANNER • فرم برنامه‌ریزی هفتگی و پایش تست داوطلب (ریپوی moshavere-va-azmoon)
            </div>
            <h2 className="text-lg sm:text-xl font-extrabold text-[#1A1C1A] mt-0.5 flex items-center gap-2">
              <Calendar className="w-5 h-5 text-[#001551]" />
              <span>برنامه هفتگی متصل به لبه بیرونی گراف دانش (KST Outer Fringe) و مرور FSRS</span>
            </h2>
          </div>

          {outerFringeNodes.length > 0 && (
            <div className="bg-[#FAF9F5] border border-[#001551] rounded-xl px-3 py-2 text-xs">
              <strong className="text-[#001551]">پیشنهاد هوشمند امروز (Outer Fringe): </strong>
              <span>{outerFringeNodes.map((n) => n.title).slice(0, 2).join(" ، ")}</span>
            </div>
          )}
        </div>

        {/* Swiss Planner Table */}
        <div className="overflow-x-auto mt-4">
          <table className="w-full text-right border-collapse text-xs">
            <thead>
              <tr className="bg-[#1A1C1A] text-white">
                <th className="p-3 rounded-tr-xl">وضعیت</th>
                <th className="p-3">روز هفته</th>
                <th className="p-3">درس و مبحث</th>
                <th className="p-3">نوع مطالعه (LearnHarness / FSRS)</th>
                <th className="p-3 text-center">ساعت (هدف / واقعی)</th>
                <th className="p-3 text-center">تست (زده / صحیح / غلط)</th>
                <th className="p-3">رضایت</th>
                <th className="p-3 rounded-tl-xl">یادداشت مشاور و موتور هوشمند</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#E2E3DF]">
              {studyPlans.map((row) => (
                <tr
                  key={row.id}
                  className={
                    row.isCompleted ? "bg-emerald-50/40" : "hover:bg-[#FAF9F5]"
                  }
                >
                  <td className="p-3">
                    <button
                      type="button"
                      onClick={() => handleTogglePlan(row)}
                      className="cursor-pointer text-[#1A1C1A] hover:text-[#059669]"
                      title="تغییر وضعیت انجام"
                    >
                      {row.isCompleted ? (
                        <CheckCircle2 className="w-5 h-5 text-[#059669]" />
                      ) : (
                        <Circle className="w-5 h-5 text-[#76777B]" />
                      )}
                    </button>
                  </td>
                  <td className="p-3 font-extrabold text-[#1A1C1A]">{row.dayOfWeek}</td>
                  <td className="p-3">
                    <span className="px-2 py-0.5 rounded bg-[#001551]/10 text-[#001551] font-bold ml-1.5">
                      {row.subject}
                    </span>
                    <span className="font-bold text-[#1A1C1A]">{row.topic}</span>
                  </td>
                  <td className="p-3 text-[#46464B] font-medium">{row.studyType}</td>
                  <td className="p-3 text-center font-mono">
                    {row.actualMinutes} / {row.targetMinutes} دقیقه
                  </td>
                  <td className="p-3 text-center font-mono">
                    <span className="font-bold">{row.completedTests}</span> از{" "}
                    {row.targetTests} (
                    <span className="text-emerald-700 font-bold">
                      +{row.correctTests}
                    </span>{" "}
                    /{" "}
                    <span className="text-[#BC000A] font-bold">-{row.wrongTests}</span>)
                  </td>
                  <td className="p-3">
                    <span
                      className={`px-2 py-0.5 rounded-full text-[11px] font-bold ${
                        row.satisfaction === "excellent"
                          ? "bg-emerald-100 text-emerald-900"
                          : row.satisfaction === "review_needed"
                            ? "bg-rose-100 text-[#BC000A]"
                            : "bg-amber-100 text-amber-900"
                      }`}
                    >
                      {row.satisfaction === "excellent"
                        ? "عالی"
                        : row.satisfaction === "review_needed"
                          ? "نیاز به بازنگری"
                          : "خوب"}
                    </span>
                  </td>
                  <td className="p-3 text-[#46464B] max-w-xs leading-relaxed">
                    {row.advisorNote}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Quick Add Study Row Form */}
        <form
          onSubmit={handleAddPlanRow}
          className="mt-4 pt-4 border-t border-[#E2E3DF] grid grid-cols-1 sm:grid-cols-6 gap-2.5 items-end"
        >
          <div>
            <label className="block text-[11px] font-bold mb-1">روز هفته:</label>
            <select
              value={dayOfWeek}
              onChange={(e) => setDayOfWeek(e.target.value)}
              className="w-full bg-[#FAF9F5] border border-[#C7C6CB] rounded-xl px-2.5 py-2 text-xs font-bold"
            >
              {["شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه"].map(
                (d) => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                )
              )}
            </select>
          </div>
          <div>
            <label className="block text-[11px] font-bold mb-1">درس:</label>
            <input
              type="text"
              value={planSubject}
              onChange={(e) => setPlanSubject(e.target.value)}
              className="w-full bg-[#FAF9F5] border border-[#C7C6CB] rounded-xl px-2.5 py-2 text-xs font-bold"
            />
          </div>
          <div className="sm:col-span-2">
            <label className="block text-[11px] font-bold mb-1">مبحث و هدف مطالعاتی:</label>
            <input
              type="text"
              value={planTopic}
              onChange={(e) => setPlanTopic(e.target.value)}
              placeholder="مثلاً: مرور FSRS فصل ۲ شیمی + ۳۰ تست زمان‌دار"
              className="w-full bg-[#FAF9F5] border border-[#C7C6CB] rounded-xl px-2.5 py-2 text-xs font-bold"
            />
          </div>
          <div>
            <label className="block text-[11px] font-bold mb-1">هدف زمان / تست:</label>
            <div className="flex gap-1.5">
              <input
                type="number"
                value={targetMinutes}
                onChange={(e) => setTargetMinutes(Number(e.target.value))}
                className="w-1/2 bg-[#FAF9F5] border border-[#C7C6CB] rounded-xl px-2 py-2 text-xs font-mono"
                title="دقیقه"
              />
              <input
                type="number"
                value={targetTests}
                onChange={(e) => setTargetTests(Number(e.target.value))}
                className="w-1/2 bg-[#FAF9F5] border border-[#C7C6CB] rounded-xl px-2 py-2 text-xs font-mono"
                title="تعداد تست"
              />
            </div>
          </div>
          <button
            type="submit"
            disabled={addingPlan}
            className="inline-flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-[#1A1C1A] hover:bg-[#001551] text-white text-xs font-bold cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>افزودن به برنامه</span>
          </button>
        </form>
      </div>

      {/* SECTION 3: APPEND-ONLY xAPI & THINK-OUT-LOUD EVIDENCE LOG */}
      <div className="bg-white border-2 border-[#1A1C1A] rounded-2xl p-5 shadow-[3px_3px_0px_#1A1C1A]">
        <h3 className="text-base font-extrabold text-[#1A1C1A] flex items-center gap-2 mb-3">
          <Activity className="w-5 h-5 text-[#001551]" />
          <span>لاگ تغییرناپذیر شواهد یادگیری (xAPI Telemetry + LearnHarness Think-Out-Loud)</span>
        </h3>
        <div className="space-y-2 max-h-64 overflow-y-auto">
          {evidence.map((ev) => (
            <div
              key={ev.id}
              className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 p-3 rounded-xl bg-[#FAF9F5] border border-[#E2E3DF] text-xs"
            >
              <div className="space-y-0.5">
                <div className="flex flex-wrap items-center gap-2">
                  <span
                    className={`px-2 py-0.5 rounded font-mono font-bold text-[10px] ${
                      ev.isCorrect
                        ? "bg-emerald-100 text-emerald-900"
                        : "bg-rose-100 text-[#BC000A]"
                    }`}
                  >
                    {ev.xapiVerb.toUpperCase()}
                  </span>
                  <span className="font-mono font-bold text-[#001551]">{ev.nodeSlug}</span>
                  <span className="text-[#46464B]">
                    فاز: <strong>{ev.phase}</strong> • حالت: <strong>{ev.supportUsed}</strong> • اطمینان:{" "}
                    <strong>{ev.confidencePct}%</strong>
                  </span>
                </div>
                {ev.thinkingTrace && (
                  <p className="text-[#1A1C1A] italic">
                    «بلند فکر کن»: {ev.thinkingTrace}
                  </p>
                )}
              </div>

              <div className="font-mono text-[11px] shrink-0 text-left">
                <div>
                  BKT: {Math.round(ev.masteryBefore * 100)}% →{" "}
                  <strong>{Math.round(ev.masteryAfter * 100)}%</strong>
                </div>
                <div className="text-[#46464B]">FSRS S: {ev.stabilityAfter}d</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
