"use client";

import React, { useState } from "react";
import {
  BookOpen,
  Check,
  Code2,
  Copy,
  FileCode,
  GitBranch,
  Layers,
  Microscope,
  ShieldCheck,
} from "lucide-react";
import type {
  LegacyFormDefectAnalysis,
  SubjectIsomorphismGuide,
} from "@/lib/pedagogy-engine";

type Props = {
  legacyDefects: LegacyFormDefectAnalysis[];
  isomorphismMatrix: SubjectIsomorphismGuide[];
  agentSystemPrompt: string;
};

const STRICT_JSON_SCHEMA_CONTRACT = `{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "MimoKonkurAlgorithmicLessonContract",
  "type": "object",
  "required": ["title", "chapterReference", "pedagogicalBlueprint", "steps"],
  "properties": {
    "pedagogicalBlueprint": {
      "type": "object",
      "description": "مرحله ۱ و ۲ اجباری پیش از تولید گام‌ها: استخراج گراف مفاهیم اتمی، قیدها و تله‌های طراح",
      "required": ["atomicConcepts", "prerequisiteChain", "konkurModifiersAndFormulas", "designerTraps", "missingLinkMapping"],
      "properties": {
        "atomicConcepts": { "type": "array", "minItems": 3, "maxItems": 5 },
        "konkurModifiersAndFormulas": { "type": "array", "minItems": 2 },
        "designerTraps": { "type": "array", "minItems": 2 }
      }
    },
    "steps": {
      "type": "array",
      "minItems": 6,
      "maxItems": 8,
      "description": "زنجیره ۶ گامی با شیب داربست صعودی (scaffoldingLevel: 1 -> 6) و حضور اجباری token_assembly و trap_detector",
      "items": {
        "type": "object",
        "required": ["type", "conceptNodeId", "scaffoldingLevel", "content"],
        "properties": {
          "type": {
            "enum": ["concept_bite", "guided_cloze", "token_assembly", "trap_detector", "step_solver", "konkur_test"]
          },
          "scaffoldingLevel": { "type": "integer", "minimum": 1, "maximum": 6 }
        }
      }
    }
  }
}`;

export function PedagogyResearchAndSpec({
  legacyDefects,
  isomorphismMatrix,
  agentSystemPrompt,
}: Props) {
  const [copiedPrompt, setCopiedPrompt] = useState(false);
  const [copiedSchema, setCopiedSchema] = useState(false);

  function copyText(text: string, which: "prompt" | "schema") {
    navigator.clipboard.writeText(text);
    if (which === "prompt") {
      setCopiedPrompt(true);
      setTimeout(() => setCopiedPrompt(false), 2000);
    } else {
      setCopiedSchema(true);
      setTimeout(() => setCopiedSchema(false), 2000);
    }
  }

  return (
    <div className="space-y-8">
      {/* Section 1: Deep Reverse-Engineering of Legacy Mimo Repo Forms */}
      <div className="rounded-3xl border border-slate-800 bg-slate-900/95 p-6 shadow-xl">
        <div className="flex items-center gap-2 border-b border-slate-800 pb-4">
          <Microscope className="h-6 w-6 text-rose-400" />
          <div>
            <h2 className="text-lg font-black text-white">
              ۱. کالبدشکافی دقیق فرم‌ها و درسنامه‌های ریپوی میمو (`StepEditor.tsx`, `LessonForm.tsx`, `seed.ts`)
            </h2>
            <p className="text-xs text-slate-400">
              چرا وقتی به یک ایجنت کتاب کنکور می‌دهیم و از فرم‌های اولیه میمو استفاده می‌کنیم کیفیت سقوط می‌کند و «حلقه مفقوده» شکل می‌گیرد؟
            </p>
          </div>
        </div>

        <div className="mt-5 space-y-4">
          {legacyDefects.map((defect, idx) => (
            <div
              key={defect.id}
              className="rounded-2xl border border-slate-800 bg-slate-950/90 p-5"
            >
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="rounded-lg bg-rose-500/20 px-3 py-1 text-xs font-black text-rose-300">
                  نقص ساختاری شماره {idx + 1}: {defect.legacyComponent}
                </span>
                <code
                  dir="ltr"
                  className="rounded-lg border border-slate-800 bg-slate-900 px-3 py-1 text-[11px] text-indigo-300"
                >
                  {defect.legacySchemaSignature}
                </code>
              </div>

              <div className="mt-3 rounded-xl border border-slate-800/80 bg-slate-900/60 p-3 text-xs text-slate-300">
                <strong className="text-amber-300">
                  نمونه درسنامه در ریپوی اصلی میمو (`seed.ts`):{" "}
                </strong>
                <span dir="ltr" className="font-mono text-[11px]">
                  {defect.mimoCodingExampleInRepo}
                </span>
              </div>

              <div className="mt-3 grid gap-3 md:grid-cols-3">
                <div className="rounded-xl border border-rose-500/30 bg-rose-950/20 p-3.5 text-xs leading-6">
                  <div className="mb-1 font-extrabold text-rose-300">
                    ❌ چرا ایجنت در کنکور شکست می‌خورد؟
                  </div>
                  <p className="text-slate-300">
                    {defect.whyNaiveAgentFailsForKonkur}
                  </p>
                </div>

                <div className="rounded-xl border border-indigo-500/30 bg-indigo-950/20 p-3.5 text-xs leading-6">
                  <div className="mb-1 font-extrabold text-indigo-300">
                    🌉 پل هم‌ریختی (حلقه مفقوده میمو ↔ کنکور)
                  </div>
                  <p className="text-slate-300">{defect.missingLinkBridge}</p>
                </div>

                <div className="rounded-xl border border-emerald-500/30 bg-emerald-950/20 p-3.5 text-xs leading-6">
                  <div className="mb-1 font-extrabold text-emerald-300">
                    🔒 قفل الگوریتمی در قالب جدید ما
                  </div>
                  <p className="text-slate-300">
                    {defect.enforcedAlgorithmicConstraint}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Section 2: Subject-by-Subject Missing Link Isomorphism Matrix */}
      <div className="rounded-3xl border border-slate-800 bg-slate-900/95 p-6 shadow-xl">
        <div className="flex items-center gap-2 border-b border-slate-800 pb-4">
          <GitBranch className="h-6 w-6 text-indigo-400" />
          <div>
            <h2 className="text-lg font-black text-white">
              ۲. ماتریس پر کردن «حلقه مفقوده»: ترجمه گام‌های `Code`، `Debug` و `Fill` میمو به دروس مختلف کنکور
            </h2>
            <p className="text-xs text-slate-400">
              نگاشت دقیق پداگوژی تعاملی میمو به زیست‌شناسی، فیزیک، شیمی، ریاضی و علوم انسانی
            </p>
          </div>
        </div>

        <div className="mt-5 grid gap-4 md:grid-cols-2">
          {isomorphismMatrix.map((item) => (
            <div
              key={item.subject}
              className="space-y-3 rounded-2xl border border-slate-800 bg-slate-950/90 p-5 text-xs leading-6"
            >
              <div className="flex items-center gap-2 text-base font-black text-white">
                <span className="text-2xl">{item.icon}</span>
                <span>{item.subject}</span>
              </div>

              <div className="rounded-xl border border-violet-500/30 bg-violet-950/20 p-3">
                <div className="font-extrabold text-violet-300">
                  🧩 معادل نوشتن کد (`Code Assembly` میمو):
                </div>
                <p className="mt-1 text-slate-300">{item.mimoCodeEquivalent}</p>
              </div>

              <div className="rounded-xl border border-amber-500/30 bg-amber-950/20 p-3">
                <div className="font-extrabold text-amber-300">
                  🐞 معادل کشف باگ (`Code Debugging` میمو):
                </div>
                <p className="mt-1 text-slate-300">{item.mimoDebugEquivalent}</p>
              </div>

              <div className="rounded-xl border border-sky-500/30 bg-sky-950/20 p-3">
                <div className="font-extrabold text-sky-300">
                  ✏️ معادل جای‌خالی (`Cloze Fill` میمو):
                </div>
                <p className="mt-1 text-slate-300">{item.mimoClozeEquivalent}</p>
              </div>

              <div className="rounded-xl border border-emerald-500/30 bg-emerald-950/20 p-3">
                <div className="font-extrabold text-emerald-300">
                  🤖 دستور استخراج به ایجنت:
                </div>
                <p className="mt-1 text-slate-300">{item.agentExtractionRule}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Section 3: Copyable Agent System Prompt & Enforced JSON Schema Contract */}
      <div className="grid gap-6 lg:grid-cols-12">
        <div className="rounded-3xl border border-slate-800 bg-slate-900/95 p-6 shadow-xl lg:col-span-7">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <FileCode className="h-5 w-5 text-emerald-400" />
              <h3 className="text-sm font-black text-white">
                ۳. سیستم‌پرامپت الگوریتمی ایجنت (قابل کپی برای Claude / GPT / Cursor)
              </h3>
            </div>
            <button
              type="button"
              onClick={() => copyText(agentSystemPrompt, "prompt")}
              className="flex items-center gap-1.5 rounded-xl bg-emerald-500 px-3.5 py-1.5 text-xs font-black text-slate-950 hover:bg-emerald-400"
            >
              {copiedPrompt ? (
                <>
                  <Check className="h-3.5 w-3.5" />
                  <span>کپی شد!</span>
                </>
              ) : (
                <>
                  <Copy className="h-3.5 w-3.5" />
                  <span>کپی پرامپت الگوریتمی</span>
                </>
              )}
            </button>
          </div>

          <pre className="mt-4 max-h-[460px] overflow-auto rounded-2xl border border-slate-800 bg-slate-950 p-4 text-xs leading-7 text-slate-200 whitespace-pre-wrap">
            {agentSystemPrompt}
          </pre>
        </div>

        <div className="rounded-3xl border border-slate-800 bg-slate-900/95 p-6 shadow-xl lg:col-span-5">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <Code2 className="h-5 w-5 text-indigo-400" />
              <h3 className="text-sm font-black text-white">
                ۴. قرارداد JSON Schema مقید به گاردریل
              </h3>
            </div>
            <button
              type="button"
              onClick={() => copyText(STRICT_JSON_SCHEMA_CONTRACT, "schema")}
              className="flex items-center gap-1.5 rounded-xl border border-indigo-500/40 bg-indigo-500/20 px-3 py-1.5 text-xs font-bold text-indigo-200 hover:bg-indigo-500/30"
            >
              {copiedSchema ? (
                <>
                  <Check className="h-3.5 w-3.5" />
                  <span>کپی شد!</span>
                </>
              ) : (
                <>
                  <Copy className="h-3.5 w-3.5" />
                  <span>کپی JSON Schema</span>
                </>
              )}
            </button>
          </div>

          <pre
            dir="ltr"
            className="mt-4 max-h-[460px] overflow-auto rounded-2xl border border-slate-800 bg-slate-950 p-4 font-mono text-[11px] leading-6 text-indigo-200"
          >
            {STRICT_JSON_SCHEMA_CONTRACT}
          </pre>
        </div>
      </div>
    </div>
  );
}
