"use client";

import React, { useEffect, useMemo, useState } from "react";
import {
  AlertTriangle,
  ArrowLeft,
  ArrowRight,
  Award,
  BookOpen,
  CheckCircle2,
  Clock,
  Cpu,
  Flame,
  Heart,
  HelpCircle,
  Layers,
  Lightbulb,
  RotateCcw,
  ShieldAlert,
  Sparkles,
  Target,
  XCircle,
  Zap,
} from "lucide-react";
import type {
  KonkurCourse,
  KonkurLesson,
  KonkurStep,
} from "@/db/schema";

type Props = {
  courses: KonkurCourse[];
  lessons: KonkurLesson[];
  steps: KonkurStep[];
  selectedLessonId: number;
  onSelectLesson: (lessonId: number) => void;
  onStepComplete: (payload: {
    stepId: number;
    lessonId: number;
    correctFirstTry: boolean;
    attempts: number;
    xpEarned: number;
  }) => Promise<void>;
  onOpenGuardrailEditor: (lessonId: number) => void;
};

const STEP_TYPE_META: Record<
  string,
  { label: string; mimoOrigin: string; badgeColor: string }
> = {
  concept_bite: {
    label: "۱. لقمه مفهومی و شهود (Concept Bite)",
    mimoOrigin: "معادل گام Text میمو + میکرو-سوال ضداسکرول",
    badgeColor: "bg-emerald-500/15 text-emerald-300 border-emerald-500/30",
  },
  guided_cloze: {
    label: "۲. قیدگذاری هوشمند (Guided Cloze)",
    mimoOrigin: "معادل گام Fill میمو روی قیدهای کنکوری",
    badgeColor: "bg-sky-500/15 text-sky-300 border-sky-500/30",
  },
  token_assembly: {
    label: "۳. چیدمان بلوکی مکانیزم/فرمول (Token Assembly)",
    mimoOrigin: "حلقه مفقوده ۱: معادل مستقیم Code Assembly میمو",
    badgeColor: "bg-violet-500/15 text-violet-300 border-violet-500/30",
  },
  trap_detector: {
    label: "۴. شکارچی تله طراح / دیباگر (Trap Detector)",
    mimoOrigin: "حلقه مفقوده ۲: معادل مستقیم Code Debugging میمو",
    badgeColor: "bg-amber-500/15 text-amber-300 border-amber-500/30",
  },
  step_solver: {
    label: "۵. حل پله‌ای هدایت‌شده (Step Solver)",
    mimoOrigin: "معادل Parsons Problem پیش از تست نهایی",
    badgeColor: "bg-fuchsia-500/15 text-fuchsia-300 border-fuchsia-500/30",
  },
  konkur_test: {
    label: "۶. تست استاندارد کنکور + کالبدشکافی ۴ گزینه",
    mimoOrigin: "چالش نهایی (Boss Challenge) به همراه تکنیک رد گزینه",
    badgeColor: "bg-rose-500/15 text-rose-300 border-rose-500/30",
  },
};

export function MimoKonkurPlayer({
  courses,
  lessons,
  steps,
  selectedLessonId,
  onSelectLesson,
  onStepComplete,
  onOpenGuardrailEditor,
}: Props) {
  const activeLesson = useMemo(
    () => lessons.find((l) => l.id === selectedLessonId) ?? lessons[0],
    [lessons, selectedLessonId],
  );

  const activeCourse = useMemo(
    () => courses.find((c) => c.id === activeLesson?.courseId) ?? courses[0],
    [courses, activeLesson],
  );

  const lessonSteps = useMemo(
    () =>
      steps
        .filter((s) => s.lessonId === activeLesson?.id)
        .sort((a, b) => a.position - b.position),
    [steps, activeLesson],
  );

  const [stepIdx, setStepIdx] = useState(0);
  const [hearts, setHearts] = useState(5);
  const [sessionXp, setSessionXp] = useState(0);
  const [attemptsOnCurrent, setAttemptsOnCurrent] = useState(0);
  const [showHint, setShowHint] = useState(false);
  const [stepSolved, setStepSolved] = useState(false);
  const [feedback, setFeedback] = useState<{
    correct: boolean;
    title: string;
    detail: string;
  } | null>(null);
  const [lessonFinished, setLessonFinished] = useState(false);

  // Per-step interactive state
  const [microCheckChoice, setMicroCheckChoice] = useState<boolean | null>(null);
  const [clozePick, setClozePick] = useState<string>("");
  const [assembledTokens, setAssembledTokens] = useState<string[]>([]);
  const [trapRejectedMessage, setTrapRejectedMessage] = useState<string | null>(
    null,
  );
  const [selectedFlawedIdx, setSelectedFlawedIdx] = useState<number | null>(
    null,
  );
  const [selectedFixIdx, setSelectedFixIdx] = useState<number | null>(null);
  const [subStepAnswers, setSubStepAnswers] = useState<Record<number, number>>(
    {},
  );
  const [konkurChoice, setKonkurChoice] = useState<number | null>(null);
  const [showEliminationShortcut, setShowEliminationShortcut] = useState(false);
  const [timerSec, setTimerSec] = useState(45);

  const currentStep = lessonSteps[stepIdx];
  const content = currentStep?.content;

  // Reset state when switching lesson or step
  useEffect(() => {
    setAttemptsOnCurrent(0);
    setShowHint(false);
    setStepSolved(false);
    setFeedback(null);
    setMicroCheckChoice(null);
    setClozePick("");
    setAssembledTokens([]);
    setTrapRejectedMessage(null);
    setSelectedFlawedIdx(null);
    setSelectedFixIdx(null);
    setSubStepAnswers({});
    setKonkurChoice(null);
    setShowEliminationShortcut(false);
    if (content?.kind === "konkur_test") {
      setTimerSec(content.targetTimeSeconds || 45);
    }
  }, [stepIdx, activeLesson?.id, content?.kind]);

  // Countdown timer for final Konkur test step
  useEffect(() => {
    if (content?.kind !== "konkur_test" || stepSolved) return;
    const interval = setInterval(() => {
      setTimerSec((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(interval);
  }, [content?.kind, stepSolved]);

  // Build shuffled pool for token_assembly
  const tokenPool = useMemo(() => {
    if (!content || content.kind !== "token_assembly") return [];
    const combined = [
      ...content.orderedTokens.map((t) => ({
        token: t,
        isDistractor: false,
        trapReason: "",
      })),
      ...content.distractorTokens.map((d) => ({
        token: d.token,
        isDistractor: true,
        trapReason: d.trapReason,
      })),
    ];
    // Deterministic shuffle based on token length so hydration is stable
    return [...combined].sort(
      (a, b) => (a.token.length * 13) % 7 - ((b.token.length * 17) % 7),
    );
  }, [content]);

  if (!activeLesson || !currentStep || !content) {
    return (
      <div className="rounded-2xl border border-slate-800 bg-slate-900 p-8 text-center text-slate-300">
        در حال بارگذاری درسنامه‌های میمو-کنکور...
      </div>
    );
  }

  const attachedConcept = activeLesson.pedagogicalBlueprint.atomicConcepts.find(
    (c) => c.id === currentStep.conceptNodeId,
  );

  async function markCurrentStepSolved(
    title: string,
    detail: string,
    attemptNum: number,
  ) {
    setStepSolved(true);
    setFeedback({ correct: true, title, detail });
    const earned = attemptNum === 1 ? 10 : 5;
    setSessionXp((x) => x + earned);
    await onStepComplete({
      stepId: currentStep.id,
      lessonId: activeLesson.id,
      correctFirstTry: attemptNum === 1,
      attempts: attemptNum,
      xpEarned: earned,
    });
  }

  function registerMistake(title: string, detail: string) {
    setHearts((h) => Math.max(1, h - 1));
    setFeedback({ correct: false, title, detail });
  }

  function handleCheckStep() {
    if (!content) return;
    const nextAttempt = attemptsOnCurrent + 1;
    setAttemptsOnCurrent(nextAttempt);

    if (content.kind === "concept_bite") {
      if (microCheckChoice === null) return;
      if (microCheckChoice === content.interactiveCheckAnswer) {
        markCurrentStepSolved(
          "مفهوم پایه تثبیت شد! (+۱۰ XP)",
          content.interactiveCheckExplanation,
          nextAttempt,
        );
      } else {
        registerMistake(
          "دوباره به قید طلایی کارت دقت کن!",
          content.interactiveCheckExplanation,
        );
      }
      return;
    }

    if (content.kind === "guided_cloze") {
      if (!clozePick) return;
      if (clozePick === content.correctAnswer) {
        markCurrentStepSolved(
          "قید کنکوری دقیقاً در جای درست قفل شد! (+۱۰ XP)",
          content.deepExplanation,
          nextAttempt,
        );
      } else {
        registerMistake(
          "تله قیدی! این گزینه با نص کتاب درسی تضاد دارد.",
          nextAttempt >= 2
            ? `پاسخ صحیح «${content.correctAnswer}» است: ${content.deepExplanation}`
            : `راهنمایی: ${content.nudgeHint}`,
        );
      }
      return;
    }

    if (content.kind === "token_assembly") {
      const target = content.orderedTokens;
      if (assembledTokens.length < target.length) {
        registerMistake(
          "زنجیره هنوز کامل نیست!",
          `باید تمام ${target.length} مرحله اصلی را به ترتیب در کادر بالا بچینید.`,
        );
        return;
      }
      const isExactOrder = target.every((t, i) => assembledTokens[i] === t);
      if (isExactOrder) {
        markCurrentStepSolved(
          "چیدمان بلوکی مکانیزم/فرمول با موفقیت کامپایل شد! (+۱۰ XP)",
          content.assemblyExplanation,
          nextAttempt,
        );
      } else {
        registerMistake(
          "ترتیب تقدم و تاخر بلوک‌ها نادرست است!",
          `راهنمایی: ${content.nudgeHint}`,
        );
      }
      return;
    }

    if (content.kind === "trap_detector") {
      if (selectedFlawedIdx === null) return;
      if (selectedFlawedIdx !== content.flawedSegmentIndex) {
        registerMistake(
          "این بخش کاملاً منطبق بر کتاب درسی است و باگ ندارد!",
          "دوباره بخش‌های دیگر را بررسی کنید؛ دنبال قید مطلق، نام آنزیم/متغیر جابه‌جاشده یا خطای علامت بگردید.",
        );
        return;
      }
      if (selectedFixIdx === null) {
        setFeedback({
          correct: false,
          title: "بخش باگ‌دار را درست پیدا کردید! حالا اصلاحیه صحیح را انتخاب کنید.",
          detail: `نوع تله شناسایی‌شده: ${content.trapCategory}`,
        });
        return;
      }
      if (selectedFixIdx === content.correctFixIndex) {
        markCurrentStepSolved(
          "تله طراح کنکور با موفقیت دیباگ و خنثی شد! (+۱۰ XP)",
          content.diagnosticAutopsy,
          nextAttempt,
        );
      } else {
        registerMistake(
          "بخش معیوب را درست یافتید، اما اصلاحیه انتخابی نادرست است.",
          content.diagnosticAutopsy,
        );
      }
      return;
    }

    if (content.kind === "step_solver") {
      const allAnswered = content.subSteps.every(
        (_, i) => subStepAnswers[i] !== undefined,
      );
      if (!allAnswered) return;
      const allCorrect = content.subSteps.every(
        (sub, i) => subStepAnswers[i] === sub.correctIndex,
      );
      if (allCorrect) {
        markCurrentStepSolved(
          "حل پله‌ای با موفقیت کامل شد! آماده تست نهایی هستید (+۱۰ XP)",
          content.finalTakeaway,
          nextAttempt,
        );
      } else {
        registerMistake(
          "یکی از زیرگام‌های استدلال نیاز به اصلاح دارد.",
          "بازخورد هر گام را بررسی کرده و گزینه منطبق بر شرط مرزی را انتخاب کنید.",
        );
      }
      return;
    }

    if (content.kind === "konkur_test") {
      if (konkurChoice === null) return;
      if (konkurChoice === content.correctIndex) {
        markCurrentStepSolved(
          "تست استاندارد کنکور را با موفقیت فتح کردید! (+۱۵ XP)",
          content.eliminationShortcut,
          nextAttempt,
        );
      } else {
        const pickedDiag = content.optionDiagnostics.find(
          (d) => d.optionIndex === konkurChoice,
        );
        registerMistake(
          `در دام افتادید: ${pickedDiag?.trapOrMisconceptionLabel ?? "گزینه انحرافی"}`,
          pickedDiag?.detailedAnalysis ?? content.eliminationShortcut,
        );
      }
    }
  }

  function handleNextStep() {
    if (stepIdx < lessonSteps.length - 1) {
      setStepIdx((i) => i + 1);
    } else {
      setLessonFinished(true);
    }
  }

  function handleTapToken(item: {
    token: string;
    isDistractor: boolean;
    trapReason: string;
  }) {
    if (stepSolved) return;
    if (item.isDistractor) {
      setHearts((h) => Math.max(1, h - 1));
      setTrapRejectedMessage(
        `⛔ بلوک تله طراح شناسایی شد! «${item.token}» — دلیل خطا: ${item.trapReason}`,
      );
      return;
    }
    setTrapRejectedMessage(null);
    if (!assembledTokens.includes(item.token)) {
      setAssembledTokens((prev) => [...prev, item.token]);
    }
  }

  const meta = STEP_TYPE_META[currentStep.type] ?? STEP_TYPE_META.concept_bite;

  return (
    <div className="space-y-6">
      {/* Top Course & Lesson Selector Strip */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-4 shadow-xl">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-semibold text-slate-400">
              انتخاب مبحث کنکوری (۴ درس استاندارد + درس‌های کامپایل‌شده ایجنت):
            </span>
            {lessons.map((l) => {
              const c = courses.find((cr) => cr.id === l.courseId);
              const isSelected = l.id === activeLesson.id;
              return (
                <button
                  key={l.id}
                  type="button"
                  onClick={() => {
                    onSelectLesson(l.id);
                    setStepIdx(0);
                    setLessonFinished(false);
                  }}
                  className={`flex items-center gap-2 rounded-xl border px-3.5 py-2 text-xs font-bold transition-all ${
                    isSelected
                      ? "border-emerald-400 bg-emerald-500/20 text-emerald-200 shadow-lg shadow-emerald-950/50"
                      : "border-slate-700 bg-slate-800/70 text-slate-300 hover:border-slate-500"
                  }`}
                >
                  <span>{c?.icon ?? "📘"}</span>
                  <span>{l.title}</span>
                  <span className="rounded-md bg-slate-950/70 px-1.5 py-0.5 text-[10px] text-emerald-400">
                    عیار: {l.qualityAudit.overallScore}/100
                  </span>
                </button>
              );
            })}
          </div>
          <button
            type="button"
            onClick={() => onOpenGuardrailEditor(activeLesson.id)}
            className="flex items-center gap-1.5 rounded-xl border border-indigo-500/40 bg-indigo-500/15 px-3 py-2 text-xs font-semibold text-indigo-300 hover:bg-indigo-500/25"
          >
            <Cpu className="h-3.5 w-3.5" />
            <span>بازرسی فرم گاردریل این درس</span>
          </button>
        </div>
      </div>

      {lessonFinished ? (
        <div className="rounded-3xl border border-emerald-500/40 bg-gradient-to-b from-emerald-950/60 to-slate-900 p-8 text-center shadow-2xl">
          <div className="mx-auto mb-4 flex h-20 w-20 items-center justify-center rounded-3xl bg-emerald-500/20 text-emerald-300 ring-2 ring-emerald-400/40">
            <Award className="h-10 w-10" />
          </div>
          <h2 className="text-2xl font-black text-white">
            تبریک! چرخه ۶ گامی میمو-کنکور کامل شد 🎉
          </h2>
          <p className="mx-auto mt-2 max-w-xl text-sm leading-7 text-slate-300">
            شما مبحث «{activeLesson.title}» را از سطح ۱ (درک شهودی و قیدگذاری) تا
            سطح ۶ (تست زمان‌دار کنکور با کالبدشکافی ۴ گزینه) با موفقیت به پایان
            رساندید.
          </p>
          <div className="mx-auto mt-6 grid max-w-lg grid-cols-3 gap-3">
            <div className="rounded-2xl border border-slate-700 bg-slate-900/90 p-4">
              <div className="text-xs text-slate-400">امتیاز کسب‌شده</div>
              <div className="mt-1 text-xl font-black text-amber-400">
                +{sessionXp + activeLesson.xpReward} XP
              </div>
            </div>
            <div className="rounded-2xl border border-slate-700 bg-slate-900/90 p-4">
              <div className="text-xs text-slate-400">جان باقی‌مانده</div>
              <div className="mt-1 text-xl font-black text-rose-400">
                {hearts} / 5 ❤️
              </div>
            </div>
            <div className="rounded-2xl border border-slate-700 bg-slate-900/90 p-4">
              <div className="text-xs text-slate-400">عیار پداگوژیک درس</div>
              <div className="mt-1 text-xl font-black text-emerald-400">
                {activeLesson.qualityAudit.overallScore}/100
              </div>
            </div>
          </div>
          <div className="mt-6 flex justify-center gap-3">
            <button
              type="button"
              onClick={() => {
                setStepIdx(0);
                setLessonFinished(false);
                setHearts(5);
              }}
              className="flex items-center gap-2 rounded-xl bg-emerald-500 px-6 py-3 text-sm font-bold text-slate-950 hover:bg-emerald-400"
            >
              <RotateCcw className="h-4 w-4" />
              <span>مرور دوباره این درسنامه</span>
            </button>
          </div>
        </div>
      ) : (
        <div className="grid gap-6 lg:grid-cols-12">
          {/* Main Mimo Interactive Player Column (7 cols) */}
          <div className="lg:col-span-7">
            <div className="overflow-hidden rounded-3xl border border-slate-700/80 bg-slate-900 shadow-2xl">
              {/* Mimo Top Status Header: Progress Segments + Hearts + Streak + XP */}
              <div className="border-b border-slate-800 bg-slate-950/90 px-5 py-4">
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <span className="text-xl">{activeCourse?.icon ?? "🧬"}</span>
                    <div>
                      <div className="text-xs font-bold text-slate-400">
                        {activeLesson.chapterReference}
                      </div>
                      <h2 className="text-sm font-extrabold text-white">
                        {activeLesson.title}
                      </h2>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 text-xs font-bold">
                    <span className="flex items-center gap-1 rounded-full bg-rose-500/15 px-2.5 py-1 text-rose-400">
                      <Heart className="h-3.5 w-3.5 fill-rose-500 text-rose-500" />
                      {hearts}
                    </span>
                    <span className="flex items-center gap-1 rounded-full bg-amber-500/15 px-2.5 py-1 text-amber-300">
                      <Flame className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
                      ۷ روز
                    </span>
                    <span className="flex items-center gap-1 rounded-full bg-emerald-500/15 px-2.5 py-1 text-emerald-300">
                      <Zap className="h-3.5 w-3.5" />
                      {sessionXp} XP
                    </span>
                  </div>
                </div>

                {/* Segmented Progress Bar (6 Mimo Steps) */}
                <div className="mt-4 grid grid-cols-6 gap-1.5">
                  {lessonSteps.map((s, idx) => (
                    <button
                      key={s.id}
                      type="button"
                      onClick={() => setStepIdx(idx)}
                      className="group text-right focus:outline-none"
                      title={`گام ${idx + 1}: ${STEP_TYPE_META[s.type]?.label ?? s.type}`}
                    >
                      <div
                        className={`h-2.5 w-full rounded-full transition-all ${
                          idx < stepIdx
                            ? "bg-emerald-400"
                            : idx === stepIdx
                              ? "bg-indigo-400 ring-2 ring-indigo-400/40"
                              : "bg-slate-800 group-hover:bg-slate-700"
                        }`}
                      />
                      <div className="mt-1 truncate text-[10px] font-semibold text-slate-400">
                        گام {idx + 1} (سطح {s.scaffoldingLevel})
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Step Modality Badge Bar */}
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800/80 bg-slate-900/60 px-5 py-2.5">
                <span
                  className={`inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-1 text-xs font-bold ${meta.badgeColor}`}
                >
                  <Sparkles className="h-3.5 w-3.5" />
                  {meta.label}
                </span>
                <span className="text-[11px] font-medium text-slate-400">
                  {meta.mimoOrigin}
                </span>
              </div>

              {/* Interactive Step Body */}
              <div className="space-y-5 p-6">
                {/* 1. CONCEPT BITE */}
                {content.kind === "concept_bite" && (
                  <div className="space-y-4">
                    <h3 className="text-lg font-black text-white">
                      {content.title}
                    </h3>

                    {/* Hook Analogy Box */}
                    <div className="rounded-2xl border border-amber-500/30 bg-amber-500/10 p-4">
                      <div className="mb-1 flex items-center gap-1.5 text-xs font-extrabold text-amber-300">
                        <Lightbulb className="h-4 w-4" />
                        <span>قلاب شهودی (Mental Model Hook):</span>
                      </div>
                      <p className="text-xs leading-6 text-amber-100/90">
                        {content.hookAnalogy}
                      </p>
                    </div>

                    {/* Bite-sized Markdown Body */}
                    <div className="rounded-2xl border border-slate-800 bg-slate-950/70 p-4 text-sm leading-8 text-slate-200 whitespace-pre-line">
                      {content.bodyMarkdown}
                    </div>

                    {/* Highlighted Modifiers */}
                    {content.highlightedModifiers.length > 0 && (
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-xs font-bold text-slate-400">
                          قیدها و کلیدواژه‌های حساس کنکور:
                        </span>
                        {content.highlightedModifiers.map((m, i) => (
                          <span
                            key={i}
                            className="rounded-lg border border-emerald-500/40 bg-emerald-500/15 px-2.5 py-1 text-xs font-bold text-emerald-300"
                          >
                            🔍 {m}
                          </span>
                        ))}
                      </div>
                    )}

                    {/* Core Formula / Rule Box */}
                    <div className="rounded-xl border border-indigo-500/30 bg-indigo-950/40 px-4 py-3 text-xs font-bold text-indigo-200">
                      ⚡ قاعده فشرده: {content.coreFormulaOrRule}
                    </div>

                    {/* Mandatory Anti-Passive-Scroll Micro-Check */}
                    <div className="rounded-2xl border border-slate-700 bg-slate-800/60 p-4">
                      <div className="mb-2 flex items-center justify-between">
                        <span className="text-xs font-extrabold text-sky-300">
                          🔒 قفل ضداسکرول میمو (برای باز شدن گام بعد پاسخ دهید):
                        </span>
                        <span className="text-[11px] text-slate-400">
                          بار شناختی: {currentStep.cognitiveLoadWords} کلمه (استاندارد ≤ ۸۵)
                        </span>
                      </div>
                      <p className="mb-3 text-sm font-bold text-white">
                        {content.interactiveCheckQuestion}
                      </p>
                      <div className="grid grid-cols-2 gap-3">
                        {[
                          { val: true, label: "بله، کاملاً صحیح است" },
                          { val: false, label: "خیر، نادرست / تله کنکوری است" },
                        ].map((opt) => (
                          <button
                            key={String(opt.val)}
                            type="button"
                            disabled={stepSolved}
                            onClick={() => setMicroCheckChoice(opt.val)}
                            className={`rounded-xl border px-4 py-3 text-xs font-bold transition-all ${
                              microCheckChoice === opt.val
                                ? "border-sky-400 bg-sky-500/20 text-white ring-2 ring-sky-400/30"
                                : "border-slate-700 bg-slate-900 text-slate-300 hover:border-slate-500"
                            }`}
                          >
                            {opt.label}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {/* 2. GUIDED CLOZE */}
                {content.kind === "guided_cloze" && (
                  <div className="space-y-4">
                    <p className="text-sm font-bold text-slate-200">
                      {content.prompt}
                    </p>

                    {/* Statement with Interactive Slot */}
                    <div className="rounded-2xl border border-sky-500/30 bg-slate-950 p-5 text-sm leading-9 text-white">
                      {content.templateWithBlank.split("___").map((part, i, arr) => (
                        <React.Fragment key={i}>
                          <span>{part}</span>
                          {i < arr.length - 1 && (
                            <span
                              className={`mx-1.5 inline-flex min-w-[130px] items-center justify-center rounded-xl border-2 px-3 py-1 font-extrabold transition-all ${
                                clozePick
                                  ? "border-sky-400 bg-sky-500/20 text-sky-200"
                                  : "border-dashed border-slate-600 bg-slate-900 text-slate-500"
                              }`}
                            >
                              {clozePick || "؟ قید را انتخاب کنید"}
                            </span>
                          )}
                        </React.Fragment>
                      ))}
                    </div>

                    {/* Mimo-style Word Chips */}
                    <div>
                      <div className="mb-2 text-xs font-semibold text-slate-400">
                        یکی از چیپ‌های قیدی زیر را برای قرار گرفتن در جای خالی لمس کنید:
                      </div>
                      <div className="grid grid-cols-2 gap-2.5">
                        {content.chipOptions.map((chip) => (
                          <button
                            key={chip}
                            type="button"
                            disabled={stepSolved}
                            onClick={() => setClozePick(chip)}
                            className={`rounded-xl border px-4 py-3 text-right text-xs font-bold transition-all ${
                              clozePick === chip
                                ? "border-sky-400 bg-sky-500/25 text-white ring-2 ring-sky-400/30"
                                : "border-slate-700 bg-slate-800/80 text-slate-200 hover:border-slate-500"
                            }`}
                          >
                            {chip}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {/* 3. TOKEN ASSEMBLY (Mimo Code Equivalent) */}
                {content.kind === "token_assembly" && (
                  <div className="space-y-4">
                    <p className="text-sm font-bold text-slate-200">
                      {content.prompt}
                    </p>

                    {/* Assembled Slot Box */}
                    <div className="min-h-[150px] rounded-2xl border-2 border-dashed border-violet-500/40 bg-slate-950/90 p-4">
                      <div className="mb-2 flex items-center justify-between text-xs text-slate-400">
                        <span className="font-bold text-violet-300">
                          🧩 محیط کامپایل زنجیره ({assembledTokens.length} از{" "}
                          {content.orderedTokens.length} بلوک چیده شده):
                        </span>
                        {assembledTokens.length > 0 && !stepSolved && (
                          <button
                            type="button"
                            onClick={() => setAssembledTokens([])}
                            className="text-rose-400 hover:underline"
                          >
                            پاک کردن چیدمان
                          </button>
                        )}
                      </div>

                      {assembledTokens.length === 0 ? (
                        <div className="flex h-24 items-center justify-center text-xs text-slate-500">
                          روی بلوک‌های پایین به ترتیب صحیح علمی کلیک کنید تا زنجیره ساخته شود...
                        </div>
                      ) : (
                        <div className="space-y-2">
                          {assembledTokens.map((tok, i) => (
                            <div
                              key={tok}
                              className="flex items-center justify-between rounded-xl border border-violet-500/40 bg-violet-500/15 px-3.5 py-2.5 text-xs font-bold text-violet-100"
                            >
                              <span>
                                گام {i + 1}: {tok}
                              </span>
                              {!stepSolved && (
                                <button
                                  type="button"
                                  onClick={() =>
                                    setAssembledTokens((prev) =>
                                      prev.filter((t) => t !== tok),
                                    )
                                  }
                                  className="text-rose-300 hover:text-rose-200"
                                >
                                  حذف ×
                                </button>
                              )}
                            </div>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Distractor Trap Alert */}
                    {trapRejectedMessage && (
                      <div className="rounded-xl border border-rose-500/40 bg-rose-950/50 p-3 text-xs leading-6 text-rose-200">
                        {trapRejectedMessage}
                      </div>
                    )}

                    {/* Available Token Pool */}
                    <div>
                      <div className="mb-2 text-xs font-semibold text-slate-400">
                        بانک بلوک‌ها (شامل {content.orderedTokens.length} بلوک صحیح +{" "}
                        {content.distractorTokens.length} بلوک تله طراح کنکور):
                      </div>
                      <div className="grid gap-2">
                        {tokenPool.map((item) => {
                          const alreadyUsed = assembledTokens.includes(
                            item.token,
                          );
                          return (
                            <button
                              key={item.token}
                              type="button"
                              disabled={alreadyUsed || stepSolved}
                              onClick={() => handleTapToken(item)}
                              className={`rounded-xl border px-4 py-3 text-right text-xs font-bold transition-all ${
                                alreadyUsed
                                  ? "border-slate-800 bg-slate-900/40 text-slate-600 opacity-50"
                                  : "border-slate-700 bg-slate-800/90 text-slate-200 hover:border-violet-400 hover:bg-slate-800"
                              }`}
                            >
                              + {item.token}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                )}

                {/* 4. TRAP DETECTOR (Mimo Code Debugger Equivalent) */}
                {content.kind === "trap_detector" && (
                  <div className="space-y-4">
                    <p className="text-sm font-bold text-slate-200">
                      {content.prompt}
                    </p>

                    <div className="space-y-2.5">
                      <div className="text-xs font-semibold text-amber-300">
                        مرحله اول: روی سطر یا بخشی که حاوی «باگ علمی / تله طراح کنکور» است کلیک کنید:
                      </div>
                      {content.segments.map((seg, idx) => {
                        const isPicked = selectedFlawedIdx === idx;
                        return (
                          <button
                            key={idx}
                            type="button"
                            disabled={stepSolved}
                            onClick={() => {
                              setSelectedFlawedIdx(idx);
                              setSelectedFixIdx(null);
                            }}
                            className={`w-full rounded-xl border p-3.5 text-right text-xs font-bold leading-6 transition-all ${
                              isPicked
                                ? "border-amber-400 bg-amber-500/20 text-amber-100 ring-2 ring-amber-400/30"
                                : "border-slate-700 bg-slate-950/80 text-slate-200 hover:border-slate-500"
                            }`}
                          >
                            <span className="ml-2 inline-block rounded bg-slate-800 px-2 py-0.5 text-[10px] text-slate-400">
                              قطعه {idx + 1}
                            </span>
                            {seg}
                          </button>
                        );
                      })}
                    </div>

                    {selectedFlawedIdx === content.flawedSegmentIndex && (
                      <div className="space-y-2.5 rounded-2xl border border-amber-500/40 bg-amber-950/20 p-4">
                        <div className="text-xs font-extrabold text-amber-300">
                          🎯 آفرین! قطعه باگ‌دار ({content.trapCategory}) شکار شد! حالا مرحله دوم: اصلاحیه درست را انتخاب کنید:
                        </div>
                        {content.fixOptions.map((fix, fIdx) => (
                          <button
                            key={fIdx}
                            type="button"
                            disabled={stepSolved}
                            onClick={() => setSelectedFixIdx(fIdx)}
                            className={`w-full rounded-xl border p-3 text-right text-xs font-bold leading-6 transition-all ${
                              selectedFixIdx === fIdx
                                ? "border-emerald-400 bg-emerald-500/20 text-white"
                                : "border-slate-700 bg-slate-900 text-slate-300 hover:border-slate-500"
                            }`}
                          >
                            {fix}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                {/* 5. STEP SOLVER */}
                {content.kind === "step_solver" && (
                  <div className="space-y-4">
                    <div className="rounded-2xl border border-fuchsia-500/30 bg-fuchsia-950/20 p-4 text-sm font-bold leading-7 text-fuchsia-100">
                      {content.problemStatement}
                    </div>

                    {content.subSteps.map((sub, sIdx) => {
                      const prevDone =
                        sIdx === 0 || subStepAnswers[sIdx - 1] !== undefined;
                      if (!prevDone) return null;
                      const picked = subStepAnswers[sIdx];
                      return (
                        <div
                          key={sIdx}
                          className="space-y-3 rounded-2xl border border-slate-700 bg-slate-950/80 p-4"
                        >
                          <div className="text-xs font-extrabold text-fuchsia-300">
                            {sub.stageLabel}
                          </div>
                          <p className="text-xs font-bold leading-6 text-white">
                            {sub.question}
                          </p>
                          <div className="space-y-2">
                            {sub.options.map((opt, oIdx) => (
                              <button
                                key={oIdx}
                                type="button"
                                disabled={stepSolved}
                                onClick={() =>
                                  setSubStepAnswers((prev) => ({
                                    ...prev,
                                    [sIdx]: oIdx,
                                  }))
                                }
                                className={`w-full rounded-xl border p-3 text-right text-xs font-bold transition-all ${
                                  picked === oIdx
                                    ? "border-fuchsia-400 bg-fuchsia-500/20 text-white"
                                    : "border-slate-800 bg-slate-900 text-slate-300 hover:border-slate-600"
                                }`}
                              >
                                {opt}
                              </button>
                            ))}
                          </div>
                          {picked === sub.correctIndex && (
                            <div className="rounded-lg bg-emerald-500/15 px-3 py-2 text-xs text-emerald-300">
                              ✓ {sub.microFeedback}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}

                {/* 6. KONKUR TEST (4-Option + Diagnostics + Elimination Shortcut) */}
                {content.kind === "konkur_test" && (
                  <div className="space-y-4">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <span className="rounded-lg bg-rose-500/20 px-2.5 py-1 text-xs font-bold text-rose-300">
                        🎯 {content.sourceBadge}
                      </span>
                      <span
                        className={`flex items-center gap-1 rounded-lg px-2.5 py-1 text-xs font-extrabold ${
                          timerSec <= 10
                            ? "bg-rose-600 text-white animate-pulse"
                            : "bg-slate-800 text-amber-300"
                        }`}
                      >
                        <Clock className="h-3.5 w-3.5" />
                        زمان استاندارد: {timerSec} ثانیه
                      </span>
                    </div>

                    <div className="rounded-2xl border border-slate-700 bg-slate-950 p-4 text-sm font-bold leading-8 text-white">
                      {content.questionStem}
                    </div>

                    <div className="space-y-2.5">
                      {content.options.map((opt, oIdx) => {
                        const isPicked = konkurChoice === oIdx;
                        const diag = content.optionDiagnostics.find(
                          (d) => d.optionIndex === oIdx,
                        );
                        return (
                          <div key={oIdx} className="space-y-1.5">
                            <button
                              type="button"
                              disabled={stepSolved}
                              onClick={() => setKonkurChoice(oIdx)}
                              className={`w-full rounded-xl border p-3.5 text-right text-xs font-bold leading-6 transition-all ${
                                stepSolved && oIdx === content.correctIndex
                                  ? "border-emerald-400 bg-emerald-500/20 text-emerald-100"
                                  : isPicked
                                    ? "border-rose-400 bg-rose-500/20 text-white ring-2 ring-rose-400/30"
                                    : "border-slate-700 bg-slate-800/80 text-slate-200 hover:border-slate-500"
                              }`}
                            >
                              <span className="ml-2 inline-flex h-5 w-5 items-center justify-center rounded-md bg-slate-950 text-[11px] font-black text-slate-300">
                                {oIdx + 1}
                              </span>
                              {opt}
                            </button>

                            {/* Show 4-Option Diagnostic Autopsy once answered */}
                            {(stepSolved || feedback) && diag && (
                              <div
                                className={`rounded-xl border px-3.5 py-2.5 text-[11px] leading-6 ${
                                  diag.isCorrect
                                    ? "border-emerald-500/30 bg-emerald-950/30 text-emerald-200"
                                    : "border-slate-800 bg-slate-950/70 text-slate-400"
                                }`}
                              >
                                <span className="font-extrabold">
                                  {diag.isCorrect ? "✅ " : "⚠️ "}
                                  {diag.trapOrMisconceptionLabel}:{" "}
                                </span>
                                {diag.detailedAnalysis}
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>

                    {/* Shortcut Elimination Technique Toggle */}
                    <div className="pt-1">
                      <button
                        type="button"
                        onClick={() =>
                          setShowEliminationShortcut((prev) => !prev)
                        }
                        className="flex items-center gap-1.5 text-xs font-bold text-amber-300 hover:text-amber-200"
                      >
                        <Zap className="h-3.5 w-3.5" />
                        <span>
                          {showEliminationShortcut
                            ? "بستن تکنیک سرعتی رد گزینه"
                            : "مشاهده تکنیک سرعتی رد گزینه زیر ۲۰ ثانیه"}
                        </span>
                      </button>
                      {showEliminationShortcut && (
                        <div className="mt-2 rounded-xl border border-amber-500/30 bg-amber-950/30 p-3 text-xs leading-6 text-amber-200">
                          ⚡ {content.eliminationShortcut}
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Hint Drawer for Guided Cloze & Token Assembly */}
                {(content.kind === "guided_cloze" ||
                  content.kind === "token_assembly") && (
                  <div>
                    <button
                      type="button"
                      onClick={() => setShowHint((h) => !h)}
                      className="flex items-center gap-1 text-xs font-semibold text-indigo-300 hover:text-indigo-200"
                    >
                      <HelpCircle className="h-3.5 w-3.5" />
                      <span>
                        {showHint
                          ? "بستن راهنمای لایه اول"
                          : "نیاز به راهنمای لایه اول (بدون لو رفتن جواب) دارید؟"}
                      </span>
                    </button>
                    {showHint && (
                      <div className="mt-2 rounded-xl border border-indigo-500/30 bg-indigo-950/40 p-3 text-xs text-indigo-200">
                        💡 {content.nudgeHint}
                      </div>
                    )}
                  </div>
                )}

                {/* Feedback Banner */}
                {feedback && (
                  <div
                    className={`rounded-2xl border p-4 ${
                      feedback.correct
                        ? "border-emerald-500/40 bg-emerald-950/40 text-emerald-100"
                        : "border-rose-500/40 bg-rose-950/40 text-rose-100"
                    }`}
                  >
                    <div className="flex items-center gap-2 text-sm font-black">
                      {feedback.correct ? (
                        <CheckCircle2 className="h-5 w-5 text-emerald-400" />
                      ) : (
                        <XCircle className="h-5 w-5 text-rose-400" />
                      )}
                      <span>{feedback.title}</span>
                    </div>
                    <p className="mt-1.5 text-xs leading-6 opacity-90">
                      {feedback.detail}
                    </p>
                  </div>
                )}
              </div>

              {/* Mimo Bottom Action Bar */}
              <div className="flex items-center justify-between border-t border-slate-800 bg-slate-950/90 px-6 py-4">
                <button
                  type="button"
                  disabled={stepIdx === 0}
                  onClick={() => setStepIdx((i) => Math.max(0, i - 1))}
                  className="flex items-center gap-1.5 rounded-xl border border-slate-700 bg-slate-900 px-3.5 py-2.5 text-xs font-bold text-slate-300 disabled:opacity-40"
                >
                  <ArrowRight className="h-4 w-4" />
                  <span>گام قبلی</span>
                </button>

                <div className="flex items-center gap-2">
                  {!stepSolved ? (
                    <button
                      type="button"
                      onClick={handleCheckStep}
                      className="flex items-center gap-2 rounded-xl bg-emerald-500 px-6 py-2.5 text-xs font-black text-slate-950 shadow-lg shadow-emerald-950/50 transition hover:bg-emerald-400"
                    >
                      <CheckCircle2 className="h-4 w-4" />
                      <span>بررسی و ثبت پاسخ</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={handleNextStep}
                      className="flex items-center gap-2 rounded-xl bg-indigo-500 px-6 py-2.5 text-xs font-black text-white shadow-lg shadow-indigo-950/50 transition hover:bg-indigo-400"
                    >
                      <span>
                        {stepIdx === lessonSteps.length - 1
                          ? "اتمام درس و دریافت پاداش"
                          : "ادامه به گام بعدی"}
                      </span>
                      <ArrowLeft className="h-4 w-4" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Live Pedagogical X-Ray & Blueprint Inspector (5 cols) */}
          <div className="space-y-4 lg:col-span-5">
            <div className="rounded-3xl border border-slate-800 bg-slate-900/90 p-5 shadow-xl">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <Layers className="h-5 w-5 text-emerald-400" />
                  <h3 className="text-sm font-black text-white">
                    اشعه ایکس پداگوژیک گام فعلی (Agent X-Ray)
                  </h3>
                </div>
                <span className="rounded-lg bg-emerald-500/15 px-2.5 py-1 text-xs font-black text-emerald-300">
                  عیار درس: {activeLesson.qualityAudit.overallScore}/100
                </span>
              </div>

              <div className="mt-4 space-y-3 text-xs">
                {/* Connected Atomic Concept Node */}
                <div className="rounded-2xl border border-slate-800 bg-slate-950/80 p-3.5">
                  <div className="text-[11px] font-bold text-slate-400">
                    گره مفهومی متصل در گراف دانشی (Concept Node Lock):
                  </div>
                  <div className="mt-1 font-extrabold text-emerald-300">
                    [{currentStep.conceptNodeId}] {attachedConcept?.title}
                  </div>
                  <div className="mt-1.5 text-[11px] leading-5 text-slate-400">
                    نقل‌قول مستقیم کتاب درسی: «{attachedConcept?.textbookQuote}»
                  </div>
                </div>

                {/* Missing Link Explanation */}
                <div className="rounded-2xl border border-violet-500/30 bg-violet-950/20 p-3.5">
                  <div className="flex items-center gap-1.5 font-extrabold text-violet-300">
                    <Target className="h-4 w-4" />
                    <span>پر کردن حلقه مفقوده میمو ↔ کنکور در این درس:</span>
                  </div>
                  <p className="mt-1.5 leading-6 text-slate-300">
                    <strong className="text-white">مکانیک هم‌ریخت: </strong>
                    {
                      activeLesson.pedagogicalBlueprint.missingLinkMapping
                        .konkurIsomorphicMechanic
                    }
                  </p>
                  <p className="mt-1 text-[11px] leading-5 text-slate-400">
                    {
                      activeLesson.pedagogicalBlueprint.missingLinkMapping
                        .bridgingRationale
                    }
                  </p>
                </div>

                {/* Extracted Modifiers & Formulas */}
                <div className="rounded-2xl border border-slate-800 bg-slate-950/80 p-3.5">
                  <div className="mb-2 flex items-center gap-1.5 font-extrabold text-sky-300">
                    <BookOpen className="h-4 w-4" />
                    <span>قیدها، فرمول‌ها و استثنائات استخراج‌شده از کتاب:</span>
                  </div>
                  <div className="space-y-2">
                    {activeLesson.pedagogicalBlueprint.konkurModifiersAndFormulas.map(
                      (mod) => (
                        <div
                          key={mod.id}
                          className="rounded-xl border border-slate-800 bg-slate-900 p-2.5"
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-white">
                              {mod.phrase}
                            </span>
                            <span className="rounded bg-sky-500/15 px-1.5 py-0.5 text-[10px] text-sky-300">
                              {mod.category}
                            </span>
                          </div>
                          <p className="mt-1 text-[11px] leading-5 text-slate-400">
                            {mod.explanation}
                          </p>
                        </div>
                      ),
                    )}
                  </div>
                </div>

                {/* Designer Traps */}
                <div className="rounded-2xl border border-slate-800 bg-slate-950/80 p-3.5">
                  <div className="mb-2 flex items-center gap-1.5 font-extrabold text-amber-300">
                    <ShieldAlert className="h-4 w-4" />
                    <span>ماتریس تله‌های طراح کنکور در این مبحث:</span>
                  </div>
                  <div className="space-y-2">
                    {activeLesson.pedagogicalBlueprint.designerTraps.map(
                      (trap) => (
                        <div
                          key={trap.id}
                          className="rounded-xl border border-slate-800 bg-slate-900 p-2.5"
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-amber-200">
                              {trap.trapTitle}
                            </span>
                            <span className="rounded bg-amber-500/15 px-1.5 py-0.5 text-[10px] text-amber-300">
                              {trap.trapCategory}
                            </span>
                          </div>
                          <div className="mt-1 text-[11px] text-rose-300">
                            ❌ باور غلط رایج: {trap.commonWrongBelief}
                          </div>
                          <div className="mt-0.5 text-[11px] text-emerald-300">
                            ✅ حقیقت کتاب درسی: {trap.scientificTruth}
                          </div>
                        </div>
                      ),
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
