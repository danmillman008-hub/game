"use client";

import React, { useState, useEffect } from "react";
import type { KonkurQuestionItem, ExamQuestionLog } from "@/db/schema";
import {
  Timer,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Award,
  RotateCcw,
  Play,
  ShieldAlert,
  Sparkles,
} from "lucide-react";

export interface KonkurExamData {
  id: number;
  slug: string;
  title: string;
  organizer: string;
  track: string;
  durationMinutes: number;
  negativeMarkingRatio: number;
  questions: KonkurQuestionItem[];
}

export interface ExamSubmissionData {
  id: number;
  examSlug: string;
  examTitle: string;
  organizer: string;
  rawPercent: number;
  withoutNegativePercent: number;
  estimatedTaraz: number;
  correctCount: number;
  wrongCount: number;
  blankCount: number;
  trapFallCount: number;
  timeSpentSec: number;
  questionLogs: ExamQuestionLog[];
  remediationSlugs: string[];
  createdAt: string;
}

interface Props {
  exams: KonkurExamData[];
  submissions: ExamSubmissionData[];
  onRefreshState: () => Promise<void>;
  onLaunchRemediationQuest: (nodeSlug: string) => void;
}

export default function KonkurExamSimulator({
  exams,
  submissions,
  onRefreshState,
  onLaunchRemediationQuest,
}: Props) {
  const activeExam = exams[0];
  const [answers, setAnswers] = useState<Record<string, 1 | 2 | 3 | 4 | null>>({});
  const [flags, setFlags] = useState<
    Record<string, "none" | "doubt" | "time_consuming" | "trap_alert">
  >({});
  const [elapsedSec, setElapsedSec] = useState<number>(0);
  const [timerRunning, setTimerRunning] = useState<boolean>(true);
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [latestResult, setLatestResult] = useState<{
    submission: ExamSubmissionData;
    rankBracket: string;
  } | null>(null);

  useEffect(() => {
    if (!timerRunning || latestResult) return;
    const interval = setInterval(() => {
      setElapsedSec((s) => s + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [timerRunning, latestResult]);

  if (!activeExam) {
    return null;
  }

  const totalSecondsAllowed = activeExam.durationMinutes * 60;
  const remainingSec = Math.max(0, totalSecondsAllowed - elapsedSec);
  const mm = String(Math.floor(remainingSec / 60)).padStart(2, "0");
  const ss = String(remainingSec % 60).padStart(2, "0");

  const toggleBubble = (qId: string, optIndex: 1 | 2 | 3 | 4) => {
    if (latestResult) return;
    setAnswers((prev) => ({
      ...prev,
      [qId]: prev[qId] === optIndex ? null : optIndex,
    }));
  };

  const cycleFlag = (qId: string) => {
    const current = flags[qId] ?? "none";
    const next =
      current === "none"
        ? "doubt"
        : current === "doubt"
          ? "time_consuming"
          : current === "time_consuming"
            ? "trap_alert"
            : "none";
    setFlags((prev) => ({ ...prev, [qId]: next }));
  };

  const handleSubmitExam = async () => {
    setSubmitting(true);
    setTimerRunning(false);
    try {
      const res = await fetch("/api/exams/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          examSlug: activeExam.slug,
          answers,
          flags,
          timeSpentSec: Math.max(30, elapsedSec),
        }),
      });
      const data = await res.json();
      if (data.submission) {
        setLatestResult({
          submission: data.submission,
          rankBracket: data.rankBracket,
        });
      }
      await onRefreshState();
    } finally {
      setSubmitting(false);
    }
  };

  const handleResetExam = () => {
    setAnswers({});
    setFlags({});
    setElapsedSec(0);
    setLatestResult(null);
    setTimerRunning(true);
  };

  const answeredCount = Object.values(answers).filter((v) => v !== null && v !== undefined).length;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      {/* RIGHT SIDEBAR (in RTL): Optical Bubble Sheet (`stitch_8`) + Exam Controls */}
      <div className="lg:col-span-4 space-y-5">
        <div className="bg-white border-2 border-[#1A1C1A] rounded-2xl p-4 shadow-[4px_4px_0px_#1A1C1A] sticky top-4">
          <div className="flex items-center justify-between pb-3 border-b-2 border-[#1A1C1A]">
            <div>
              <div className="text-[11px] font-bold text-[#BC000A]">
                پاسخ‌برگ کلیدی استاندارد کنکور (Stitch #8)
              </div>
              <h3 className="text-sm font-extrabold text-[#1A1C1A]">
                {activeExam.organizer}
              </h3>
            </div>
            <div
              dir="ltr"
              className="flex items-center gap-1.5 bg-[#1A1C1A] text-white px-3 py-1.5 rounded-xl font-mono text-sm font-bold"
            >
              <Timer className="w-4 h-4 text-amber-400" />
              <span>
                {mm}:{ss}
              </span>
            </div>
          </div>

          {/* Formula Banner */}
          <div className="mt-3 bg-[#FAF9F5] border border-[#C7C6CB] rounded-xl p-2.5 text-[11px] flex items-center justify-between">
            <span className="font-bold text-[#1A1C1A]">فرمول نمره منفی یک‌سوم:</span>
            <code dir="ltr" className="font-mono font-bold text-[#BC000A]">
              % = ((3C - W) / 3N) × 100
            </code>
          </div>

          {/* Optical Bubble Grid */}
          <div className="mt-4 space-y-2">
            <div className="grid grid-cols-6 text-[11px] font-mono font-bold text-center text-[#46464B] pb-1 border-b border-[#E2E3DF]">
              <span>سوال</span>
              <span>1</span>
              <span>2</span>
              <span>3</span>
              <span>4</span>
              <span>نشان</span>
            </div>

            {activeExam.questions.map((q) => {
              const sel = answers[q.id] ?? null;
              const flg = flags[q.id] ?? "none";
              const logItem = latestResult?.submission.questionLogs.find(
                (l) => l.questionId === q.id
              );

              return (
                <div
                  key={q.id}
                  className="grid grid-cols-6 items-center text-center py-1.5 px-1 rounded-lg bg-[#FAF9F5] border border-[#E2E3DF]"
                >
                  <span className="font-mono text-xs font-extrabold text-[#1A1C1A]">
                    #{q.number}
                  </span>
                  {([1, 2, 3, 4] as const).map((optIdx) => {
                    const isPicked = sel === optIdx;
                    let bubbleCls =
                      "bg-white text-[#1A1C1A] border-[#1A1C1A] hover:bg-[#E8E8E4]";
                    if (latestResult) {
                      if (optIdx === q.correctOption) {
                        bubbleCls = "bg-[#059669] text-white border-[#059669]";
                      } else if (isPicked && optIdx !== q.correctOption) {
                        bubbleCls = "bg-[#BC000A] text-white border-[#BC000A]";
                      }
                    } else if (isPicked) {
                      bubbleCls = "bg-[#1A1C1A] text-white border-[#1A1C1A]";
                    }

                    return (
                      <div key={optIdx} className="flex justify-center">
                        <button
                          type="button"
                          onClick={() => toggleBubble(q.id, optIdx)}
                          className={`w-7 h-5 rounded-full border text-[11px] font-mono font-bold transition cursor-pointer ${bubbleCls}`}
                        >
                          {optIdx}
                        </button>
                      </div>
                    );
                  })}

                  <button
                    type="button"
                    onClick={() => cycleFlag(q.id)}
                    title="تکنیک ضربدر و منها (شک‌دار / زمان‌بر / تله)"
                    className="text-xs font-bold cursor-pointer"
                  >
                    {flg === "doubt"
                      ? "؟"
                      : flg === "time_consuming"
                        ? "⏱"
                        : flg === "trap_alert"
                          ? "⚠"
                          : logItem?.fellForTrap
                            ? "🪤"
                            : "—"}
                  </button>
                </div>
              );
            })}
          </div>

          <div className="mt-4 pt-3 border-t border-[#E2E3DF] space-y-2.5">
            <div className="flex items-center justify-between text-xs">
              <span className="text-[#46464B]">تعداد پاسخ داده‌شده:</span>
              <span className="font-mono font-bold text-[#1A1C1A]">
                {answeredCount} / {activeExam.questions.length}
              </span>
            </div>

            {!latestResult ? (
              <button
                type="button"
                disabled={submitting}
                onClick={handleSubmitExam}
                className="w-full py-3 rounded-xl bg-[#BC000A] hover:bg-[#930005] text-white text-xs sm:text-sm font-extrabold transition cursor-pointer shadow-[2px_2px_0px_#1A1C1A]"
              >
                {submitting
                  ? "در حال تصحیح اپتیکال و تحلیل تله‌ها..."
                  : "ثبت نهایی پاسخ‌برگ و محاسبه تراز + گراف ترمیم"}
              </button>
            ) : (
              <button
                type="button"
                onClick={handleResetExam}
                className="w-full py-2.5 rounded-xl bg-[#1A1C1A] hover:bg-[#001551] text-white text-xs font-bold flex items-center justify-center gap-2 cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
                <span>شروع آزمون جدید (پاک کردن پاسخ‌برگ)</span>
              </button>
            )}
          </div>

          {/* Historical Exam Submissions Mini-Table */}
          {submissions.length > 0 && (
            <div className="mt-4 pt-3 border-t border-[#E2E3DF]">
              <div className="text-xs font-extrabold text-[#1A1C1A] mb-2">
                کارنامه‌های اخیر ثبت‌شده در دیتابیس:
              </div>
              <div className="space-y-1.5 max-h-40 overflow-y-auto">
                {submissions.map((sub) => (
                  <div
                    key={sub.id}
                    className="flex items-center justify-between text-[11px] bg-[#FAF9F5] px-2.5 py-1.5 rounded-lg border border-[#C7C6CB]"
                  >
                    <span className="font-bold text-[#1A1C1A]">
                      تراز: <strong className="font-mono text-[#001551]">{sub.estimatedTaraz}</strong>
                    </span>
                    <span className="font-mono">
                      درصد خالص: <strong>{sub.rawPercent}%</strong>
                    </span>
                    <span className="text-[#BC000A] font-bold">
                      دام: {sub.trapFallCount}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* LEFT MAIN AREA (in RTL): Konkur Booklet Questions + Post-Exam Diagnostic Karnameh */}
      <div className="lg:col-span-8 space-y-5">
        {/* Post-Exam Diagnostic Karnameh Card */}
        {latestResult && (
          <div className="bg-white border-2 border-[#1A1C1A] rounded-2xl p-5 shadow-[4px_4px_0px_#001551] space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-[#E2E3DF]">
              <div className="flex items-center gap-2">
                <Award className="w-6 h-6 text-[#001551]" />
                <div>
                  <h3 className="text-lg font-extrabold text-[#1A1C1A]">
                    کارنامه تحلیلی کنکور + خروجی موتور ترمیم LearnHarness
                  </h3>
                  <p className="text-xs text-[#059669] font-bold">
                    {latestResult.rankBracket}
                  </p>
                </div>
              </div>
              <span className="px-3 py-1 rounded-full bg-[#001551] text-white font-mono text-sm font-extrabold">
                تراز تخمینی: {latestResult.submission.estimatedTaraz}
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 text-center">
              <div className="bg-[#FAF9F5] border border-[#1A1C1A] rounded-xl p-3">
                <div className="text-lg font-extrabold font-mono text-[#001551]">
                  {latestResult.submission.rawPercent}%
                </div>
                <div className="text-[11px] text-[#46464B]">درصد با نمره منفی</div>
              </div>
              <div className="bg-[#FAF9F5] border border-[#C7C6CB] rounded-xl p-3">
                <div className="text-lg font-extrabold font-mono text-[#1A1C1A]">
                  {latestResult.submission.withoutNegativePercent}%
                </div>
                <div className="text-[11px] text-[#46464B]">درصد بدون نمره منفی</div>
              </div>
              <div className="bg-emerald-50 border border-emerald-600/40 rounded-xl p-3">
                <div className="text-lg font-extrabold font-mono text-emerald-700">
                  {latestResult.submission.correctCount}
                </div>
                <div className="text-[11px] text-emerald-900">تست صحیح</div>
              </div>
              <div className="bg-rose-50 border border-rose-600/40 rounded-xl p-3">
                <div className="text-lg font-extrabold font-mono text-[#BC000A]">
                  {latestResult.submission.wrongCount}
                </div>
                <div className="text-[11px] text-rose-900">غلط (-1/3)</div>
              </div>
              <div className="bg-amber-50 border border-amber-600/40 rounded-xl p-3">
                <div className="text-lg font-extrabold font-mono text-amber-800">
                  {latestResult.submission.trapFallCount}
                </div>
                <div className="text-[11px] text-amber-950">شکار در تله طراح</div>
              </div>
            </div>

            {latestResult.submission.remediationSlugs.length > 0 && (
              <div className="bg-[#FFF5F5] border border-[#BC000A] rounded-xl p-4 space-y-2">
                <div className="text-xs font-extrabold text-[#BC000A] flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4" />
                  <span>
                    مباحث نیازمند ترمیم فوری (پایداری FSRS آن‌ها در دیتابیس کاهش یافت و به صدر صف میمو آمدند):
                  </span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {latestResult.submission.remediationSlugs.map((slug) => (
                    <button
                      key={slug}
                      type="button"
                      onClick={() => onLaunchRemediationQuest(slug)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#1A1C1A] hover:bg-[#001551] text-white text-xs font-bold cursor-pointer"
                    >
                      <Play className="w-3.5 h-3.5 text-emerald-400" />
                      <span>ورود مستقیم به کوئست ترمیمی: {slug}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Exam Booklet Questions */}
        <div className="space-y-4">
          {activeExam.questions.map((q) => {
            const selected = answers[q.id] ?? null;
            const flag = flags[q.id] ?? "none";
            const isGraded = Boolean(latestResult);
            const fellInTrap = isGraded && selected === q.trapOption;

            return (
              <div
                key={q.id}
                className="bg-white border-2 border-[#1A1C1A] rounded-2xl p-5 shadow-[3px_3px_0px_#1A1C1A]"
              >
                <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-[#E2E3DF]">
                  <div className="flex items-center gap-2">
                    <span className="w-7 h-7 rounded-lg bg-[#1A1C1A] text-white font-mono text-xs font-bold flex items-center justify-center">
                      {q.number}
                    </span>
                    <span className="px-2.5 py-0.5 rounded-full bg-[#001551]/10 text-[#001551] text-xs font-extrabold">
                      {q.subject} • {q.topic}
                    </span>
                    <span className="text-[11px] text-[#46464B]">({q.sourceTag})</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-[11px] font-mono text-[#46464B]">
                      زمان استاندارد: {q.idealTimeSec}s
                    </span>
                    <button
                      type="button"
                      onClick={() => cycleFlag(q.id)}
                      className="px-2.5 py-1 rounded-lg bg-[#FAF9F5] border border-[#C7C6CB] text-xs font-bold cursor-pointer"
                    >
                      {flag === "none"
                        ? "نشان‌گذاری (ضربدر/منها)"
                        : flag === "doubt"
                          ? "؟ شک‌دار"
                          : flag === "time_consuming"
                            ? "⏱ زمان‌بر"
                            : "⚠ تله احتمالی"}
                    </button>
                  </div>
                </div>

                <p className="text-sm font-bold text-[#1A1C1A] mt-3 leading-relaxed">
                  {q.stem}
                </p>

                {q.formula && (
                  <div
                    dir="ltr"
                    className="mt-2.5 bg-[#FAF9F5] border border-[#C7C6CB] px-3 py-2 rounded-xl font-mono text-xs text-[#001551]"
                  >
                    {q.formula}
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 mt-4">
                  {q.options.map((opt) => {
                    const isChosen = selected === opt.index;
                    const isCorrectOpt = opt.index === q.correctOption;
                    const isTrapOpt = opt.index === q.trapOption;

                    let cls =
                      "bg-[#FAF9F5] hover:bg-[#F4F4F0] text-[#1A1C1A] border-[#C7C6CB]";
                    if (isGraded) {
                      if (isCorrectOpt) {
                        cls = "bg-emerald-50 text-emerald-950 border-[#059669]";
                      } else if (isChosen && !isCorrectOpt) {
                        cls = "bg-rose-50 text-rose-950 border-[#BC000A]";
                      }
                    } else if (isChosen) {
                      cls = "bg-[#1A1C1A] text-white border-[#1A1C1A]";
                    }

                    return (
                      <button
                        key={opt.index}
                        type="button"
                        onClick={() => toggleBubble(q.id, opt.index)}
                        className={`text-right p-3 rounded-xl border-2 transition flex items-start gap-2.5 cursor-pointer ${cls}`}
                      >
                        <span className="w-5 h-5 rounded-full border border-current font-mono text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
                          {opt.index}
                        </span>
                        <div className="text-xs font-bold leading-relaxed flex-1">
                          {opt.text}
                          {isGraded && isTrapOpt && (
                            <span className="block mt-1 text-[10px] font-extrabold text-[#BC000A]">
                              ⚠ گزینه دام طراح ({q.trapName})
                            </span>
                          )}
                        </div>
                      </button>
                    );
                  })}
                </div>

                {/* Post-grading detailed solution & Trap Radar */}
                {isGraded && (
                  <div className="mt-4 pt-3 border-t border-[#E2E3DF] space-y-2 text-xs">
                    {fellInTrap && (
                      <div className="bg-rose-50 border border-[#BC000A] rounded-xl p-3 text-[#BC000A] flex items-start gap-2">
                        <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5" />
                        <div>
                          <strong>شما در «{q.trapName}» افتادید: </strong>
                          {q.trapExplanation}
                        </div>
                      </div>
                    )}

                    <div className="bg-[#FAF9F5] border border-[#C7C6CB] rounded-xl p-3 text-[#1A1C1A] leading-relaxed flex items-start justify-between gap-3">
                      <div>
                        <strong className="text-[#059669]">پاسخ تشریحی: </strong>
                        {q.detailedSolution}
                      </div>
                      <button
                        type="button"
                        onClick={() => onLaunchRemediationQuest(q.linkedNodeSlug)}
                        className="shrink-0 px-3 py-1.5 rounded-lg bg-[#001551] text-white text-[11px] font-bold cursor-pointer"
                      >
                        تمرین در میمو
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
