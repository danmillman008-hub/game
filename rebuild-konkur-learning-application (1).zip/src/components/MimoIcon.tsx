"use client";

import React from "react";
import { MIMO_VECTORS } from "@/lib/mimo-vectors";
import arscVectorsRaw from "@/lib/mimo/data/arsc-vectors.json";

interface FallbackPath {
  d: string;
  fill?: string | null;
  stroke?: string | null;
  strokeWidth?: number | null;
  fillType?: string | null;
  alpha?: string | number | null;
}

interface FallbackDef {
  viewport: number[];
  paths: FallbackPath[];
}

const FALLBACK_VECTORS = arscVectorsRaw as unknown as Record<string, FallbackDef>;

function argbToCss(c?: string | null): string {
  if (!c || c.charAt(0) !== "#") return "currentColor";
  if (c.length === 9) {
    const a = parseInt(c.slice(1, 3), 16) / 255;
    if (a === 0) return "none";
    const r = parseInt(c.slice(3, 5), 16);
    const g = parseInt(c.slice(5, 7), 16);
    const b = parseInt(c.slice(7, 9), 16);
    return `rgba(${r},${g},${b},${+a.toFixed(3)})`;
  }
  if (c.length === 7) return c;
  return "currentColor";
}

export interface MimoIconProps {
  name: string;
  size?: number;
  mono?: boolean;
  className?: string;
  style?: React.CSSProperties;
  flipRtl?: boolean;
}

export function MimoIcon({
  name,
  size = 24,
  mono = false,
  className = "",
  style,
  flipRtl = false,
}: MimoIconProps) {
  const vec =
    (MIMO_VECTORS[name] as FallbackDef | undefined) ??
    FALLBACK_VECTORS[name] ??
    (MIMO_VECTORS["ic_cap"] as FallbackDef | undefined);
  if (!vec || !vec.paths) return null;
  const [vw = 24, vh = 24] = vec.viewport || [24, 24];
  const h = Math.max(1, Math.round((size * vh) / vw));

  return (
    <svg
      className={`ic inline-block shrink-0 ${className}`}
      width={size}
      height={h}
      viewBox={`0 0 ${vw} ${vh}`}
      fill="none"
      aria-hidden="true"
      style={{
        transform: flipRtl ? "scaleX(-1)" : undefined,
        ...style,
      }}
    >
      {vec.paths.map((p, idx) => {
        let fill = mono ? "currentColor" : argbToCss(p.fill);
        if (fill === "currentColor" && !p.fill) fill = "currentColor";
        const strokeVal = p.stroke
          ? mono
            ? "currentColor"
            : argbToCss(p.stroke)
          : undefined;
        return (
          <path
            key={idx}
            d={p.d}
            fill={fill}
            stroke={strokeVal}
            strokeWidth={p.strokeWidth ?? undefined}
            fillRule={
              p.fillType === "1" || p.fillType === "evenOdd"
                ? "evenodd"
                : undefined
            }
            fillOpacity={p.alpha ? Number(p.alpha) : undefined}
          />
        );
      })}
    </svg>
  );
}
