"use client";

import React, { useState, useEffect, useCallback } from "react";
import BlueprintCommandCenter from "@/components/BlueprintCommandCenter";
import MimoLearnPlayer, {
  type EnrichedKnowledgeNode,
  type MimoLessonItem,
} from "@/components/MimoLearnPlayer";
import KonkurExamSimulator, {
  type KonkurExamData,
  type ExamSubmissionData,
} from "@/components/KonkurExamSimulator";
import SwissPlannerAndCompiler, {
  type StudyPlanRow,
  type EvidenceRow,
} from "@/components/SwissPlannerAndCompiler";
import { MimoEngineeringWorkbench } from "@/components/MimoEngineeringWorkbench";
import { MimoLessonPlayer } from "@/components/MimoLessonPlayer";
import { MimoIcon } from "@/components/MimoIcon";
import type { MimoTutorial, MimoTrack } from "@/lib/mimo/corpus";
import type { VectorTestResult } from "@/lib/mimo/engine";
import {
  Compass,
  Zap,
  FileCheck2,
  CalendarRange,
  Award,
  Activity,
  Cpu,
  Play,
  Database,
  CheckCircle2,
  Download,
  Layers,
  GitBranch,
  Sparkles,
} from "lucide-react";

// ============================================================================
// 1. LEARNHARNESS ADAPTIVE MASTERY HUB (BKT + KST + FSRS-5 + SWISS PLANNER)
// ============================================================================

interface LearnerProfileData {
  id: number;
  fullName: string;
  track: string;
  gradeLevel: string;
  targetRank: number;
  xp: number;
  level: number;
  streakDays: number;
  hearts: number;
  maxHearts: number;
  targetRetention: number;
  flowBandAccuracy: number;
  forgettingScale: number;
}

interface BlueprintPhaseRow {
  id: number;
  phaseNumber: number;
  code: string;
  title: string;
  weightPct: number;
  status: string;
  customNotes: string;
}

export function UnifiedAdaptiveHub() {
  const [activeTab, setActiveTab] = useState<
    "learn" | "planner" | "exam" | "blueprint"
  >("learn");
  const [loading, setLoading] = useState<boolean>(true);
  const [profile, setProfile] = useState<LearnerProfileData | null>(null);
  const [nodes, setNodes] = useState<EnrichedKnowledgeNode[]>([]);
  const [lessons, setLessons] = useState<MimoLessonItem[]>([]);
  const [evidence, setEvidence] = useState<EvidenceRow[]>([]);
  const [exams, setExams] = useState<KonkurExamData[]>([]);
  const [submissions, setSubmissions] = useState<ExamSubmissionData[]>([]);
  const [studyPlans, setStudyPlans] = useState<StudyPlanRow[]>([]);
  const [blueprintPhases, setBlueprintPhases] = useState<BlueprintPhaseRow[]>(
    []
  );
  const [targetLessonSlug, setTargetLessonSlug] = useState<string | null>(null);

  const fetchState = useCallback(async () => {
    try {
      const res = await fetch("/api/adaptive/state", { cache: "no-store" });
      if (!res.ok) return;
      const data = await res.json();
      setProfile(data.profile ?? null);
      setNodes(data.nodes ?? []);
      setLessons(data.lessons ?? []);
      setEvidence(data.evidence ?? []);
      setExams(data.exams ?? []);
      setSubmissions(data.submissions ?? []);
      setStudyPlans(data.studyPlans ?? []);
      setBlueprintPhases(data.blueprintPhases ?? []);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchState();
  }, [fetchState]);

  const handlePhaseStatusChange = async (
    phaseNumber: number,
    status: "completed" | "in_progress" | "ready"
  ) => {
    await fetch("/api/ingest", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ phaseNumber, status }),
    });
    await fetchState();
  };

  const handleLaunchRemediationQuest = (nodeSlug: string) => {
    const matchedLesson = lessons.find((l) =>
      l.beats.some((b) => b.nodeSlug === nodeSlug)
    );
    if (matchedLesson) {
      setTargetLessonSlug(matchedLesson.slug);
    }
    setActiveTab("learn");
  };

  const handlePlayCompiledLesson = (lessonSlug: string) => {
    setTargetLessonSlug(lessonSlug);
    setActiveTab("learn");
  };

  const latestTaraz = submissions[0]?.estimatedTaraz ?? 6480;
  const flowPct = Math.round((profile?.flowBandAccuracy ?? 0.79) * 100);

  return (
    <div
      dir="rtl"
      className="min-h-full bg-[#FBFBF9] text-[#1A1C1A] flex flex-col pb-12"
    >
      <div className="border-b-2 border-[#1A1C1A] bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#001551] text-white flex items-center justify-center font-black text-base shadow-[2px_2px_0px_#1A1C1A]">
              LH
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-sm sm:text-base font-black text-[#1A1C1A]">
                  قطعهٔ ۳ پازل: موتور تطبیقی لرن‌هارنس (BKT + KST + FSRS-5 + برنامه‌ریز سوئیسی)
                </h2>
                <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-[#E0E7FF] text-[#001551] border border-[#001551]/30">
                  comprehensive-software-development-roadmap.zip
                </span>
              </div>
              <p className="text-[11px] text-[#46464B]">
                تلفیق ۱۹ ریپوی گیت‌هاب شما (Gramophone KST/BKT + Learnly + LearnHarness + Swiss Konkur Planner)
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center gap-1.5 bg-[#FFFBEB] border border-[#1A1C1A] px-2.5 py-1 rounded-xl text-xs font-extrabold">
              <Award className="w-3.5 h-3.5 text-[#D97706]" />
              <span>تراز تخمینی سنجش: {latestTaraz}</span>
            </div>
            <div className="flex items-center gap-1.5 bg-[#ECFDF5] border border-[#1A1C1A] px-2.5 py-1 rounded-xl text-xs font-extrabold text-[#005236]">
              <Activity className="w-3.5 h-3.5" />
              <span>باند جریان (Flow): {flowPct}٪</span>
            </div>
            <div className="flex items-center gap-1.5 bg-[#F4F4F0] border border-[#1A1C1A] px-2.5 py-1 rounded-xl text-xs font-extrabold">
              <span>گره‌های دانش KST: {nodes.length}</span>
            </div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 pb-3 flex flex-wrap gap-2">
          <button
            onClick={() => setActiveTab("learn")}
            className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-extrabold border-2 transition cursor-pointer ${
              activeTab === "learn"
                ? "bg-[#001551] text-white border-[#1A1C1A] shadow-[2px_2px_0px_#1A1C1A]"
                : "bg-white hover:bg-[#F4F4F0] text-[#1A1C1A] border-[#1A1C1A]"
            }`}
          >
            <Zap className="w-4 h-4" />
            <span>۱. پلیر تطبیقی و گراف فضای دانش (BKT + KST + FSRS-5)</span>
          </button>

          <button
            onClick={() => setActiveTab("planner")}
            className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-extrabold border-2 transition cursor-pointer ${
              activeTab === "planner"
                ? "bg-[#001551] text-white border-[#1A1C1A] shadow-[2px_2px_0px_#1A1C1A]"
                : "bg-white hover:bg-[#F4F4F0] text-[#1A1C1A] border-[#1A1C1A]"
            }`}
          >
            <CalendarRange className="w-4 h-4" />
            <span>۲. برنامه‌ریز هفتگی Swiss Konkur و کامپایلر جزوه</span>
          </button>

          <button
            onClick={() => setActiveTab("exam")}
            className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-extrabold border-2 transition cursor-pointer ${
              activeTab === "exam"
                ? "bg-[#001551] text-white border-[#1A1C1A] shadow-[2px_2px_0px_#1A1C1A]"
                : "bg-white hover:bg-[#F4F4F0] text-[#1A1C1A] border-[#1A1C1A]"
            }`}
          >
            <FileCheck2 className="w-4 h-4" />
            <span>۳. شبیه‌ساز تراز سنجش و دام‌شناسی (نمره منفی ۳۳٪)</span>
          </button>

          <button
            onClick={() => setActiveTab("blueprint")}
            className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-extrabold border-2 transition cursor-pointer ${
              activeTab === "blueprint"
                ? "bg-[#001551] text-white border-[#1A1C1A] shadow-[2px_2px_0px_#1A1C1A]"
                : "bg-white hover:bg-[#F4F4F0] text-[#1A1C1A] border-[#1A1C1A]"
            }`}
          >
            <Compass className="w-4 h-4" />
            <span>۴. نقشهٔ مهندسی ۱۹ ریپو (MASTER_BLUEPRINT)</span>
          </button>
        </div>
      </div>

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6">
        {loading ? (
          <div className="bg-white border-2 border-[#1A1C1A] rounded-2xl p-12 text-center space-y-3">
            <p className="text-sm font-extrabold text-[#1A1C1A]">
              در حال بارگذاری گراف فضای دانش (KST)، موتور BKT/FSRS-5 و برنامه‌ریز سوئیسی...
            </p>
          </div>
        ) : (
          <>
            {activeTab === "learn" && (
              <MimoLearnPlayer
                nodes={nodes}
                lessons={lessons}
                initialLessonSlug={targetLessonSlug}
                onRefreshState={fetchState}
              />
            )}

            {activeTab === "planner" && (
              <SwissPlannerAndCompiler
                studyPlans={studyPlans}
                nodes={nodes}
                evidence={evidence}
                onRefreshState={fetchState}
                onPlayCompiledLesson={handlePlayCompiledLesson}
              />
            )}

            {activeTab === "exam" && (
              <KonkurExamSimulator
                exams={exams}
                submissions={submissions}
                onRefreshState={fetchState}
                onLaunchRemediationQuest={handleLaunchRemediationQuest}
              />
            )}

            {activeTab === "blueprint" && (
              <BlueprintCommandCenter
                blueprintPhases={blueprintPhases}
                onPhaseStatusChange={handlePhaseStatusChange}
                onJumpToMimoPlayer={() => setActiveTab("learn")}
              />
            )}
          </>
        )}
      </main>
    </div>
  );
}

// ============================================================================
// 2. MIMO 9.35 ORIGINAL DEX / ROOM SQLITE RECONSTRUCTION HUB
// ============================================================================

interface MimoDexStateResponse {
  ok: boolean;
  apkIdentity: {
    package: string;
    versionName: string;
    versionCode: number;
    publishSetVersion: number;
    apkSha256: string;
    roomMaster: { id: number; identityHash: string };
  };
  catalogCounts: Record<string, number>;
  tracks: MimoTrack[];
  activeTutorial: MimoTutorial;
  pathState: {
    track: MimoTrack;
    sectionIndex: number;
    activeSection: {
      name: string;
      description: string;
      tutorialIds: number[];
    };
    nodes: Array<{
      tutorialId: number;
      title: string;
      type: string;
      codeLanguage: string;
      status: string;
      completedLessons: number;
      totalLessons: number;
      iconBanner: string | null;
      chapters: Array<{
        id: number;
        title: string;
        type: string;
        lessonCount: number;
        completedCount: number;
        isCompleted: boolean;
      }>;
    }>;
  };
  roomTables: {
    lessonProgress: Array<{
      lessonId: number;
      completedAt: number;
      startedAt: number;
      tries: number;
      tutorialId: number;
      tutorialVersion: number;
      trackId: number;
      publishSetVersion: number;
      attempts: number;
      isPracticeProgress: number;
      inQueue: number;
    }>;
    tutorialCompletions: Array<{
      tutorialId: number;
      trackId: number;
      isCompleted: number;
      updatedAt: number;
    }>;
    chapterCompletions: Array<{
      chapterId: number;
      trackId: number;
      tutorialId: number;
      createdAt: number;
    }>;
  };
  economyCounters: {
    totalRows: number;
    pendingInQueue: number;
    solvedCount: number;
    firstTryCount: number;
    answersInChapter: { answeredCorrectly: number; answeredTotal: number };
    localCoinsCache: number;
  };
  verification: {
    total: number;
    passed: number;
    failed: number;
    results: VectorTestResult[];
  };
  telemetry: Array<{
    id: number;
    category: string;
    sourceClass: string;
    operation: string;
    payload: Record<string, unknown>;
    evidenceCode: string;
    createdAt: number;
  }>;
}

export function UnifiedDexEngineHub({ nightMode }: { nightMode: boolean }) {
  const [dexState, setDexState] = useState<MimoDexStateResponse | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [subMode, setSubMode] = useState<"workbench" | "player">("workbench");
  const [selectedTrackId, setSelectedTrackId] = useState<number>(50);
  const [selectedTutorialId, setSelectedTutorialId] = useState<number>(904);
  const [selectedChapterIdx, setSelectedChapterIdx] = useState<number>(0);

  const fetchDexState = useCallback(
    async (trackId = selectedTrackId, tutorialId = selectedTutorialId) => {
      try {
        const res = await fetch(
          `/api/mimo/state?trackId=${trackId}&tutorialId=${tutorialId}`,
          { cache: "no-store" }
        );
        if (res.ok) {
          const json: MimoDexStateResponse = await res.json();
          if (json.ok) {
            setDexState(json);
          }
        }
      } finally {
        setLoading(false);
      }
    },
    [selectedTrackId, selectedTutorialId]
  );

  useEffect(() => {
    fetchDexState();
  }, [fetchDexState]);

  const postDexAction = async (payload: Record<string, unknown>) => {
    const res = await fetch("/api/mimo/action", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ...payload,
        trackId: selectedTrackId,
        tutorialId: selectedTutorialId,
      }),
    });
    if (res.ok) {
      await fetchDexState(selectedTrackId, selectedTutorialId);
    }
  };

  if (loading || !dexState) {
    return (
      <div className="p-12 text-center text-sm font-bold">
        در حال بارگذاری هستهٔ مهندسی معکوس‌شدهٔ Mimo 9.35 (DEX + Room SQLite + Test Vectors)...
      </div>
    );
  }

  const activeTutorial = dexState.activeTutorial;
  const activeChapter =
    activeTutorial.chapters[
      Math.min(selectedChapterIdx, Math.max(0, activeTutorial.chapters.length - 1))
    ] || activeTutorial.chapters[0];

  return (
    <div className="max-w-7xl mx-auto px-4 py-5 space-y-4">
      <div
        className="rounded-2xl border p-4 flex flex-wrap items-center justify-between gap-3"
        style={{
          background: "var(--card)",
          borderColor: "var(--line)",
        }}
      >
        <div className="flex items-center gap-3">
          <div
            className="w-10 h-10 rounded-xl flex items-center justify-center text-white"
            style={{ background: "var(--primary)" }}
          >
            <Cpu className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-sm sm:text-base font-extrabold">
                قطعهٔ ۴ پازل: بازسازی ۱۰۰٪ جاوااسکریپت/تایپ‌اسکریپت نرم‌افزار اصلی Mimo 9.35 (DEX & Room SQLite)
              </h2>
              <span
                className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold border"
                style={{
                  background: "var(--progress-weak)",
                  borderColor: "var(--primary)",
                  color: "var(--primary)",
                }}
              >
                rebuild-complete-software-application.zip + شاخهٔ ecb8af07-game
              </span>
            </div>
            <p className="text-xs" style={{ color: "var(--text-weak)" }}>
              پارسر ۲۷ تگ <code dir="ltr">Lte/c.b</code> · نرمال‌ساز ۹ کاراکتری{" "}
              <code dir="ltr">Lqm/i.a</code> · ماشین حالت{" "}
              <code dir="ltr">V/W/X/U</code> · وکتورهای تست{" "}
              <code dir="ltr">
                {dexState.verification.passed}/{dexState.verification.total} PASS
              </code>{" "}
              · ۱۹ مسیر و ۱٬۰۲۹ درسنامهٔ اصلی APK
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setSubMode("workbench")}
            className="px-3.5 py-2 rounded-xl text-xs font-extrabold border cursor-pointer flex items-center gap-1.5"
            style={{
              background:
                subMode === "workbench" ? "var(--primary)" : "var(--card-pressed)",
              borderColor:
                subMode === "workbench" ? "var(--primary)" : "var(--line)",
              color: subMode === "workbench" ? "#FFFFFF" : "var(--text)",
            }}
          >
            <Database className="w-4 h-4" />
            <span>میزکار مهندسی DEX، دیتابیس Room و وکتورهای تست</span>
          </button>

          <button
            type="button"
            onClick={() => setSubMode("player")}
            className="px-3.5 py-2 rounded-xl text-xs font-extrabold border cursor-pointer flex items-center gap-1.5"
            style={{
              background:
                subMode === "player" ? "var(--primary)" : "var(--card-pressed)",
              borderColor:
                subMode === "player" ? "var(--primary)" : "var(--line)",
              color: subMode === "player" ? "#FFFFFF" : "var(--text)",
            }}
          >
            <Play className="w-4 h-4" />
            <span>پلیر درسنامه‌های اصلی APK میمو (۱٬۰۲۹ درسنامه + سندباکس کد)</span>
          </button>
        </div>
      </div>

      {subMode === "workbench" ? (
        <div dir="ltr" className="rounded-2xl overflow-hidden border" style={{ borderColor: "var(--line)" }}>
          <MimoEngineeringWorkbench
            apkIdentity={dexState.apkIdentity}
            roomTables={dexState.roomTables}
            economyCounters={dexState.economyCounters}
            verification={dexState.verification}
            telemetry={dexState.telemetry}
            nightMode={nightMode}
            onSyncOutbox={async () => {
              await postDexAction({ action: "SYNC_OUTBOX" });
            }}
            onColdStartSql={async () => {
              await postDexAction({
                action: "COLD_START_CLEANUP",
                respectOverride: false,
              });
            }}
            onClearAllTables={async () => {
              await postDexAction({ action: "RESET_ALL_PROGRESS" });
            }}
            onLoadSnapshot={async (snapshotName) => {
              await postDexAction({
                action: "LOAD_SNAPSHOT",
                snapshotName,
              });
            }}
          />
        </div>
      ) : (
        <div className="grid lg:grid-cols-12 gap-4">
          <div
            className="lg:col-span-4 rounded-2xl border p-4 space-y-3"
            style={{ background: "var(--card)", borderColor: "var(--line)" }}
          >
            <h3 className="text-xs font-extrabold flex items-center gap-1.5">
              <MimoIcon name="ic_cap_filled" size={18} />
              <span>انتخاب مسیر و درسنامهٔ اصلی APK (نسخهٔ ۷۵۳)</span>
            </h3>

            <div className="space-y-1.5">
              <label className="text-[11px] font-bold block" style={{ color: "var(--text-weak)" }}>
                مسیر آموزشی (۱۹ Track اصلی):
              </label>
              <select
                value={selectedTrackId}
                onChange={(e) => {
                  const nextTrack = Number(e.target.value);
                  setSelectedTrackId(nextTrack);
                  const foundTrack = dexState.tracks.find((t) => t.id === nextTrack);
                  const firstTut =
                    foundTrack?.sections?.[0]?.tutorialIds?.[0] ?? 904;
                  setSelectedTutorialId(firstTut);
                  setSelectedChapterIdx(0);
                  fetchDexState(nextTrack, firstTut);
                }}
                className="w-full rounded-xl border px-3 py-2 text-xs font-bold"
                style={{
                  background: "var(--card-pressed)",
                  borderColor: "var(--line)",
                  color: "var(--text)",
                }}
              >
                {dexState.tracks.map((tr) => (
                  <option key={tr.id} value={tr.id}>
                    #{tr.id} — {tr.title} ({tr.sections.length} بخش)
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="text-[11px] font-bold block" style={{ color: "var(--text-weak)" }}>
                درسنامه‌های بخش جاری ({dexState.pathState.activeSection.name}):
              </label>
              <div className="space-y-1.5 max-h-64 overflow-y-auto mimo-scroll">
                {dexState.pathState.nodes.map((node) => {
                  const active = node.tutorialId === activeTutorial.id;
                  return (
                    <button
                      key={node.tutorialId}
                      type="button"
                      onClick={() => {
                        setSelectedTutorialId(node.tutorialId);
                        setSelectedChapterIdx(0);
                        fetchDexState(selectedTrackId, node.tutorialId);
                      }}
                      className="w-full text-right p-2.5 rounded-xl border flex items-center justify-between gap-2 cursor-pointer"
                      style={{
                        background: active
                          ? "var(--progress-weak)"
                          : "var(--card-pressed)",
                        borderColor: active ? "var(--primary)" : "var(--line)",
                      }}
                    >
                      <div>
                        <div className="text-xs font-extrabold" dir="ltr">
                          #{node.tutorialId} · {node.title}
                        </div>
                        <div
                          className="text-[10.5px]"
                          style={{ color: "var(--text-weak)" }}
                        >
                          زبان: {node.codeLanguage.toUpperCase()} · وضعیت:{" "}
                          {node.status}
                        </div>
                      </div>
                      <span className="text-[11px] font-mono font-bold">
                        {node.completedLessons}/{node.totalLessons}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {activeTutorial.chapters.length > 1 && (
              <div className="space-y-1.5">
                <label className="text-[11px] font-bold block" style={{ color: "var(--text-weak)" }}>
                  فصل (Chapter):
                </label>
                <div className="flex flex-wrap gap-1.5">
                  {activeTutorial.chapters.map((ch, idx) => (
                    <button
                      key={ch.id}
                      type="button"
                      onClick={() => setSelectedChapterIdx(idx)}
                      className="px-2.5 py-1 rounded-lg text-[11px] font-bold border cursor-pointer"
                      style={{
                        background:
                          selectedChapterIdx === idx
                            ? "var(--primary)"
                            : "var(--card-pressed)",
                        borderColor:
                          selectedChapterIdx === idx
                            ? "var(--primary)"
                            : "var(--line)",
                        color:
                          selectedChapterIdx === idx ? "#FFFFFF" : "var(--text)",
                      }}
                    >
                      {idx + 1}. {ch.title}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div
            className="lg:col-span-8 rounded-2xl border overflow-hidden min-h-[680px] flex flex-col"
            style={{ background: "var(--card)", borderColor: "var(--line)" }}
            dir="ltr"
          >
            {activeChapter && (
              <MimoLessonPlayer
                key={`${activeTutorial.id}-${activeChapter.id}`}
                tutorial={activeTutorial}
                chapter={activeChapter}
                trackId={selectedTrackId}
                nightMode={nightMode}
                onLessonSubmit={async (payload) => {
                  await postDexAction({
                    action: "SUBMIT_LESSON",
                    ...payload,
                  });
                }}
                onClaimRewardChest={async () => {
                  await postDexAction({ action: "CLAIM_REWARD_CHEST" });
                }}
                onCloseChapter={() => setSubMode("workbench")}
                onSwitchPath={() => setSubMode("workbench")}
              />
            )}
          </div>
        </div>
      )}
    </div>
  );
}

// ============================================================================
// 3. FORENSIC PUZZLE SYNTHESIS VIEW (EXPLAINING ALL 6 ZIPS & REPO BRANCHES)
// ============================================================================

export function UnifiedPuzzleSynthesisView({
  onJumpToMode,
}: {
  onJumpToMode: (
    mode:
      | "mimo-konkur-app"
      | "pedagogical-compiler"
      | "learnharness-adaptive"
      | "mimo-dex-engine"
  ) => void;
}) {
  const puzzlePieces = [
    {
      num: "قطعهٔ ۱ و ۲",
      zips: [
        "educational-software-development-project.zip",
        "develop-konkur-learning-application.zip",
        "develop-konkur-learning-application (1).zip",
      ],
      branch: "origin/arena/aebb90b7-game (HEAD: 9179b8c4)",
      title: "اپلیکیشن بومی میمو ۹٫۳۵ برای کنکور (طرح مصوب v12.5-fa + خروجی تک‌فایل آفلاین)",
      whatWasInside:
        "حاوی کالبدشکافی کامل گرافیک و ناوبری Mimo 9.35، قواعد سخت‌گیرانهٔ v12.5-fa (۵ تب فارسی یادگیری/تمرین/هوش مصنوعی/امتیازها/پروفایل، ۳ چیپ سکه/کلید ∞/استریک، نقشهٔ ۶ گره مارپیچ بدون گره قفل‌شده، هاب آزمون ۷بخشی با تفکیک پاسخبرگ ≠ پاسخنامه و تایمر ۲۷۰ دقیقه‌ای، ۹۴ وکتور ARSC، و قرارداد صداقت SERVER CONFIRMED = 0).",
      whatWasFixed:
        "رفع کامل ۶ ایراد فرانکشتاینی پروتوتایپ اولیه: حذف هش تصادفی در chapterRefFor(id) و اتصال قطعی ۱۲ کتاب کنکور (۶۰ فصل و ۱۸۰ درس)، پیاده‌سازی هر ۹ خانوادهٔ رندرر میمو (شامل ValidatedInput سه حالته، Spell ترتیبی، FillTheGap، InteractiveWebView و Hard Mode)، و کارنامهٔ واقعی با نمره منفی ⅓ به جای عدد ثابت ۶۸٪.",
      targetMode: "mimo-konkur-app" as const,
      ctaLabel: "ورود به اپ اصلی میمو کنکور (v12.5-fa)",
    },
    {
      num: "قطعهٔ ۳",
      zips: ["build-konkur-pedagogical-ai-agent.zip"],
      branch: "کالبدشکافی پداگوژی و فرم اطلاعاتی MIMO_INFORMATION_FORM",
      title: "کامپایلر پداگوژیک ایجنت، گاردریل ۹ قانون و پل هم‌ریختی کد میمو ↔ کنکور",
      whatWasInside:
        "کشف بزرگ‌ترین حلقهٔ مفقودهٔ پازل: چرا در میمو یادگیری پایتون و SQL اعتیادآور است ولی وقتی متن کتاب زیست و فیزیک کنکور را به ایجنت می‌دهیم خروجی خشک و کسل‌کننده می‌شود؟ چون ایجنت گام Code و Debug میمو را حذف می‌کرد و در گام Text دیوار متنی ۳۰۰ کلمه‌ای می‌ریخت.",
      whatWasFixed:
        "تبدیل گام Code میمو به ۲ مکانیک هم‌ریخت کنکوری: ۱) token_assembly (چیدمان بلوکی مسیرهای زیستی، اشتقاق فرمول فیزیک/ریاضی و استوکیومتری شیمی با بلوک‌های تله) و ۲) trap_detector (شکارچی تله طراح کنکور روی قیدهای همه/برخی/اغلب) + گاردریل ۹ قانون (سقف ۲۰ تا ۸۵ کلمه و ماتریس کالبدشکافی ۴ گزینه).",
      targetMode: "pedagogical-compiler" as const,
      ctaLabel: "ورود به کامپایلر پداگوژیک و فرم گاردریل",
    },
    {
      num: "قطعهٔ ۴",
      zips: ["comprehensive-software-development-roadmap.zip"],
      branch: "MASTER_BLUEPRINT.md (تلفیق ۱۹ ریپوی گیت‌هاب شما)",
      title: "موتور تطبیقی لرن‌هارنس (BKT + فضای دانش KST + مرور FSRS-5 + برنامه‌ریز سوئیسی)",
      whatWasInside:
        "معماری ریاضی استخراج‌شده از ریپوهای newlearning (Gramophone)، my-first (Learnly) و moshavere-va-azmoon: نظریهٔ فضای دانش (KST Outer/Inner Fringe)، ردیابی دانش بیزی (BKT کالیبره‌شده با تفکیک تلاش با راهنما و بدون راهنما)، زمان‌بند مرور FSRS-5 و کنترلر باند جریان ۷۰ تا ۸۵ درصد.",
      whatWasFixed:
        "رفع باگ غیرقابل دسترس بودن تسلط (Q3/Q4 در Gramophone)، جلوگیری از عبور کاذب تسلط با زدن Hint، تخمین تراز و رتبهٔ سنجش، و اتصال مستقیم غلط‌های آزمون به کوئست‌های ترمیمی و برنامه‌ریز هفتگی Swiss Konkur.",
      targetMode: "learnharness-adaptive" as const,
      ctaLabel: "ورود به موتور تطبیقی BKT/KST و برنامه‌ریز سوئیسی",
    },
    {
      num: "قطعهٔ ۵",
      zips: ["rebuild-complete-software-application.zip"],
      branch: "origin/arena/ecb8af07-game (HANDOFF/01..15 + mimo-re)",
      title: "بازسازی کامل نرم‌افزار اصلی Mimo 9.35 با جاوااسکریپت/تایپ‌اسکریپت (DEX + Room SQLite)",
      whatWasInside:
        "پیاده‌سازی خط‌به‌خط کلاس‌های دیکدشدهٔ APK میمو ۹٫۳۵: پارسر ۲۷ تگ Lte/c.b (@14378108)، نرمال‌ساز Lqm/i.a با ۹ علامت نگارشی، ماشین حالت V/W/X/U در base/c، جداول دقیق دیتابیس Room (lesson_progress، tutorial_completions، chapter_completions با identityHash اصلی)، ۲۱۵ بنر SVG و وکتورهای تست رسمی.",
      whatWasFixed:
        "در فایل زیپ شما کامپوننت‌های MimoLessonPlayer و MimoEngineeringWorkbench ساخته شده بودند اما page.tsx هنوز روی صفحهٔ خام Starter مانده بود! اکنون این موتور به طور کامل به رابط کاربری و دیتابیس متصل شده و تمام وکتورهای تست را ۱۰۰٪ پاس می‌کند.",
      targetMode: "mimo-dex-engine" as const,
      ctaLabel: "ورود به میزکار مهندسی DEX و پلیر ۱٬۰۲۹ درسنامهٔ اصلی",
    },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 space-y-6" dir="rtl">
      <div
        className="rounded-3xl border p-6 space-y-4"
        style={{ background: "var(--card)", borderColor: "var(--primary)" }}
      >
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div
              className="w-12 h-12 rounded-2xl flex items-center justify-center text-white font-black text-xl"
              style={{ background: "var(--primary)" }}
            >
              <Layers className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-extrabold">
                گزارش جامع کالبدشکافی و تلفیق ۶ فایل زیپ و ریپوی گیت‌هاب (danmillman008-hub/game)
              </h2>
              <p className="text-xs" style={{ color: "var(--text-weak)" }}>
                بررسی کامل تمام شاخه‌های گیت‌هاب (<code dir="ltr">aebb90b7-game</code> و{" "}
                <code dir="ltr">ecb8af07-game</code>) و هر ۶ فایل زیپ (با حذف کامل فایل‌های غیرمرتبط داروخانه/TTAC و Streets of Rage)
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <a
              href="/Mimo.html"
              download="Mimo.html"
              className="px-3.5 py-2 rounded-xl text-xs font-extrabold text-white flex items-center gap-1.5"
              style={{ background: "var(--primary)", textDecoration: "none" }}
            >
              <Download className="w-4 h-4" />
              <span>دانلود Mimo.html (تک‌فایل خودکفا)</span>
            </a>
            <a
              href="/STRUCTURED_PACKAGE.json"
              download="STRUCTURED_PACKAGE.json"
              className="px-3 py-2 rounded-xl text-xs font-bold border flex items-center gap-1.5"
              style={{
                background: "var(--card-pressed)",
                borderColor: "var(--line)",
                color: "var(--text)",
                textDecoration: "none",
              }}
            >
              <Download className="w-3.5 h-3.5" />
              <span>STRUCTURED_PACKAGE.json</span>
            </a>
            <a
              href="/MASTER_BLUEPRINT.md"
              download="MASTER_BLUEPRINT.md"
              className="px-3 py-2 rounded-xl text-xs font-bold border flex items-center gap-1.5"
              style={{
                background: "var(--card-pressed)",
                borderColor: "var(--line)",
                color: "var(--text)",
                textDecoration: "none",
              }}
            >
              <Download className="w-3.5 h-3.5" />
              <span>MASTER_BLUEPRINT.md</span>
            </a>
          </div>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-2">
          <div
            className="p-3.5 rounded-2xl border"
            style={{ background: "var(--card-pressed)", borderColor: "var(--line)" }}
          >
            <div className="text-xs font-extrabold" style={{ color: "var(--primary)" }}>
              ۱. پوسته و ناوبری بومی v12.5-fa
            </div>
            <div className="text-lg font-black mt-0.5">۵ تب · ۱۶ صفحه · ۹۴ وکتور</div>
            <p className="text-[11px] mt-1" style={{ color: "var(--text-weak)" }}>
              یادگیری، تمرین (هاب ۷بخشی)، هوش مصنوعی محلی، امتیازها و پروفایل + ۲۱۵ بنر SVG اصلی.
            </p>
          </div>

          <div
            className="p-3.5 rounded-2xl border"
            style={{ background: "var(--card-pressed)", borderColor: "var(--line)" }}
          >
            <div className="text-xs font-extrabold" style={{ color: "var(--success)" }}>
              ۲. پل هم‌ریختی میمو ↔ کنکور
            </div>
            <div className="text-lg font-black mt-0.5">۶ گام پداگوژیک · ۹ قانون گاردریل</div>
            <p className="text-[11px] mt-1" style={{ color: "var(--text-weak)" }}>
              تبدیل گام Code و Debug میمو به چیدمان بلوکی فرمول/مسیر و شکارچی تلهٔ طراح کنکور.
            </p>
          </div>

          <div
            className="p-3.5 rounded-2xl border"
            style={{ background: "var(--card-pressed)", borderColor: "var(--line)" }}
          >
            <div className="text-xs font-extrabold" style={{ color: "var(--blue)" }}>
              ۳. موتور تطبیقی LearnHarness
            </div>
            <div className="text-lg font-black mt-0.5">BKT + KST + FSRS-5 + تراز سنجش</div>
            <p className="text-[11px] mt-1" style={{ color: "var(--text-weak)" }}>
              ردیابی احتمال تسلط، لبهٔ بیرونی دانش، زمان‌بند مرور فراموشی و برنامه‌ریز هفتگی سوئیسی.
            </p>
          </div>

          <div
            className="p-3.5 rounded-2xl border"
            style={{ background: "var(--card-pressed)", borderColor: "var(--line)" }}
          >
            <div className="text-xs font-extrabold" style={{ color: "var(--yellow)" }}>
              ۴. هستهٔ اصلی Mimo 9.35 DEX
            </div>
            <div className="text-lg font-black mt-0.5">۲۰ جدول PostgreSQL · ۱۰۰٪ تست سبز</div>
            <p className="text-[11px] mt-1" style={{ color: "var(--text-weak)" }}>
              بازسازی دقیق پارسر Lte/c.b، ولیدیتورهای A6–A11، ماشین حالت V/W/X/U و جداول Room.
            </p>
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        {puzzlePieces.map((piece, idx) => (
          <div
            key={idx}
            className="rounded-3xl border p-5 flex flex-col justify-between space-y-4"
            style={{ background: "var(--card)", borderColor: "var(--line)" }}
          >
            <div className="space-y-3">
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <span
                  className="px-3 py-1 rounded-full text-xs font-extrabold text-white"
                  style={{ background: "var(--primary)" }}
                >
                  {piece.num}
                </span>
                <span
                  className="text-[11px] font-mono font-bold px-2.5 py-0.5 rounded-lg border"
                  style={{
                    background: "var(--card-pressed)",
                    borderColor: "var(--line)",
                  }}
                  dir="ltr"
                >
                  {piece.branch}
                </span>
              </div>

              <h3 className="text-sm sm:text-base font-extrabold">
                {piece.title}
              </h3>

              <div className="flex flex-wrap gap-1.5" dir="ltr">
                {piece.zips.map((z) => (
                  <span
                    key={z}
                    className="text-[10.5px] font-mono px-2 py-0.5 rounded border"
                    style={{
                      background: "var(--card-pressed)",
                      borderColor: "var(--line)",
                      color: "var(--text-weak)",
                    }}
                  >
                    📦 {z}
                  </span>
                ))}
              </div>

              <div
                className="p-3 rounded-2xl border text-xs space-y-1.5 leading-relaxed"
                style={{
                  background: "var(--card-pressed)",
                  borderColor: "var(--line)",
                }}
              >
                <div>
                  <b style={{ color: "var(--primary)" }}>🔍 آنچه داخل این آرشیو بود: </b>
                  <span>{piece.whatWasInside}</span>
                </div>
                <div>
                  <b style={{ color: "var(--success)" }}>✅ نحوهٔ تکمیل و اتصال در پلتفرم جامع: </b>
                  <span>{piece.whatWasFixed}</span>
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={() => onJumpToMode(piece.targetMode)}
              className="mimo-cta text-xs sm:text-sm"
            >
              <Sparkles className="w-4 h-4" />
              <span>{piece.ctaLabel}</span>
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
