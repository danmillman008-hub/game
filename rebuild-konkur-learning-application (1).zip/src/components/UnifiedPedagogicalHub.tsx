"use client";

import React, { useCallback, useEffect, useState } from "react";
import {
  Cpu,
  Microscope,
  Play,
  ShieldCheck,
  Sliders,
  Zap,
} from "lucide-react";
import { AgentCompilerStudio } from "@/components/AgentCompilerStudio";
import { EnforcedGuardrailForm } from "@/components/EnforcedGuardrailForm";
import { MimoKonkurPlayer } from "@/components/MimoKonkurPlayer";
import { PedagogyResearchAndSpec } from "@/components/PedagogyResearchAndSpec";
import type {
  AgentCompilationLog,
  KonkurCourse,
  KonkurLesson,
  KonkurStep,
} from "@/db/schema";
import type {
  LegacyFormDefectAnalysis,
  SubjectIsomorphismGuide,
} from "@/lib/pedagogy-engine";

type ActiveTab = "player" | "compiler" | "guardrail" | "research";

type PlatformStateResponse = {
  courses: KonkurCourse[];
  lessons: KonkurLesson[];
  steps: KonkurStep[];
  logs: AgentCompilationLog[];
  totalXp: number;
  presets: {
    id: string;
    subject: string;
    grade: string;
    topicTitle: string;
    chapterReference: string;
    rawTextbookExcerpt: string;
  }[];
  legacyDefects: LegacyFormDefectAnalysis[];
  isomorphismMatrix: SubjectIsomorphismGuide[];
  agentSystemPrompt: string;
};

export function UnifiedPedagogicalHub() {
  const [data, setData] = useState<PlatformStateResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<ActiveTab>("player");
  const [selectedLessonId, setSelectedLessonId] = useState<number>(1);

  const fetchState = useCallback(async (preferredLessonId?: number | null) => {
    try {
      const res = await fetch("/api/konkur/state", { cache: "no-store" });
      if (res.ok) {
        const json: PlatformStateResponse = await res.json();
        setData(json);
        if (preferredLessonId) {
          setSelectedLessonId(preferredLessonId);
        } else if (json.lessons.length > 0) {
          setSelectedLessonId((prev) =>
            json.lessons.some((l) => l.id === prev) ? prev : json.lessons[0].id
          );
        }
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchState();
  }, [fetchState]);

  async function handleStepComplete(payload: {
    stepId: number;
    lessonId: number;
    correctFirstTry: boolean;
    attempts: number;
    xpEarned: number;
  }) {
    await fetch("/api/konkur/progress", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    await fetchState(payload.lessonId);
  }

  return (
    <div className="min-h-full bg-slate-950 text-slate-100 pb-12" dir="rtl">
      <div className="border-b border-slate-800/80 bg-slate-900/90">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-4 px-4 py-3.5 sm:px-6">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-gradient-to-br from-emerald-400 to-indigo-500 text-lg font-black text-slate-950 shadow-lg">
              M
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-sm font-black text-white sm:text-base">
                  قطعهٔ ۲ پازل: کامپایلر پداگوژیک ایجنت و پل هم‌ریختی میمو ↔ کنکور
                </h2>
                <span className="rounded-full border border-emerald-500/40 bg-emerald-500/15 px-2.5 py-0.5 text-[10px] font-black text-emerald-300">
                  build-konkur-pedagogical-ai-agent.zip
                </span>
              </div>
              <p className="text-xs text-slate-400">
                تبدیل گام‌های Code و Debug میمو به چیدمان بلوکی مسیر/فرمول (token_assembly) و شکارچی تله طراح (trap_detector) + گاردریل ۹ قانون
              </p>
            </div>
          </div>

          {data && (
            <div className="flex flex-wrap items-center gap-2 text-xs font-bold">
              <div className="flex items-center gap-1.5 rounded-xl border border-slate-800 bg-slate-950 px-3 py-1.5 text-emerald-300">
                <ShieldCheck className="h-4 w-4 text-emerald-400" />
                <span>درسنامه‌های تاییدشده گاردریل: {data.lessons.length}</span>
              </div>
              <div className="flex items-center gap-1.5 rounded-xl border border-slate-800 bg-slate-950 px-3 py-1.5 text-amber-300">
                <Zap className="h-4 w-4 text-amber-400" />
                <span>امتیاز پداگوژیک: {data.totalXp} XP</span>
              </div>
            </div>
          )}
        </div>

        <div className="mx-auto max-w-7xl px-4 pb-3 sm:px-6">
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            <button
              type="button"
              onClick={() => setActiveTab("player")}
              className={`flex items-center justify-center gap-2 rounded-2xl border px-3 py-2.5 text-xs font-black transition-all cursor-pointer ${
                activeTab === "player"
                  ? "border-emerald-400 bg-emerald-500/20 text-white shadow-lg"
                  : "border-slate-800 bg-slate-900/70 text-slate-400 hover:border-slate-700 hover:text-slate-200"
              }`}
            >
              <Play className="h-4 w-4 text-emerald-400" />
              <span>۱. پلیر ۶ گامی هم‌ریخت (Token Assembly & Trap)</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab("compiler")}
              className={`flex items-center justify-center gap-2 rounded-2xl border px-3 py-2.5 text-xs font-black transition-all cursor-pointer ${
                activeTab === "compiler"
                  ? "border-indigo-400 bg-indigo-500/20 text-white shadow-lg"
                  : "border-slate-800 bg-slate-900/70 text-slate-400 hover:border-slate-700 hover:text-slate-200"
              }`}
            >
              <Cpu className="h-4 w-4 text-indigo-400" />
              <span>۲. کامپایلر متن کتاب درسی به میمو</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab("guardrail")}
              className={`flex items-center justify-center gap-2 rounded-2xl border px-3 py-2.5 text-xs font-black transition-all cursor-pointer ${
                activeTab === "guardrail"
                  ? "border-amber-400 bg-amber-500/20 text-white shadow-lg"
                  : "border-slate-800 bg-slate-900/70 text-slate-400 hover:border-slate-700 hover:text-slate-200"
              }`}
            >
              <Sliders className="h-4 w-4 text-amber-400" />
              <span>۳. فرم گاردریل و عیارسنج ۹ شاخصه (M1–M9)</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab("research")}
              className={`flex items-center justify-center gap-2 rounded-2xl border px-3 py-2.5 text-xs font-black transition-all cursor-pointer ${
                activeTab === "research"
                  ? "border-rose-400 bg-rose-500/20 text-white shadow-lg"
                  : "border-slate-800 bg-slate-900/70 text-slate-400 hover:border-slate-700 hover:text-slate-200"
              }`}
            >
              <Microscope className="h-4 w-4 text-rose-400" />
              <span>۴. کالبدشکافی فرم‌های قدیمی و ماتریس هم‌ریختی</span>
            </button>
          </div>
        </div>
      </div>

      <main className="mx-auto max-w-7xl px-4 py-6 sm:px-6">
        {loading || !data ? (
          <div className="rounded-3xl border border-slate-800 bg-slate-900 p-12 text-center text-sm font-bold text-slate-300">
            در حال راه‌اندازی کامپایلر پداگوژیک میمو-کنکور و بارگذاری دیتابیس PostgreSQL...
          </div>
        ) : (
          <>
            {activeTab === "player" && (
              <MimoKonkurPlayer
                courses={data.courses}
                lessons={data.lessons}
                steps={data.steps}
                selectedLessonId={selectedLessonId}
                onSelectLesson={(id) => setSelectedLessonId(id)}
                onStepComplete={handleStepComplete}
                onOpenGuardrailEditor={(id) => {
                  setSelectedLessonId(id);
                  setActiveTab("guardrail");
                }}
              />
            )}

            {activeTab === "compiler" && (
              <AgentCompilerStudio
                courses={data.courses}
                presets={data.presets}
                logs={data.logs}
                onCompiledAndSaved={async (newLessonId) => {
                  await fetchState(newLessonId);
                  if (newLessonId) {
                    setSelectedLessonId(newLessonId);
                    setActiveTab("player");
                  }
                }}
              />
            )}

            {activeTab === "guardrail" && (
              <EnforcedGuardrailForm
                lessons={data.lessons}
                steps={data.steps}
                selectedLessonId={selectedLessonId}
                onSelectLesson={(id) => setSelectedLessonId(id)}
                onSavedToDb={async () => {
                  await fetchState(selectedLessonId);
                }}
              />
            )}

            {activeTab === "research" && (
              <PedagogyResearchAndSpec
                legacyDefects={data.legacyDefects}
                isomorphismMatrix={data.isomorphismMatrix}
                agentSystemPrompt={data.agentSystemPrompt}
              />
            )}
          </>
        )}
      </main>
    </div>
  );
}
