"use client";

import React, { useState, useEffect, useMemo } from "react";
import { MimoIcon } from "./MimoIcon";
import {
  MimoTutorial,
  MimoChapter,
  MimoLesson,
} from "@/lib/mimo/corpus";
import {
  parseLessonDsl,
  isModuleVisible,
  gradeValidatedInput,
  gradeSelection,
  gradeFillTheGap,
  gradeSpell,
  gradeExecutableFiles,
  applySubmission,
  executeCodeSandbox,
  CORRECT,
  PARTIAL,
  INCORRECT,
  Verdict,
} from "@/lib/mimo/engine";

interface MimoLessonPlayerProps {
  tutorial: MimoTutorial;
  chapter: MimoChapter;
  trackId: number;
  initialLessonIndex?: number;
  hardModeDefault?: boolean;
  nightMode?: boolean;
  onLessonSubmit: (payload: {
    lessonId: number;
    tutorialId: number;
    tutorialVersion: number;
    chapterId: number;
    trackId: number;
    startedAt: number;
    tries: number;
    attempts: number;
    isPracticeProgress: boolean;
    verdict: string;
    callSite: "V" | "W" | "X" | "U";
  }) => Promise<void>;
  onClaimRewardChest: () => Promise<void>;
  onCloseChapter: () => void;
  onSwitchPath: () => void;
}

export function MimoLessonPlayer({
  tutorial,
  chapter,
  trackId,
  initialLessonIndex = 0,
  hardModeDefault = false,
  nightMode = false,
  onLessonSubmit,
  onClaimRewardChest,
  onCloseChapter,
  onSwitchPath,
}: MimoLessonPlayerProps) {
  const lessons = chapter.lessons || [];
  const [lessonIdx, setLessonIdx] = useState(
    Math.min(Math.max(0, initialLessonIndex), Math.max(0, lessons.length - 1))
  );
  const lesson: MimoLesson | undefined = lessons[lessonIdx];

  const [useHardMode, setUseHardMode] = useState<boolean>(
    Boolean(hardModeDefault && lesson?.hardModeContent)
  );
  const [startedAt, setStartedAt] = useState<number>(() => Date.now());

  // Session counters for V/W/X/U state machine (base/c fields C = wrongLatch, d = attempts)
  const [wrongLatchC, setWrongLatchC] = useState<boolean | null>(null);
  const [attemptsD, setAttemptsD] = useState<number>(0);
  const [lastTransition, setLastTransition] = useState<{
    site: "V" | "W" | "X" | "U";
    tries: number;
    attempts: number;
    C_after?: boolean;
  } | null>(null);

  // Interactive lesson state
  const [verdict, setVerdict] = useState<Verdict | null>(null);
  const [selectedItems, setSelectedItems] = useState<Set<number>>(new Set());
  const [placedGaps, setPlacedGaps] = useState<Array<{ optionId: string; text: string } | null>>([]);
  const [validatedInputText, setValidatedInputText] = useState<string>("");
  const [spellChars, setSpellChars] = useState<string[]>([]);
  const [webviewCompleted, setWebviewCompleted] = useState<boolean>(false);
  const [webviewBridgeLog, setWebviewBridgeLog] = useState<string[]>([]);

  // Executable lesson state
  const [execTab, setExecTab] = useState<"instructions" | "editor" | "output">("editor");
  const [activeFileIdx, setActiveFileIdx] = useState<number>(0);
  const [userFiles, setUserFiles] = useState<
    Array<{ name: string; codeLanguage: string; content: string; solvedContent?: string | null }>
  >([]);
  const [sandboxOutput, setSandboxOutput] = useState<{
    stdout: string;
    htmlPreview: string | null;
    error: string | null;
  } | null>(null);
  const [showSolutionDiff, setShowSolutionDiff] = useState<boolean>(false);

  // Modals / Sheets
  const [showQuitDialog, setShowQuitDialog] = useState<boolean>(false);
  const [showAiTutor, setShowAiTutor] = useState<boolean>(false);
  const [aiMessages, setAiMessages] = useState<
    Array<{ id: string; role: "user" | "assistant"; content: string }>
  >([]);
  const [aiInput, setAiInput] = useState<string>("");
  const [aiLoading, setAiLoading] = useState<boolean>(false);
  const [aiEnvelope, setAiEnvelope] = useState<Record<string, unknown> | null>(null);

  // Chapter Finished state
  const [chapterFinished, setChapterFinished] = useState<boolean>(false);
  const [chapterSessionRows, setChapterSessionRows] = useState<
    Array<{ lessonId: number; tries: number; attempts: number }>
  >([]);
  const [rewardBoxOpened, setRewardBoxOpened] = useState<boolean>(false);
  const [submitting, setSubmitting] = useState<boolean>(false);

  const activeDslSource = useMemo(() => {
    if (!lesson) return "";
    if (useHardMode && lesson.hardModeContent) return lesson.hardModeContent;
    return lesson.interactiveContent || "";
  }, [lesson, useHardMode]);

  const parsedDoc = useMemo(() => parseLessonDsl(activeDslSource), [activeDslSource]);

  const codeModWithInteraction = useMemo(
    () => parsedDoc.modules.find((m) => m.kind === "code" && m.activeInteraction),
    [parsedDoc]
  );

  const selectionMod = useMemo(
    () => parsedDoc.modules.find((m) => m.kind === "selection" && m.items && m.items.length > 0),
    [parsedDoc]
  );

  // Reset per-lesson state when lessonIdx or useHardMode changes
  useEffect(() => {
    setStartedAt(Date.now());
    setVerdict(null);
    setWrongLatchC(null);
    setAttemptsD(0);
    setLastTransition(null);
    setSelectedItems(new Set());
    setValidatedInputText("");
    setSpellChars([]);
    setWebviewCompleted(false);
    setWebviewBridgeLog([]);
    setShowSolutionDiff(false);
    setSandboxOutput(null);

    if (codeModWithInteraction?.activeInteraction) {
      const gapCount = Math.max(1, codeModWithInteraction.activeInteraction.gaps.length);
      setPlacedGaps(Array(gapCount).fill(null));
    } else {
      setPlacedGaps([]);
    }

    if (lesson?.contentType === "executableFiles" && lesson.executableContent) {
      setUserFiles(
        lesson.executableContent.files.map((f) => ({
          name: f.name,
          codeLanguage: f.codeLanguage,
          content: f.content,
          solvedContent: f.solvedContent,
        }))
      );
      setActiveFileIdx(lesson.executableContent.preselectedFileIndex || 0);
      setExecTab("editor");
    }
  }, [lessonIdx, useHardMode, lesson, codeModWithInteraction]);

  // Listen for iframe WebView bridge messages (lesson-webview.js protocol)
  useEffect(() => {
    const handleMessage = (ev: MessageEvent) => {
      if (!ev.data) return;
      const msg = typeof ev.data === "string" ? (() => { try { return JSON.parse(ev.data); } catch { return null; } })() : ev.data;
      if (!msg) return;
      if (msg.kind === "activity" || (typeof msg.type === "string" && msg.type.startsWith("mimo.activity."))) {
        const resType = msg.result || msg.type;
        setWebviewBridgeLog((prev) => [
          ...prev.slice(-5),
          `MimoLesson.postMessage -> ${resType}`,
        ]);
        if (resType === "mimo.activity.correct" || resType === "mimo.activity.completed") {
          setWebviewCompleted(true);
          setVerdict(CORRECT);
        } else if (resType === "mimo.activity.wrong") {
          setVerdict(INCORRECT);
        }
      }
    };
    window.addEventListener("message", handleMessage);
    return () => window.removeEventListener("message", handleMessage);
  }, []);

  if (!lesson) {
    return null;
  }

  const isPractice =
    tutorial.type.toLowerCase().includes("practice") ||
    chapter.type.toLowerCase().includes("practicelevel2") ||
    chapter.type.toLowerCase().includes("practicelevel3");

  // Determine if user has entered an answer so the Check/Run button is enabled
  const canCheckAnswer = (() => {
    if (lesson.contentType === "executableFiles") return true;
    if (!parsedDoc.hasAssessedInteraction) return true; // Slide / WebView
    if (selectionMod) return selectedItems.size > 0;
    if (codeModWithInteraction?.activeInteraction) {
      const t = codeModWithInteraction.activeInteraction.type;
      if (t === "validatedInput") return validatedInputText.trim().length > 0;
      if (t === "spell") return spellChars.length > 0;
      return placedGaps.every((g) => g !== null);
    }
    return true;
  })();

  const handleCheckOrContinue = async () => {
    if (submitting) return;

    // If non-interactive slide (or InteractiveWebView without native grading) -> U() site
    if (lesson.contentType === "interactive" && !parsedDoc.hasAssessedInteraction) {
      setSubmitting(true);
      try {
        const tries = 1;
        const attempts = 1;
        setLastTransition({ site: "U", tries, attempts });
        await onLessonSubmit({
          lessonId: lesson.id,
          tutorialId: tutorial.id,
          tutorialVersion: tutorial.version,
          chapterId: chapter.id,
          trackId,
          startedAt,
          tries,
          attempts,
          isPracticeProgress: isPractice,
          verdict: CORRECT,
          callSite: "U",
        });
        setChapterSessionRows((prev) => [
          ...prev.filter((r) => r.lessonId !== lesson.id),
          { lessonId: lesson.id, tries, attempts },
        ]);
        advanceOrFinish();
      } finally {
        setSubmitting(false);
      }
      return;
    }

    // Executable lesson -> run sandbox + grade via Lq.I()
    if (lesson.contentType === "executableFiles" && lesson.executableContent) {
      const runRes = executeCodeSandbox(userFiles);
      setSandboxOutput(runRes);
      const gradeRes = gradeExecutableFiles(userFiles, lesson.executableContent.files);
      const computedVerdict: "CORRECT" | "INCORRECT" =
        gradeRes.ok && !runRes.error ? CORRECT : INCORRECT;
      const site = computedVerdict === CORRECT ? "V" : "X";
      const counterUpdate = applySubmission(computedVerdict, wrongLatchC, attemptsD);

      setAttemptsD(counterUpdate.attempts);
      setWrongLatchC(counterUpdate.C_after ?? false);
      setVerdict(computedVerdict);
      setLastTransition({
        site,
        tries: counterUpdate.tries,
        attempts: counterUpdate.attempts,
        C_after: counterUpdate.C_after,
      });

      setSubmitting(true);
      try {
        await onLessonSubmit({
          lessonId: lesson.id,
          tutorialId: tutorial.id,
          tutorialVersion: tutorial.version,
          chapterId: chapter.id,
          trackId,
          startedAt,
          tries: counterUpdate.tries,
          attempts: counterUpdate.attempts,
          isPracticeProgress: isPractice,
          verdict: computedVerdict,
          callSite: site,
        });
        if (computedVerdict === CORRECT) {
          setChapterSessionRows((prev) => [
            ...prev.filter((r) => r.lessonId !== lesson.id),
            {
              lessonId: lesson.id,
              tries: counterUpdate.tries,
              attempts: counterUpdate.attempts,
            },
          ]);
        }
      } finally {
        setSubmitting(false);
      }
      return;
    }

    // Assessed Interactive DSL lesson (Selection, FillTheGap, ValidatedInput, Spell)
    let computedVerdict: Verdict = INCORRECT;

    if (selectionMod && selectionMod.items) {
      const itemsWithSelected = selectionMod.items.map((it, idx) => ({
        text: it.text,
        correct: it.correct,
        selected: selectedItems.has(idx),
      }));
      computedVerdict = gradeSelection(itemsWithSelected);
    } else if (codeModWithInteraction?.activeInteraction) {
      const inter = codeModWithInteraction.activeInteraction;
      if (inter.type === "validatedInput") {
        computedVerdict = gradeValidatedInput(validatedInputText, inter.expectedText || "");
      } else if (inter.type === "spell") {
        const expectedChars = (inter.expectedText || "").split("");
        computedVerdict = gradeSpell(spellChars, expectedChars);
      } else {
        // fillTheGap or selection inside code
        const selectedTexts = placedGaps.map((g) => g?.text ?? "");
        const expectedTexts = inter.gaps.map((g) => g.expectedText);
        computedVerdict = gradeFillTheGap(selectedTexts, expectedTexts);
      }
    }

    const normalizedVerdict: "CORRECT" | "PARTIAL" | "INCORRECT" =
      computedVerdict === CORRECT
        ? "CORRECT"
        : computedVerdict === PARTIAL
        ? "PARTIAL"
        : "INCORRECT";

    const site: "V" | "W" | "X" =
      normalizedVerdict === "CORRECT" ? "V" : normalizedVerdict === "PARTIAL" ? "W" : "X";

    const counterUpdate = applySubmission(normalizedVerdict, wrongLatchC, attemptsD);
    setAttemptsD(counterUpdate.attempts);
    setWrongLatchC(counterUpdate.C_after ?? false);
    setVerdict(normalizedVerdict);
    setLastTransition({
      site,
      tries: counterUpdate.tries,
      attempts: counterUpdate.attempts,
      C_after: counterUpdate.C_after,
    });

    setSubmitting(true);
    try {
      await onLessonSubmit({
        lessonId: lesson.id,
        tutorialId: tutorial.id,
        tutorialVersion: tutorial.version,
        chapterId: chapter.id,
        trackId,
        startedAt,
        tries: counterUpdate.tries,
        attempts: counterUpdate.attempts,
        isPracticeProgress: isPractice,
        verdict: normalizedVerdict,
        callSite: site,
      });
      if (normalizedVerdict === "CORRECT" || normalizedVerdict === "PARTIAL") {
        setChapterSessionRows((prev) => [
          ...prev.filter((r) => r.lessonId !== lesson.id),
          {
            lessonId: lesson.id,
            tries: counterUpdate.tries,
            attempts: counterUpdate.attempts,
          },
        ]);
      }
    } finally {
      setSubmitting(false);
    }
  };

  const advanceOrFinish = () => {
    if (lessonIdx + 1 < lessons.length) {
      setLessonIdx(lessonIdx + 1);
    } else {
      setChapterFinished(true);
    }
  };

  const askAiTutor = async (
    instantPrompt?: "ExplainError" | "ExplainInteractiveMistake" | "FirstHint" | "SecondHint"
  ) => {
    setShowAiTutor(true);
    setAiLoading(true);
    try {
      const expectedAnswer =
        lesson.contentType === "executableFiles"
          ? lesson.executableContent?.files?.[0]?.solvedContent || ""
          : codeModWithInteraction?.activeInteraction?.expectedText ||
            codeModWithInteraction?.activeInteraction?.gaps.map((g) => g.expectedText).join(" ") ||
            selectionMod?.items?.filter((i) => i.correct).map((i) => i.text).join(", ") ||
            "";

      const res = await fetch("/api/mimo/action", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "AI_TUTOR",
          lessonId: lesson.id,
          tutorialId: tutorial.id,
          mode: lesson.contentType === "executableFiles" ? "executable" : "interactive",
          pathName:
            lesson.contentType === "executableFiles"
              ? userFiles[activeFileIdx]?.name || "script.py"
              : codeModWithInteraction?.fileName || tutorial.title,
          lessonContext: activeDslSource.replace(/<[^>]+>/g, " ").slice(0, 300),
          instructions: lesson.executableContent?.instructions,
          expectedAnswer,
          instantPrompt,
          userText: aiInput || undefined,
          errorText: sandboxOutput?.error || "IncorrectSolutionException",
          wrongAnswer:
            validatedInputText ||
            placedGaps.map((g) => g?.text).join(" ") ||
            "Selected wrong option",
        }),
      });
      const data = await res.json();
      if (data.ok && data.tutorRes) {
        setAiEnvelope(data.tutorRes.systemEnvelope);
        setAiMessages((prev) => [
          ...prev,
          data.tutorRes.userMessage,
          data.tutorRes.assistantMessage,
        ]);
        setAiInput("");
      }
    } finally {
      setAiLoading(false);
    }
  };

  // Coding keyboard snippets based on lesson language
  const codingSnippets = useMemo(() => {
    const lang = (
      codeModWithInteraction?.codeLang ||
      tutorial.codeLanguage ||
      "html"
    ).toLowerCase();
    if (lang === "html") {
      return ["<", ">", "</", "button", "h1", "p", "ol", "li", "strong", "Login", "Subscribe"];
    }
    if (lang === "python") {
      return ["=", "+=", ">=", "<=", "==", ":", "if ", "else:", "for ", "in range(", "print(", "True", "False"];
    }
    if (lang === "sql") {
      return ["SELECT", "FROM", "WHERE", "*", "INSERT INTO", "VALUES", "AND", "ORDER BY", ";"];
    }
    return ["const ", "let ", "await", "=>", "===", "console.log(", "shipping", "calcTotal", "{", "}", ";"];
  }, [codeModWithInteraction, tutorial.codeLanguage]);

  // Render Chapter Complete / Reward Ritual Screen (ChapterFinishedViewModel)
  if (chapterFinished) {
    const solvedInSession = chapterSessionRows.filter((r) => r.tries >= 1).length;
    const firstTryInSession = chapterSessionRows.filter(
      (r) => r.tries >= 1 && r.attempts === 1
    ).length;

    return (
      <div
        className={`flex flex-col h-full justify-between p-6 ${
          nightMode ? "bg-[#252746] text-white" : "bg-[#F6F7FB] text-[#252746]"
        }`}
      >
        <div className="text-center space-y-3 pt-4">
          <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-[#8D60E2] to-[#7E4BDE] mx-auto flex items-center justify-center shadow-[0_8px_0_#6E3EC8]">
            <MimoIcon name="ic_trophy_filled" size={44} mono className="text-white" />
          </div>
          <span className="inline-block text-xs font-bold uppercase tracking-wider px-3 py-1 rounded-full bg-[#7E4BDE]/15 text-[#7E4BDE]">
            ChapterFinishedViewModel · VERIFIED_STATIC
          </span>
          <h2 className="text-2xl font-extrabold">{chapter.title} Complete!</h2>
          <p className="text-sm opacity-80">
            You finished all {lessons.length} lessons in <strong>{tutorial.title}</strong>.
          </p>
        </div>

        {/* Exact F2 / F3 / F5 Derived Metrics Cards */}
        <div className="grid grid-cols-3 gap-3 my-4">
          <div
            className={`rounded-2xl p-3 text-center border ${
              nightMode ? "bg-[#3F4273] border-[#4A4D85]" : "bg-white border-[#E4E6F1]"
            }`}
          >
            <div className="text-xs opacity-70 font-semibold">AnswersInChapter</div>
            <div className="text-xl font-extrabold text-[#66BC5A] mt-1">
              {solvedInSession}/{ Math.max(lessons.length, chapterSessionRows.length) }
            </div>
            <div className="text-[10px] opacity-60 font-mono">F2 / F3</div>
          </div>
          <div
            className={`rounded-2xl p-3 text-center border ${
              nightMode ? "bg-[#3F4273] border-[#4A4D85]" : "bg-white border-[#E4E6F1]"
            }`}
          >
            <div className="text-xs opacity-70 font-semibold">First-Try Solved</div>
            <div className="text-xl font-extrabold text-[#7E4BDE] mt-1">{firstTryInSession}</div>
            <div className="text-[10px] opacity-60 font-mono">F5 (attempts==1)</div>
          </div>
          <div
            className={`rounded-2xl p-3 text-center border ${
              nightMode ? "bg-[#3F4273] border-[#4A4D85]" : "bg-white border-[#E4E6F1]"
            }`}
          >
            <div className="text-xs opacity-70 font-semibold">Sparks XP</div>
            <div className="text-xl font-extrabold text-[#F1C325] mt-1">
              +{Math.max(15, solvedInSession * 15)}
            </div>
            <div className="text-[10px] opacity-60 font-mono">Daily Goal Ring</div>
          </div>
        </div>

        {/* Reward Ritual Box (reward_choose_box / reward_tap_to_open) */}
        <div
          className={`rounded-2xl p-4 border text-center space-y-3 ${
            nightMode ? "bg-[#333661] border-[#4A4D85]" : "bg-white border-[#E4E6F1]"
          }`}
        >
          <div className="text-xs font-bold uppercase tracking-wider text-[#7E4BDE]">
            Reward Ritual (/v1/user/rewards/next)
          </div>
          {!rewardBoxOpened ? (
            <>
              <p className="text-xs opacity-80">
                Tap the Mimo Reward Chest to confirm your chapter completion reward (+50 Coins)!
              </p>
              <button
                type="button"
                onClick={async () => {
                  setRewardBoxOpened(true);
                  await onClaimRewardChest();
                }}
                className="px-5 py-2.5 rounded-xl bg-[#F4D055] text-[#252746] font-extrabold text-sm shadow-[0_4px_0_#D5A80E] hover:brightness-105 transition"
              >
                🎁 Tap to Open Reward Chest (reward_tap_to_open)
              </button>
            </>
          ) : (
            <div className="flex items-center justify-center gap-2 text-[#66BC5A] font-extrabold text-sm">
              <MimoIcon name="ic_coin" size={24} />
              <span>+50 Coins Credited via POST /v1/user/rewards/confirm!</span>
            </div>
          )}
        </div>

        <button
          type="button"
          onClick={onCloseChapter}
          className="w-full py-3.5 rounded-2xl bg-[#7E4BDE] text-white font-bold text-base shadow-[0_5px_0_#6E3EC8] hover:brightness-105 transition"
        >
          Continue to Path Map
        </button>
      </div>
    );
  }

  const progressPct = Math.round(((lessonIdx + (verdict === CORRECT ? 1 : 0.35)) / lessons.length) * 100);

  return (
    <div
      className={`flex flex-col h-full relative select-none ${
        nightMode ? "bg-[#252746] text-white" : "bg-[#F6F7FB] text-[#252746]"
      }`}
    >
      {/* 1. ChapterActivity Top Toolbar (chapter_toolbar.xml) */}
      <div
        className={`flex items-center gap-3 px-4 py-2.5 border-b shrink-0 ${
          nightMode ? "bg-[#333661] border-[#3F4273]" : "bg-white border-[#EDEEF6]"
        }`}
      >
        <button
          type="button"
          onClick={() => setShowQuitDialog(true)}
          title="btn_lesson_close"
          className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-black/5 transition"
        >
          <MimoIcon name="ic_close" size={20} mono />
        </button>

        {/* 6dp lesson_progressbar_height */}
        <div className="flex-1">
          <div
            className={`h-2 rounded-full overflow-hidden ${
              nightMode ? "bg-[#252746]" : "bg-[#E4E6F1]"
            }`}
          >
            <div
              className="h-full rounded-full bg-[#8D60E2] transition-all duration-300"
              style={{ width: `${ Math.min(100, Math.max(8, progressPct)) }%` }}
            />
          </div>
          <div className="flex items-center justify-between text-[10px] opacity-70 mt-1 font-medium">
            <span>
              {lessonIdx + 1}/{lessons.length} · {lesson.title} (#{lesson.id})
            </span>
            <span className="font-mono">
              {lesson.contentType === "executableFiles"
                ? "ExecutableFiles"
                : parsedDoc.interactionFamily}
            </span>
          </div>
        </div>

        {/* Hard Mode Toggle if lesson ships with hardModeContent */}
        {lesson.hardModeContent && (
          <button
            type="button"
            onClick={() => setUseHardMode((v) => !v)}
            className={`px-2 py-1 rounded-lg text-[10px] font-extrabold border transition ${
              useHardMode
                ? "bg-[#F05A6E] text-white border-[#F05A6E]"
                : "bg-transparent border-current opacity-70"
            }`}
            title="Toggle hardModeContent (shipped in APK tutorial JSON)"
          >
            {useHardMode ? "HARD MODE ON" : "HARD MODE"}
          </button>
        )}

        {/* AI Tutor Pulse Button (AiTutorBottomSheetKt) */}
        <button
          type="button"
          onClick={() => setShowAiTutor(true)}
          title="Open AI Tutor (AiTutorBottomSheetKt)"
          className="px-2.5 py-1.5 rounded-xl bg-[#7E4BDE]/15 text-[#7E4BDE] flex items-center gap-1 text-xs font-bold hover:bg-[#7E4BDE]/25 transition"
        >
          <MimoIcon name="ic_ai_tutor" size={18} />
          <span className="hidden sm:inline">AI Tutor</span>
        </button>
      </div>

      {/* 2. Scrollable Lesson Body */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
        {/* Provenance & Metadata Pill */}
        <div className="flex flex-wrap items-center justify-between gap-2 text-[11px]">
          <span
            className={`px-2.5 py-0.5 rounded-full font-semibold ${
              lesson.provenance === "VERIFIED_ASSET_VERBATIM"
                ? "bg-[#66BC5A]/15 text-[#66BC5A]"
                : "bg-[#3890FA]/15 text-[#3890FA]"
            }`}
          >
            {lesson.provenance === "VERIFIED_ASSET_VERBATIM"
              ? "★ VERIFIED_ASSET (Verbatim APK Lesson)"
              : "◆ CURRICULUM_GRAPH (Mimo v753 Index)"}
          </span>
          <span className="font-mono opacity-60">
            attempts={attemptsD} · wrongLatch(C)={String(wrongLatchC)}
          </span>
        </div>

        {/* === EXECUTABLE LESSON PLAYER (ExecutableLessonViewModel) === */}
        {lesson.contentType === "executableFiles" && lesson.executableContent ? (
          <div className="space-y-3">
            {/* Instructions Card */}
            <div
              className={`rounded-2xl p-3.5 border text-sm leading-relaxed ${
                nightMode ? "bg-[#333661] border-[#3F4273]" : "bg-white border-[#E4E6F1]"
              }`}
            >
              <div className="text-xs font-bold uppercase tracking-wider text-[#7E4BDE] mb-1">
                executable_lesson_instructions
              </div>
              <p className="whitespace-pre-line">{lesson.executableContent.instructions}</p>
            </div>

            {/* File Tabs + See Solution Diff button */}
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-1.5 overflow-x-auto">
                {userFiles.map((f, idx) => (
                  <button
                    key={f.name}
                    type="button"
                    onClick={() => setActiveFileIdx(idx)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold transition ${
                      activeFileIdx === idx
                        ? "bg-[#7E4BDE] text-white"
                        : nightMode
                        ? "bg-[#333661] text-white/70"
                        : "bg-white text-[#252746]/70 border border-[#E4E6F1]"
                    }`}
                  >
                    {f.name}
                  </button>
                ))}
              </div>
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => setShowSolutionDiff((v) => !v)}
                  className="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-[#3890FA]/15 text-[#3890FA] hover:bg-[#3890FA]/25"
                >
                  {showSolutionDiff ? "Hide Diff" : "See Solution"}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    if (!lesson.executableContent) return;
                    setUserFiles(
                      lesson.executableContent.files.map((f) => ({
                        name: f.name,
                        codeLanguage: f.codeLanguage,
                        content: f.solvedContent ?? f.content,
                        solvedContent: f.solvedContent,
                      }))
                    );
                  }}
                  className="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-[#66BC5A]/15 text-[#66BC5A] hover:bg-[#66BC5A]/25"
                >
                  Auto-Solve
                </button>
              </div>
            </div>

            {/* Code Editor Surface (code_editor_text_size = 15sp, #1D1F32) */}
            <div className="rounded-2xl overflow-hidden border border-[#3F4273] bg-[#1D1F32] text-white shadow-inner">
              <div className="flex items-center justify-between px-3 py-1.5 bg-[#252746] text-[11px] font-mono text-white/70 border-b border-white/10">
                <span>
                  {userFiles[activeFileIdx]?.name} ({userFiles[activeFileIdx]?.codeLanguage})
                </span>
                <button
                  type="button"
                  onClick={() => {
                    const res = executeCodeSandbox(userFiles);
                    setSandboxOutput(res);
                  }}
                  className="text-[#A4E59B] font-bold hover:underline"
                >
                  ▶ Run Preview
                </button>
              </div>
              <textarea
                value={userFiles[activeFileIdx]?.content ?? ""}
                onChange={(e) => {
                  const val = e.target.value;
                  setUserFiles((prev) =>
                    prev.map((f, i) => (i === activeFileIdx ? { ...f, content: val } : f))
                  );
                }}
                rows={7}
                spellCheck={false}
                className="w-full p-3.5 bg-transparent font-mono text-[14px] leading-relaxed text-[#F5F9FE] focus:outline-none resize-y"
              />
              {/* 64dp Coding Keyboard (CodingKeyboardKt) */}
              <div className="flex items-center gap-1.5 px-3 py-2 bg-[#252746] border-t border-white/10 overflow-x-auto">
                {codingSnippets.map((snip) => (
                  <button
                    key={snip}
                    type="button"
                    onClick={() => {
                      setUserFiles((prev) =>
                        prev.map((f, i) =>
                          i === activeFileIdx ? { ...f, content: f.content + snip } : f
                        )
                      );
                    }}
                    className="px-2.5 py-1 rounded-lg bg-[#3F4273] hover:bg-[#7E4BDE] text-white font-mono text-xs shrink-0 transition"
                  >
                    {snip}
                  </button>
                ))}
              </div>
            </div>

            {/* CodeDiffViewModel (see_solution_user_code vs see_solution_our_solution) */}
            {showSolutionDiff && (
              <div className="rounded-2xl p-3.5 bg-[#1D1F32] border border-[#3890FA]/50 text-white text-xs font-mono space-y-2">
                <div className="text-[#3890FA] font-bold">
                  CodeDiffViewModel · see_solution_our_solution:
                </div>
                <pre className="whitespace-pre-wrap text-[#A4E59B] bg-black/30 p-2.5 rounded-xl">
                  {userFiles[activeFileIdx]?.solvedContent || "(Any non-empty valid solution)"}
                </pre>
              </div>
            )}

            {/* Console / Visual Output (InputConsoleActivity) */}
            {sandboxOutput && (
              <div className="rounded-2xl overflow-hidden border border-[#3F4273] bg-[#1D1F32] text-white">
                <div className="px-3 py-1.5 bg-[#252746] text-[11px] font-mono text-white/70 border-b border-white/10">
                  Console / Browser Output (InputConsoleActivity)
                </div>
                {sandboxOutput.htmlPreview ? (
                  <iframe
                    title="Executable HTML Preview"
                    srcDoc={sandboxOutput.htmlPreview}
                    className="w-full h-44 bg-white border-0"
                    sandbox="allow-scripts"
                  />
                ) : (
                  <pre className="p-3 text-xs font-mono text-[#A4E59B] whitespace-pre-wrap">
                    {sandboxOutput.error ? `Error: ${sandboxOutput.error}` : sandboxOutput.stdout}
                  </pre>
                )}
              </div>
            )}
          </div>
        ) : (
          /* === INTERACTIVE DSL LESSON PLAYER (Lte/c.b 27-tag AST renderer) === */
          <div className="space-y-4">
            {parsedDoc.modules.map((mod) => {
              const visible = isModuleVisible(mod.visibleIf, verdict);
              if (!visible) return null;

              if (mod.kind === "paragraph") {
                const isFeedbackBlock = mod.visibleIf !== "ALWAYS";
                return (
                  <div
                    key={mod.id}
                    className={`text-[15px] leading-relaxed ${
                      isFeedbackBlock
                        ? mod.visibleIf === "CORRECT"
                          ? "p-3 rounded-xl bg-[#66BC5A]/15 border border-[#66BC5A]/40 text-[#66BC5A] font-medium"
                          : "p-3 rounded-xl bg-[#F05A6E]/15 border border-[#F05A6E]/40 text-[#F05A6E] font-medium"
                        : ""
                    }`}
                  >
                    {isFeedbackBlock && (
                      <div className="text-[10px] font-mono uppercase tracking-wider mb-1 opacity-75">
                        visible-if=&quot;{mod.visibleIf.toLowerCase()}&quot; revealed ({verdict})
                      </div>
                    )}
                    <div
                      className="[&_code]:px-1.5 [&_code]:py-0.5 [&_code]:rounded-md [&_code]:bg-[#7E4BDE]/15 [&_code]:text-[#7E4BDE] [&_code]:font-mono [&_code]:text-[13px]"
                      dangerouslySetInnerHTML={{ __html: mod.html || "" }}
                    />
                  </div>
                );
              }

              if (mod.kind === "code") {
                const inter = mod.activeInteraction;
                const fullCode = mod.fullCodeText || "";
                return (
                  <div
                    key={mod.id}
                    className="rounded-2xl overflow-hidden border border-[#3F4273] bg-[#1D1F32] text-[#F5F9FE] shadow-md"
                  >
                    <div className="flex items-center justify-between px-3.5 py-2 bg-[#252746] border-b border-white/10 text-xs font-mono text-white/75">
                      <span>{mod.fileName || "code"}</span>
                      <span className="uppercase text-[10px] px-2 py-0.5 rounded bg-white/10">
                        {mod.codeLang}
                      </span>
                    </div>

                    {/* Render code with interactive gap slots or validatedInput slot */}
                    <div className="p-4 font-mono text-[14px] leading-7 whitespace-pre-wrap overflow-x-auto">
                      {!inter || inter.gaps.length === 0 ? (
                        <span>{fullCode}</span>
                      ) : inter.type === "validatedInput" ? (
                        (() => {
                          const g = inter.gaps[0];
                          const before = fullCode.slice(0, g.startIndex);
                          const after = fullCode.slice(g.endIndex);
                          return (
                            <>
                              <span>{before}</span>
                              <input
                                type="text"
                                value={validatedInputText}
                                onChange={(e) => setValidatedInputText(e.target.value)}
                                placeholder={
                                  "type here..."
                                }
                                style={{
                                  width: `${Math.max(8, (g.expectedText?.length || 5) + 3)}ch`,
                                }}
                                className="inline-block mx-1 px-2 py-0.5 rounded-lg bg-[#333661] border-2 border-[#3890FA] text-white font-mono text-[14px] focus:outline-none focus:border-[#885BDE]"
                              />
                              <span>{after}</span>
                            </>
                          );
                        })()
                      ) : (
                        (() => {
                          const pieces: React.ReactNode[] = [];
                          let cursor = 0;
                          inter.gaps.forEach((g, gIdx) => {
                            if (g.startIndex > cursor) {
                              pieces.push(
                                <span key={`txt-${gIdx}`}>
                                  {fullCode.slice(cursor, g.startIndex)}
                                </span>
                              );
                            }
                            const placed = placedGaps[gIdx];
                            pieces.push(
                              <button
                                key={`gap-${gIdx}`}
                                type="button"
                                onClick={() => {
                                  if (!placed) return;
                                  setPlacedGaps((prev) =>
                                    prev.map((item, i) => (i === gIdx ? null : item))
                                  );
                                }}
                                className={`inline-flex items-center justify-center min-w-[56px] h-7 mx-1 px-2.5 rounded-lg font-mono text-xs font-bold border-2 align-middle transition ${
                                  placed
                                    ? "bg-[#7E4BDE] border-[#8D60E2] text-white shadow-sm"
                                    : "bg-[#2F314F] border-dashed border-[#86BDFE] text-[#86BDFE]"
                                }`}
                              >
                                {placed ? placed.text : `___`}
                              </button>
                            );
                            cursor = Math.max(cursor, g.endIndex);
                          });
                          if (cursor < fullCode.length) {
                            pieces.push(<span key="txt-end">{fullCode.slice(cursor)}</span>);
                          }
                          return pieces;
                        })()
                      )}
                    </div>

                    {/* Console output block inside <code> if present */}
                    {mod.codeOutput && (
                      <div className="px-4 py-2.5 bg-black/35 border-t border-white/10 text-xs font-mono text-[#A4E59B]">
                        <span className="text-white/50 mr-2">Output:</span>
                        {mod.codeOutput}
                      </div>
                    )}

                    {/* Interaction Controls below Code Block */}
                    {inter && inter.type === "validatedInput" && (
                      <div className="p-3 bg-[#252746] border-t border-white/10 space-y-2">
                        <div className="flex items-center justify-between text-[11px] text-white/70">
                          <span>
                            interaction_hint_validated_input · Expected:{" "}
                            <code className="text-[#A4E59B]">{inter.expectedText}</code>
                          </span>
                          <div className="flex items-center gap-1.5">
                            <button
                              type="button"
                              onClick={() =>
                                setValidatedInputText(
                                  (inter.expectedText || "").toLowerCase() === inter.expectedText
                                    ? `  ${inter.expectedText}  `
                                    : (inter.expectedText || "").toLowerCase()
                                )
                              }
                              className="px-2 py-0.5 rounded bg-[#F1C325]/20 text-[#F1C325] font-bold hover:bg-[#F1C325]/30"
                              title="Fill normalised match to test qm.f PARTIAL verdict"
                            >
                              Test PARTIAL
                            </button>
                            <button
                              type="button"
                              onClick={() => setValidatedInputText(inter.expectedText || "")}
                              className="px-2 py-0.5 rounded bg-[#66BC5A]/20 text-[#A4E59B] font-bold hover:bg-[#66BC5A]/30"
                            >
                              Fill Exact
                            </button>
                          </div>
                        </div>
                        {/* 64dp CodingKeyboardKt snippet bar */}
                        <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                          {codingSnippets.map((snip) => (
                            <button
                              key={snip}
                              type="button"
                              onClick={() => setValidatedInputText((v) => v + snip)}
                              className="px-2.5 py-1 rounded-lg bg-[#3F4273] hover:bg-[#7E4BDE] text-white font-mono text-xs shrink-0"
                            >
                              {snip}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                    {inter && inter.type === "spell" && (
                      <div className="p-3 bg-[#252746] border-t border-white/10 space-y-2">
                        <div className="text-[11px] text-white/70">
                          Spell answer: <code className="text-white font-bold">{spellChars.join("") || "(tap letters)"}</code>
                        </div>
                        <div className="flex flex-wrap gap-1.5">
                          {(inter.expectedText || "var").split("").map((ch, idx) => (
                            <button
                              key={`${ch}-${idx}`}
                              type="button"
                              onClick={() => setSpellChars((prev) => [...prev, ch])}
                              className="w-8 h-8 rounded-lg bg-[#3F4273] hover:bg-[#7E4BDE] text-white font-mono font-bold text-sm"
                            >
                              {ch}
                            </button>
                          ))}
                          <button
                            type="button"
                            onClick={() => setSpellChars([])}
                            className="px-2.5 h-8 rounded-lg bg-white/10 text-xs text-white/70"
                          >
                            Clear
                          </button>
                        </div>
                      </div>
                    )}

                    {inter &&
                      inter.type !== "validatedInput" &&
                      inter.type !== "spell" &&
                      inter.options.length > 0 && (
                        <div className="p-3.5 bg-[#252746] border-t border-white/10 space-y-2">
                          <div className="flex items-center justify-between text-[11px] text-white/70">
                            <span>interaction_hint_ftg: Tap the snippets below</span>
                            <button
                              type="button"
                              onClick={() => {
                                const correctOpts = inter.gaps.map((g, idx) => ({
                                  optionId: `auto-${idx}`,
                                  text: g.expectedText,
                                }));
                                setPlacedGaps(correctOpts);
                              }}
                              className="text-[#A4E59B] font-bold hover:underline"
                            >
                              Auto-Fill Correct
                            </button>
                          </div>
                          <div className="flex flex-wrap gap-2">
                            {inter.options.map((opt) => {
                              const alreadyUsed = placedGaps.some(
                                (p) => p?.optionId === opt.id
                              );
                              return (
                                <button
                                  key={opt.id}
                                  type="button"
                                  disabled={alreadyUsed}
                                  onClick={() => {
                                    const nextEmptyIdx = placedGaps.findIndex((p) => p === null);
                                    if (nextEmptyIdx === -1) return;
                                    setPlacedGaps((prev) =>
                                      prev.map((item, i) =>
                                        i === nextEmptyIdx
                                          ? { optionId: opt.id, text: opt.text }
                                          : item
                                      )
                                    );
                                  }}
                                  className={`px-3 py-1.5 rounded-xl font-mono text-xs font-bold border transition ${
                                    alreadyUsed
                                      ? "bg-white/5 border-white/10 text-white/30 cursor-not-allowed"
                                      : "bg-[#3F4273] border-[#4A4D85] text-white shadow-[0_3px_0_#1D1F32] hover:border-[#8D60E2]"
                                  }`}
                                >
                                  {opt.text}
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      )}
                  </div>
                );
              }

              if (mod.kind === "selection" && mod.items) {
                return (
                  <div key={mod.id} className="space-y-2.5">
                    <div className="text-[11px] opacity-70 font-medium">
                      {mod.multiple
                        ? "interaction_hint_multiple_choice: Select options"
                        : "interaction_hint_single_choice: Select one option"}
                    </div>
                    {mod.items.map((it, idx) => {
                      const isSel = selectedItems.has(idx);
                      return (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => {
                            setSelectedItems((prev) => {
                              const next = new Set(prev);
                              const correctCount =
                                mod.items?.filter((x) => x.correct).length ?? 1;
                              if (correctCount <= 1) {
                                next.clear();
                                next.add(idx);
                              } else {
                                if (next.has(idx)) next.delete(idx);
                                else next.add(idx);
                              }
                              return next;
                            });
                          }}
                          className={`w-full text-left p-3.5 rounded-2xl border-2 transition flex items-center justify-between gap-3 ${
                            isSel
                              ? "border-[#3890FA] bg-[#3890FA]/10 shadow-none"
                              : nightMode
                              ? "border-[#3F4273] bg-[#333661] hover:border-[#4A4D85]"
                              : "border-[#E4E6F1] bg-white shadow-[0_3px_0_#E4E6F1] hover:border-[#CED0E2]"
                          }`}
                        >
                          <div
                            className={`text-sm ${mod.isCode ? "font-mono" : "font-medium"} [&_code]:font-mono [&_code]:px-1.5 [&_code]:py-0.5 [&_code]:rounded [&_code]:bg-[#7E4BDE]/15 [&_code]:text-[#7E4BDE]`}
                            dangerouslySetInnerHTML={{ __html: it.html }}
                          />
                          <span
                            className={`w-5 h-5 rounded-md border-2 flex items-center justify-center shrink-0 ${
                              isSel
                                ? "border-[#3890FA] bg-[#3890FA] text-white"
                                : "border-current opacity-40"
                            }`}
                          >
                            {isSel && "✓"}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                );
              }

              if (mod.kind === "webview" && mod.webviewContent) {
                // Inject MimoLesson.postMessage bridge into embedded WebView HTML
                const bridgeScript = `
                  <script>
                    window.MimoLesson = {
                      postMessage: function(payload) {
                        window.parent.postMessage(payload, '*');
                      }
                    };
                    document.addEventListener('click', function(e) {
                      const btn = e.target.closest('button');
                      if (btn) {
                        setTimeout(function() {
                          const resEl = document.getElementById('result');
                          if (resEl && resEl.textContent.toLowerCase().includes('correct')) {
                            window.parent.postMessage({ kind: 'activity', result: 'mimo.activity.correct' }, '*');
                          } else if (resEl && resEl.textContent.toLowerCase().includes('try again')) {
                            window.parent.postMessage({ kind: 'activity', result: 'mimo.activity.wrong' }, '*');
                          } else {
                            window.parent.postMessage({ kind: 'activity', result: 'mimo.activity.completed' }, '*');
                          }
                        }, 50);
                      }
                    });
                  </script>
                `;
                const srcDocWithBridge = mod.webviewContent.includes("</body>")
                  ? mod.webviewContent.replace("</body>", `${bridgeScript}</body>`)
                  : `${mod.webviewContent}${bridgeScript}`;

                return (
                  <div
                    key={mod.id}
                    className="rounded-2xl overflow-hidden border border-[#CED0E2] bg-white shadow-sm"
                  >
                    <div className="px-3 py-1.5 bg-[#252746] text-white text-[11px] font-mono flex items-center justify-between">
                      <span>&lt;webview version=&quot;2&quot;&gt; · lesson-webview.js bridge</span>
                      <span className="text-[#A4E59B]">
                        {webviewCompleted ? "mimo.activity.correct ✓" : "Interactive"}
                      </span>
                    </div>
                    <iframe
                      title={`Mimo WebView ${mod.id}`}
                      srcDoc={srcDocWithBridge}
                      className="w-full h-64 border-0 bg-white"
                      sandbox="allow-scripts"
                    />
                    {webviewBridgeLog.length > 0 && (
                      <div className="px-3 py-1.5 bg-[#1D1F32] text-[#86BDFE] font-mono text-[10px]">
                        {webviewBridgeLog[webviewBridgeLog.length - 1]}
                      </div>
                    )}
                  </div>
                );
              }

              if (mod.kind === "database" && mod.tables) {
                return (
                  <div
                    key={mod.id}
                    className={`rounded-2xl overflow-hidden border ${
                      nightMode ? "bg-[#333661] border-[#4A4D85]" : "bg-white border-[#E4E6F1]"
                    }`}
                  >
                    <div className="px-3.5 py-2 bg-[#252746] text-white text-xs font-mono flex items-center justify-between">
                      <span>SQL Sandbox (&lt;database&gt; Lte/b.a)</span>
                      <span className="text-[10px] text-[#A4E59B]">SQLite In-Memory</span>
                    </div>
                    {mod.bootstrapScript && (
                      <pre className="px-3.5 py-2 bg-[#1D1F32] text-[#86BDFE] text-[11px] font-mono overflow-x-auto border-b border-white/10">
                        {mod.bootstrapScript}
                      </pre>
                    )}
                    <div className="p-3 space-y-3">
                      {mod.tables.map((t, tIdx) => (
                        <div key={tIdx}>
                          <div className="text-xs font-bold font-mono mb-1.5 text-[#7E4BDE]">
                            Table: {t.name}
                          </div>
                          <table className="w-full text-xs font-mono border-collapse">
                            <thead>
                              <tr className="bg-[#7E4BDE]/10">
                                {t.headers.map((h, hIdx) => (
                                  <th
                                    key={hIdx}
                                    className="border border-[#CED0E2]/40 px-2.5 py-1.5 text-left font-bold"
                                  >
                                    {h}
                                  </th>
                                ))}
                              </tr>
                            </thead>
                            <tbody>
                              {t.rows.map((r, rIdx) => (
                                <tr key={rIdx}>
                                  {r.map((cell, cIdx) => (
                                    <td
                                      key={cIdx}
                                      className="border border-[#CED0E2]/40 px-2.5 py-1.5"
                                    >
                                      {cell}
                                    </td>
                                  ))}
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              }

              return null;
            })}
          </div>
        )}
      </div>

      {/* 3. AnimatedResultBottomSheetKt (Feedback Banner when verdict != null) */}
      {verdict && (
        <div
          className={`px-4 py-3 border-t space-y-2 ${
            verdict === CORRECT
              ? "bg-[#66BC5A]/15 border-[#66BC5A]"
              : verdict === PARTIAL
              ? "bg-[#F1C325]/20 border-[#F1C325]"
              : "bg-[#F05A6E]/15 border-[#F05A6E]"
          }`}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span
                className={`w-6 h-6 rounded-full flex items-center justify-center text-white text-xs font-bold ${
                  verdict === CORRECT
                    ? "bg-[#66BC5A]"
                    : verdict === PARTIAL
                    ? "bg-[#D5A80E]"
                    : "bg-[#F05A6E]"
                }`}
              >
                {verdict === CORRECT ? "✓" : verdict === PARTIAL ? "≈" : "✕"}
              </span>
              <div>
                <div className="font-extrabold text-sm">
                  {verdict === CORRECT
                    ? "Correct! (jm.m)"
                    : verdict === PARTIAL
                    ? "Almost! Pay attention to exact casing/whitespace (jm.n PARTIAL)"
                    : "Not quite right — try again! (jm.o)"}
                </div>
                {verdict === PARTIAL && codeModWithInteraction?.activeInteraction?.expectedText && (
                  <div className="text-xs opacity-90">
                    The exact expected answer is:{" "}
                    <code className="font-mono font-bold underline">
                      {codeModWithInteraction.activeInteraction.expectedText}
                    </code>
                  </div>
                )}
              </div>
            </div>
            {lastTransition && (
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-black/10">
                Site {lastTransition.site}: tries={lastTransition.tries}, attempts={lastTransition.attempts}
              </span>
            )}
          </div>

          {verdict === INCORRECT && (
            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={() => askAiTutor("ExplainInteractiveMistake")}
                className="px-3 py-1.5 rounded-xl bg-[#7E4BDE] text-white text-xs font-bold flex items-center gap-1"
              >
                <MimoIcon name="ic_ai_tutor" size={14} mono className="text-white" />
                <span>Explain My Mistake (AI Tutor)</span>
              </button>
              <button
                type="button"
                onClick={() => setVerdict(null)}
                className="px-3 py-1.5 rounded-xl bg-black/10 text-xs font-bold"
              >
                Edit Answer
              </button>
            </div>
          )}
        </div>
      )}

      {/* 4. Bottom Action Bar (RunButton$State) */}
      <div
        className={`p-4 border-t shrink-0 ${
          nightMode ? "bg-[#333661] border-[#3F4273]" : "bg-white border-[#EDEEF6]"
        }`}
      >
        {verdict === CORRECT || verdict === PARTIAL ? (
          <button
            type="button"
            onClick={advanceOrFinish}
            className="w-full py-3.5 rounded-2xl bg-[#66BC5A] text-white font-extrabold text-base shadow-[0_5px_0_#4E9943] hover:brightness-105 transition"
          >
            Continue ({lessonIdx + 1 < lessons.length ? "Next Lesson" : "Finish Chapter"})
          </button>
        ) : (
          <button
            type="button"
            disabled={!canCheckAnswer || submitting}
            onClick={handleCheckOrContinue}
            className={`w-full py-3.5 rounded-2xl font-extrabold text-base transition ${
              canCheckAnswer && !submitting
                ? "bg-[#7E4BDE] text-white shadow-[0_5px_0_#6E3EC8] hover:brightness-105"
                : "bg-[#7E4BDE]/25 text-[#7E4BDE]/60 cursor-not-allowed"
            }`}
          >
            {submitting
              ? "Processing..."
              : lesson.contentType === "executableFiles"
              ? "Run & Check Code"
              : parsedDoc.hasAssessedInteraction
              ? "Check Answer"
              : "Continue"}
          </button>
        )}
      </div>

      {/* 5. Quit Lesson Dialog (QUIT_DIALOG state in M09 Navigation State Machine) */}
      {showQuitDialog && (
        <div className="absolute inset-0 z-40 bg-black/60 flex items-center justify-center p-6">
          <div
            className={`w-full max-w-xs rounded-3xl p-5 space-y-3 text-center shadow-2xl ${
              nightMode ? "bg-[#333661] text-white" : "bg-white text-[#252746]"
            }`}
          >
            <h3 className="text-lg font-extrabold">Are you sure you want to quit?</h3>
            <p className="text-xs opacity-75">
              Your solved lessons in this chapter are already persisted in <code>lesson_progress</code>.
            </p>
            <div className="space-y-2 pt-2">
              <button
                type="button"
                onClick={onCloseChapter}
                className="w-full py-2.5 rounded-xl bg-[#F05A6E] text-white font-bold text-sm"
              >
                Quit lesson
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowQuitDialog(false);
                  onSwitchPath();
                }}
                className={`w-full py-2.5 rounded-xl font-bold text-sm border ${
                  nightMode ? "border-[#4A4D85]" : "border-[#E4E6F1]"
                }`}
              >
                Choose a different path
              </button>
              <button
                type="button"
                onClick={() => setShowQuitDialog(false)}
                className="w-full py-2 rounded-xl text-xs font-bold opacity-75"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 6. AiTutorBottomSheetKt (SSE AI Tutor with {{{ ... }}} Fenced Context) */}
      {showAiTutor && (
        <div className="absolute inset-0 z-40 bg-black/60 flex flex-col justify-end">
          <div
            className={`rounded-t-3xl p-4 max-h-[82%] flex flex-col gap-3 shadow-2xl ${
              nightMode ? "bg-[#333661] text-white" : "bg-white text-[#252746]"
            }`}
          >
            <div className="flex items-center justify-between border-b pb-2.5 border-current/10">
              <div className="flex items-center gap-2">
                <MimoIcon name="ic_ai_tutor" size={22} />
                <div>
                  <div className="font-extrabold text-sm">Mimo AI Tutor</div>
                  <div className="text-[10px] opacity-65 font-mono">
                    POST /v1/aiTutor/conversations (Accept: text/event-stream)
                  </div>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowAiTutor(false)}
                className="p-1 rounded-lg hover:bg-black/10"
              >
                <MimoIcon name="ic_close" size={18} mono />
              </button>
            </div>

            {/* PromptSuggestions Chips (FirstHint, SecondHint, ExplainError, ExplainInteractiveMistake) */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
              <button
                type="button"
                onClick={() => askAiTutor("FirstHint")}
                className="px-3 py-1 rounded-full bg-[#7E4BDE]/15 text-[#7E4BDE] text-xs font-bold shrink-0"
              >
                💡 FirstHint
              </button>
              <button
                type="button"
                onClick={() => askAiTutor("SecondHint")}
                className="px-3 py-1 rounded-full bg-[#7E4BDE]/15 text-[#7E4BDE] text-xs font-bold shrink-0"
              >
                🎯 SecondHint
              </button>
              <button
                type="button"
                onClick={() => askAiTutor("ExplainInteractiveMistake")}
                className="px-3 py-1 rounded-full bg-[#F05A6E]/15 text-[#F05A6E] text-xs font-bold shrink-0"
              >
                🔍 ExplainMistake
              </button>
              <button
                type="button"
                onClick={() => askAiTutor("ExplainError")}
                className="px-3 py-1 rounded-full bg-[#3890FA]/15 text-[#3890FA] text-xs font-bold shrink-0"
              >
                🐞 ExplainError
              </button>
            </div>

            {/* Fenced System Envelope Inspector */}
            {aiEnvelope && (
              <details className="text-[10px] font-mono bg-black/20 p-2 rounded-xl">
                <summary className="cursor-pointer font-bold text-[#B89CED]">
                  Inspect &#123;&#123;&#123; ... &#125;&#125;&#125; SystemMessage Envelope (08_AI_TUTOR_ARCHITECTURE)
                </summary>
                <pre className="mt-1 whitespace-pre-wrap overflow-x-auto">
                  {JSON.stringify(aiEnvelope, null, 2)}
                </pre>
              </details>
            )}

            {/* Chat Messages */}
            <div className="flex-1 overflow-y-auto space-y-2 min-h-[140px] max-h-[240px] pr-1">
              {aiMessages.length === 0 && !aiLoading && (
                <div className="text-xs opacity-70 text-center py-6">
                  Tap a <code>PromptSuggestions</code> chip above or ask a question about{" "}
                  <strong>{lesson.title}</strong>!
                </div>
              )}
              {aiMessages.map((m) => (
                <div
                  key={m.id}
                  className={`p-3 rounded-2xl text-xs leading-relaxed max-w-[88%] ${
                    m.role === "user"
                      ? "ml-auto bg-[#7E4BDE] text-white rounded-br-sm"
                      : nightMode
                      ? "bg-[#3F4273] text-white rounded-bl-sm"
                      : "bg-[#F6F7FB] text-[#252746] rounded-bl-sm"
                  }`}
                >
                  {m.content}
                </div>
              ))}
              {aiLoading && (
                <div className="text-xs font-mono opacity-70 animate-pulse">
                  ChatWritingIndicator: streaming SSE tokens...
                </div>
              )}
            </div>

            {/* Input row */}
            <div className="flex items-center gap-2 pt-1">
              <input
                type="text"
                value={aiInput}
                onChange={(e) => setAiInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && aiInput.trim()) askAiTutor();
                }}
                placeholder="Ask Mimo AI Tutor..."
                className={`flex-1 px-3.5 py-2 rounded-xl text-xs border focus:outline-none ${
                  nightMode
                    ? "bg-[#252746] border-[#4A4D85] text-white"
                    : "bg-[#F6F7FB] border-[#E4E6F1] text-[#252746]"
                }`}
              />
              <button
                type="button"
                onClick={() => askAiTutor()}
                className="px-4 py-2 rounded-xl bg-[#7E4BDE] text-white text-xs font-bold"
              >
                Send
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
