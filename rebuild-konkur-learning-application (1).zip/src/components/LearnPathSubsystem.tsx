"use client";

import React, { useState } from "react";
import { MimoIcon } from "./MimoIcon";
import {
  KONKUR_COURSES,
  KONKUR_PROGRAMS,
  KONKUR_FORTNIGHT_DATES,
  KONKUR_QUESTIONS,
  KonkurCourseItem,
  chapterRefFor,
  ResolvedChapterRef,
  ROLE_FA,
  CHAPTER_TYPE_FA,
  LessonProgressRow,
  faNum,
} from "@/lib/mimo-engine";

export interface LearnPathProps {
  screen:
    | "learn"
    | "select-path"
    | "path-overview"
    | "section-detail"
    | "section-practice"
    | "native-done";
  selectionKind: "course" | "program";
  programKey: string;
  courseKey: string;
  activeChapterIdx: number;
  selectedLessonId: string;
  completedNodes: string[];
  lessonProgress: LessonProgressRow[];
  coins: number;
  streak: number;
  lastCelebrationStats: {
    dxp: number;
    dcoins: number;
    lessonTitle: string;
  } | null;
  onNavigate: (target: string) => void;
  onSelectCourse: (courseKey: string) => void;
  onSelectProgram: (programKey: string) => void;
  onSelectChapterIdx: (idx: number) => void;
  onOpenLessonPlayer: (lessonId: string) => void;
  onCompleteBoltPractice: (correctCount: number, totalCount: number) => void;
  onToast: (msg: string) => void;
}

export function LearnPathSubsystem({
  screen,
  selectionKind,
  programKey,
  courseKey,
  activeChapterIdx,
  selectedLessonId,
  completedNodes,
  lessonProgress,
  coins,
  streak,
  lastCelebrationStats,
  onNavigate,
  onSelectCourse,
  onSelectProgram,
  onSelectChapterIdx,
  onOpenLessonPlayer,
  onCompleteBoltPractice,
  onToast,
}: LearnPathProps) {
  // Modals inside Learn screens
  const [chapterModalRef, setChapterModalRef] =
    useState<ResolvedChapterRef | null>(null);
  const [showUnfinishedModal, setShowUnfinishedModal] = useState(false);
  const [showPracticeModal, setShowPracticeModal] = useState(false);

  // Bolt Checkpoint Quiz (section-practice) state
  const [boltCheckpointNum, setBoltCheckpointNum] = useState<number>(4);
  const [boltAnswers, setBoltAnswers] = useState<Record<number, number>>({});
  const [boltSubmitted, setBoltSubmitted] = useState(false);

  const currentCourse: KonkurCourseItem =
    KONKUR_COURSES.find((c) => c.key === courseKey) || KONKUR_COURSES[0];
  const currentProgram =
    KONKUR_PROGRAMS.find((p) => p.key === programKey) || KONKUR_PROGRAMS[0];
  const currentChapter =
    currentCourse.chapters[
      Math.min(activeChapterIdx, currentCourse.chapters.length - 1)
    ] || currentCourse.chapters[0];

  // Flatten lessons of the current course to bind the 4 lesson nodes on the PathMap
  const courseLessons = currentCourse.chapters.flatMap((ch) => ch.lessons);
  const chapterStartOffset = activeChapterIdx * 3;
  const fourPathLessons = [0, 1, 2, 3].map(
    (offset) =>
      courseLessons[(chapterStartOffset + offset) % courseLessons.length]
  );

  // Compute course completion percentage
  const completedInCourse = courseLessons.filter((l) =>
    completedNodes.includes(l.id)
  ).length;
  const coursePct = Math.round(
    (completedInCourse / Math.max(1, courseLessons.length)) * 100
  );

  // Helper to open the ChapterModal deterministically for ANY lesson node (#curNode included!)
  const handleNodeClick = (lessonId: string) => {
    const resolved = chapterRefFor(lessonId);
    setChapterModalRef(resolved);
  };

  // Determine which of the 4 nodes on the PathMap is current ('cur'), 'done', or 'next'
  const firstUndoneIdx = fourPathLessons.findIndex(
    (l) => !completedNodes.includes(l.id)
  );
  const activeNodeIdx = firstUndoneIdx === -1 ? 0 : firstUndoneIdx;

  // ==========================================================================
  // SCREEN 1: LEARN / PATH MAP (6-Node Zigzag PathMap + 3 Pills + Overview Card)
  // ==========================================================================
  if (screen === "learn") {
    return (
      <div className="flex flex-col h-full w-full relative overflow-y-auto mimo-scroll" dir="rtl">
        {/* 1. Top 3 Pills Header (F14, PN-16: Coin / Key ∞ / Streak) */}
        <div
          className="flex items-center justify-between px-4 py-2.5 border-b shrink-0"
          style={{
            background: "var(--card)",
            borderColor: "var(--line)",
          }}
        >
          <button
            type="button"
            onClick={() => onNavigate("native-tokens")}
            className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full border text-xs font-bold cursor-pointer"
            style={{
              background: "var(--card-pressed)",
              borderColor: "var(--line)",
            }}
          >
            <MimoIcon name="ic_coin" size={22} />
            <b>{faNum(coins)}</b>
          </button>

          <button
            type="button"
            onClick={() =>
              onToast("کلیدهای مسیر آموزشی در نسخهٔ آفلاین بی‌نهایت (∞) هستند")
            }
            className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full border text-xs font-bold cursor-pointer"
            style={{
              background: "var(--card-pressed)",
              borderColor: "var(--line)",
            }}
          >
            <MimoIcon name="ic_key" size={20} />
            <span className="text-sm font-extrabold">∞</span>
          </button>

          <button
            type="button"
            onClick={() => onNavigate("leaderboard")}
            className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full border text-xs font-bold cursor-pointer"
            style={{
              background: "var(--card-pressed)",
              borderColor: "var(--line)",
            }}
          >
            <MimoIcon name="ic_streak_active" size={22} />
            <b>{faNum(streak)}</b>
          </button>
        </div>

        {/* 2. Course Switcher Bar (PN-17: ic_list_bulleted -> select-path) */}
        <div
          className="flex items-center gap-2.5 px-4 py-2.5 border-b shrink-0"
          style={{
            background: "var(--card)",
            borderColor: "var(--line)",
          }}
        >
          <button
            type="button"
            id="pathSwitchBtn"
            onClick={() => onNavigate("select-path")}
            aria-label="انتخاب مسیر"
            className="w-9 h-9 rounded-xl border flex items-center justify-center shrink-0 cursor-pointer"
            style={{
              background: "var(--card-pressed)",
              borderColor: "var(--line)",
            }}
          >
            <MimoIcon name="ic_list_bulleted" size={20} mono />
          </button>
          <div className="flex-1 min-w-0">
            <b id="learnPathTitle" className="text-sm block truncate">
              {selectionKind === "program"
                ? `${currentProgram.label} (${currentCourse.name})`
                : `${currentCourse.name} · پایهٔ ${currentCourse.grade}`}
            </b>
          </div>
          <button
            type="button"
            onClick={() => onNavigate("select-path")}
            className="text-xs font-bold px-2.5 py-1 rounded-lg cursor-pointer"
            style={{
              background: "var(--progress-weak)",
              color: "var(--primary)",
            }}
          >
            تغییر درس
          </button>
        </div>

        {/* 3. Overview Entry Card (ViewsKt$OverviewEntryPointHeader — PN-18) */}
        <div className="px-4 pt-3 pb-1 shrink-0" style={{ background: "var(--bg)" }}>
          <button
            type="button"
            id="overviewEntry"
            onClick={() => onNavigate("path-overview")}
            className="w-full p-3.5 rounded-2xl border text-right space-y-1.5 shadow-xs transition-transform active:scale-[0.99] cursor-pointer"
            style={{
              background: "var(--card)",
              borderColor: "var(--line)",
            }}
          >
            <div className="flex items-center justify-between text-xs">
              <span
                className="font-bold"
                style={{ color: "var(--primary)" }}
              >
                {currentCourse.name} · فهرست فصل‌ها
              </span>
              <span style={{ color: "var(--text-weak)" }}>
                {faNum(coursePct)}٪ تکمیل‌شده ‹
              </span>
            </div>
            <div className="text-base font-bold">
              فصل {faNum(currentChapter.ordinal)} · {currentChapter.name}
            </div>
            <div className="mimo-progress-track">
              <div
                className="mimo-progress-fill"
                style={{ width: `${Math.max(8, coursePct)}%` }}
              />
            </div>
          </button>
        </div>

        {/* 4. 6-Node Zigzag PathMap (PN-01..PN-14, Exact Q-Curve Connectors) */}
        <div className="mimo-pathwrap" dir="ltr">
          <svg
            className="absolute inset-0 w-full h-full pointer-events-none z-[1]"
            viewBox="0 0 392 690"
            preserveAspectRatio="none"
          >
            <path
              d="M242 70 H280 Q312 70 312 102 V140 M312 232 V270 Q312 302 280 302 H242"
              fill="none"
              stroke="var(--progress)"
              strokeWidth="10"
              strokeLinecap="round"
              strokeLinejoin="round"
              opacity="0.88"
            />
            <path
              d="M150 302 H112 Q80 302 80 334 V372 M80 464 V502 Q80 534 112 534 H150 M196 580 V618 Q196 650 164 650 H126"
              fill="none"
              stroke="var(--progress-bg)"
              strokeWidth="10"
              strokeLinecap="round"
              strokeLinejoin="round"
              opacity="1"
            />
          </svg>

          {/* Nodes 1..4: Real Konkur Lessons */}
          {fourPathLessons.map((lessonItem, idx) => {
            const isDone = completedNodes.includes(lessonItem.id);
            const isCur = idx === activeNodeIdx && !isDone;
            const stateClass = isDone ? "done" : isCur ? "cur" : "next";
            const ref = chapterRefFor(lessonItem.id);
            const solvedMicrosInTut = ref.chapter.lessons.filter((m) =>
              lessonProgress.some(
                (r) => r.lessonId === m.id && r.tries >= 1
              )
            ).length;
            const totalMicros = ref.chapter.lessons.length;

            return (
              <button
                key={lessonItem.id}
                type="button"
                id={isCur ? "curNode" : undefined}
                onClick={() => handleNodeClick(lessonItem.id)}
                className={`mimo-node ${stateClass} l10n${idx + 1}`}
                title={`${lessonItem.title} (${lessonItem.courseName})`}
              >
                {isDone ? (
                  <MimoIcon name="ic_check_white" size={44} mono />
                ) : isCur ? (
                  <span
                    className="w-[60px] h-[60px] rounded-full flex items-center justify-center relative"
                    style={{
                      background: `conic-gradient(from -90deg, var(--progress) 0 ${Math.max(
                        25,
                        Math.round((solvedMicrosInTut / totalMicros) * 100)
                      )}%, var(--progress-bg) ${Math.max(
                        25,
                        Math.round((solvedMicrosInTut / totalMicros) * 100)
                      )}% 100%)`,
                    }}
                  >
                    <span
                      className="absolute inset-[8px] rounded-full flex items-center justify-center"
                      style={{ background: "var(--card)" }}
                    >
                      <b
                        className="text-xs font-extrabold"
                        style={{ color: "var(--text)" }}
                        dir="rtl"
                      >
                        {solvedMicrosInTut > 0
                          ? `${faNum(solvedMicrosInTut)}/${faNum(totalMicros)}`
                          : "۱/۲"}
                      </b>
                    </span>
                  </span>
                ) : (
                  <MimoIcon name="ic_play" size={42} mono />
                )}
                <span className="mimo-node-caption" dir="rtl">
                  {lessonItem.title}
                </span>
              </button>
            );
          })}

          {/* Node 5: Charged Bolt Checkpoint (l10n5) */}
          <button
            type="button"
            onClick={() => {
              setBoltCheckpointNum(currentChapter.ordinal);
              setBoltAnswers({});
              setBoltSubmitted(false);
              onNavigate("section-practice");
            }}
            className="mimo-node bolt-active l10n5"
            title="تمرین تثبیت فصل"
          >
            <MimoIcon name="ic_bolt_charged" size={48} />
            <span className="mimo-node-caption" dir="rtl">
              تمرین فصل {faNum(currentChapter.ordinal)}
            </span>
          </button>

          {/* Node 6: Optional / Mastered Bolt Checkpoint (l10n6) */}
          <button
            type="button"
            onClick={() => {
              setBoltCheckpointNum(currentChapter.ordinal + 1);
              setBoltAnswers({});
              setBoltSubmitted(false);
              onNavigate("section-practice");
            }}
            className="mimo-node bolt-optional l10n6"
            title="چالش تسلط مبحث"
          >
            <MimoIcon name="ic_bolt_mastered" size={48} />
            <span className="mimo-node-caption" dir="rtl">
              چالش تسلط
            </span>
          </button>
        </div>

        {/* 5. Chapter Start Modal (#chapterModal — Deterministic & Dynamic!) */}
        {chapterModalRef && (
          <div
            className="fixed inset-0 z-50 flex items-center justify-center p-4"
            style={{ background: "rgba(37, 39, 70, 0.58)" }}
            dir="rtl"
          >
            <div
              className="w-full max-w-[360px] rounded-3xl p-5 space-y-3.5 shadow-2xl border max-h-[85vh] flex flex-col"
              style={{
                background: "var(--card)",
                borderColor: "var(--line)",
              }}
            >
              <div className="flex items-start justify-between">
                <div>
                  <span
                    className="text-xs font-bold block"
                    style={{ color: "var(--primary)" }}
                  >
                    {chapterModalRef.courseName} · فصل{" "}
                    {faNum(chapterModalRef.chapterOrdinal)} (
                    {chapterModalRef.chapterName})
                  </span>
                  <h2 className="text-xl font-bold mt-1">
                    {chapterModalRef.lessonTitle}
                  </h2>
                  <span className="text-xs" style={{ color: "var(--text-weak)" }}>
                    درسنامهٔ «{chapterModalRef.tutorial.title}» ·{" "}
                    {CHAPTER_TYPE_FA[chapterModalRef.chapter.type]}
                  </span>
                </div>
                <div
                  className="w-11 h-11 rounded-2xl flex items-center justify-center shrink-0"
                  style={{
                    background: "var(--progress-weak)",
                    color: "var(--primary)",
                  }}
                >
                  <MimoIcon name="ic_cap_filled" size={32} />
                </div>
              </div>

              {/* Micro-lessons list inside Chapter Modal */}
              <div className="flex-1 overflow-y-auto mimo-scroll space-y-1.5 pr-1 max-h-[260px]">
                {chapterModalRef.chapter.lessons.map((micro, mi) => {
                  const row = lessonProgress.find(
                    (r) => r.lessonId === micro.id
                  );
                  const isSolved = row && row.tries >= 1;
                  return (
                    <div
                      key={micro.id}
                      className="p-2.5 rounded-xl border flex items-center gap-2.5 text-xs"
                      style={{
                        background: "var(--card-pressed)",
                        borderColor: isSolved
                          ? "var(--success)"
                          : "var(--line)",
                      }}
                    >
                      <span
                        className="w-6 h-6 rounded-lg flex items-center justify-center font-bold shrink-0 text-white"
                        style={{
                          background: isSolved
                            ? "var(--success)"
                            : "var(--primary)",
                        }}
                      >
                        {isSolved ? "✓" : faNum(mi + 1)}
                      </span>
                      <div className="flex-1 min-w-0">
                        <b className="block truncate">{micro.title}</b>
                        <small
                          className="text-[11px]"
                          style={{ color: "var(--text-weak)" }}
                        >
                          {ROLE_FA[micro.pedagogicalRole]} ·{" "}
                          {micro.blocks.map((b) => b.renderer).join(" + ")}
                        </small>
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="space-y-2 pt-1">
                <button
                  type="button"
                  id="startLearning"
                  onClick={() => {
                    const targetId = chapterModalRef.lessonId;
                    setChapterModalRef(null);
                    onOpenLessonPlayer(targetId);
                  }}
                  className="mimo-cta"
                >
                  <span>شروع یادگیری ({faNum(chapterModalRef.chapter.lessons.length)} ریزدرس)</span>
                  <MimoIcon name="ic_arrow_left" size={18} mono />
                </button>
                <button
                  type="button"
                  onClick={() => setChapterModalRef(null)}
                  className="mimo-cta secondary"
                >
                  بستن
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  // ==========================================================================
  // SCREEN 2: SELECT PATH (3 Program Cards + 12 Konkur Courses — F15, F38)
  // ==========================================================================
  if (screen === "select-path") {
    return (
      <div className="flex flex-col h-full overflow-y-auto mimo-scroll pb-6" dir="rtl">
        <div
          className="flex items-center gap-3 px-4 shrink-0 border-b"
          style={{
            height: "var(--toolbar)",
            background: "var(--card)",
            borderColor: "var(--line)",
          }}
        >
          <button
            type="button"
            onClick={() => onNavigate("learn")}
            className="w-9 h-9 flex items-center justify-center rounded-lg cursor-pointer"
          >
            <MimoIcon name="ic_close" size={22} mono />
          </button>
          <b className="text-lg">انتخاب مسیر و کتاب درسی</b>
        </div>

        <div className="p-4 space-y-5">
          {/* 3 Big Program Cards (F38) */}
          <div className="space-y-2.5">
            <h3 className="text-sm font-bold" style={{ color: "var(--text-weak)" }}>
              یادگیری برنامه‌محور (همگام با بودجه‌بندی آزمون‌ها)
            </h3>
            <div className="grid gap-2.5">
              {KONKUR_PROGRAMS.map((prog) => {
                const isSel =
                  selectionKind === "program" && programKey === prog.key;
                return (
                  <button
                    key={prog.key}
                    type="button"
                    onClick={() => onSelectProgram(prog.key)}
                    className="p-4 rounded-2xl border-2 text-right space-y-2 transition-all cursor-pointer"
                    style={{
                      background: "var(--card)",
                      borderColor: isSel ? "var(--primary)" : "var(--line)",
                    }}
                  >
                    <div className="flex items-center justify-between">
                      <div
                        className="w-11 h-11 rounded-2xl flex items-center justify-center"
                        style={{
                          background: "var(--progress-weak)",
                          color: "var(--primary)",
                        }}
                      >
                        <MimoIcon name={prog.icon} size={32} />
                      </div>
                      <span
                        className="text-xs font-bold px-2.5 py-1 rounded-full"
                        style={{
                          background: isSel
                            ? "var(--primary)"
                            : "var(--card-pressed)",
                          color: isSel ? "#FFFFFF" : "var(--text-weak)",
                        }}
                      >
                        ۱۰ ایستگاه دوهفتگی
                      </span>
                    </div>
                    <h4 className="font-bold text-base">{prog.label}</h4>
                    <div className="mimo-progress-track">
                      <div
                        className="mimo-progress-fill"
                        style={{ width: "30%" }}
                      />
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 12 Konkur Courses (4 subjects × 3 grades) */}
          <div className="space-y-2.5">
            <h3 className="text-sm font-bold" style={{ color: "var(--text-weak)" }}>
              یادگیری مبحثی (۱۲ کتاب درسی کنکور · ۶۰ فصل · ۱۸۰ درس)
            </h3>
            <div className="grid gap-2">
              {KONKUR_COURSES.map((c) => {
                const isSelectedCourse = courseKey === c.key;
                const flat = c.chapters.flatMap((ch) => ch.lessons);
                const doneCount = flat.filter((l) =>
                  completedNodes.includes(l.id)
                ).length;

                return (
                  <button
                    key={c.key}
                    type="button"
                    onClick={() => onSelectCourse(c.key)}
                    className="p-3.5 rounded-xl border-2 flex items-center justify-between gap-3 text-right transition-all cursor-pointer"
                    style={{
                      background: "var(--card)",
                      borderColor: isSelectedCourse
                        ? "var(--primary)"
                        : "var(--line)",
                    }}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
                        style={{
                          background: "var(--progress-weak)",
                          color: "var(--primary)",
                        }}
                      >
                        <MimoIcon name={c.icon} size={26} />
                      </div>
                      <div>
                        <b className="text-sm block">{c.name}</b>
                        <small
                          className="text-xs"
                          style={{ color: "var(--text-weak)" }}
                        >
                          {faNum(c.chapters.length)} فصل ·{" "}
                          {faNum(flat.length)} درس · درسنامهٔ اختصاصی {c.subject}
                        </small>
                      </div>
                    </div>
                    <span
                      className="px-2.5 py-1 rounded-full text-xs font-bold"
                      style={{
                        background: isSelectedCourse
                          ? "var(--primary)"
                          : "var(--card-pressed)",
                        color: isSelectedCourse ? "#FFFFFF" : "var(--text)",
                      }}
                    >
                      {faNum(doneCount)}/{faNum(flat.length)}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ==========================================================================
  // SCREEN 3: PATH OVERVIEW (Certificate + Numbered Chapters — F16, F17)
  // ==========================================================================
  if (screen === "path-overview") {
    return (
      <div className="flex flex-col h-full overflow-y-auto mimo-scroll pb-6" dir="rtl">
        <div
          className="flex items-center justify-between px-4 shrink-0 border-b"
          style={{
            height: "var(--toolbar)",
            background: "var(--card)",
            borderColor: "var(--line)",
          }}
        >
          <button
            type="button"
            onClick={() => onNavigate("learn")}
            className="w-9 h-9 flex items-center justify-center rounded-lg cursor-pointer"
          >
            <MimoIcon name="ic_close" size={22} mono />
          </button>
          <b className="text-base">نمای کلی دوره</b>
          <button
            type="button"
            onClick={() => onNavigate("select-path")}
            className="w-9 h-9 flex items-center justify-center rounded-lg cursor-pointer"
          >
            <MimoIcon name="ic_switch" size={24} />
          </button>
        </div>

        <div className="p-4 space-y-4">
          <div>
            <span
              className="text-xs font-bold block"
              style={{ color: "var(--primary)" }}
            >
              {selectionKind === "program"
                ? "یادگیری برنامه‌محور"
                : "یادگیری مبحثی"}
            </span>
            <h1 className="text-xl font-bold mt-0.5">
              {selectionKind === "program"
                ? currentProgram.label
                : currentCourse.name}
            </h1>
          </div>

          {/* Certificate Card (opens #unfinishedModal — F17) */}
          <button
            type="button"
            onClick={() => setShowUnfinishedModal(true)}
            className="w-full p-4 rounded-2xl border flex items-center gap-3.5 text-right cursor-pointer"
            style={{
              background: "var(--card)",
              borderColor: "var(--line)",
            }}
          >
            <div
              className="w-12 h-12 rounded-2xl flex items-center justify-center shrink-0"
              style={{ background: "var(--progress-weak)" }}
            >
              <MimoIcon name="ic_cap_filled" size={36} />
            </div>
            <div className="flex-1 space-y-1.5">
              <div className="flex justify-between items-center">
                <b className="text-sm">مدرک پایان دوره</b>
                <span className="text-xs font-bold" style={{ color: "var(--primary)" }}>
                  {faNum(completedInCourse)}/{faNum(courseLessons.length)}
                </span>
              </div>
              <div className="mimo-progress-track">
                <div
                  className="mimo-progress-fill"
                  style={{ width: `${Math.max(6, coursePct)}%` }}
                />
              </div>
              <div className="text-xs" style={{ color: "var(--text-weak)" }}>
                {faNum(coursePct)} درصد کامل شده
              </div>
            </div>
          </button>

          {/* Chapters List */}
          <div className="space-y-2.5">
            {currentCourse.chapters.map((ch, idx) => {
              const chDone = ch.lessons.filter((l) =>
                completedNodes.includes(l.id)
              ).length;
              const chPct = Math.round(
                (chDone / Math.max(1, ch.lessons.length)) * 100
              );
              const isActive = idx === activeChapterIdx;

              return (
                <button
                  key={ch.id}
                  type="button"
                  onClick={() => {
                    onSelectChapterIdx(idx);
                    onNavigate("section-detail");
                  }}
                  className="w-full p-3.5 rounded-2xl border-2 flex items-center gap-3.5 text-right transition-all cursor-pointer"
                  style={{
                    background: "var(--card)",
                    borderColor: isActive ? "var(--primary)" : "var(--line)",
                  }}
                >
                  <div
                    className="w-12 h-12 rounded-full border-4 flex items-center justify-center text-xs font-bold shrink-0"
                    style={{
                      borderColor:
                        chPct > 0 ? "var(--progress)" : "var(--progress-bg)",
                      background: "var(--card-pressed)",
                    }}
                  >
                    {faNum(chPct)}٪
                  </div>
                  <div className="flex-1 min-w-0">
                    <b className="text-sm block">
                      فصل {faNum(ch.ordinal)} · {ch.name}
                    </b>
                    <p
                      className="text-xs truncate mt-0.5"
                      style={{ color: "var(--text-weak)" }}
                    >
                      دروس: {ch.lessons.map((l) => l.title).join("، ")}
                    </p>
                    {selectionKind === "program" &&
                      KONKUR_FORTNIGHT_DATES[idx] && (
                        <span
                          className="inline-block mt-1 px-2 py-0.5 rounded text-[10.5px] font-bold"
                          style={{
                            background: "var(--progress-weak)",
                            color: "var(--primary)",
                          }}
                        >
                          ایستگاه {KONKUR_FORTNIGHT_DATES[idx]}
                        </span>
                      )}
                  </div>
                  <MimoIcon name="ic_arrow_left" size={18} mono />
                </button>
              );
            })}
          </div>
        </div>

        {/* Unfinished Track Modal (F17) */}
        {showUnfinishedModal && (
          <div
            className="fixed inset-0 z-50 flex items-center justify-center p-4"
            style={{ background: "rgba(37, 39, 70, 0.58)" }}
          >
            <div
              className="w-full max-w-[330px] rounded-3xl p-6 text-center space-y-3 border"
              style={{
                background: "var(--card)",
                borderColor: "var(--line)",
              }}
            >
              <div className="flex justify-center">
                <MimoIcon name="ic_mimo_mascot" size={92} />
              </div>
              <h2 className="text-lg font-bold">
                {coursePct >= 100 ? "تبریک! دوره تکمیل شد" : "مسیر ناتمام"}
              </h2>
              <p className="text-xs leading-relaxed" style={{ color: "var(--text-weak)" }}>
                {coursePct >= 100
                  ? `شما تمام درس‌های «${currentCourse.name}» را با موفقیت به پایان رساندید!`
                  : "مسیر را تمام کنید تا گواهی شخصی‌سازی‌شدهٔ پایان دورهٔ خود را دریافت کنید."}
              </p>
              <button
                type="button"
                onClick={() => setShowUnfinishedModal(false)}
                className="mimo-cta"
              >
                باشه
              </button>
            </div>
          </div>
        )}
      </div>
    );
  }

  // ==========================================================================
  // SCREEN 4: SECTION DETAIL (Lessons inside a Chapter)
  // ==========================================================================
  if (screen === "section-detail") {
    const chDone = currentChapter.lessons.filter((l) =>
      completedNodes.includes(l.id)
    ).length;
    const chPct = Math.round(
      (chDone / Math.max(1, currentChapter.lessons.length)) * 100
    );

    return (
      <div className="flex flex-col h-full overflow-y-auto mimo-scroll pb-6" dir="rtl">
        <div
          className="flex items-center gap-3 px-4 shrink-0 border-b"
          style={{
            height: "var(--toolbar)",
            background: "var(--card)",
            borderColor: "var(--line)",
          }}
        >
          <button
            type="button"
            onClick={() => onNavigate("path-overview")}
            className="w-9 h-9 flex items-center justify-center rounded-lg cursor-pointer"
          >
            <MimoIcon name="ic_arrow_back_24" size={22} mono />
          </button>
          <b className="text-base">
            {currentCourse.name} · فصل {faNum(currentChapter.ordinal)}
          </b>
        </div>

        <div className="p-4 space-y-4">
          <div
            className="p-4 rounded-2xl border space-y-2"
            style={{
              background: "var(--card)",
              borderColor: "var(--line)",
            }}
          >
            <span className="text-xs font-bold" style={{ color: "var(--primary)" }}>
              فصل {faNum(currentChapter.ordinal)}
            </span>
            <h2 className="text-lg font-bold">{currentChapter.name}</h2>
            <p className="text-xs" style={{ color: "var(--text-weak)" }}>
              شامل {faNum(currentChapter.lessons.length)} درس و ۲۴ ریزدرس تعاملی
            </p>
            <div className="mimo-progress-track">
              <div
                className="mimo-progress-fill"
                style={{ width: `${Math.max(10, chPct)}%` }}
              />
            </div>
          </div>

          <div className="space-y-2">
            {currentChapter.lessons.map((lItem, li) => {
              const isDone = completedNodes.includes(lItem.id);
              const ref = chapterRefFor(lItem.id);
              return (
                <button
                  key={lItem.id}
                  type="button"
                  onClick={() => onOpenLessonPlayer(lItem.id)}
                  className="w-full p-3.5 rounded-xl border flex items-center justify-between gap-3 text-right cursor-pointer"
                  style={{
                    background: "var(--card)",
                    borderColor: isDone ? "var(--success)" : "var(--line)",
                  }}
                >
                  <div className="flex items-center gap-3">
                    <span
                      className="w-9 h-9 rounded-xl flex items-center justify-center text-white shrink-0"
                      style={{
                        background: isDone
                          ? "var(--success)"
                          : "var(--primary)",
                      }}
                    >
                      <MimoIcon
                        name={isDone ? "ic_check_white" : "ic_play"}
                        size={18}
                        mono
                      />
                    </span>
                    <div>
                      <b className="text-sm block">
                        درس {faNum(li + 1)} · {lItem.title}
                      </b>
                      <small
                        className="text-xs"
                        style={{ color: "var(--text-weak)" }}
                      >
                        مبحث: {ref.tutorial.title} · ۸ ریزدرس تعاملی
                      </small>
                    </div>
                  </div>
                  <MimoIcon name="ic_arrow_left" size={18} mono />
                </button>
              );
            })}

            {/* Chapter Project / Bolt Checkpoint Row */}
            <button
              type="button"
              onClick={() => {
                setBoltCheckpointNum(currentChapter.ordinal);
                setBoltAnswers({});
                setBoltSubmitted(false);
                onNavigate("section-practice");
              }}
              className="w-full p-3.5 rounded-xl border flex items-center justify-between gap-3 text-right cursor-pointer"
              style={{
                background: "var(--card-pressed)",
                borderColor: "var(--primary)",
              }}
            >
              <div className="flex items-center gap-3">
                <span
                  className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0"
                  style={{
                    background: "var(--progress-weak)",
                    color: "var(--primary)",
                  }}
                >
                  <MimoIcon name="ic_bolt_charged" size={22} />
                </span>
                <div>
                  <b className="text-sm block">پروژه و تمرین تثبیت فصل</b>
                  <small className="text-xs" style={{ color: "var(--text-weak)" }}>
                    مرور سؤالات کلیدی {currentCourse.subject} در این فصل
                  </small>
                </div>
              </div>
              <MimoIcon name="ic_arrow_left" size={18} mono />
            </button>
          </div>

          <button
            type="button"
            onClick={() =>
              onOpenLessonPlayer(
                currentChapter.lessons[0]?.id || selectedLessonId
              )
            }
            className="mimo-cta"
          >
            شروع یادگیری این فصل
          </button>
        </div>
      </div>
    );
  }

  // ==========================================================================
  // SCREEN 5: SECTION PRACTICE (Bolt Checkpoint Quiz — F21, Isolated from Exam)
  // ==========================================================================
  if (screen === "section-practice") {
    const subjectQuestions = KONKUR_QUESTIONS.filter(
      (q) => q.subject === currentCourse.subject
    );
    const quizPool =
      subjectQuestions.length >= 3
        ? subjectQuestions.slice(0, 4)
        : KONKUR_QUESTIONS.slice(0, 4);

    const answeredCount = Object.keys(boltAnswers).length;
    const correctCount = quizPool.filter(
      (q, i) => boltAnswers[i] === q.correctIndex
    ).length;

    return (
      <div
        className="flex flex-col h-full overflow-y-auto mimo-scroll pb-6"
        data-scope="learn-practice"
        dir="rtl"
      >
        <div
          className="flex items-center gap-3 px-4 shrink-0 border-b"
          style={{
            height: "var(--toolbar)",
            background: "var(--card)",
            borderColor: "var(--line)",
          }}
        >
          <button
            type="button"
            onClick={() => onNavigate("learn")}
            className="w-9 h-9 flex items-center justify-center rounded-lg cursor-pointer"
          >
            <MimoIcon name="ic_arrow_right" size={22} mono />
          </button>
          <b className="text-base">
            تمرین مبحث (گرهٔ رعد فصل {faNum(boltCheckpointNum)})
          </b>
        </div>

        <div className="p-4 space-y-4">
          <div
            className="p-4 rounded-2xl border space-y-2"
            style={{
              background: "var(--card)",
              borderColor: "var(--line)",
            }}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold" style={{ color: "var(--primary)" }}>
                چک‌پوینت یادگیری · بدون تایمر آزمون (F21)
              </span>
              <MimoIcon name="ic_bolt_charged" size={28} />
            </div>
            <h2 className="text-lg font-bold">
              {currentCourse.name} · {currentChapter.name}
            </h2>
            <p className="text-xs leading-relaxed" style={{ color: "var(--text-weak)" }}>
              این تمرین کوتاه برای تثبیت درسنامه‌های تا فصل{" "}
              {faNum(boltCheckpointNum)} است و از فضای آزمون کنکور کاملاً جداست.
            </p>
          </div>

          <div className="space-y-3">
            {quizPool.map((q, qi) => (
              <div
                key={q.id}
                className="p-4 rounded-xl border space-y-2.5"
                style={{
                  background: "var(--card)",
                  borderColor: "var(--line)",
                }}
              >
                <div className="flex justify-between text-xs">
                  <b style={{ color: "var(--primary)" }}>
                    پرسش {faNum(qi + 1)} · {q.topic}
                  </b>
                  <span style={{ color: "var(--text-weak)" }}>
                    دشواری {q.difficultyLabel}
                  </span>
                </div>
                <p className="text-sm font-bold leading-relaxed">{q.stemFa}</p>

                <div className="grid gap-2">
                  {q.options.map((opt, oi) => {
                    const isPicked = boltAnswers[qi] === oi;
                    const isRight = boltSubmitted && oi === q.correctIndex;
                    const isWrong =
                      boltSubmitted && isPicked && oi !== q.correctIndex;
                    return (
                      <button
                        key={oi}
                        type="button"
                        onClick={() =>
                          setBoltAnswers((prev) => ({ ...prev, [qi]: oi }))
                        }
                        className="p-2.5 rounded-xl border-2 text-right text-xs flex items-center gap-2.5 cursor-pointer"
                        style={{
                          background: isRight
                            ? "rgba(102, 188, 90, 0.14)"
                            : isWrong
                            ? "rgba(240, 90, 110, 0.14)"
                            : isPicked
                            ? "var(--progress-weak)"
                            : "var(--card-pressed)",
                          borderColor: isRight
                            ? "var(--success)"
                            : isWrong
                            ? "var(--error)"
                            : isPicked
                            ? "var(--primary)"
                            : "var(--line)",
                          fontWeight: isPicked || isRight ? 700 : 500,
                        }}
                      >
                        <span
                          className="w-6 h-6 rounded-md flex items-center justify-center font-bold shrink-0"
                          style={{
                            background: isPicked
                              ? "var(--primary)"
                              : "var(--card)",
                            color: isPicked ? "#FFFFFF" : "var(--text)",
                          }}
                        >
                          {faNum(oi + 1)}
                        </span>
                        <span>{opt}</span>
                      </button>
                    );
                  })}
                </div>

                {boltSubmitted && (
                  <div
                    className="p-2.5 rounded-lg text-xs leading-relaxed"
                    style={{
                      background: "var(--card-pressed)",
                      color: "var(--text-weak)",
                    }}
                  >
                    <b>توضیح:</b> {q.explanationFa}
                  </div>
                )}
              </div>
            ))}
          </div>

          {boltSubmitted && (
            <div
              className="p-3.5 rounded-xl border text-center text-sm font-bold"
              style={{
                background: "rgba(102, 188, 90, 0.15)",
                borderColor: "var(--success)",
                color: "var(--success)",
              }}
            >
              ✓ {faNum(correctCount)} از {faNum(quizPool.length)} پاسخ صحیح ثبت شد!
            </div>
          )}

          <div className="space-y-2">
            <button
              type="button"
              onClick={() => {
                if (answeredCount < quizPool.length) {
                  onToast("لطفاً به همهٔ پرسش‌های این چک‌پوینت پاسخ دهید");
                  return;
                }
                setBoltSubmitted(true);
                onCompleteBoltPractice(correctCount, quizPool.length);
                setShowPracticeModal(true);
              }}
              className="mimo-cta"
            >
              ثبت و بررسی تمرین مبحث
            </button>
            <button
              type="button"
              onClick={() => setShowPracticeModal(true)}
              className="mimo-cta secondary"
            >
              شارژ کامل! ⚡
            </button>
          </div>
        </div>

        {/* Practice Charged Modal (#practiceModal) */}
        {showPracticeModal && (
          <div
            className="fixed inset-0 z-50 flex items-center justify-center p-4"
            style={{ background: "rgba(37, 39, 70, 0.58)" }}
          >
            <div
              className="w-full max-w-[330px] rounded-3xl p-6 text-center space-y-3 border"
              style={{
                background: "var(--card)",
                borderColor: "var(--line)",
              }}
            >
              <div className="flex justify-center">
                <MimoIcon name="ic_mascot_practice" size={92} />
              </div>
              <h2 className="text-lg font-bold">
                {boltSubmitted ? "تمرین مبحث کامل شد!" : "شارژ کامل!"}
              </h2>
              <p className="text-xs leading-relaxed" style={{ color: "var(--text-weak)" }}>
                هر روز کمی تمرین کردن، مؤثرترین راه تثبیت مطالب در حافظهٔ بلندمدت برای کنکور است.
              </p>
              <button
                type="button"
                onClick={() => {
                  setShowPracticeModal(false);
                  if (boltSubmitted) onNavigate("learn");
                }}
                className="mimo-cta"
              >
                {boltSubmitted ? "بازگشت به نقشهٔ مسیر" : "با این حال تمرین می‌کنم"}
              </button>
            </div>
          </div>
        )}
      </div>
    );
  }

  // ==========================================================================
  // SCREEN 6: NATIVE DONE (Lesson Completion Celebration)
  // ==========================================================================
  const solvedMicroCount = lessonProgress.filter((r) => r.tries >= 1).length;
  return (
    <div
      className="flex flex-col h-full justify-between p-6 text-center"
      style={{ background: "var(--card)", color: "var(--text)" }}
      dir="rtl"
    >
      <div className="my-auto space-y-4">
        <div
          className="w-24 h-24 rounded-3xl mx-auto flex items-center justify-center shadow-lg"
          style={{
            background: "linear-gradient(158deg, var(--progress), var(--primary))",
            color: "#FFFFFF",
          }}
        >
          <MimoIcon name="ic_check_white" size={56} mono />
        </div>
        <h2 className="text-2xl font-extrabold">درس تمام شد!</h2>
        <p className="text-sm leading-relaxed" style={{ color: "var(--text-weak)" }}>
          «{lastCelebrationStats?.lessonTitle || "این مبحث"}» با موفقیت ثبت شد و گام بعدی در نقشهٔ مسیر باز شد.
        </p>

        <div className="grid grid-cols-3 gap-2.5 pt-2">
          <div
            className="p-3 rounded-2xl border"
            style={{
              background: "var(--card-pressed)",
              borderColor: "var(--line)",
            }}
          >
            <b className="text-lg block" style={{ color: "var(--primary)" }}>
              +{faNum(lastCelebrationStats?.dxp ?? 30)}
            </b>
            <small className="text-[11px]" style={{ color: "var(--text-weak)" }}>
              امتیاز تجربه (XP)
            </small>
          </div>
          <div
            className="p-3 rounded-2xl border"
            style={{
              background: "var(--card-pressed)",
              borderColor: "var(--line)",
            }}
          >
            <b className="text-lg block" style={{ color: "var(--primary)" }}>
              +{faNum(lastCelebrationStats?.dcoins ?? 15)}
            </b>
            <small className="text-[11px]" style={{ color: "var(--text-weak)" }}>
              سکهٔ پاداش
            </small>
          </div>
          <div
            className="p-3 rounded-2xl border"
            style={{
              background: "var(--card-pressed)",
              borderColor: "var(--line)",
            }}
          >
            <b className="text-lg block" style={{ color: "var(--success)" }}>
              {faNum(solvedMicroCount)}
            </b>
            <small className="text-[11px]" style={{ color: "var(--text-weak)" }}>
              ریزدرس حل‌شده
            </small>
          </div>
        </div>
      </div>

      <button
        type="button"
        onClick={() => onNavigate("learn")}
        className="mimo-cta"
      >
        ادامهٔ مسیر یادگیری ←
      </button>
    </div>
  );
}
