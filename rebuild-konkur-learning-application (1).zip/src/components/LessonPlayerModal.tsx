"use client";

import React, { useState, useEffect } from "react";
import { MimoIcon } from "./MimoIcon";
import {
  ResolvedChapterRef,
  MicroLesson,
  LessonBlock,
  ROLE_FA,
  CHAPTER_TYPE_FA,
  faNum,
  validateLessonBlock,
  ValidationOutcome,
  LessonProgressRow,
} from "@/lib/mimo-engine";

export interface LessonPlayerProps {
  chapterRef: ResolvedChapterRef;
  existingProgress: LessonProgressRow[];
  onRecordMicroProgress: (
    micro: MicroLesson,
    stepIdx: number,
    ok: boolean,
    block?: LessonBlock,
    userChoiceIdx?: number
  ) => LessonProgressRow;
  onFinishChapter: (hadCorrect: boolean, hardModeUsed: boolean) => void;
  onQuitToLearn: () => void;
  onQuitToSelectPath: () => void;
  onOpenAiWithContext: (ctxText: string, detailHtml: string) => void;
  onToast: (msg: string) => void;
}

export function LessonPlayerModal({
  chapterRef,
  existingProgress,
  onRecordMicroProgress,
  onFinishChapter,
  onQuitToLearn,
  onQuitToSelectPath,
  onOpenAiWithContext,
  onToast,
}: LessonPlayerProps) {
  const lessons = chapterRef.chapter.lessons;
  const [stepIdx, setStepIdx] = useState(0);
  const [hardMode, setHardMode] = useState(false);
  const [showQuitDialog, setShowQuitDialog] = useState(false);

  // Interactive states per step
  const [selectedChoice, setSelectedChoice] = useState<number | null>(null);
  const [gapTokens, setGapTokens] = useState<string[]>([]);
  const [spellTokens, setSpellTokens] = useState<string[]>([]);
  const [typedInput, setTypedInput] = useState("");
  const [webviewDone, setWebviewDone] = useState(false);
  const [revealed, setRevealed] = useState(false);

  // Submission & Feedback Bottom Sheet state
  const [submitted, setSubmitted] = useState(false);
  const [outcome, setOutcome] = useState<ValidationOutcome | null>(null);
  const [lastRow, setLastRow] = useState<LessonProgressRow | null>(null);
  const [sessionAnyCorrect, setSessionAnyCorrect] = useState(true);

  const currentMicro = lessons[stepIdx] || lessons[0];
  const progressPct = Math.round(((stepIdx + 1) / lessons.length) * 100);

  // Find if current step has an interactive block requiring validation
  const interactiveBlock = currentMicro.blocks.find((b) =>
    [
      "MultipleChoice",
      "SingleChoice",
      "FillTheGap",
      "ValidatedInput",
      "Spell",
      "InteractiveWebView",
      "executableFiles",
    ].includes(b.renderer)
  );

  const spellBlock = currentMicro.blocks.find((b) => b.renderer === "Spell");
  const validatedInputBlock = currentMicro.blocks.find(
    (b) => b.renderer === "ValidatedInput"
  );

  // Reset step-local state whenever stepIdx changes
  useEffect(() => {
    setSelectedChoice(null);
    setGapTokens([]);
    setSpellTokens([]);
    setTypedInput("");
    setWebviewDone(false);
    setRevealed(false);
    setSubmitted(false);
    setOutcome(null);
    setLastRow(null);
  }, [stepIdx, chapterRef.lessonId]);

  // Determine whether the user has provided input for the interactive block
  const canSubmitInteraction = (() => {
    if (!interactiveBlock) return true;
    if (
      interactiveBlock.renderer === "MultipleChoice" ||
      interactiveBlock.renderer === "SingleChoice"
    ) {
      return selectedChoice !== null;
    }
    if (interactiveBlock.renderer === "FillTheGap") {
      return gapTokens.length > 0;
    }
    if (interactiveBlock.renderer === "InteractiveWebView") {
      return webviewDone;
    }
    if (spellBlock && validatedInputBlock) {
      return (
        spellTokens.length === (spellBlock.correctTokens?.length || 3) &&
        typedInput.trim().length > 0
      );
    }
    if (interactiveBlock.renderer === "Spell") {
      return (
        spellTokens.length === (interactiveBlock.correctTokens?.length || 1)
      );
    }
    if (interactiveBlock.renderer === "ValidatedInput") {
      return typedInput.trim().length > 0;
    }
    return true;
  })();

  const handleCheckAnswer = () => {
    if (!interactiveBlock) return;

    let finalOutcome: ValidationOutcome;
    let choiceIdxForMistake: number | undefined;

    if (
      interactiveBlock.renderer === "MultipleChoice" ||
      interactiveBlock.renderer === "SingleChoice"
    ) {
      choiceIdxForMistake = selectedChoice ?? undefined;
      finalOutcome = validateLessonBlock(
        interactiveBlock.renderer,
        { selected: selectedChoice !== null ? [selectedChoice] : [] },
        interactiveBlock
      );
    } else if (interactiveBlock.renderer === "FillTheGap") {
      finalOutcome = validateLessonBlock(
        "FillTheGap",
        { tokens: gapTokens },
        interactiveBlock
      );
    } else if (interactiveBlock.renderer === "InteractiveWebView") {
      finalOutcome = validateLessonBlock(
        "InteractiveWebView",
        { webviewCompleted: webviewDone },
        interactiveBlock
      );
    } else if (spellBlock && validatedInputBlock) {
      const r1 = validateLessonBlock(
        "Spell",
        { tokens: spellTokens },
        spellBlock
      );
      const r2 = validateLessonBlock(
        "ValidatedInput",
        { text: typedInput },
        validatedInputBlock
      );
      finalOutcome = {
        ok: r1.ok && r2.ok,
        matchKind: r1.ok && r2.ok ? r2.matchKind : "WRONG",
        validatorCode: "A9/A10",
      };
    } else if (interactiveBlock.renderer === "Spell") {
      finalOutcome = validateLessonBlock(
        "Spell",
        { tokens: spellTokens },
        interactiveBlock
      );
    } else {
      finalOutcome = validateLessonBlock(
        "ValidatedInput",
        { text: typedInput },
        interactiveBlock
      );
    }

    const row = onRecordMicroProgress(
      currentMicro,
      stepIdx,
      finalOutcome.ok,
      interactiveBlock,
      choiceIdxForMistake
    );
    if (finalOutcome.ok) setSessionAnyCorrect(true);
    setOutcome(finalOutcome);
    setLastRow(row);
    setSubmitted(true);
  };

  const handleAdvance = () => {
    if (!interactiveBlock && !submitted) {
      // Non-interactive slide / feedback / recap creates a LessonProgress row with tries=1, attempts=1
      onRecordMicroProgress(currentMicro, stepIdx, true);
    }
    if (stepIdx < lessons.length - 1) {
      setStepIdx(stepIdx + 1);
    } else {
      onFinishChapter(sessionAnyCorrect, hardMode);
    }
  };

  const handlePrimaryCta = () => {
    if (interactiveBlock && !submitted) {
      handleCheckAnswer();
    } else {
      handleAdvance();
    }
  };

  const handleSendToAi = () => {
    const q = chapterRef.question;
    const userAnsText =
      selectedChoice !== null && q.options[selectedChoice]
        ? q.options[selectedChoice]
        : gapTokens[0] || typedInput || "مشاهدهٔ درسنامه";
    const ctxText = `زمینهٔ درس: ${chapterRef.courseName} · ${chapterRef.chapterName} · ${currentMicro.title} · پاسخ شما: ${userAnsText}`;
    const detailHtml = `<b>تحلیل ریزدرس «${currentMicro.title}» (${q.subject} · ${q.topic}):</b><br>• صورت سؤال: ${q.stemFa}<br>• پاسخ صحیح: گزینهٔ ${faNum(
      q.correctIndex + 1
    )} (${q.options[q.correctIndex]})<br>• درسنامه و توضیح تشریحی: ${q.explanationFa}<br>• فرمول/قاعده: ${q.labFormulaFa}`;
    onOpenAiWithContext(ctxText, detailHtml);
  };

  // Shuffled-like deterministic order for Spell chips (reverse or rotated so user orders them)
  const spellPool = spellBlock?.options
    ? [
        spellBlock.options[1] || spellBlock.options[0],
        spellBlock.options[2] || spellBlock.options[0],
        spellBlock.options[0],
      ]
    : [];

  return (
    <div
      className="flex flex-col h-full w-full relative select-none"
      style={{ background: "var(--card)", color: "var(--text)" }}
      dir="rtl"
    >
      {/* 1. Mimo 9.35 chapter_toolbar.xml (52dp, LTR progress bar + X + Flag + HardMode) */}
      <div
        className="flex items-center gap-3 px-4 shrink-0 border-b"
        style={{
          height: 52,
          borderColor: "var(--line)",
          direction: "ltr",
        }}
      >
        <button
          type="button"
          onClick={() => setShowQuitDialog(true)}
          aria-label="خروج از درس"
          className="w-8 h-8 flex items-center justify-center rounded-lg hover:opacity-80 cursor-pointer"
          style={{ color: "var(--icon)" }}
        >
          <MimoIcon name="ic_close" size={22} mono />
        </button>

        <div className="flex-1 mimo-progress-track">
          <div
            className="mimo-progress-fill"
            style={{ width: `${progressPct}%` }}
          />
        </div>

        <button
          type="button"
          onClick={() => {
            setHardMode((h) => !h);
            onToast(
              !hardMode
                ? "حالت چالشی (Hard Mode) فعال شد"
                : "حالت استاندارد فعال شد"
            );
          }}
          className="px-2.5 py-1 rounded-full text-[11px] font-bold border cursor-pointer transition-colors"
          style={{
            background: hardMode ? "var(--primary)" : "var(--card-pressed)",
            color: hardMode ? "#FFFFFF" : "var(--text-weak)",
            borderColor: hardMode ? "var(--primary)" : "var(--line)",
            direction: "rtl",
          }}
        >
          {hardMode ? "⚡ چالشی" : "سطح عادی"}
        </button>

        <button
          type="button"
          onClick={() =>
            onToast(
              `گزارش کیفیت برای ریزدرس #${faNum(currentMicro.id)} ثبت شد`
            )
          }
          aria-label="گزارش"
          className="w-8 h-8 flex items-center justify-center rounded-lg hover:opacity-80 cursor-pointer"
          style={{ color: "var(--weak-icon)" }}
        >
          <MimoIcon name="ic_flag" size={20} mono />
        </button>
      </div>

      {/* 2. Step Stepper Dots (Quick visual indicator of the 8 micro-lessons in this chapter) */}
      <div
        className="flex items-center justify-between px-4 py-2 border-b text-xs"
        style={{
          borderColor: "var(--line)",
          background: "var(--card-pressed)",
        }}
      >
        <div className="flex items-center gap-1.5">
          <span
            className="px-2 py-0.5 rounded-full font-bold text-[11px]"
            style={{
              background: "var(--progress-weak)",
              color: "var(--primary)",
            }}
          >
            {ROLE_FA[currentMicro.pedagogicalRole]}
          </span>
          <span style={{ color: "var(--text-weak)" }}>
            {chapterRef.courseName} · {chapterRef.lessonTitle}
          </span>
        </div>
        <span className="font-bold" style={{ color: "var(--text-weak)" }}>
          {faNum(stepIdx + 1)} از {faNum(lessons.length)}
        </span>
      </div>

      {/* 3. Scrollable Lesson Body */}
      <div className="flex-1 overflow-y-auto mimo-scroll p-4 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-[19px] font-bold leading-snug">
            {currentMicro.title}
          </h3>
          {existingProgress.some(
            (r) => r.lessonId === currentMicro.id && r.tries >= 1
          ) && (
            <span
              className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold"
              style={{
                background: "rgba(102, 188, 90, 0.16)",
                color: "var(--success)",
              }}
            >
              ✓ حل‌شده
            </span>
          )}
        </div>

        {/* Hard Mode Prompt Banner (R7) */}
        {hardMode && currentMicro.hardModePromptFa && (
          <div
            className="p-3 rounded-xl border text-xs leading-relaxed"
            style={{
              background: "var(--progress-weak)",
              borderColor: "var(--primary)",
              color: "var(--text)",
            }}
          >
            <b className="block mb-1" style={{ color: "var(--primary)" }}>
              ⚡ نکتهٔ سطح چالشی (Hard Mode · {CHAPTER_TYPE_FA[chapterRef.chapter.type]}):
            </b>
            {currentMicro.hardModePromptFa}
          </div>
        )}

        {/* Render each typed block of the current MicroLesson */}
        {currentMicro.blocks.map((b) => {
          // 1) text block
          if (b.renderer === "text") {
            return (
              <div key={b.id} className="space-y-2">
                {b.hintFa && (
                  <div
                    className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-bold"
                    style={{
                      background: "var(--code-bg)",
                      color: "var(--text-weak)",
                    }}
                  >
                    <MimoIcon name="ic_cap_filled" size={16} />
                    <span>{b.hintFa}</span>
                  </div>
                )}
                <p className="text-[16px] leading-[1.9]">{b.contentFa}</p>
              </div>
            );
          }

          // 2) strong highlight block
          if (b.renderer === "strong") {
            return (
              <div
                key={b.id}
                className="p-3.5 rounded-xl font-bold text-[15px] leading-relaxed border-r-4"
                style={{
                  background: "var(--code-bg)",
                  borderRightColor: "var(--primary)",
                }}
              >
                {b.contentFa}
              </div>
            );
          }

          // 3) InteractiveWebView micro-simulator (R5)
          if (b.renderer === "InteractiveWebView") {
            return (
              <div key={b.id} className="space-y-3">
                <p className="text-[15px] leading-relaxed">{b.contentFa}</p>
                <div
                  className="rounded-xl overflow-hidden border"
                  style={{
                    borderColor: "var(--progress)",
                    background: "var(--progress-weak)",
                  }}
                >
                  <div
                    className="px-3 py-2 flex items-center justify-between border-b"
                    style={{
                      background: "var(--code-bg)",
                      borderColor: "var(--line)",
                    }}
                  >
                    <span className="text-xs font-bold" style={{ color: "var(--text-weak)" }}>
                      آزمایشگاه تعاملی میمو (InteractiveWebView · آفلاین)
                    </span>
                    <MimoIcon name="browser_view_header_dots" size={24} />
                  </div>
                  <div className="p-4 text-center space-y-3">
                    <div
                      className="p-3 rounded-xl font-mono font-bold text-sm"
                      style={{
                        background: "var(--card)",
                        color: "var(--primary)",
                        direction: "ltr",
                      }}
                    >
                      {b.webviewPromptFa}
                    </div>
                    {!webviewDone ? (
                      <button
                        type="button"
                        onClick={() => {
                          setWebviewDone(true);
                          onToast("شبیه‌ساز اجرا شد · اکنون «بررسی پاسخ» را بزنید");
                        }}
                        className="px-4 py-2.5 rounded-xl font-bold text-sm text-white cursor-pointer shadow-sm"
                        style={{ background: "var(--primary)" }}
                      >
                        ▶ {b.webviewActionLabel || "اجرای شبیه‌ساز"}
                      </button>
                    ) : (
                      <div
                        className="p-3 rounded-xl text-sm font-bold border"
                        style={{
                          background: "var(--card)",
                          borderColor: "var(--success)",
                          color: "var(--success)",
                        }}
                      >
                        ✓ {b.webviewResultFa}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          }

          // 4) MultipleChoice / SingleChoice (Validator A7)
          if (
            b.renderer === "MultipleChoice" ||
            b.renderer === "SingleChoice"
          ) {
            return (
              <div key={b.id} className="space-y-3">
                <p className="text-[16px] font-bold leading-[1.85]">
                  {b.contentFa}
                </p>
                <div
                  className="flex items-center gap-2 px-3 py-2 rounded-xl text-xs"
                  style={{
                    background: "var(--code-bg)",
                    color: "var(--text-weak)",
                  }}
                >
                  <MimoIcon name="ic_help" size={16} mono />
                  <span>
                    گزینهٔ درست را انتخاب کنید{" "}
                    {b.hintFa ? `· ${b.hintFa}` : ""}
                  </span>
                </div>
                <div className="grid gap-2.5">
                  {(b.options || []).map((opt, oi) => {
                    const isSel = selectedChoice === oi;
                    const isCorrectOpt =
                      submitted && oi === Number(b.correctIndex);
                    const isWrongOpt =
                      submitted && isSel && oi !== Number(b.correctIndex);

                    let borderCol = "var(--line)";
                    let bgCol = "var(--card)";
                    let numBg = "var(--code-bg)";
                    let numCol = "var(--text)";

                    if (isCorrectOpt) {
                      borderCol = "var(--success)";
                      bgCol = "rgba(102, 188, 90, 0.12)";
                      numBg = "var(--success)";
                      numCol = "#FFFFFF";
                    } else if (isWrongOpt) {
                      borderCol = "var(--error)";
                      bgCol = "rgba(240, 90, 110, 0.12)";
                      numBg = "var(--error)";
                      numCol = "#FFFFFF";
                    } else if (isSel) {
                      borderCol = "var(--primary)";
                      bgCol = "var(--card-pressed)";
                      numBg = "var(--primary)";
                      numCol = "#FFFFFF";
                    }

                    return (
                      <button
                        key={oi}
                        type="button"
                        disabled={submitted}
                        onClick={() => setSelectedChoice(oi)}
                        className="flex items-center gap-3 w-full min-h-[50px] p-3 rounded-xl border-2 text-right transition-all cursor-pointer"
                        style={{
                          borderColor: borderCol,
                          background: bgCol,
                        }}
                      >
                        <span
                          className="w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold shrink-0"
                          style={{ background: numBg, color: numCol }}
                        >
                          {faNum(oi + 1)}
                        </span>
                        <span className="text-[14.5px] font-medium leading-snug flex-1">
                          {opt}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            );
          }

          // 5) Feedback / پاسخنامه تشریحی block
          if (b.renderer === "feedback") {
            return (
              <div key={b.id} className="space-y-3">
                <div
                  className="p-4 rounded-xl border"
                  style={{
                    background: "var(--progress-weak)",
                    borderColor: "var(--progress)",
                  }}
                >
                  <div className="flex items-center gap-2 mb-2 font-bold text-sm">
                    <MimoIcon name="ic_file" size={18} mono />
                    <span>پاسخنامهٔ تشریحی و تحلیل کتاب</span>
                  </div>
                  <p className="text-[14.5px] leading-[1.9]">{b.contentFa}</p>
                </div>
                <div className="space-y-2">
                  <div
                    className="text-xs font-bold"
                    style={{ color: "var(--text-weak)" }}
                  >
                    بررسی تک‌تک گزینه‌ها:
                  </div>
                  {(b.options || []).map((note, ni) => {
                    const isRight = note.includes("(گزینهٔ درست)");
                    return (
                      <div
                        key={ni}
                        className="p-3 rounded-xl border text-xs leading-relaxed"
                        style={{
                          background: "var(--card)",
                          borderColor: isRight
                            ? "var(--success)"
                            : "var(--line)",
                          borderRightWidth: 4,
                          borderRightColor: isRight
                            ? "var(--success)"
                            : "var(--weak-icon)",
                        }}
                      >
                        {note}
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          }

          // 6) Interactive FillTheGap (Validator A6)
          if (b.renderer === "FillTheGap") {
            const filledText = gapTokens[0] || "";
            return (
              <div key={b.id} className="space-y-3">
                <p className="text-[15.5px] leading-[1.9]">
                  {chapterRef.question.stemFa}
                </p>
                <div
                  className="flex items-center gap-2 px-3 py-2 rounded-xl text-xs"
                  style={{
                    background: "var(--code-bg)",
                    color: "var(--text-weak)",
                  }}
                >
                  <MimoIcon name="ic_help" size={16} mono />
                  <span>
                    روی قطعهٔ صحیح تپ کنید تا جای خالی پر شود (ولیدیتور A6)
                  </span>
                </div>

                {/* Periwinkle Mimo FillTheGap Card */}
                <div
                  className="p-4 rounded-xl border text-center space-y-4"
                  style={{
                    background: "var(--progress-weak)",
                    borderColor: "var(--progress)",
                  }}
                >
                  <div className="text-sm font-bold" style={{ color: "var(--text-weak)" }}>
                    جای خالی را تکمیل کنید:
                  </div>

                  <button
                    type="button"
                    disabled={submitted || !filledText}
                    onClick={() => setGapTokens([])}
                    className="min-h-[48px] px-4 py-2 rounded-xl border-2 border-dashed inline-flex items-center justify-center font-bold text-sm transition-all cursor-pointer"
                    style={{
                      background: "var(--card)",
                      borderColor: filledText
                        ? "var(--primary)"
                        : "var(--text-weak)",
                      color: filledText ? "var(--primary)" : "var(--text-weak)",
                    }}
                  >
                    {filledText ? `${filledText} ✕` : "＿＿＿＿＿＿＿＿"}
                  </button>

                  <div className="flex flex-wrap gap-2 justify-center pt-1">
                    {(b.options || []).map((opt, oi) => {
                      const active = gapTokens[0] === opt;
                      return (
                        <button
                          key={oi}
                          type="button"
                          disabled={submitted}
                          onClick={() => setGapTokens([opt])}
                          className="px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer"
                          style={{
                            background: active
                              ? "var(--primary)"
                              : "var(--text)",
                            color: "#FFFFFF",
                            outline: active
                              ? "3px solid var(--progress)"
                              : "none",
                          }}
                        >
                          {opt}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            );
          }

          // 7) Spell / Ordered Sequence Builder (Validator A8)
          if (b.renderer === "Spell") {
            return (
              <div
                key={b.id}
                className="p-3.5 rounded-xl border space-y-3"
                style={{
                  background: "var(--card-pressed)",
                  borderColor: "var(--line)",
                }}
              >
                <div className="flex items-center justify-between">
                  <b className="text-xs" style={{ color: "var(--primary)" }}>
                    گام ۱ · ولیدیتور ترتیبی A8 (Spell / Sequence)
                  </b>
                  {spellTokens.length > 0 && !submitted && (
                    <button
                      type="button"
                      onClick={() => setSpellTokens([])}
                      className="text-xs underline cursor-pointer"
                      style={{ color: "var(--text-weak)" }}
                    >
                      پاک کردن ترتیب
                    </button>
                  )}
                </div>
                <p className="text-sm font-medium">{b.contentFa}</p>

                {/* Chosen sequence slots */}
                <div
                  className="min-h-[46px] p-2 rounded-xl border flex flex-wrap gap-1.5 items-center"
                  style={{
                    background: "var(--card)",
                    borderColor: "var(--progress)",
                  }}
                >
                  {spellTokens.length === 0 ? (
                    <span className="text-xs px-2" style={{ color: "var(--weak-icon)" }}>
                      مراحل زیر را به ترتیب ۱ → ۲ → ۳ انتخاب کنید…
                    </span>
                  ) : (
                    spellTokens.map((tok, ti) => (
                      <span
                        key={ti}
                        className="px-2.5 py-1 rounded-lg text-xs font-bold text-white"
                        style={{ background: "var(--primary)" }}
                      >
                        {faNum(ti + 1)}. {tok}
                      </span>
                    ))
                  )}
                </div>

                {/* Available sequence tokens */}
                <div className="flex flex-wrap gap-2">
                  {spellPool.map((tok, ti) => {
                    const alreadyPicked = spellTokens.includes(tok);
                    return (
                      <button
                        key={ti}
                        type="button"
                        disabled={submitted || alreadyPicked}
                        onClick={() => setSpellTokens([...spellTokens, tok])}
                        className="px-3 py-2 rounded-xl text-xs font-bold border cursor-pointer transition-opacity"
                        style={{
                          background: alreadyPicked
                            ? "var(--disabled)"
                            : "var(--card)",
                          borderColor: "var(--line)",
                          opacity: alreadyPicked ? 0.45 : 1,
                        }}
                      >
                        + {tok}
                      </button>
                    );
                  })}
                </div>
              </div>
            );
          }

          // 8) ValidatedInput (Validator A9 + A10)
          if (b.renderer === "ValidatedInput") {
            return (
              <div
                key={b.id}
                className="p-3.5 rounded-xl border space-y-3"
                style={{
                  background: "var(--card-pressed)",
                  borderColor: "var(--line)",
                }}
              >
                <b className="block text-xs" style={{ color: "var(--primary)" }}>
                  گام ۲ · ولیدیتور نرمال‌ساز A9/A10 (ValidatedInput)
                </b>
                <p className="text-sm font-medium">{b.contentFa}</p>
                <input
                  type="text"
                  disabled={submitted}
                  value={typedInput}
                  onChange={(e) => setTypedInput(e.target.value)}
                  placeholder={`پاسخ یا کلیدواژه را بنویسید (مثلاً: ${chapterRef.question.keyTermFa})`}
                  className="w-full px-3.5 py-2.5 rounded-xl border text-sm font-bold outline-none"
                  style={{
                    background: "var(--card)",
                    borderColor: "var(--progress)",
                    color: "var(--text)",
                  }}
                />
                <div className="flex flex-wrap gap-1.5 items-center">
                  <span className="text-[11px]" style={{ color: "var(--text-weak)" }}>
                    درج سریع:
                  </span>
                  <button
                    type="button"
                    disabled={submitted}
                    onClick={() => setTypedInput(chapterRef.question.keyTermFa)}
                    className="px-2.5 py-1 rounded-lg text-xs font-bold border cursor-pointer"
                    style={{
                      background: "var(--card)",
                      borderColor: "var(--primary)",
                      color: "var(--primary)",
                    }}
                  >
                    {chapterRef.question.keyTermFa}
                  </button>
                  {(b.options || []).slice(0, 2).map((opt, oi) => (
                    <button
                      key={oi}
                      type="button"
                      disabled={submitted}
                      onClick={() => setTypedInput(opt)}
                      className="px-2.5 py-1 rounded-lg text-xs border cursor-pointer"
                      style={{
                        background: "var(--card)",
                        borderColor: "var(--line)",
                        color: "var(--text-weak)",
                      }}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </div>
            );
          }

          // 9) Reveal / Flashcard summary block (R6)
          if (b.renderer === "Reveal") {
            return (
              <div key={b.id} className="space-y-3">
                <div
                  className="p-4 rounded-xl border text-center space-y-3"
                  style={{
                    background: "var(--progress-weak)",
                    borderColor: "var(--progress)",
                  }}
                >
                  <div className="text-xs font-bold" style={{ color: "var(--primary)" }}>
                    فلش‌کارت بازیابی نهایی (Reveal)
                  </div>
                  <p className="text-base font-bold">{chapterRef.question.stemFa}</p>
                  {!revealed ? (
                    <button
                      type="button"
                      onClick={() => setRevealed(true)}
                      className="px-4 py-2 rounded-xl font-bold text-xs text-white cursor-pointer"
                      style={{ background: "var(--primary)" }}
                    >
                      نمایش پاسخ قطعی و فرمول 👁
                    </button>
                  ) : (
                    <div
                      className="p-3 rounded-xl text-right space-y-1.5 border"
                      style={{
                        background: "var(--card)",
                        borderColor: "var(--success)",
                      }}
                    >
                      <div className="font-bold text-sm" style={{ color: "var(--success)" }}>
                        ✓ {b.contentFa}
                      </div>
                      <p className="text-xs leading-relaxed">
                        {b.explanationFa}
                      </p>
                      {b.hintFa && (
                        <div
                          className="text-xs font-mono p-2 rounded-lg mt-1"
                          style={{
                            background: "var(--code-bg)",
                            direction: "ltr",
                          }}
                        >
                          {b.hintFa}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            );
          }

          return (
            <p key={b.id} className="text-base leading-relaxed">
              {b.contentFa}
            </p>
          );
        })}

        {/* Quick AI Studio / Explanation Chip + Provenance Footer */}
        <div className="pt-2 flex flex-wrap items-center justify-between gap-2 border-t" style={{ borderColor: "var(--line)" }}>
          <button
            type="button"
            onClick={handleSendToAi}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold border cursor-pointer"
            style={{
              background: "var(--card-pressed)",
              borderColor: "var(--primary)",
              color: "var(--primary)",
            }}
          >
            <MimoIcon name="ic_magic_wand" size={15} mono />
            <span>توضیح و کالبدشکافی با هوش مصنوعی (محلی)</span>
          </button>

          <span className="text-[11px]" style={{ color: "var(--weak-icon)" }}>
            منبع: {currentMicro.trace.sourceRef} · نسخهٔ {faNum(753)}
          </span>
        </div>
      </div>

      {/* 4. Mimo 9.35 Feedback Bottom Sheet (lesson_interactive_feedback_bottom_sheet_dialog.xml) */}
      {submitted && outcome && (
        <div
          className="px-4 py-3.5 border-t-2 space-y-2 transition-all"
          style={{
            background: outcome.ok
              ? "rgba(102, 188, 90, 0.14)"
              : "rgba(240, 90, 110, 0.14)",
            borderColor: outcome.ok ? "var(--success)" : "var(--error)",
          }}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span
                className="w-6 h-6 rounded-full flex items-center justify-center text-white text-xs font-bold"
                style={{
                  background: outcome.ok ? "var(--success)" : "var(--error)",
                }}
              >
                {outcome.ok ? "✓" : "✕"}
              </span>
              <b
                className="text-sm"
                style={{
                  color: outcome.ok ? "var(--success)" : "var(--error)",
                }}
              >
                {outcome.ok
                  ? outcome.matchKind === "PARTIAL"
                    ? "درست! (تطابق نرمال‌سازی‌شده W)"
                    : "عالی! پاسخ درست است (V)"
                  : `پاسخ نادرست · گزینهٔ درست: ${
                      chapterRef.question.options[
                        chapterRef.question.correctIndex
                      ]
                    }`}
              </b>
            </div>
            <span
              className="text-[11px] font-mono px-2 py-0.5 rounded"
              style={{
                background: "var(--card)",
                color: "var(--text-weak)",
              }}
            >
              {outcome.validatorCode}
            </span>
          </div>
          <p className="text-xs leading-relaxed">
            {chapterRef.question.explanationFa}
          </p>
          {lastRow && (
            <div className="text-[11px]" style={{ color: "var(--text-weak)" }}>
              ردیف پیشرفت (LessonProgress): تلاش {faNum(lastRow.attempts)} · tries=
              {faNum(lastRow.tries)} ·{" "}
              {lastRow.tries >= 1 ? "isSolvedCorrectly=true" : "در صف مرور غلط‌ها"}
            </div>
          )}
        </div>
      )}

      {/* 5. Bottom Primary CTA Bar (run_button_view.xml) */}
      <div
        className="p-3.5 border-t shrink-0 flex items-center gap-2"
        style={{
          background: "var(--card)",
          borderColor: "var(--line)",
        }}
      >
        {stepIdx > 0 && (
          <button
            type="button"
            onClick={() => setStepIdx(stepIdx - 1)}
            aria-label="ریزدرس قبلی"
            className="w-12 h-[52px] rounded-xl border flex items-center justify-center shrink-0 cursor-pointer"
            style={{
              background: "var(--card-pressed)",
              borderColor: "var(--line)",
              color: "var(--text)",
            }}
          >
            <MimoIcon name="ic_arrow_right" size={20} mono />
          </button>
        )}

        <button
          type="button"
          disabled={Boolean(interactiveBlock && !submitted && !canSubmitInteraction)}
          onClick={handlePrimaryCta}
          className="mimo-cta flex-1"
        >
          <span>
            {interactiveBlock && !submitted
              ? "بررسی پاسخ"
              : stepIdx === lessons.length - 1
              ? "پایان درس و ثبت پیشرفت"
              : "ادامه"}
          </span>
          <MimoIcon name="ic_arrow_left" size={18} mono />
        </button>
      </div>

      {/* 6. Mimo 9.35 Quit Dialog (3 measured choices from M09 ChapterActivity) */}
      {showQuitDialog && (
        <div
          className="absolute inset-0 z-50 flex items-center justify-center p-5"
          style={{ background: "rgba(37, 39, 70, 0.6)" }}
        >
          <div
            className="w-full max-w-[330px] rounded-2xl p-5 space-y-3 shadow-xl border"
            style={{
              background: "var(--card)",
              borderColor: "var(--line)",
            }}
          >
            <h3 className="text-lg font-bold text-center">
              از درس خارج می‌شوید؟
            </h3>
            <p
              className="text-xs text-center leading-relaxed"
              style={{ color: "var(--text-weak)" }}
            >
              ردیف‌های پیشرفتی که تا این لحظه ثبت کرده‌اید در دیتابیس محلی محفوظ می‌ماند.
            </p>
            <div className="space-y-2 pt-1">
              <button
                type="button"
                onClick={() => setShowQuitDialog(false)}
                className="mimo-cta"
              >
                ادامهٔ درس
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowQuitDialog(false);
                  onQuitToSelectPath();
                }}
                className="mimo-cta secondary"
              >
                انتخاب مسیر دیگر
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowQuitDialog(false);
                  onQuitToLearn();
                }}
                className="w-full py-2.5 rounded-xl text-xs font-bold cursor-pointer"
                style={{ color: "var(--error)" }}
              >
                خروج به نقشهٔ یادگیری
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
