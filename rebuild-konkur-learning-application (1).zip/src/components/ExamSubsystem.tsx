"use client";

import React, { useState, useEffect } from "react";
import { MimoIcon } from "./MimoIcon";
import {
  KONKUR_QUESTIONS,
  KonkurQuestion,
  EXAM_HUB_SECTIONS,
  EXAM_POLICIES,
  ExamKind,
  MistakeItem,
  faNum,
} from "@/lib/mimo-engine";

export interface SavedExamSnapshot {
  examTitle: string;
  examKind: ExamKind;
  questionIds: string[];
  qi: number;
  answers: Record<number, number>; // 1-based option index (1..4)
  checked: Record<number, boolean>;
  marks: Record<number, boolean>;
  durationMinutes: number;
  timerState: "idle" | "running" | "paused" | "finished";
  remainingSeconds: number;
}

export interface CompletedExamResult {
  examTitle: string;
  examKind: ExamKind;
  partial: boolean;
  questions: KonkurQuestion[];
  answers: Record<number, number>;
  correctCount: number;
  wrongCount: number;
  blankCount: number;
  answeredCount: number;
  pctWithNeg: number;
  pctNoNeg: number;
  durationMinutes: number;
}

export interface ExamSubsystemProps {
  mode: "exam-hub" | "exam-run" | "exam-result";
  isGuest: boolean;
  mistakes: MistakeItem[];
  savedExam: SavedExamSnapshot | null;
  lastResult: CompletedExamResult | null;
  onCreateLocalProfile: () => void;
  onBackToLearn: () => void;
  onStartOrResumeExam: (snap: SavedExamSnapshot) => void;
  onSaveExamAndExit: (snap: SavedExamSnapshot) => void;
  onFinishExam: (result: CompletedExamResult) => void;
  onBackToHub: () => void;
  onOpenAiWithContext: (ctxText: string, detailHtml: string) => void;
  onOpenPlaygroundSheet: () => void;
  onToast: (msg: string) => void;
}

export function ExamSubsystem({
  mode,
  isGuest,
  mistakes,
  savedExam,
  lastResult,
  onCreateLocalProfile,
  onBackToLearn,
  onStartOrResumeExam,
  onSaveExamAndExit,
  onFinishExam,
  onBackToHub,
  onOpenAiWithContext,
  onOpenPlaygroundSheet,
  onToast,
}: ExamSubsystemProps) {
  // Filter chip in Exam Hub
  const [hubFilter, setHubFilter] = useState<string>("all");

  // Active Exam Run state
  const [examTitle, setExamTitle] = useState(
    savedExam?.examTitle || "آزمون جامع کنکور"
  );
  const [examKind, setExamKind] = useState<ExamKind>(
    savedExam?.examKind || "comprehensive"
  );
  const [examQuestions, setExamQuestions] = useState<KonkurQuestion[]>(
    KONKUR_QUESTIONS
  );
  const [qi, setQi] = useState<number>(savedExam?.qi || 0);
  const [answers, setAnswers] = useState<Record<number, number>>(
    savedExam?.answers || {}
  );
  const [checked, setChecked] = useState<Record<number, boolean>>(
    savedExam?.checked || {}
  );
  const [marks, setMarks] = useState<Record<number, boolean>>(
    savedExam?.marks || {}
  );

  // Timer State Machine (F45, F46: single chip, editable minutes for EVERY exam kind)
  const [timerState, setTimerState] = useState<
    "idle" | "running" | "paused" | "finished"
  >("idle");
  const [timerMinutesInput, setTimerMinutesInput] = useState<number>(270);
  const [remainingSec, setRemainingSec] = useState<number>(270 * 60);

  // Bottom Sheets inside exam-run / exam-result
  const [activeSheet, setActiveSheet] = useState<
    "none" | "timer" | "palette" | "key" | "exit"
  >("none");
  const [keyTab, setKeyTab] = useState<"desc" | "test">("desc");

  // Sync when entering exam-run from savedExam
  useEffect(() => {
    if (mode === "exam-run" && savedExam) {
      setExamTitle(savedExam.examTitle);
      setExamKind(savedExam.examKind);
      const qList = savedExam.questionIds
        .map((id) => KONKUR_QUESTIONS.find((q) => q.id === id))
        .filter((q): q is KonkurQuestion => Boolean(q));
      setExamQuestions(qList.length > 0 ? qList : KONKUR_QUESTIONS);
      setQi(savedExam.qi);
      setAnswers(savedExam.answers);
      setChecked(savedExam.checked);
      setMarks(savedExam.marks);
      setTimerMinutesInput(savedExam.durationMinutes);
      setRemainingSec(savedExam.remainingSeconds);
      setTimerState(
        savedExam.timerState === "running" ? "paused" : savedExam.timerState
      );
      setActiveSheet("none");
    }
  }, [mode, savedExam]);

  // Countdown interval when timerState === 'running'
  useEffect(() => {
    if (mode !== "exam-run" || timerState !== "running") return;
    const id = setInterval(() => {
      setRemainingSec((prev) => {
        if (prev <= 1) {
          clearInterval(id);
          setTimerState("finished");
          onToast("زمان آزمون به پایان رسید · کارنامه محاسبه شد");
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(id);
  }, [mode, timerState, onToast]);

  const formatTimer = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    const mStr = m >= 100 ? String(m) : ("0" + m).slice(-2);
    const sStr = ("0" + s).slice(-2);
    return `${faNum(mStr)}:${faNum(sStr)}`;
  };

  // Start an exam from Exam Hub
  const handleLaunchExam = (item: {
    examTitle: string;
    kind: ExamKind;
    subjectFilter?: "زیست" | "شیمی" | "فیزیک" | "ریاضی";
    minutesPreset?: number;
    mistakesOnly?: boolean;
  }) => {
    // Check if resuming the exact same saved exam
    if (savedExam && savedExam.examTitle === item.examTitle) {
      onStartOrResumeExam(savedExam);
      onToast(`ادامهٔ آزمون ذخیره‌شده · سؤال ${faNum(savedExam.qi + 1)}`);
      return;
    }

    let pool = KONKUR_QUESTIONS;
    if (item.mistakesOnly) {
      const openKeys = new Set(
        mistakes.filter((m) => !m.resolved).map((m) => m.questionKey)
      );
      const matched = KONKUR_QUESTIONS.filter((q) => openKeys.has(q.id));
      pool = matched.length > 0 ? matched : KONKUR_QUESTIONS.slice(0, 8);
    } else if (item.subjectFilter) {
      pool = KONKUR_QUESTIONS.filter((q) => q.subject === item.subjectFilter);
    }

    const mins =
      item.minutesPreset ?? EXAM_POLICIES[item.kind].defaultMinutes ?? 30;
    const snap: SavedExamSnapshot = {
      examTitle: item.examTitle,
      examKind: item.kind,
      questionIds: pool.map((q) => q.id),
      qi: 0,
      answers: {},
      checked: {},
      marks: {},
      durationMinutes: mins,
      timerState: "idle",
      remainingSeconds: mins * 60,
    };
    onStartOrResumeExam(snap);
    onToast(`وارد «${item.examTitle}» شدید — ${EXAM_POLICIES[item.kind].label}`);
  };

  const computeExamResult = (partial: boolean): CompletedExamResult => {
    let correct = 0;
    let wrong = 0;
    let answered = 0;
    examQuestions.forEach((q, idx) => {
      const a = answers[idx];
      if (a && a >= 1 && a <= 4) {
        answered++;
        if (a - 1 === q.correctIndex) correct++;
        else wrong++;
      }
    });
    const total = examQuestions.length;
    const blank = total - answered;
    const denom = partial ? Math.max(1, answered) : Math.max(1, total);
    const pctWithNeg =
      answered === 0
        ? 0
        : Math.max(0, Math.round(((correct - wrong / 3) / denom) * 100));
    const pctNoNeg =
      answered === 0 ? 0 : Math.round((correct / denom) * 100);

    return {
      examTitle,
      examKind,
      partial,
      questions: examQuestions,
      answers: { ...answers },
      correctCount: correct,
      wrongCount: wrong,
      blankCount: blank,
      answeredCount: answered,
      pctWithNeg,
      pctNoNeg,
      durationMinutes: timerMinutesInput,
    };
  };

  // Guest Gate (M08 S234_resume_02_after.xml)
  if (isGuest && mode === "exam-hub") {
    return (
      <div className="flex flex-col h-full p-5 justify-between" dir="rtl">
        <div className="flex items-center gap-3 border-b pb-3" style={{ borderColor: "var(--line)" }}>
          <button
            type="button"
            onClick={onBackToLearn}
            className="w-9 h-9 flex items-center justify-center rounded-lg cursor-pointer"
          >
            <MimoIcon name="ic_arrow_back_24" size={22} mono />
          </button>
          <b className="text-lg">درگاه تمرین و آزمون</b>
        </div>
        <div className="text-center space-y-4 my-auto px-2">
          <div
            className="w-20 h-20 rounded-3xl mx-auto flex items-center justify-center"
            style={{ background: "var(--progress-weak)", color: "var(--primary)" }}
          >
            <MimoIcon name="ic_lock_alt_02" size={48} mono />
          </div>
          <h2 className="text-xl font-bold">یادگیریت رو تثبیت کن</h2>
          <p className="text-sm leading-relaxed" style={{ color: "var(--text-weak)" }}>
            برای دسترسی به هاب ۷بخشی آزمون‌ها، پاسخبرگ، پاسخنامه و صف مرور غلط‌ها، یک پروفایل محلی بساز. هیچ ایمیل، رمز یا سروری لازم نیست.
          </p>
        </div>
        <div className="space-y-2.5">
          <button
            type="button"
            onClick={onCreateLocalProfile}
            className="mimo-cta"
          >
            ساخت پروفایل محلی و ورود به آزمون‌ها
          </button>
          <button
            type="button"
            onClick={onBackToLearn}
            className="mimo-cta secondary"
          >
            بعداً
          </button>
        </div>
      </div>
    );
  }

  // ==========================================================================
  // VIEW 1: EXAM HUB (7 Sections + Filter Chips + Saved Exam Resume Bar)
  // ==========================================================================
  if (mode === "exam-hub") {
    const filterButtons = [
      { key: "all", label: "همه" },
      { key: "0", label: "جامع" },
      { key: "1", label: "زمان‌دار" },
      { key: "2", label: "تک‌درسی / مبحثی" },
      { key: "3", label: "این ماه" },
      { key: "4", label: "تحلیلی" },
      { key: "5", label: "جمع‌بندی" },
      { key: "6", label: "مرور غلط‌ها" },
    ];

    const visibleSections = EXAM_HUB_SECTIONS.filter(
      (s) => hubFilter === "all" || hubFilter === s.filterKey
    );

    return (
      <div className="flex flex-col h-full overflow-y-auto mimo-scroll pb-6" dir="rtl">
        {/* Appbar */}
        <div
          className="flex items-center justify-between px-4 shrink-0 border-b"
          style={{
            height: "var(--toolbar)",
            borderColor: "var(--line)",
            background: "var(--card)",
          }}
        >
          <b className="text-lg">آزمون‌ها و تمرین کنکور</b>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onOpenPlaygroundSheet}
              className="px-3 py-1.5 rounded-full text-xs font-bold border cursor-pointer"
              style={{
                background: "var(--card-pressed)",
                borderColor: "var(--primary)",
                color: "var(--primary)",
              }}
            >
              ＋ ساخت آزمون
            </button>
          </div>
        </div>

        <div className="p-4 space-y-4">
          {/* Hero Card (quiz_introduction_fragment.xml) */}
          <div
            className="p-4 rounded-xl border flex items-center gap-3.5"
            style={{
              background: "var(--card)",
              borderColor: "var(--line)",
            }}
          >
            <div
              className="w-14 h-14 rounded-2xl flex items-center justify-center shrink-0"
              style={{ background: "var(--progress-weak)" }}
            >
              <MimoIcon name="ic_survey" size={44} />
            </div>
            <div className="space-y-1">
              <b className="text-base block">هاب ۷بخشی آزمون‌های کنکور</b>
              <p className="text-xs leading-relaxed" style={{ color: "var(--text-weak)" }}>
                تایمر داخل آزمون (پیش‌فرض ۲۷۰ دقیقه برای جامع) · تفکیک پاسخبرگ و پاسخنامه · کارنامهٔ واقعی با نمرهٔ منفی ⅓
              </p>
            </div>
          </div>

          {/* Resume Bar if an exam was saved (v12.5 خروج و ذخیره) */}
          {savedExam && (
            <div
              className="p-3.5 rounded-xl border-2 flex items-center justify-between gap-3"
              style={{
                background: "var(--progress-weak)",
                borderColor: "var(--primary)",
              }}
            >
              <div className="text-xs">
                <b className="block text-sm" style={{ color: "var(--primary)" }}>
                  آزمون ذخیره‌شده: «{savedExam.examTitle}»
                </b>
                <span style={{ color: "var(--text-weak)" }}>
                  سؤال {faNum(savedExam.qi + 1)} از{" "}
                  {faNum(savedExam.questionIds.length)} ·{" "}
                  {faNum(Object.keys(savedExam.answers).length)} پاسخ ثبت‌شده
                </span>
              </div>
              <button
                type="button"
                onClick={() => onStartOrResumeExam(savedExam)}
                className="px-3.5 py-2 rounded-xl text-xs font-bold text-white shrink-0 cursor-pointer"
                style={{ background: "var(--primary)" }}
              >
                ادامهٔ آزمون ←
              </button>
            </div>
          )}

          {/* Functional Filter Chips (B3) */}
          <div className="flex flex-wrap gap-1.5">
            {filterButtons.map((fb) => {
              const on = hubFilter === fb.key;
              return (
                <button
                  key={fb.key}
                  type="button"
                  onClick={() => setHubFilter(fb.key)}
                  className="px-3 py-1.5 rounded-full text-xs font-bold border transition-colors cursor-pointer"
                  style={{
                    background: on ? "var(--primary)" : "var(--card)",
                    borderColor: on ? "var(--primary)" : "var(--line)",
                    color: on ? "#FFFFFF" : "var(--text-weak)",
                  }}
                >
                  {fb.label}
                </button>
              );
            })}
          </div>

          {/* 7 Sections */}
          {visibleSections.map((sec) => (
            <div key={sec.index} className="space-y-2 pt-1">
              <div className="font-bold text-sm">{sec.titleFa}</div>
              <div
                className="text-[11.5px] leading-relaxed px-3 py-2 rounded-xl border"
                style={{
                  background: "var(--card-pressed)",
                  borderColor: "var(--line)",
                  color: "var(--text-weak)",
                }}
              >
                {sec.metaHtmlFa}
              </div>
              <div className="grid grid-cols-3 gap-2.5">
                {sec.items.map((item, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleLaunchExam(item)}
                    className="p-3 rounded-xl border flex flex-col items-center text-center gap-2 transition-transform hover:-translate-y-0.5 cursor-pointer"
                    style={{
                      background: "var(--card)",
                      borderColor: "var(--line)",
                    }}
                  >
                    <div
                      className="w-12 h-12 rounded-2xl flex items-center justify-center"
                      style={{
                        background: "var(--progress-weak)",
                        color: "var(--primary)",
                      }}
                    >
                      <MimoIcon name={item.icon} size={26} />
                    </div>
                    <div className="text-xs font-bold leading-tight">
                      {item.labelLines[0]}
                      <br />
                      {item.labelLines[1]}
                    </div>
                    <span
                      className="text-[10.5px] px-2 py-0.5 rounded-full font-bold"
                      style={{
                        background: "var(--code-bg)",
                        color: "var(--text-weak)",
                      }}
                    >
                      {item.mistakesOnly
                        ? `${faNum(
                            mistakes.filter((m) => !m.resolved).length
                          )} مورد`
                        : item.badge}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // ==========================================================================
  // VIEW 2: EXAM RUN (Full-Screen Mimo Exam Player + Timer + پاسخبرگ/پاسخنامه)
  // ==========================================================================
  if (mode === "exam-run") {
    const currentQ = examQuestions[qi] || examQuestions[0];
    const policy = EXAM_POLICIES[examKind] || EXAM_POLICIES.normal;
    const chosenOpt = answers[qi]; // 1..4
    const isChecked = Boolean(checked[qi]);
    const isMarked = Boolean(marks[qi]);
    const progPct = Math.round(((qi + 1) / examQuestions.length) * 100);

    const handleOptionSelect = (optNum: number) => {
      if (timerState === "finished") return;
      setAnswers((prev) => ({ ...prev, [qi]: optNum }));
      setChecked((prev) => ({ ...prev, [qi]: false }));
    };

    const handleNextOrSubmitCta = () => {
      // In exams where key is visible during the exam (normal/timed/analytical), first tap checks answer, second tap advances
      if (chosenOpt && !isChecked && policy.allowKeyDuring) {
        setChecked((prev) => ({ ...prev, [qi]: true }));
        const ok = chosenOpt - 1 === currentQ.correctIndex;
        onToast(
          ok
            ? "پاسخ درست است ✓ توضیح تشریحی نمایش داده شد"
            : "پاسخ نادرست ✕ توضیح مبحث نمایش داده شد"
        );
        return;
      }
      if (qi < examQuestions.length - 1) {
        setQi(qi + 1);
      } else {
        // Last question -> open پاسخبرگ or finish
        setActiveSheet("palette");
      }
    };

    return (
      <div
        className="flex flex-col h-full w-full relative select-none"
        style={{ background: "var(--card)", color: "var(--text)" }}
        dir="rtl"
      >
        {/* 1. Mimo chapter_toolbar.xml (52dp): X + 6dp progress + 1 Stateful Timer Chip + Flag */}
        <div
          className="flex items-center gap-2.5 px-3.5 shrink-0 border-b"
          style={{
            height: 52,
            borderColor: "var(--line)",
            direction: "ltr",
          }}
        >
          <button
            type="button"
            onClick={() => setActiveSheet("exit")}
            aria-label="خروج از آزمون"
            className="w-8 h-8 flex items-center justify-center rounded-lg cursor-pointer"
          >
            <MimoIcon name="ic_close" size={22} mono />
          </button>

          <div className="flex-1 mimo-progress-track">
            <div
              className="mimo-progress-fill"
              style={{ width: `${progPct}%` }}
            />
          </div>

          {/* ONE Stateful Timer Chip (#timerWrap — F45, F46) */}
          <div
            className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold border"
            style={{
              background:
                timerState === "running"
                  ? "var(--primary)"
                  : "var(--card-pressed)",
              color: timerState === "running" ? "#FFFFFF" : "var(--text)",
              borderColor:
                timerState === "running" ? "var(--primary)" : "var(--line)",
              direction: "rtl",
            }}
          >
            <button
              type="button"
              onClick={() => {
                if (timerState === "idle" || timerState === "finished") {
                  setActiveSheet("timer");
                } else if (timerState === "running") {
                  setTimerState("paused");
                  onToast("تایمر متوقف شد");
                } else if (timerState === "paused") {
                  setTimerState("running");
                  onToast("ادامهٔ تایمر");
                }
              }}
              className="inline-flex items-center gap-1 cursor-pointer"
            >
              <MimoIcon name="ic_clock_black_24dp" size={14} mono />
              <span>
                {timerState === "idle"
                  ? `تنظیم زمان (${faNum(timerMinutesInput)} د)`
                  : timerState === "finished"
                  ? "پایان زمان"
                  : formatTimer(remainingSec)}
              </span>
            </button>
            {(timerState === "running" || timerState === "paused") && (
              <>
                <button
                  type="button"
                  onClick={() => setActiveSheet("timer")}
                  title="تغییر دقیقه"
                  className="px-1 hover:opacity-80 cursor-pointer"
                >
                  ⚙
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setTimerState("idle");
                    setRemainingSec(timerMinutesInput * 60);
                    onToast("تایمر بازنشانی شد");
                  }}
                  title="پاک کردن تایمر"
                  className="px-1 hover:opacity-80 cursor-pointer"
                >
                  ✕
                </button>
              </>
            )}
          </div>
        </div>

        {/* 2. Question Body */}
        <div className="flex-1 overflow-y-auto mimo-scroll p-4 space-y-3.5">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold" style={{ color: "var(--text-weak)" }}>
              {examTitle} · سؤال {faNum(qi + 1)} از{" "}
              {faNum(examQuestions.length)}
            </span>
            <span
              className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full font-bold"
              style={{
                background: "var(--progress-weak)",
                color: "var(--primary)",
              }}
            >
              <span>{currentQ.subject}</span>
              <span>·</span>
              <span>{currentQ.topic}</span>
              <span>·</span>
              <span>{currentQ.difficultyLabel}</span>
            </span>
          </div>

          <h2 className="text-[17px] font-bold leading-[1.85]">
            {currentQ.stemFa}
          </h2>

          <div
            className="flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs"
            style={{
              background: "var(--code-bg)",
              color: "var(--text-weak)",
            }}
          >
            <MimoIcon name="ic_help" size={14} mono />
            <span>گزینهٔ درست را انتخاب کنید</span>
          </div>

          {/* 4 Mimo Options (choice_list_item.xml) */}
          <div className="grid gap-2.5">
            {currentQ.options.map((opt, idx) => {
              const optNum = idx + 1;
              const isSel = chosenOpt === optNum;
              const showKeyFeedback = isChecked && policy.allowKeyDuring;
              const isRight =
                showKeyFeedback && idx === currentQ.correctIndex;
              const isWrong =
                showKeyFeedback && isSel && idx !== currentQ.correctIndex;

              let borderCol = "var(--line)";
              let bgCol = "var(--card)";
              let badgeBg = "var(--code-bg)";
              let badgeCol = "var(--text)";

              if (isRight) {
                borderCol = "var(--success)";
                bgCol = "rgba(102, 188, 90, 0.12)";
                badgeBg = "var(--success)";
                badgeCol = "#FFFFFF";
              } else if (isWrong) {
                borderCol = "var(--error)";
                bgCol = "rgba(240, 90, 110, 0.12)";
                badgeBg = "var(--error)";
                badgeCol = "#FFFFFF";
              } else if (isSel) {
                borderCol = "var(--primary)";
                bgCol = "var(--card-pressed)";
                badgeBg = "var(--primary)";
                badgeCol = "#FFFFFF";
              }

              return (
                <button
                  key={idx}
                  type="button"
                  onClick={() => handleOptionSelect(optNum)}
                  className="flex items-center gap-3 w-full min-h-[50px] p-3 rounded-xl border-2 text-right transition-all cursor-pointer"
                  style={{
                    borderColor: borderCol,
                    background: bgCol,
                  }}
                >
                  <span
                    className="w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold shrink-0"
                    style={{ background: badgeBg, color: badgeCol }}
                  >
                    {faNum(optNum)}
                  </span>
                  <span className="text-[14.5px] font-medium flex-1">
                    {opt}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Feedback Panel when checked in normal/timed/analytical mode */}
          {isChecked && policy.allowKeyDuring && (
            <div
              className="p-3.5 rounded-xl border-2 space-y-1.5"
              style={{
                background:
                  chosenOpt - 1 === currentQ.correctIndex
                    ? "rgba(102, 188, 90, 0.12)"
                    : "rgba(240, 90, 110, 0.12)",
                borderColor:
                  chosenOpt - 1 === currentQ.correctIndex
                    ? "var(--success)"
                    : "var(--error)",
              }}
            >
              <b
                className="block text-xs"
                style={{
                  color:
                    chosenOpt - 1 === currentQ.correctIndex
                      ? "var(--success)"
                      : "var(--error)",
                }}
              >
                {chosenOpt - 1 === currentQ.correctIndex
                  ? "✓ پاسخ درست است"
                  : `✕ پاسخ نادرست است · گزینهٔ صحیح: ${faNum(
                      currentQ.correctIndex + 1
                    )}`}
              </b>
              <p className="text-xs leading-relaxed">
                {currentQ.explanationFa}
              </p>
            </div>
          )}

          {/* THREE Quiet Chips (v12.5 F46: پاسخبرگ / پاسخنامه / توضیح با هوش مصنوعی) */}
          <div className="flex flex-wrap gap-2 pt-2">
            <button
              type="button"
              onClick={() => setActiveSheet("palette")}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold border cursor-pointer"
              style={{
                background: "var(--card-pressed)",
                borderColor: "var(--line)",
                color: "var(--text)",
              }}
            >
              <MimoIcon name="ic_list_bulleted" size={15} mono />
              <span>پاسخبرگ ({faNum(Object.keys(answers).length)}/{faNum(examQuestions.length)})</span>
            </button>

            {policy.allowKeyDuring && (
              <button
                type="button"
                onClick={() => setActiveSheet("key")}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold border cursor-pointer"
                style={{
                  background: "var(--card-pressed)",
                  borderColor: "var(--line)",
                  color: "var(--text)",
                }}
              >
                <MimoIcon name="ic_file" size={15} mono />
                <span>پاسخنامه</span>
              </button>
            )}

            <button
              type="button"
              onClick={() => {
                const userPick = chosenOpt
                  ? currentQ.options[chosenOpt - 1]
                  : "هنوز انتخاب نشده";
                onOpenAiWithContext(
                  `زمینه: ${examTitle} · سؤال ${faNum(qi + 1)} · ${
                    currentQ.stemFa
                  } · پاسخ شما: ${userPick}`,
                  `<b>تحلیل سؤال ${faNum(qi + 1)} (${currentQ.subject} · ${
                    currentQ.topic
                  }):</b><br>• صورت سؤال: ${
                    currentQ.stemFa
                  }<br>• پاسخ شما: ${userPick}<br>• پاسخ صحیح: گزینهٔ ${faNum(
                    currentQ.correctIndex + 1
                  )} (${
                    currentQ.options[currentQ.correctIndex]
                  })<br>• توضیح تشریحی: ${currentQ.explanationFa}`
                );
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold border cursor-pointer"
              style={{
                background: "var(--card-pressed)",
                borderColor: "var(--primary)",
                color: "var(--primary)",
              }}
            >
              <MimoIcon name="ic_magic_wand" size={15} mono />
              <span>توضیح با هوش مصنوعی</span>
            </button>
          </div>
        </div>

        {/* 3. Footer (interaction_keyboard_view.xml — F40: 2 square 48dp buttons + 1 full-width CTA) */}
        <div
          className="p-3.5 border-t shrink-0 flex items-center gap-2"
          style={{
            background: "var(--card)",
            borderColor: "var(--line)",
          }}
        >
          <button
            type="button"
            disabled={qi === 0}
            onClick={() => setQi(Math.max(0, qi - 1))}
            aria-label="سؤال قبل"
            className="w-12 h-12 rounded-xl border flex items-center justify-center shrink-0 cursor-pointer disabled:opacity-40"
            style={{
              background: "var(--card-pressed)",
              borderColor: "var(--line)",
            }}
          >
            <MimoIcon name="ic_arrow_right" size={20} mono />
          </button>

          <button
            type="button"
            onClick={() => {
              setMarks((prev) => ({ ...prev, [qi]: !prev[qi] }));
              onToast(
                !isMarked
                  ? "سؤال برای مرور علامت‌گذاری شد"
                  : "علامت سؤال برداشته شد"
              );
            }}
            aria-label="علامت‌گذاری"
            className="w-12 h-12 rounded-xl border flex items-center justify-center shrink-0 cursor-pointer"
            style={{
              background: isMarked ? "var(--yellow)" : "var(--card-pressed)",
              borderColor: isMarked ? "var(--yellow)" : "var(--line)",
              color: isMarked ? "#252746" : "var(--text)",
            }}
          >
            <MimoIcon name="bookmark" size={19} mono />
          </button>

          <button
            type="button"
            onClick={handleNextOrSubmitCta}
            className="mimo-cta flex-1"
          >
            <span>
              {chosenOpt && !isChecked && policy.allowKeyDuring
                ? "بررسی پاسخ"
                : qi === examQuestions.length - 1
                ? "مشاهدهٔ پاسخبرگ و پایان"
                : "ادامه"}
            </span>
            <MimoIcon name="ic_arrow_left" size={18} mono />
          </button>
        </div>

        {/* 4. Bottom Sheets inside Exam Run */}
        {activeSheet !== "none" && (
          <div
            className="absolute inset-0 z-40 flex flex-col justify-end"
            style={{ background: "rgba(37, 39, 70, 0.55)" }}
          >
            <div
              className="w-full rounded-t-3xl p-5 space-y-4 max-h-[82%] overflow-y-auto mimo-scroll border-t"
              style={{
                background: "var(--sheet)",
                borderColor: "var(--line)",
              }}
            >
              <div
                className="w-10 h-1.5 rounded-full mx-auto"
                style={{ background: "var(--progress-bg)" }}
              />

              {/* SHEET A: Timer Configuration (#timerSheet — editable in EVERY exam kind, default 270 for comprehensive) */}
              {activeSheet === "timer" && (
                <div className="space-y-3.5">
                  <h4 className="font-bold text-base">تنظیم زمان آزمون</h4>
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold block">
                      مدت (دقیقه)
                    </label>
                    <input
                      type="number"
                      min={1}
                      value={timerMinutesInput}
                      onChange={(e) =>
                        setTimerMinutesInput(
                          Math.max(1, parseInt(e.target.value || "1", 10))
                        )
                      }
                      className="w-full px-3.5 py-2.5 rounded-xl border text-base font-bold"
                      style={{
                        background: "var(--card-pressed)",
                        borderColor: "var(--primary)",
                      }}
                    />
                  </div>
                  <p className="text-xs" style={{ color: "var(--text-weak)" }}>
                    مدت دلخواه به دقیقه — در همهٔ آزمون‌ها، حتی جامع (پیش‌فرض ۲۷۰ دقیقه)، قابل تغییر است.
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {[15, 30, 45, 60, 90, 120, 270].map((m) => (
                      <button
                        key={m}
                        type="button"
                        onClick={() => setTimerMinutesInput(m)}
                        className="px-3 py-1.5 rounded-xl text-xs font-bold border cursor-pointer"
                        style={{
                          background:
                            timerMinutesInput === m
                              ? "var(--primary)"
                              : "var(--card-pressed)",
                          color:
                            timerMinutesInput === m ? "#FFFFFF" : "var(--text)",
                          borderColor:
                            timerMinutesInput === m
                              ? "var(--primary)"
                              : "var(--line)",
                        }}
                      >
                        {faNum(m)} دقیقه
                      </button>
                    ))}
                  </div>
                  <div className="flex gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => {
                        setRemainingSec(timerMinutesInput * 60);
                        setTimerState("running");
                        setActiveSheet("none");
                        onToast(
                          `تایمر شروع شد: ${faNum(
                            timerMinutesInput
                          )} دقیقه شمارش معکوس`
                        );
                      }}
                      className="mimo-cta flex-1"
                    >
                      شروع آزمون ⏱
                    </button>
                    <button
                      type="button"
                      onClick={() => setActiveSheet("none")}
                      className="mimo-cta secondary flex-1"
                    >
                      انصراف
                    </button>
                  </div>
                </div>
              )}

              {/* SHEET B: پاسخبرگ (#paletteSheet — shows chosen option numbers, NOT answer key) */}
              {activeSheet === "palette" && (
                <div className="space-y-3.5">
                  <div className="flex items-center justify-between">
                    <h4 className="font-bold text-base">پاسخبرگ</h4>
                    <span className="text-xs" style={{ color: "var(--text-weak)" }}>
                      {faNum(Object.keys(answers).length)} از{" "}
                      {faNum(examQuestions.length)} پاسخ‌داده‌شده
                    </span>
                  </div>
                  <p className="text-xs" style={{ color: "var(--text-weak)" }}>
                    شمارهٔ سؤال‌ها و <b>گزینه‌ای که زده‌اید</b>. با کلیک روی هر خانه به همان سؤال می‌روید.
                  </p>
                  <div className="grid grid-cols-5 gap-2">
                    {examQuestions.map((_, idx) => {
                      const ans = answers[idx];
                      const mk = marks[idx];
                      const isCur = idx === qi;
                      return (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => {
                            setQi(idx);
                            setActiveSheet("none");
                          }}
                          className="p-2 rounded-xl border text-center flex flex-col items-center justify-center cursor-pointer"
                          style={{
                            background: isCur
                              ? "var(--progress-weak)"
                              : ans
                              ? "var(--primary)"
                              : "var(--card-pressed)",
                            color:
                              ans && !isCur ? "#FFFFFF" : "var(--text)",
                            borderColor: mk
                              ? "var(--yellow)"
                              : isCur
                              ? "var(--primary)"
                              : "var(--line)",
                            borderWidth: mk || isCur ? 2 : 1,
                          }}
                        >
                          <span className="text-xs font-bold">
                            {faNum(idx + 1)} {mk ? "★" : ""}
                          </span>
                          <small className="text-[11px] opacity-90">
                            {ans ? `گزینه ${faNum(ans)}` : "—"}
                          </small>
                        </button>
                      );
                    })}
                  </div>
                  <div className="flex gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => {
                        setActiveSheet("none");
                        onFinishExam(computeExamResult(false));
                      }}
                      className="mimo-cta flex-1"
                    >
                      ثبت پاسخ‌ها و پایان آزمون
                    </button>
                    <button
                      type="button"
                      onClick={() => setActiveSheet("none")}
                      className="mimo-cta secondary flex-1"
                    >
                      بستن
                    </button>
                  </div>
                </div>
              )}

              {/* SHEET C: پاسخنامه (#keySheet — full dynamic answer key & explanations) */}
              {activeSheet === "key" && (
                <div className="space-y-3.5">
                  <h4 className="font-bold text-base">
                    پاسخنامه · کلید تستی و تشریحی همهٔ سؤالات
                  </h4>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setKeyTab("desc")}
                      className="px-3.5 py-1.5 rounded-full text-xs font-bold border cursor-pointer"
                      style={{
                        background:
                          keyTab === "desc"
                            ? "var(--primary)"
                            : "var(--card-pressed)",
                        color: keyTab === "desc" ? "#FFFFFF" : "var(--text)",
                        borderColor: "var(--line)",
                      }}
                    >
                      پاسخ تشریحی
                    </button>
                    <button
                      type="button"
                      onClick={() => setKeyTab("test")}
                      className="px-3.5 py-1.5 rounded-full text-xs font-bold border cursor-pointer"
                      style={{
                        background:
                          keyTab === "test"
                            ? "var(--primary)"
                            : "var(--card-pressed)",
                        color: keyTab === "test" ? "#FFFFFF" : "var(--text)",
                        borderColor: "var(--line)",
                      }}
                    >
                      کلید تستی
                    </button>
                  </div>

                  {keyTab === "desc" ? (
                    <div className="space-y-2.5 max-h-[320px] overflow-y-auto mimo-scroll pr-1">
                      {examQuestions.map((q, idx) => {
                        const userAns = answers[idx];
                        const isRight = userAns === q.correctIndex + 1;
                        return (
                          <div
                            key={q.id}
                            className="p-3 rounded-xl border text-xs space-y-1"
                            style={{
                              background: "var(--card-pressed)",
                              borderColor: userAns
                                ? isRight
                                  ? "var(--success)"
                                  : "var(--error)"
                                : "var(--line)",
                            }}
                          >
                            <div className="flex items-center justify-between font-bold">
                              <span>
                                سؤال {faNum(idx + 1)} · {q.subject} / {q.topic}
                              </span>
                              <span
                                style={{
                                  color: !userAns
                                    ? "var(--text-weak)"
                                    : isRight
                                    ? "var(--success)"
                                    : "var(--error)",
                                }}
                              >
                                {!userAns
                                  ? "نزده"
                                  : isRight
                                  ? `پاسخ شما: ${faNum(userAns)} ✓`
                                  : `پاسخ شما: ${faNum(userAns)} ✗ (کلید: ${faNum(
                                      q.correctIndex + 1
                                    )})`}
                              </span>
                            </div>
                            <p className="leading-relaxed">
                              <b>پاسخ صحیح (گزینهٔ {faNum(q.correctIndex + 1)}):</b>{" "}
                              {q.explanationFa}
                            </p>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="grid grid-cols-2 gap-2 max-h-[320px] overflow-y-auto mimo-scroll">
                      {examQuestions.map((q, idx) => {
                        const userAns = answers[idx];
                        const ok = userAns === q.correctIndex + 1;
                        return (
                          <div
                            key={q.id}
                            className="p-2.5 rounded-xl border text-xs flex items-center justify-between"
                            style={{
                              background: "var(--card-pressed)",
                              borderColor: "var(--line)",
                            }}
                          >
                            <span>
                              سؤال {faNum(idx + 1)} ←{" "}
                              <b>گزینهٔ {faNum(q.correctIndex + 1)}</b>
                            </span>
                            <span
                              className="font-bold"
                              style={{
                                color: !userAns
                                  ? "var(--weak-icon)"
                                  : ok
                                  ? "var(--success)"
                                  : "var(--error)",
                              }}
                            >
                              {!userAns
                                ? "نزده"
                                : ok
                                ? `شما: ${faNum(userAns)} ✓`
                                : `شما: ${faNum(userAns)} ✗`}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  )}

                  <button
                    type="button"
                    onClick={() => setActiveSheet("none")}
                    className="mimo-cta"
                  >
                    بستن پاسخنامه
                  </button>
                </div>
              )}

              {/* SHEET D: 3-Route Exit Sheet (#exitSheet — F46) */}
              {activeSheet === "exit" && (
                <div className="space-y-3.5">
                  <h4 className="font-bold text-base">خروج از آزمون؟</h4>
                  <p className="text-xs leading-relaxed" style={{ color: "var(--text-weak)" }}>
                    پاسخ‌ها تا این لحظه ذخیره می‌شوند. «خروج و ذخیره» بعداً از همان سؤال قابل ادامه است؛ گزینهٔ سوم همین‌جا کارنامه و درصد پاسخ‌های زده‌شده را نشان می‌دهد.
                  </p>
                  <div className="space-y-2">
                    <button
                      type="button"
                      onClick={() => {
                        setActiveSheet("none");
                        onSaveExamAndExit({
                          examTitle,
                          examKind,
                          questionIds: examQuestions.map((q) => q.id),
                          qi,
                          answers,
                          checked,
                          marks,
                          durationMinutes: timerMinutesInput,
                          timerState:
                            timerState === "running" ? "paused" : timerState,
                          remainingSeconds: remainingSec,
                        });
                      }}
                      className="mimo-cta"
                    >
                      خروج و ذخیره (ادامه در مراجعات بعدی)
                    </button>
                    <button
                      type="button"
                      onClick={() => setActiveSheet("none")}
                      className="mimo-cta secondary"
                    >
                      ادامهٔ آزمون
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setActiveSheet("none");
                        onFinishExam(computeExamResult(true));
                      }}
                      className="w-full p-3 rounded-xl border text-center cursor-pointer"
                      style={{
                        background: "var(--card-pressed)",
                        borderColor: "var(--primary)",
                        color: "var(--primary)",
                      }}
                    >
                      <b className="block text-sm">
                        پایان آزمون و دیدن کارنامه
                      </b>
                      <small className="text-[11px] opacity-85">
                        خروج و دیدن درصد تا همین‌جا (محاسبه از پاسخ‌های زده‌شده)
                      </small>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    );
  }

  // ==========================================================================
  // VIEW 3: EXAM RESULT (100% Real Dynamic Report Card — Fixes R9!)
  // ==========================================================================
  const res: CompletedExamResult =
    lastResult || computeExamResult(false);

  const wrongOrBlankQuestions = res.questions
    .map((q, idx) => ({
      q,
      idx,
      userAns: res.answers[idx],
      isWrong:
        res.answers[idx] !== undefined &&
        res.answers[idx] - 1 !== q.correctIndex,
      isBlank: res.answers[idx] === undefined,
    }))
    .filter((item) => item.isWrong || item.isBlank);

  // Subject breakdown
  const subjects: ("زیست" | "شیمی" | "فیزیک" | "ریاضی")[] = [
    "زیست",
    "شیمی",
    "فیزیک",
    "ریاضی",
  ];
  const subjectStats = subjects
    .map((subj) => {
      const items = res.questions
        .map((q, idx) => ({ q, idx }))
        .filter((x) => x.q.subject === subj);
      if (items.length === 0) return null;
      let c = 0,
        w = 0;
      items.forEach(({ q, idx }) => {
        const a = res.answers[idx];
        if (a) {
          if (a - 1 === q.correctIndex) c++;
          else w++;
        }
      });
      const pct = Math.max(
        0,
        Math.round(((c - w / 3) / items.length) * 100)
      );
      return { subj, total: items.length, c, w, pct };
    })
    .filter(Boolean);

  // Local estimated rank/taraz (transparently labeled local calculation)
  const localTaraz = 4500 + Math.round(res.pctWithNeg * 52);

  return (
    <div
      className="flex flex-col h-full w-full relative overflow-y-auto mimo-scroll pb-6"
      style={{ background: "var(--bg)", color: "var(--text)" }}
      dir="rtl"
    >
      {/* Top Bar */}
      <div
        className="flex items-center justify-between px-4 shrink-0 border-b"
        style={{
          height: 54,
          background: "var(--card)",
          borderColor: "var(--line)",
        }}
      >
        <button
          type="button"
          onClick={onBackToHub}
          className="w-9 h-9 flex items-center justify-center rounded-lg cursor-pointer"
        >
          <MimoIcon name="ic_arrow_right" size={22} mono />
        </button>
        <div className="flex-1 px-3">
          <b className="text-sm block">نتیجه و کارنامهٔ آزمون</b>
          <div className="mimo-progress-track mt-1">
            <div className="mimo-progress-fill" style={{ width: "100%" }} />
          </div>
        </div>
        <span
          className="px-2.5 py-0.5 rounded-full text-xs font-bold border"
          style={{
            background: "var(--progress-weak)",
            borderColor: "var(--primary)",
            color: "var(--primary)",
          }}
        >
          {res.partial
            ? "تا این لحظه"
            : EXAM_POLICIES[res.examKind].shortLabel}
        </span>
      </div>

      <div className="p-4 space-y-4">
        {/* Hero Celebration */}
        <div
          className="p-5 rounded-2xl border text-center space-y-2"
          style={{
            background: "var(--card)",
            borderColor: "var(--line)",
          }}
        >
          <div
            className="w-16 h-16 rounded-2xl mx-auto flex items-center justify-center"
            style={{
              background: "var(--progress-weak)",
              color: "var(--primary)",
            }}
          >
            <MimoIcon name="ic_cap_filled" size={44} />
          </div>
          <h2 className="text-xl font-bold">
            {res.partial ? "کارنامهٔ تا این لحظه" : "آزمون تمام شد!"}
          </h2>
          <p className="text-xs" style={{ color: "var(--text-weak)" }}>
            «{res.examTitle}» · {faNum(res.correctCount)} درست ·{" "}
            {faNum(res.wrongCount)} غلط · {faNum(res.blankCount)} نزده
          </p>
        </div>

        {/* Partial Exit Banner */}
        {res.partial && (
          <div
            className="p-3.5 rounded-xl border text-xs leading-relaxed"
            style={{
              background: "rgba(244, 208, 85, 0.18)",
              borderColor: "var(--yellow)",
            }}
          >
            <b>خروج و دیدن درصد تا همین‌جا:</b> این درصد فقط از{" "}
            {faNum(res.answeredCount)} پاسخی که تا این لحظه ثبت کرده‌اید محاسبه شده است ({faNum(res.correctCount)} درست و {faNum(res.wrongCount)} غلط)؛{" "}
            {faNum(res.blankCount)} سؤال نزده باقی مانده‌اند.
          </div>
        )}

        {/* Primary Metrics Card */}
        <div
          className="p-4 rounded-xl border space-y-2.5"
          style={{
            background: "var(--card)",
            borderColor: "var(--line)",
          }}
        >
          <b className="text-sm block pb-1 border-b" style={{ borderColor: "var(--line)" }}>
            نتیجه و تحلیل واقعی پاسخ‌های شما
          </b>
          <div className="flex justify-between items-center text-sm py-1">
            <span style={{ color: "var(--text-weak)" }}>
              {res.partial
                ? "درصد تا این لحظه (با نمرهٔ منفی ⅓)"
                : "درصد کل با نمرهٔ منفی ⅓"}
            </span>
            <b
              className="text-lg"
              style={{
                color:
                  res.pctWithNeg >= 50 ? "var(--success)" : "var(--primary)",
              }}
            >
              {faNum(res.pctWithNeg)}٪
            </b>
          </div>
          <div className="flex justify-between items-center text-sm py-1 border-t" style={{ borderColor: "var(--line)" }}>
            <span style={{ color: "var(--text-weak)" }}>
              اگر غلط‌ها را نزده می‌گذاشتی (بدون نمرهٔ منفی)
            </span>
            <b className="text-base">{faNum(res.pctNoNeg)}٪</b>
          </div>
          <div className="flex justify-between items-center text-sm py-1 border-t" style={{ borderColor: "var(--line)" }}>
            <span style={{ color: "var(--text-weak)" }}>
              درست / غلط / نزده
            </span>
            <b>
              {faNum(res.correctCount)} / {faNum(res.wrongCount)} /{" "}
              {faNum(res.blankCount)}
            </b>
          </div>
          <div className="flex justify-between items-center text-sm py-1 border-t" style={{ borderColor: "var(--line)" }}>
            <span style={{ color: "var(--text-weak)" }}>
              تراز تخمینی محلی (SERVER CONFIRMED=0)
            </span>
            <b>{res.answeredCount > 0 ? faNum(localTaraz) : "—"}</b>
          </div>
        </div>

        {/* Subject-by-Subject Breakdown */}
        <div
          className="p-4 rounded-xl border space-y-3"
          style={{
            background: "var(--card)",
            borderColor: "var(--line)",
          }}
        >
          <b className="text-sm block">تحلیل تفکیکی دروس</b>
          <div className="space-y-2.5">
            {subjectStats.map((st) =>
              st ? (
                <div key={st.subj} className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <b>
                      {st.subj} ({faNum(st.c)} درست · {faNum(st.w)} غلط از{" "}
                      {faNum(st.total)})
                    </b>
                    <span className="font-bold" style={{ color: "var(--primary)" }}>
                      {faNum(st.pct)}٪
                    </span>
                  </div>
                  <div className="mimo-progress-track">
                    <div
                      className="mimo-progress-fill"
                      style={{ width: `${st.pct}%` }}
                    />
                  </div>
                </div>
              ) : null
            )}
          </div>
        </div>

        {/* Actual Mistakes & Blank Questions Card (Transferred to AI on click) */}
        <div
          className="p-4 rounded-xl border space-y-2.5"
          style={{
            background: "var(--card)",
            borderColor: "var(--line)",
          }}
        >
          <div className="flex items-center justify-between">
            <b className="text-sm">
              صورت اشتباهات و نزده‌ها ({faNum(wrongOrBlankQuestions.length)} مورد)
            </b>
            <span className="text-[11px]" style={{ color: "var(--text-weak)" }}>
              آمادهٔ انتقال به هوش مصنوعی
            </span>
          </div>

          {wrongOrBlankQuestions.length === 0 ? (
            <div
              className="p-3 rounded-xl text-xs font-bold text-center"
              style={{
                background: "rgba(102, 188, 90, 0.14)",
                color: "var(--success)",
              }}
            >
              🎉 فوق‌العاده! به تمام سؤالات این آزمون پاسخ درست دادید.
            </div>
          ) : (
            <div className="space-y-2 max-h-[260px] overflow-y-auto mimo-scroll pr-1">
              {wrongOrBlankQuestions.map(({ q, idx, userAns, isWrong }) => (
                <div
                  key={q.id}
                  className="p-3 rounded-xl border text-xs space-y-1"
                  style={{
                    background: "var(--card-pressed)",
                    borderColor: isWrong ? "var(--error)" : "var(--line)",
                  }}
                >
                  <div className="font-bold flex justify-between">
                    <span>
                      سؤال {faNum(idx + 1)} · {q.subject} / {q.topic}
                    </span>
                    <span
                      style={{
                        color: isWrong ? "var(--error)" : "var(--text-weak)",
                      }}
                    >
                      {userAns
                        ? `پاسخ شما: گزینهٔ ${faNum(userAns)} ✗`
                        : "نزده"}
                    </span>
                  </div>
                  <p>{q.stemFa}</p>
                  <div style={{ color: "var(--success)" }} className="font-bold">
                    پاسخ صحیح: گزینهٔ {faNum(q.correctIndex + 1)} (
                    {q.options[q.correctIndex]})
                  </div>
                  <div style={{ color: "var(--text-weak)" }}>
                    {q.explanationFa}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Result Footer Actions: پاسخبرگ / پاسخنامه / توضیح با هوش مصنوعی */}
        <div className="grid grid-cols-3 gap-2">
          <button
            type="button"
            onClick={() => setActiveSheet("palette")}
            className="p-2.5 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer"
            style={{
              background: "var(--card)",
              borderColor: "var(--line)",
            }}
          >
            <MimoIcon name="ic_list_bulleted" size={15} mono />
            <span>پاسخبرگ</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveSheet("key")}
            className="p-2.5 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer"
            style={{
              background: "var(--card)",
              borderColor: "var(--line)",
            }}
          >
            <MimoIcon name="ic_file" size={15} mono />
            <span>پاسخنامه کامل</span>
          </button>

          <button
            type="button"
            onClick={() => {
              const summaryLines = wrongOrBlankQuestions
                .slice(0, 6)
                .map(
                  (w) =>
                    `• سؤال ${faNum(w.idx + 1)} (${w.q.subject} / ${
                      w.q.topic
                    }): «${w.q.stemFa}» | پاسخ شما: ${
                      w.userAns ? `گزینهٔ ${faNum(w.userAns)}` : "نزده"
                    } | کلید: گزینهٔ ${faNum(w.q.correctIndex + 1)} (${
                      w.q.explanationFa
                    })`
                )
                .join("<br>");
              onOpenAiWithContext(
                `زمینه: تحلیل کارنامهٔ «${res.examTitle}» · درصد: ${faNum(
                  res.pctWithNeg
                )}٪ · ${faNum(wrongOrBlankQuestions.length)} سؤال غلط/نزده`,
                `<b>تحلیل اشتباهات و نزده‌های آزمون «${
                  res.examTitle
                }»:</b><br>${
                  summaryLines ||
                  "همهٔ سؤالات این آزمون به درستی پاسخ داده شده‌اند!"
                }`
              );
            }}
            className="p-2.5 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer"
            style={{
              background: "var(--progress-weak)",
              borderColor: "var(--primary)",
              color: "var(--primary)",
            }}
          >
            <MimoIcon name="ic_magic_wand" size={15} mono />
            <span>تحلیل با AI</span>
          </button>
        </div>

        <button type="button" onClick={onBackToHub} className="mimo-cta">
          بازگشت به هاب آزمون‌ها
        </button>
      </div>

      {/* Bottom Sheets on Result Screen (پاسخبرگ / پاسخنامه) */}
      {(activeSheet === "palette" || activeSheet === "key") && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
          style={{ background: "rgba(37, 39, 70, 0.55)" }}
        >
          <div
            className="w-full max-w-[380px] rounded-3xl p-5 space-y-4 max-h-[82vh] overflow-y-auto mimo-scroll border"
            style={{
              background: "var(--sheet)",
              borderColor: "var(--line)",
            }}
          >
            {activeSheet === "palette" ? (
              <>
                <h4 className="font-bold text-base">پاسخبرگ ثبت‌شده</h4>
                <div className="grid grid-cols-5 gap-2">
                  {res.questions.map((q, idx) => {
                    const ans = res.answers[idx];
                    const ok = ans === q.correctIndex + 1;
                    return (
                      <div
                        key={q.id}
                        className="p-2 rounded-xl border text-center"
                        style={{
                          background: !ans
                            ? "var(--card-pressed)"
                            : ok
                            ? "rgba(102, 188, 90, 0.16)"
                            : "rgba(240, 90, 110, 0.16)",
                          borderColor: !ans
                            ? "var(--line)"
                            : ok
                            ? "var(--success)"
                            : "var(--error)",
                        }}
                      >
                        <div className="text-xs font-bold">
                          {faNum(idx + 1)}
                        </div>
                        <small className="text-[11px]">
                          {ans ? `گزینه ${faNum(ans)}` : "نزده"}
                        </small>
                      </div>
                    );
                  })}
                </div>
              </>
            ) : (
              <>
                <h4 className="font-bold text-base">پاسخنامهٔ تشریحی آزمون</h4>
                <div className="space-y-2.5 max-h-[340px] overflow-y-auto mimo-scroll pr-1">
                  {res.questions.map((q, idx) => (
                    <div
                      key={q.id}
                      className="p-3 rounded-xl border text-xs space-y-1"
                      style={{
                        background: "var(--card-pressed)",
                        borderColor: "var(--line)",
                      }}
                    >
                      <div className="font-bold flex justify-between">
                        <span>
                          سؤال {faNum(idx + 1)} · {q.subject} / {q.topic}
                        </span>
                        <span style={{ color: "var(--success)" }}>
                          کلید: گزینهٔ {faNum(q.correctIndex + 1)}
                        </span>
                      </div>
                      <p>{q.explanationFa}</p>
                    </div>
                  ))}
                </div>
              </>
            )}
            <button
              type="button"
              onClick={() => setActiveSheet("none")}
              className="mimo-cta"
            >
              بستن
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
