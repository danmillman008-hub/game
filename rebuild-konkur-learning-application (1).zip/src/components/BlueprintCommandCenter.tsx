"use client";

import React, { useState } from "react";
import {
  USER_REPO_FORENSICS,
  OPEN_SOURCE_REPOS_MATRIX,
  WEIGHTED_AGENT_PHASES,
  ALGORITHMIC_UPGRADES,
} from "@/lib/blueprint-data";
import {
  Copy,
  Check,
  GitBranch,
  Layers,
  Terminal,
  ShieldAlert,
  Sparkles,
  CheckCircle2,
  Clock,
  CircleDot,
  ExternalLink,
  Download,
  Cpu,
  BookOpen,
  Play,
} from "lucide-react";

interface BlueprintPhaseRow {
  id: number;
  phaseNumber: number;
  code: string;
  title: string;
  weightPct: number;
  status: string;
  customNotes: string;
}

interface Props {
  blueprintPhases: BlueprintPhaseRow[];
  onPhaseStatusChange: (
    phaseNumber: number,
    status: "completed" | "in_progress" | "ready"
  ) => Promise<void>;
  onJumpToMimoPlayer: () => void;
}

export default function BlueprintCommandCenter({
  blueprintPhases,
  onPhaseStatusChange,
  onJumpToMimoPlayer,
}: Props) {
  const [activeSubTab, setActiveSubTab] = useState<
    "roadmap" | "forensics" | "repos" | "upgrades"
  >("roadmap");
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [updatingPhase, setUpdatingPhase] = useState<number | null>(null);

  const statusByNumber = new Map<number, string>();
  for (const bp of blueprintPhases) {
    statusByNumber.set(bp.phaseNumber, bp.status);
  }

  const completedWeight = WEIGHTED_AGENT_PHASES.reduce((acc, p) => {
    const st = statusByNumber.get(p.phaseNumber) ?? "ready";
    if (st === "completed") return acc + p.weightPct;
    if (st === "in_progress") return acc + Math.round(p.weightPct * 0.5);
    return acc;
  }, 0);

  const handleCopy = async (key: string, text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedKey(key);
      setTimeout(() => setCopiedKey(null), 2200);
    } catch {
      // Fallback
    }
  };

  const buildFullMasterPrompt = () => {
    const lines: string[] = [
      "# MASTER AI AGENT EXECUTION PLAYBOOK — KONKUR-MIMO x LEARNHARNESS",
      "You are a Principal Fullstack Engineer & Cognitive EdTech Architect.",
      "Follow these 10 strictly weighted phases (100% total) sequentially. Do NOT skip verification gates.",
      "",
      "## CORE ARCHITECTURAL PILLARS:",
      "1. LearnHarness Cognitive Engine (https://github.com/amosblomqvist/learnharness): Probe (Binary Search Strands + Confidence % + Think-Out-Loud) -> Plan (Minimal Dependency DAG from Unconditional Truths) -> Teach (Principle i: Unconditional Truths + Principle ii: Motivated Discovery + Micro-Checks) -> Practice (Inactive Proposition Retrieval + Progressive Hint Ladder + Committed Model Solution).",
      "2. Gramophone KST & Flow Core (https://github.com/danmillman008-hub/newlearning): Knowledge Space Theory Outer/Inner Fringe calculation, DFS cycle removal, 70%-85% Flow-Band controller, and xAPI telemetry (with all Q1-Q7 fixes from EVAL-QUALITATIVE.md applied).",
      "3. Hybrid Memory Engine (https://github.com/open-spaced-repetition/ts-fsrs + my-first DECISIONS.md): Calibrated BKT + FSRS-5 Stability/Difficulty/Retrievability, Aided vs Unaided separation, and Massed-practice growth cap.",
      "4. Mimo Micro-Learning UX + Konkur Exam Simulator: Bite-sized interactive cards, Hearts, Streaks, XP, plus full Iranian Konkur Simulator (-33.3% negative marking: ((3*C - W)/(3*N))*100, Taraz estimation, 300-bubble optical sheet, Designer Trap radar) and Swiss Konkur Weekly Planner.",
      "",
    ];

    for (const p of WEIGHTED_AGENT_PHASES) {
      lines.push(`## PHASE ${p.phaseNumber}: ${p.title} (Weight: ${p.weightPct}%)`);
      lines.push(`Code: ${p.code}`);
      lines.push(`Objective: ${p.objective}`);
      lines.push(`Target Files: ${p.targetFiles.join(", ")}`);
      lines.push(`Guardrails:\n${p.antiDriftGuardrails.map((g) => `- ${g}`).join("\n")}`);
      lines.push(`Prompt:\n${p.agentPromptToCopy}`);
      lines.push(`Verification:\n${p.verificationCommands.map((c) => `  $ ${c}`).join("\n")}`);
      lines.push("---\n");
    }

    return lines.join("\n");
  };

  const handleDownloadBlueprint = () => {
    const content = buildFullMasterPrompt();
    const blob = new Blob([content], { type: "text/markdown;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "KONKUR_MIMO_LEARNHARNESS_MASTER_BLUEPRINT.md";
    a.click();
    URL.revokeObjectURL(url);
  };

  const cycleStatus = async (phaseNumber: number) => {
    const current = statusByNumber.get(phaseNumber) ?? "ready";
    const next: "completed" | "in_progress" | "ready" =
      current === "ready"
        ? "in_progress"
        : current === "in_progress"
          ? "completed"
          : "ready";
    setUpdatingPhase(phaseNumber);
    try {
      await onPhaseStatusChange(phaseNumber, next);
    } finally {
      setUpdatingPhase(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Executive Hero Banner */}
      <div className="bg-white border-2 border-[#1A1C1A] rounded-2xl p-6 shadow-[4px_4px_0px_#1A1C1A]">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-5 border-b border-[#E2E3DF]">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#001551] text-white text-xs font-semibold mb-2">
              <Sparkles className="w-3.5 h-3.5" />
              <span>گزارش مهندسی ارشد و نقشه گمشده گنج (Master Software Blueprint)</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-[#1A1C1A] tracking-tight">
              معماری جامع «کنکور-میمو × لرن‌هارنس» + پلی‌بوک ۱۰ مرحله‌ای ایجنت
            </h1>
            <p className="text-sm text-[#46464B] mt-2 leading-relaxed max-w-4xl">
              ما تمام <strong>۱۹ ریپوزیتوری گیت‌هاب شما (`danmillman008-hub`)</strong> را کالبدشکافی کردیم: از موتور{" "}
              <code className="bg-[#F4F4F0] px-1.5 py-0.5 rounded text-xs font-mono">newlearning (Gramophone M1–M8)</code> و آزمایشگاه ۱۷ نسخه‌ای{" "}
              <code className="bg-[#F4F4F0] px-1.5 py-0.5 rounded text-xs font-mono">my-first (Learnly + ARCHIVE_FORENSICS)</code> تا طراحی‌های{" "}
              <code className="bg-[#F4F4F0] px-1.5 py-0.5 rounded text-xs font-mono">moshavere-va-azmoon (Swiss Konkur Planner)</code> و دفترچه‌های کنکور{" "}
              <code className="bg-[#F4F4F0] px-1.5 py-0.5 rounded text-xs font-mono">ensani / reshte / books</code>. در اینجا هم <strong>نقشه راه مرحله‌به‌مرحله با پرامپت‌های آماده کپی برای ایجنت</strong> و هم <strong>محصول نهایی کارکردی</strong> در اختیار شماست.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <button
              onClick={() => handleCopy("master-all", buildFullMasterPrompt())}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#1A1C1A] hover:bg-[#001551] text-white text-xs sm:text-sm font-bold transition cursor-pointer shadow-sm"
            >
              {copiedKey === "master-all" ? (
                <>
                  <Check className="w-4 h-4 text-emerald-400" />
                  <span>کل نقشه گنج کپی شد!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  <span>کپی کل مگا-پرامپت ۱۰ مرحله‌ای برای ایجنت</span>
                </>
              )}
            </button>

            <button
              onClick={handleDownloadBlueprint}
              className="inline-flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-[#F4F4F0] hover:bg-[#E8E8E4] text-[#1A1C1A] border border-[#1A1C1A] text-xs sm:text-sm font-bold transition cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>دانلود فایل .MD</span>
            </button>

            <button
              onClick={onJumpToMimoPlayer}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#059669] hover:bg-[#047857] text-white text-xs sm:text-sm font-bold transition cursor-pointer shadow-sm"
            >
              <Play className="w-4 h-4" />
              <span>اجرای زنده پلیر میمو × لرن‌هارنس</span>
            </button>
          </div>
        </div>

        {/* Weighted Execution Progress Meter */}
        <div className="mt-5 grid grid-cols-1 md:grid-cols-4 gap-4 items-center">
          <div className="md:col-span-3">
            <div className="flex items-center justify-between text-xs font-bold mb-1.5">
              <span className="text-[#1A1C1A]">
                پیشرفت وزنی اجرای نقشه راه ایجنت (کل وزن مراحـل = ۱۰۰٪):
              </span>
              <span className="font-mono text-sm text-[#001551]">
                {completedWeight}% / 100%
              </span>
            </div>
            <div className="w-full h-3.5 bg-[#E8E8E4] rounded-full overflow-hidden border border-[#1A1C1A]/20 flex">
              {WEIGHTED_AGENT_PHASES.map((p) => {
                const st = statusByNumber.get(p.phaseNumber) ?? "ready";
                const bg =
                  st === "completed"
                    ? "bg-[#059669]"
                    : st === "in_progress"
                      ? "bg-[#D97706]"
                      : "bg-transparent";
                return (
                  <div
                    key={p.phaseNumber}
                    style={{ width: `${p.weightPct}%` }}
                    title={`فاز ${p.phaseNumber}: ${p.weightPct}% (${st})`}
                    className={`h-full ${bg} border-l border-white/40 transition-all duration-300`}
                  />
                );
              })}
            </div>
            <p className="text-[11px] text-[#46464B] mt-1.5">
              نکته: روی دکمه وضعیت هر فاز کلیک کنید تا بین «آماده اجرا»، «در حال اجرا توسط ایجنت» و «تکمیل‌شده» تغییر کند و در دیتابیس ذخیره شود.
            </p>
          </div>

          <div className="bg-[#FAF9F5] border border-[#C7C6CB] rounded-xl p-3 flex items-center justify-around text-center">
            <div>
              <div className="text-lg font-extrabold font-mono text-[#1A1C1A]">19</div>
              <div className="text-[11px] text-[#46464B]">ریپوی بررسی‌شده شما</div>
            </div>
            <div className="h-8 w-px bg-[#C7C6CB]" />
            <div>
              <div className="text-lg font-extrabold font-mono text-[#001551]">10</div>
              <div className="text-[11px] text-[#46464B]">فاز وزن‌دار ایجنت</div>
            </div>
            <div className="h-8 w-px bg-[#C7C6CB]" />
            <div>
              <div className="text-lg font-extrabold font-mono text-[#BC000A]">6</div>
              <div className="text-[11px] text-[#46464B]">ارتقای الگوریتمی</div>
            </div>
          </div>
        </div>
      </div>

      {/* Sub-navigation Pills */}
      <div className="flex flex-wrap gap-2">
        <button
          onClick={() => setActiveSubTab("roadmap")}
          className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold border transition cursor-pointer ${
            activeSubTab === "roadmap"
              ? "bg-[#1A1C1A] text-white border-[#1A1C1A]"
              : "bg-white text-[#1A1C1A] border-[#C7C6CB] hover:bg-[#F4F4F0]"
          }`}
        >
          <Terminal className="w-4 h-4" />
          <span>۱. برنامه ۱۰ مرحله‌ای وزن‌دار ایجنت (پرامپت‌های گام‌به‌گام)</span>
        </button>

        <button
          onClick={() => setActiveSubTab("forensics")}
          className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold border transition cursor-pointer ${
            activeSubTab === "forensics"
              ? "bg-[#1A1C1A] text-white border-[#1A1C1A]"
              : "bg-white text-[#1A1C1A] border-[#C7C6CB] hover:bg-[#F4F4F0]"
          }`}
        >
          <GitBranch className="w-4 h-4" />
          <span>۲. کالبدشکافی ۱۹ ریپوی گیت‌هاب شما (نقاط قوت و باگ‌های کشف‌شده)</span>
        </button>

        <button
          onClick={() => setActiveSubTab("repos")}
          className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold border transition cursor-pointer ${
            activeSubTab === "repos"
              ? "bg-[#1A1C1A] text-white border-[#1A1C1A]"
              : "bg-white text-[#1A1C1A] border-[#C7C6CB] hover:bg-[#F4F4F0]"
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>۳. ریپوزیتوری‌های متن‌باز اینترنت و معماری ۵ لایه</span>
        </button>

        <button
          onClick={() => setActiveSubTab("upgrades")}
          className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold border transition cursor-pointer ${
            activeSubTab === "upgrades"
              ? "bg-[#BC000A] text-white border-[#BC000A]"
              : "bg-white text-[#BC000A] border-[#BC000A]/40 hover:bg-[#FFF5F5]"
          }`}
        >
          <Cpu className="w-4 h-4" />
          <span>۴. پیشنهادهای ارتقای الگوریتمی نسل بعد (ویژه کنکور)</span>
        </button>
      </div>

      {/* SUBTAB 1: 10 WEIGHTED AGENT PHASES */}
      {activeSubTab === "roadmap" && (
        <div className="space-y-4">
          {WEIGHTED_AGENT_PHASES.map((phase) => {
            const st = statusByNumber.get(phase.phaseNumber) ?? "ready";
            const copyId = `phase-${phase.phaseNumber}`;
            return (
              <div
                key={phase.phaseNumber}
                className="bg-white border-2 border-[#1A1C1A] rounded-2xl p-5 shadow-[3px_3px_0px_#1A1C1A]"
              >
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 pb-4 border-b border-[#E2E3DF]">
                  <div className="flex items-start gap-3">
                    <div className="w-11 h-11 rounded-xl bg-[#001551] text-white font-mono font-bold flex flex-col items-center justify-center shrink-0">
                      <span className="text-[10px] opacity-75">PHASE</span>
                      <span className="text-base leading-none">{phase.phaseNumber}</span>
                    </div>
                    <div>
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-mono text-xs px-2 py-0.5 rounded bg-[#F4F4F0] border border-[#C7C6CB] text-[#1A1C1A]">
                          {phase.code}
                        </span>
                        <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-[#001551]/10 text-[#001551]">
                          وزن مرحله: {phase.weightPct}% از کل پروژه
                        </span>
                        <span className="text-xs text-[#46464B]">
                          ⏱ {phase.estimatedAgentTurns}
                        </span>
                      </div>
                      <h3 className="text-lg font-extrabold text-[#1A1C1A] mt-1">
                        {phase.title}
                      </h3>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 shrink-0">
                    <button
                      onClick={() => cycleStatus(phase.phaseNumber)}
                      disabled={updatingPhase === phase.phaseNumber}
                      className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold border transition cursor-pointer ${
                        st === "completed"
                          ? "bg-emerald-50 text-emerald-800 border-emerald-600"
                          : st === "in_progress"
                            ? "bg-amber-50 text-amber-800 border-amber-600"
                            : "bg-[#F4F4F0] text-[#46464B] border-[#C7C6CB]"
                      }`}
                    >
                      {st === "completed" ? (
                        <>
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                          <span>تکمیل‌شده (کلیک برای تغییر)</span>
                        </>
                      ) : st === "in_progress" ? (
                        <>
                          <Clock className="w-3.5 h-3.5 text-amber-600" />
                          <span>در حال اجرا توسط ایجنت</span>
                        </>
                      ) : (
                        <>
                          <CircleDot className="w-3.5 h-3.5" />
                          <span>آماده اجرا</span>
                        </>
                      )}
                    </button>

                    <button
                      onClick={() => handleCopy(copyId, phase.agentPromptToCopy)}
                      className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-[#1A1C1A] hover:bg-[#001551] text-white text-xs font-bold transition cursor-pointer"
                    >
                      {copiedKey === copyId ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          <span>پرامپت فاز {phase.phaseNumber} کپی شد!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>کپی پرامپت اختصاصی فاز {phase.phaseNumber}</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>

                <p className="text-sm text-[#1A1C1A] mt-3 leading-relaxed">
                  <strong>هدف معماری:</strong> {phase.objective}
                </p>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mt-4">
                  <div className="bg-[#FAF9F5] border border-[#C7C6CB] rounded-xl p-3.5">
                    <div className="text-xs font-extrabold text-[#001551] mb-2 flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>خروجی‌های الزامی این مرحله (Deliverables):</span>
                    </div>
                    <ul className="space-y-1.5 text-xs text-[#1A1C1A] list-disc list-inside leading-relaxed">
                      {phase.deliverables.map((d, i) => (
                        <li key={i}>{d}</li>
                      ))}
                    </ul>
                    <div className="mt-3 pt-2 border-t border-[#E2E3DF] flex flex-wrap gap-1.5 items-center">
                      <span className="text-[11px] font-bold text-[#46464B]">فایل‌های هدف:</span>
                      {phase.targetFiles.map((tf) => (
                        <code
                          key={tf}
                          dir="ltr"
                          className="text-[11px] font-mono bg-white px-2 py-0.5 rounded border border-[#C7C6CB]"
                        >
                          {tf}
                        </code>
                      ))}
                    </div>
                  </div>

                  <div className="bg-[#FFF5F5] border border-[#BC000A]/30 rounded-xl p-3.5">
                    <div className="text-xs font-extrabold text-[#BC000A] mb-2 flex items-center gap-1.5">
                      <ShieldAlert className="w-4 h-4" />
                      <span>خط قرمزهای جلوگیری از انحراف ایجنت (Anti-Drift Guardrails):</span>
                    </div>
                    <ul className="space-y-1.5 text-xs text-[#1A1C1A] list-disc list-inside leading-relaxed">
                      {phase.antiDriftGuardrails.map((g, i) => (
                        <li key={i}>{g}</li>
                      ))}
                    </ul>
                    <div className="mt-3 pt-2 border-t border-[#BC000A]/20">
                      <span className="text-[11px] font-bold text-[#BC000A] block mb-1">
                        دستورات دروازه تایید (Verification Gate):
                      </span>
                      <div dir="ltr" className="space-y-1">
                        {phase.verificationCommands.map((cmd, idx) => (
                          <code
                            key={idx}
                            className="block text-[11px] font-mono bg-[#1A1C1A] text-emerald-300 px-2.5 py-1 rounded"
                          >
                            $ {cmd}
                          </code>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Copyable Prompt Box */}
                <div className="mt-4 bg-[#1A1C1A] text-[#F1F1ED] rounded-xl p-3.5">
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-[11px] font-mono text-amber-300">
                      PROMPT FOR AI CODING AGENT (PHASE {phase.phaseNumber})
                    </span>
                    <button
                      onClick={() => handleCopy(copyId, phase.agentPromptToCopy)}
                      className="text-[11px] text-emerald-300 hover:underline font-mono cursor-pointer"
                    >
                      {copiedKey === copyId ? "✓ Copied" : "Copy Prompt"}
                    </button>
                  </div>
                  <pre
                    dir="ltr"
                    className="text-xs font-mono whitespace-pre-wrap leading-relaxed text-slate-200 overflow-x-auto"
                  >
                    {phase.agentPromptToCopy}
                  </pre>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* SUBTAB 2: FORENSIC AUDIT OF USER'S 19 GITHUB REPOS */}
      {activeSubTab === "forensics" && (
        <div className="space-y-4">
          <div className="bg-[#001551] text-white rounded-2xl p-5">
            <h2 className="text-lg font-extrabold flex items-center gap-2">
              <BookOpen className="w-5 h-5" />
              <span>کالبدشکافی مهندسی ۱۹ ریپوزیتوری شما در GitHub (`danmillman008-hub`)</span>
            </h2>
            <p className="text-xs sm:text-sm text-blue-100 mt-1.5 leading-relaxed">
              برخلاف تصور اولیه‌تان که فکر می‌کردید تلاش‌هایتان ناقص یا بی‌نتیجه بوده، بررسی عمیق کدهای شما نشان داد که شما <strong>عمیق‌ترین مفاهیم علوم شناختی و مهندسی یادگیری (KST، BKT، FSRS، LearnHarness و آزمایشگاه ۱۸ پرسونای ایجنت تطبیقی)</strong> را در ریپوهای مختلف خودتان گردآوری و آزمایش کرده‌اید! جدول زیر نشان می‌دهد در هر ریپوی شما چه گنجی نهفته بود، چه باگ‌هایی مانع نتیجه‌گیری شده بود و چطور همه آن‌ها را به هم بافتیم:
            </p>
          </div>

          {USER_REPO_FORENSICS.map((item, idx) => (
            <div
              key={idx}
              className="bg-white border-2 border-[#1A1C1A] rounded-2xl p-5 shadow-[3px_3px_0px_#1A1C1A]"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-[#E2E3DF]">
                <h3 className="text-base sm:text-lg font-extrabold text-[#1A1C1A] font-mono" dir="ltr">
                  {item.repoName}
                </h3>
                <a
                  href={item.githubUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs font-bold text-[#001551] hover:underline"
                >
                  <span>مشاهده ریپو در گیت‌هاب</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>

              <p className="text-xs sm:text-sm text-[#46464B] mt-3 leading-relaxed">
                <strong className="text-[#1A1C1A]">محتویات کشف‌شده:</strong> {item.discoveredAssets}
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                <div className="bg-emerald-50/70 border border-emerald-600/30 rounded-xl p-3.5">
                  <div className="text-xs font-extrabold text-emerald-900 mb-2">
                    ✓ نقاط قوت طلایی که حفظ و منتقل کردیم:
                  </div>
                  <ul className="space-y-1.5 text-xs text-emerald-950 list-disc list-inside leading-relaxed">
                    {item.strengthsToKeep.map((s, i) => (
                      <li key={i}>{s}</li>
                    ))}
                  </ul>
                </div>

                <div className="bg-rose-50/70 border border-rose-600/30 rounded-xl p-3.5">
                  <div className="text-xs font-extrabold text-rose-900 mb-2">
                    ⚠ گلوگاه‌ها و باگ‌هایی که مانع نتیجه گرفتن شما شده بود:
                  </div>
                  <ul className="space-y-1.5 text-xs text-rose-950 list-disc list-inside leading-relaxed">
                    {item.criticalGapsFound.map((g, i) => (
                      <li key={i}>{g}</li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="mt-3 bg-[#FAF9F5] border border-[#1A1C1A] rounded-xl p-3 text-xs text-[#1A1C1A] leading-relaxed">
                <strong>نحوه بافتن این رشته در معماری نهایی:</strong> {item.howWeWeaveIt}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* SUBTAB 3: EXTERNAL OPEN-SOURCE REPOS MATRIX */}
      {activeSubTab === "repos" && (
        <div className="space-y-5">
          <div className="bg-white border-2 border-[#1A1C1A] rounded-2xl p-5 shadow-[3px_3px_0px_#1A1C1A]">
            <h2 className="text-lg font-extrabold text-[#1A1C1A] mb-3">
              ماتریس ریپوزیتوری‌ها و ابزارهای متن‌باز مورد نیاز از اینترنت
            </h2>
            <div className="overflow-x-auto">
              <table className="w-full text-right border-collapse text-xs">
                <thead>
                  <tr className="bg-[#1A1C1A] text-white">
                    <th className="p-3 rounded-tr-xl">ریپوزیتوری / پکیج</th>
                    <th className="p-3">حوزه</th>
                    <th className="p-3">اولویت</th>
                    <th className="p-3">نقش در پلتفرم کنکور-میمو × لرن‌هارنس</th>
                    <th className="p-3 rounded-tl-xl">الگوی اتصال توسط ایجنت</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E2E3DF]">
                  {OPEN_SOURCE_REPOS_MATRIX.map((r, i) => (
                    <tr key={i} className="hover:bg-[#FAF9F5]">
                      <td className="p-3 font-mono font-bold text-[#001551]" dir="ltr">
                        <a
                          href={r.url}
                          target="_blank"
                          rel="noreferrer"
                          className="hover:underline inline-flex items-center gap-1"
                        >
                          <span>{r.name}</span>
                          <ExternalLink className="w-3 h-3" />
                        </a>
                        <div className="text-[10px] text-[#46464B] font-normal mt-0.5">
                          License: {r.license}
                        </div>
                      </td>
                      <td className="p-3 font-semibold text-[#1A1C1A]">{r.category}</td>
                      <td className="p-3">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[11px] font-bold ${
                            r.priority.includes("حیاتی")
                              ? "bg-[#BC000A]/10 text-[#BC000A]"
                              : r.priority.includes("مکمل")
                                ? "bg-[#001551]/10 text-[#001551]"
                                : "bg-slate-200 text-slate-700"
                          }`}
                        >
                          {r.priority}
                        </span>
                      </td>
                      <td className="p-3 text-[#1A1C1A] leading-relaxed max-w-xs">
                        {r.roleInKonkurMimo}
                      </td>
                      <td className="p-3 text-[#46464B] leading-relaxed max-w-xs">
                        {r.integrationPattern}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* 5-Layer Architecture Diagram */}
          <div className="bg-[#1A1C1A] text-white rounded-2xl p-5 shadow-[3px_3px_0px_#001551]">
            <h3 className="text-base font-extrabold text-amber-300 mb-3">
              دیاگرام معماری ۵ لایه نرم‌افزار (Software & Pedagogical Stack)
            </h3>
            <pre
              dir="ltr"
              className="text-xs font-mono text-emerald-300 overflow-x-auto leading-relaxed"
            >{`┌──────────────────────────────────────────────────────────────────────────────────┐
│ LAYER 5: SWISS KONKUR EDITORIAL UI × MIMO INTERACTIVE LESSON PLAYER (Next.js 16) │
│  • Mimo Micro-Step Player (Probe, Unconditional Truth, Fill-Blank, Ordering, MCQ)│
│  • Konkur 300-Bubble Optical Sheet + Timer + Swiss Weekly Study Planner          │
├──────────────────────────────────────────────────────────────────────────────────┤
│ LAYER 4: LEARNHARNESS COGNITIVE HARNESS (amosblomqvist/learnharness Architecture)│
│  • Phase 1 [PROBE]: Binary-search strand floor/ceiling + Confidence + ThinkAloud │
│  • Phase 2 [PLAN] : Minimal Mermaid Dependency DAG from Unconditional Truths     │
│  • Phase 3 [TEACH]: Principle i (Axioms) + Principle ii (Discovery) + Checks     │
│  • Phase 4 [PRACTICE]: Inactive Proposition Retrieval + Hint Ladder + Solution   │
├──────────────────────────────────────────────────────────────────────────────────┤
│ LAYER 3: HYBRID EPISTEMIC MEMORY ENGINE (my-first DECISIONS.md + ts-fsrs v5)     │
│  • Calibrated BKT (Aided vs Unaided guardrails — aided cannot mark Mastered)     │
│  • FSRS-5 Stability (S), Difficulty (D), Retrievability (R) + Massed Cap         │
│  • Gramophone Flow-Band Controller holding rolling accuracy inside 70%–85%       │
├──────────────────────────────────────────────────────────────────────────────────┤
│ LAYER 2: KNOWLEDGE SPACE THEORY (KST) & KONKUR DESIGNER TRAP TOPOLOGY            │
│  • Birkhoff Ideal States + Outer Fringe (Ready to Learn) + Inner Fringe (Review) │
│  • Distractor Trap Mapping: Wrong option -> Specific Konkur Designer Trap        │
├──────────────────────────────────────────────────────────────────────────────────┤
│ LAYER 1: TEXTBOOK & JOZVE COMPILER (Gramophone M1–M6 with F1–F8 Fixes Applied)   │
│  • Raw Persian Textbook / Jozve -> Propositions + DAG + Mimo Interactive Quests  │
└──────────────────────────────────────────────────────────────────────────────────┘`}</pre>
          </div>
        </div>
      )}

      {/* SUBTAB 4: 6 ALGORITHMIC UPGRADES */}
      {activeSubTab === "upgrades" && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {ALGORITHMIC_UPGRADES.map((up) => (
            <div
              key={up.id}
              className="bg-white border-2 border-[#1A1C1A] rounded-2xl p-5 shadow-[3px_3px_0px_#1A1C1A] flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-[#BC000A]/10 text-[#BC000A]">
                    {up.badge}
                  </span>
                  <span className="font-mono text-[11px] text-[#46464B]">{up.id}</span>
                </div>
                <h3 className="text-base font-extrabold text-[#1A1C1A]">{up.title}</h3>
                <p className="text-[11px] font-mono text-[#001551] mt-1" dir="ltr">
                  Basis: {up.scientificBasis}
                </p>

                <div className="mt-3 space-y-2 text-xs leading-relaxed">
                  <p className="text-[#46464B]">
                    <strong className="text-[#1A1C1A]">مسئله‌ای که حل می‌کند:</strong>{" "}
                    {up.problemSolved}
                  </p>
                  <div className="bg-[#FAF9F5] border border-[#C7C6CB] rounded-xl p-2.5">
                    <strong className="text-[#001551] block mb-1">مدل ریاضی و الگوریتمی:</strong>
                    <p className="text-[#1A1C1A]">{up.mathematicalFormulation}</p>
                  </div>
                </div>
              </div>

              <div className="mt-3 pt-3 border-t border-[#E2E3DF] text-xs text-[#1A1C1A]">
                <strong className="text-[#059669]">راهنمای پیاده‌سازی برای ایجنت:</strong>{" "}
                {up.agentImplementationHint}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
