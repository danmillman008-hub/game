"use client";

import React, { useState } from "react";
import {
  AlertOctagon,
  ArrowLeft,
  BookOpen,
  CheckCircle2,
  Cpu,
  FileText,
  Layers,
  Play,
  ShieldCheck,
  Sparkles,
  Wand2,
} from "lucide-react";
import type {
  AgentCompilationLog,
  KonkurCourse,
} from "@/db/schema";
import type { CompiledLessonArtifact } from "@/lib/pedagogy-engine";

type PresetSample = {
  id: string;
  subject: string;
  grade: string;
  topicTitle: string;
  chapterReference: string;
  rawTextbookExcerpt: string;
};

type Props = {
  courses: KonkurCourse[];
  presets: PresetSample[];
  logs: AgentCompilationLog[];
  onCompiledAndSaved: (newLessonId: number | null) => Promise<void>;
};

export function AgentCompilerStudio({
  courses,
  presets,
  logs,
  onCompiledAndSaved,
}: Props) {
  const [subject, setSubject] = useState("زیست‌شناسی");
  const [grade, setGrade] = useState("دوازدهم تجربی");
  const [topicTitle, setTopicTitle] = useState(
    "تنظیم بیان ژن در پروکاریوت‌ها: اپران لک (lac)",
  );
  const [chapterReference, setChapterReference] = useState(
    "زیست‌شناسی دوازدهم - فصل ۲ (جریان اطلاعات در یاخته) - گفتار ۳",
  );
  const [rawTextbookExcerpt, setRawTextbookExcerpt] = useState(
    "در باکتری اشریشیاکلای، زمانی که لاکتوز در محیط وجود ندارد، پروتئین مهارکننده به بخش اپراتور متصل می‌شود و مانع حرکت RNA پلی‌مراز و رونویسی ژن‌های ساختاری می‌گردد. هرگاه لاکتوز در محیط حضور داشته باشد، لاکتوز به اللولاکتوز تبدیل شده و به عنوان عامل تنظیم‌کننده به مهارکننده متصل می‌شود؛ در نتیجه شکل فضایی مهارکننده تغییر کرده، از اپراتور جدا می‌شود و مسیر برای رونویسی سه ژن ساختاری توسط یک نوع RNA پلی‌مراز باز می‌گردد.",
  );
  const [simulateNaive, setSimulateNaive] = useState(true);
  const [compiling, setCompiling] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<{
    compiled: CompiledLessonArtifact;
    createdLessonId: number | null;
  } | null>(null);

  function loadPreset(preset: PresetSample) {
    setSubject(preset.subject);
    setGrade(preset.grade);
    setTopicTitle(preset.topicTitle);
    setChapterReference(preset.chapterReference);
    setRawTextbookExcerpt(preset.rawTextbookExcerpt);
    setError(null);
  }

  async function handleRunCompiler(e: React.FormEvent) {
    e.preventDefault();
    setCompiling(true);
    setError(null);
    try {
      const matchedCourse = courses.find((c) =>
        c.subject.includes(subject.slice(0, 4)),
      );
      const res = await fetch("/api/konkur/compile", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          subject,
          grade,
          topicTitle,
          chapterReference,
          rawTextbookExcerpt,
          courseId: matchedCourse?.id ?? courses[0]?.id,
          saveToDatabase: true,
          simulateNaiveAgentFirst: simulateNaive,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "خطا در اجرای کامپایلر پداگوژیک");
      } else {
        setResult({
          compiled: data.compiled,
          createdLessonId: data.createdLessonId,
        });
        await onCompiledAndSaved(data.createdLessonId);
      }
    } catch {
      setError("خطا در ارتباط با سرور کامپایلر ایجنت");
    } finally {
      setCompiling(false);
    }
  }

  return (
    <div className="space-y-6">
      {/* Top Explanation Banner */}
      <div className="rounded-3xl border border-indigo-500/30 bg-gradient-to-r from-indigo-950/60 via-slate-900 to-emerald-950/40 p-6 shadow-xl">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="max-w-3xl space-y-2">
            <div className="inline-flex items-center gap-2 rounded-full border border-indigo-400/40 bg-indigo-500/15 px-3 py-1 text-xs font-extrabold text-indigo-300">
              <Cpu className="h-3.5 w-3.5" />
              <span>موتور کامپایلر ۵ مرحله‌ای کتاب کنکور به میمو (Agent Pedagogical Compiler)</span>
            </div>
            <h2 className="text-xl font-black text-white">
              چگونه ایجنت را مجبور می‌کنیم هر کتاب کنکور را بدون افت کیفیت به سیستم میمو تبدیل کند؟
            </h2>
            <p className="text-xs leading-7 text-slate-300">
              در این استودیو، هر پاراگراف از کتاب درسی یا کمک‌درسی کنکور (زیست، فیزیک، شیمی، ریاضی، فلسفه و منطق) را وارد کنید. الگوریتم به جای «فرم‌پرکنی سطحی»، ابتدا <strong>گراف مفاهیم اتمی</strong>، <strong>قیدهای حساس</strong> و <strong>تله‌های طراح کنکور</strong> را استخراج می‌کند، سپس <strong>حلقه مفقوده (معادل گام Code و Debug میمو)</strong> را می‌سازد و پس از عبور از <strong>گاردریل ۱۰ شاخصه (عیار ≥ ۸۵)</strong> درسنامه را در دیتابیس ذخیره می‌کند.
            </p>
          </div>
          <div className="rounded-2xl border border-emerald-500/30 bg-slate-950/80 p-4 text-center">
            <div className="text-[11px] font-bold text-slate-400">
              شرط انتشار گاردریل (Hard Gate)
            </div>
            <div className="mt-1 text-2xl font-black text-emerald-400">
              ≥ 85 / 100
            </div>
            <div className="mt-0.5 text-[10px] text-slate-400">
              + صفر خطای بحرانی (۰ Critical)
            </div>
          </div>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-12">
        {/* Input Form Column (5 cols) */}
        <form
          onSubmit={handleRunCompiler}
          className="space-y-4 rounded-3xl border border-slate-800 bg-slate-900/90 p-5 shadow-xl lg:col-span-5"
        >
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <BookOpen className="h-5 w-5 text-indigo-400" />
              <h3 className="text-sm font-black text-white">
                ورودی متن کتاب کنکور برای ایجنت
              </h3>
            </div>
            <span className="text-[11px] text-slate-400">
              آماده دریافت هر مبحث
            </span>
          </div>

          {/* Preset Quick Loaders */}
          <div>
            <div className="mb-1.5 text-[11px] font-bold text-slate-400">
              نمونه متون استاندارد کتاب درسی (کلیک برای جایگذاری سریع):
            </div>
            <div className="grid grid-cols-2 gap-1.5">
              {presets.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => loadPreset(p)}
                  className="rounded-xl border border-slate-700/80 bg-slate-950/80 px-2.5 py-2 text-right text-[11px] font-bold text-slate-300 transition hover:border-indigo-400 hover:text-white"
                >
                  📚 {p.subject}: {p.topicTitle.slice(0, 26)}...
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="mb-1 block text-xs font-bold text-slate-300">
                درس کنکور
              </label>
              <select
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 text-xs font-bold text-white"
              >
                <option value="زیست‌شناسی">🧬 زیست‌شناسی</option>
                <option value="فیزیک">⚡ فیزیک</option>
                <option value="شیمی">🧪 شیمی</option>
                <option value="ریاضیات">📐 ریاضی و حسابان</option>
                <option value="فلسفه و منطق">🏛️ فلسفه، منطق و ادبیات</option>
              </select>
            </div>
            <div>
              <label className="mb-1 block text-xs font-bold text-slate-300">
                پایه و رشته
              </label>
              <input
                value={grade}
                onChange={(e) => setGrade(e.target.value)}
                className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 text-xs font-bold text-white"
              />
            </div>
          </div>

          <div>
            <label className="mb-1 block text-xs font-bold text-slate-300">
              عنوان دقیق مبحث (Topic Title)
            </label>
            <input
              required
              value={topicTitle}
              onChange={(e) => setTopicTitle(e.target.value)}
              className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 text-xs font-bold text-white"
            />
          </div>

          <div>
            <label className="mb-1 block text-xs font-bold text-slate-300">
              آدرس فصل و گفتار کتاب درسی
            </label>
            <input
              required
              value={chapterReference}
              onChange={(e) => setChapterReference(e.target.value)}
              className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 text-xs text-slate-300"
            />
          </div>

          <div>
            <label className="mb-1 block text-xs font-bold text-slate-300">
              متن خام کتاب درسی یا جزوه کنکور (Raw Textbook Input)
            </label>
            <textarea
              required
              rows={6}
              value={rawTextbookExcerpt}
              onChange={(e) => setRawTextbookExcerpt(e.target.value)}
              className="w-full rounded-2xl border border-slate-700 bg-slate-950 p-3 text-xs leading-7 text-slate-200"
              placeholder="متن کتاب درسی را اینجا وارد کنید..."
            />
          </div>

          <label className="flex cursor-pointer items-start gap-2.5 rounded-2xl border border-amber-500/30 bg-amber-950/20 p-3 text-xs">
            <input
              type="checkbox"
              checked={simulateNaive}
              onChange={(e) => setSimulateNaive(e.target.checked)}
              className="mt-1 h-4 w-4 accent-amber-400"
            />
            <div>
              <div className="font-extrabold text-amber-300">
                شبیه‌سازی برخورد گاردریل با «ایجنت فرم‌پرکن خام» (Before & After)
              </div>
              <div className="mt-0.5 text-[11px] leading-5 text-slate-400">
                نشان می‌دهد اگر ایجنت بخواهد فرم قدیمی میمو را با دیوار متنی و بدون گام هم‌ریخت Code پر کند چطور رد می‌شود و الگوریتم چطور آن را به عیار ۱۰۰/۱۰۰ تعمیر می‌کند.
              </div>
            </div>
          </label>

          {error && (
            <div className="rounded-xl border border-rose-500/40 bg-rose-950/50 p-3 text-xs text-rose-200">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={compiling}
            className="flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-indigo-500 to-emerald-500 px-5 py-3.5 text-xs font-black text-slate-950 shadow-lg transition hover:opacity-95 disabled:opacity-50"
          >
            <Wand2 className="h-4 w-4" />
            <span>
              {compiling
                ? "در حال اجرای الگوریتم ۵ مرحله‌ای و محاسبه عیار..."
                : "اجرای الگوریتم پداگوژیک ایجنت + ساخت درسنامه میمو"}
            </span>
          </button>
        </form>

        {/* Compilation Output & Pipeline Visualizer Column (7 cols) */}
        <div className="space-y-4 lg:col-span-7">
          {!result ? (
            <div className="space-y-4 rounded-3xl border border-slate-800 bg-slate-900/90 p-6">
              <h3 className="text-sm font-black text-white">
                تاریخچه آخرین کامپایل‌های الگوریتمی ایجنت در دیتابیس (PostgreSQL Audit Log)
              </h3>
              <p className="text-xs leading-6 text-slate-400">
                روی دکمه «اجرای الگوریتم پداگوژیک ایجنت» در ستون سمت راست کلیک کنید تا مراحل استخراج گراف مفهومی، کشف قیدها، ساخت گام‌های هم‌ریخت میمو و کارنامه ۱۰ شاخصه را به صورت زنده ببینید.
              </p>
              <div className="space-y-2.5">
                {logs.map((log) => (
                  <div
                    key={log.id}
                    className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-slate-800 bg-slate-950/80 p-3.5 text-xs"
                  >
                    <div>
                      <div className="font-extrabold text-white">
                        {log.subject} — {log.topicTitle}
                      </div>
                      <div className="mt-1 text-[11px] text-slate-400">
                        عیار اولیه ایجنت خام:{" "}
                        <span className="font-bold text-rose-400">
                          {log.initialScore}/100
                        </span>{" "}
                        ← پس از الگوریتم گاردریل:{" "}
                        <span className="font-bold text-emerald-400">
                          {log.finalScore}/100
                        </span>
                      </div>
                    </div>
                    <span className="rounded-xl border border-emerald-500/40 bg-emerald-500/15 px-3 py-1 font-black text-emerald-300">
                      {log.auditSnapshot.gradeBadge}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              {/* Stage 0: Naive Agent Blocked vs Guardrail Repaired */}
              {result.compiled.initialNaiveAudit && (
                <div className="rounded-3xl border border-rose-500/30 bg-slate-900 p-5 shadow-xl">
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
                    <div className="flex items-center gap-2 text-rose-400">
                      <AlertOctagon className="h-5 w-5" />
                      <h3 className="text-sm font-black">
                        مرحله کنترل گاردریل: چرا فرم‌پرکنی معمولی ایجنت رد شد؟
                      </h3>
                    </div>
                    <div className="flex items-center gap-2 text-xs font-black">
                      <span className="rounded-lg bg-rose-500/20 px-2.5 py-1 text-rose-300">
                        ایجنت خام: {result.compiled.initialNaiveAudit.overallScore}/100 (مسدود شده)
                      </span>
                      <span>⬅</span>
                      <span className="rounded-lg bg-emerald-500/20 px-2.5 py-1 text-emerald-300">
                        پس از کامپایلر الگوریتمی: {result.compiled.finalAudit.overallScore}/100
                      </span>
                    </div>
                  </div>

                  <div className="mt-3 space-y-2">
                    {result.compiled.autoRepairLog.map((entry, idx) => (
                      <div
                        key={idx}
                        className="rounded-xl border border-slate-800 bg-slate-950/80 px-3.5 py-2 text-xs leading-6 text-slate-300"
                      >
                        🔧 {entry}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Stage 1 & 2: Extracted Blueprint */}
              <div className="rounded-3xl border border-slate-800 bg-slate-900 p-5 shadow-xl">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div className="flex items-center gap-2">
                    <Layers className="h-5 w-5 text-indigo-400" />
                    <h3 className="text-sm font-black text-white">
                      خروجی مرحله ۱ و ۲ الگوریتم: گراف مفاهیم اتمی و تله‌های استخراج‌شده
                    </h3>
                  </div>
                  <span className="text-xs font-bold text-indigo-300">
                    {result.compiled.pedagogicalBlueprint.atomicConcepts.length} گره اتمی
                  </span>
                </div>

                <div className="mt-3 grid gap-2.5 sm:grid-cols-2">
                  {result.compiled.pedagogicalBlueprint.atomicConcepts.map(
                    (node) => (
                      <div
                        key={node.id}
                        className="rounded-2xl border border-slate-800 bg-slate-950/80 p-3 text-xs"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-black text-emerald-300">
                            {node.id}
                          </span>
                          <span className="rounded bg-indigo-500/20 px-2 py-0.5 text-[10px] font-bold text-indigo-300">
                            مکانیک هدف: {node.targetMechanic}
                          </span>
                        </div>
                        <div className="mt-1 font-bold text-white">
                          {node.title}
                        </div>
                        <div className="mt-1 text-[11px] text-slate-400">
                          «{node.textbookQuote}»
                        </div>
                      </div>
                    ),
                  )}
                </div>
              </div>

              {/* Stage 3 & 4: The 6 Compiled Mimo-Konkur Steps */}
              <div className="rounded-3xl border border-slate-800 bg-slate-900 p-5 shadow-xl">
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
                  <div className="flex items-center gap-2">
                    <Sparkles className="h-5 w-5 text-emerald-400" />
                    <h3 className="text-sm font-black text-white">
                      خروجی مرحله ۳ و ۴: زنجیره ۶ گامی میمو-کنکور با شیب داربست ۱ تا ۶
                    </h3>
                  </div>
                  {result.createdLessonId && (
                    <button
                      type="button"
                      onClick={() => onCompiledAndSaved(result.createdLessonId)}
                      className="flex items-center gap-1.5 rounded-xl bg-emerald-500 px-3.5 py-2 text-xs font-black text-slate-950 hover:bg-emerald-400"
                    >
                      <Play className="h-3.5 w-3.5" />
                      <span>اجرای زنده در پلیر میمو-کنکور</span>
                    </button>
                  )}
                </div>

                <div className="mt-3 space-y-2.5">
                  {result.compiled.steps.map((s, idx) => (
                    <div
                      key={idx}
                      className="rounded-2xl border border-slate-800 bg-slate-950/80 p-3.5 text-xs"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <span className="font-black text-white">
                          گام {idx + 1}: نوع `{s.type}` (سطح داربست {s.scaffoldingLevel}/6)
                        </span>
                        <span className="rounded bg-slate-800 px-2 py-0.5 text-[10px] text-emerald-300">
                          متصل به گره: {s.conceptNodeId}
                        </span>
                      </div>
                      <div className="mt-1.5 text-slate-300">
                        {s.content.kind === "concept_bite" && s.content.bodyMarkdown}
                        {s.content.kind === "guided_cloze" &&
                          `الگوی قیددار: ${s.content.templateWithBlank} (پاسخ: ${s.content.correctAnswer})`}
                        {s.content.kind === "token_assembly" &&
                          `چیدمان ${s.content.orderedTokens.length} بلوک ترتیبی + ${s.content.distractorTokens.length} بلوک تله طراح`}
                        {s.content.kind === "trap_detector" &&
                          `دیباگر کنکوری روی ۴ قطعه — قطعه معیوب: شماره ${s.content.flawedSegmentIndex + 1} (${s.content.trapCategory})`}
                        {s.content.kind === "step_solver" &&
                          `حل پله‌ای در ${s.content.subSteps.length} زیرگام هدایت‌شده`}
                        {s.content.kind === "konkur_test" &&
                          `تست ۴ گزینه‌ای: ${s.content.questionStem} + کالبدشکافی ۴ گزینه`}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Stage 5: 10-Metric Quality Audit Report Card */}
              <div className="rounded-3xl border border-emerald-500/40 bg-slate-900 p-5 shadow-xl">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="h-5 w-5 text-emerald-400" />
                    <h3 className="text-sm font-black text-white">
                      خروجی مرحله ۵: کارنامه عیارسنج ۱۰ شاخصه پداگوژیک
                    </h3>
                  </div>
                  <span className="rounded-xl bg-emerald-500/20 px-3 py-1 text-xs font-black text-emerald-300">
                    عیار نهایی: {result.compiled.finalAudit.overallScore}/100 ({result.compiled.finalAudit.gradeBadge})
                  </span>
                </div>

                <div className="mt-3 grid gap-2 sm:grid-cols-2">
                  {result.compiled.finalAudit.metrics.map((m) => (
                    <div
                      key={m.id}
                      className="rounded-xl border border-slate-800 bg-slate-950/90 p-3 text-xs"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-white">{m.label}</span>
                        <span className="font-black text-emerald-400">
                          {m.score}/{m.maxScore}
                        </span>
                      </div>
                      <div className="mt-1 text-[11px] text-slate-400">
                        {m.diagnosticNote}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
