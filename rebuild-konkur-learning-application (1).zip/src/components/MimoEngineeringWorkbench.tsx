"use client";

import React, { useState } from "react";
import {
  normalise,
  gradeValidatedInput,
  VectorTestResult,
  CORRECT,
  PARTIAL,
} from "@/lib/mimo/engine";
import runtimeEvidenceRaw from "@/lib/mimo/data/runtime-evidence.json";

interface LessonProgressRow {
  lessonId: number;
  completedAt: number;
  startedAt: number;
  tries: number;
  tutorialId: number;
  tutorialVersion: number;
  trackId: number;
  publishSetVersion: number;
  attempts: number;
  isPracticeProgress: number;
  inQueue: number;
}

interface TelemetryRow {
  id: number;
  category: string;
  sourceClass: string;
  operation: string;
  payload: Record<string, unknown>;
  evidenceCode: string;
  createdAt: number;
}

interface MimoEngineeringWorkbenchProps {
  apkIdentity: {
    package: string;
    versionName: string;
    versionCode: number;
    publishSetVersion: number;
    apkSha256: string;
    roomMaster: { id: number; identityHash: string };
  };
  roomTables: {
    lessonProgress: LessonProgressRow[];
    tutorialCompletions: Array<{
      tutorialId: number;
      trackId: number;
      isCompleted: number;
      updatedAt: number;
    }>;
    chapterCompletions: Array<{
      chapterId: number;
      trackId: number;
      tutorialId: number;
      createdAt: number;
    }>;
  };
  economyCounters: {
    totalRows: number;
    pendingInQueue: number;
    solvedCount: number;
    firstTryCount: number;
    answersInChapter: { answeredCorrectly: number; answeredTotal: number };
    localCoinsCache: number;
  };
  verification: {
    total: number;
    passed: number;
    failed: number;
    results: VectorTestResult[];
  };
  telemetry: TelemetryRow[];
  nightMode: boolean;
  onSyncOutbox: () => Promise<void>;
  onColdStartSql: () => Promise<void>;
  onClearAllTables: () => Promise<void>;
  onLoadSnapshot: (snapshotName: string) => Promise<void>;
}

const SNAPSHOTS = runtimeEvidenceRaw.sqliteSnapshots;

const RESOLVED_ENDPOINTS = [
  { verb: "POST", path: "/v1/tutorials/{tutorialId}/progress", cls: "LessonProgressApi.java", note: "Uploads 9-field Progress DTO list from in_queue=1 outbox" },
  { verb: "GET", path: "/v1/tracks/{trackId}/completion", cls: "CompletionApi.java", note: "Populates tutorial_completions & chapter_completions" },
  { verb: "GET", path: "/v1/tracks/{trackId}/eta", cls: "TrackEtaApi.java", note: "Projected track completion ETA" },
  { verb: "GET", path: "/v1/tracks/completion/lastInteracted", cls: "CompletionApi.java", note: "Last interacted track resume" },
  { verb: "POST", path: "/v1/code/runfiles", cls: "hg/c.java", note: "CodePlaygroundExecutionBody -> stdout/errors" },
  { verb: "GET", path: "/v1/code", cls: "mh/c.java", note: "List<SavedCode> user playgrounds" },
  { verb: "POST", path: "/v1/code", cls: "mh/c.java", note: "SaveCodeRequestBody -> SavedCode" },
  { verb: "PATCH", path: "/v1/code/{savedCodeId}", cls: "mh/c.java", note: "M09 verb-resolved (@n = PATCH)" },
  { verb: "POST", path: "/v1/aiTutor/conversations", cls: "jg/a.java (SSE)", note: "Accept: text/event-stream, {{{ ... }}} fenced prompt" },
  { verb: "GET", path: "/v1/aiTutor/conversations/messages/count", cls: "jg/a.java", note: "Freemium 5-message quota counter" },
  { verb: "GET", path: "/v1/leaderboards/latest", cls: "ch/a.java", note: "5 Leagues weekly XP standings" },
  { verb: "GET", path: "/v1/user/coins", cls: "qg/a.java", note: "Server coin balance (local_coins=200 cache)" },
  { verb: "GET", path: "/v1/user/keys", cls: "bh/a.java", note: "UserKeys daily key balance" },
  { verb: "POST", path: "/v1/user/keys/consume", cls: "bh/a.java", note: "Consumes 1 key on chapter unlock" },
  { verb: "GET", path: "/v1/user/rewards/next", cls: "lh/a.java", note: "Chapter-end reward chest payload" },
  { verb: "POST", path: "/v1/user/rewards/{rewardId}/confirm", cls: "lh/a.java", note: "Confirms opened reward chest" },
  { verb: "GET", path: "/v1/user/settings", cls: "kf/a.java", note: "User settings & dailySparksGoal" },
  { verb: "PATCH", path: "/v1/user/settings", cls: "kf/a.java", note: "M09 verb-resolved (@n = PATCH)" },
  { verb: "POST", path: "/v1/products/user", cls: "nh/c.java", note: "Mimo Store purchase (useCoins=true)" },
  { verb: "GET", path: "/v1/tracks/{trackId}/certificates", cls: "og/a.java", note: "Course completion certificate PDF/view" },
];

export function MimoEngineeringWorkbench({
  apkIdentity,
  roomTables,
  economyCounters,
  verification,
  telemetry,
  nightMode,
  onSyncOutbox,
  onColdStartSql,
  onClearAllTables,
  onLoadSnapshot,
}: MimoEngineeringWorkbenchProps) {
  const [activeTab, setActiveTab] = useState<
    "room_db" | "vectors" | "telemetry" | "audit"
  >("room_db");
  const [selectedSnapshot, setSelectedSnapshot] = useState<string>(
    "S5_1_F_AFTER_CORRECT_SUBMIT"
  );
  const [testUserStr, setTestUserStr] = useState<string>("hello  world");
  const [testExpectedStr, setTestExpectedStr] = useState<string>("Hello World");
  const [busy, setBusy] = useState<boolean>(false);

  const liveNormUser = normalise(testUserStr);
  const liveNormExpected = normalise(testExpectedStr);
  const liveVerdict = gradeValidatedInput(testUserStr, testExpectedStr);

  return (
    <div
      className={`rounded-3xl border overflow-hidden flex flex-col h-[780px] shadow-xl ${
        nightMode
          ? "bg-[#1D1F32] border-[#3F4273] text-white"
          : "bg-white border-[#E4E6F1] text-[#252746]"
      }`}
    >
      {/* Top Header */}
      <div
        className={`px-4 py-3 border-b flex flex-wrap items-center justify-between gap-2 ${
          nightMode ? "bg-[#252746] border-[#3F4273]" : "bg-[#F6F7FB] border-[#E4E6F1]"
        }`}
      >
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#66BC5A] animate-pulse" />
            <span className="font-extrabold text-sm">
              Mimo 9.35 Runtime &amp; Evidence Workbench
            </span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-[#7E4BDE]/15 text-[#7E4BDE] font-bold">
              APK v{apkIdentity.versionName} ({apkIdentity.versionCode}) · v{apkIdentity.publishSetVersion}
            </span>
          </div>
          <div className="text-[11px] opacity-65 font-mono mt-0.5">
            mimo.db v2 hash: {apkIdentity.roomMaster.identityHash} · Vectors: {verification.passed}/{verification.total} PASS
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div
        className={`grid grid-cols-4 border-b text-xs font-bold ${
          nightMode ? "bg-[#252746] border-[#3F4273]" : "bg-[#F6F7FB] border-[#E4E6F1]"
        }`}
      >
        <button
          type="button"
          onClick={() => setActiveTab("room_db")}
          className={`py-2.5 px-2 border-b-2 transition ${
            activeTab === "room_db"
              ? "border-[#7E4BDE] text-[#7E4BDE] bg-[#7E4BDE]/10"
              : "border-transparent opacity-70 hover:opacity-100"
          }`}
        >
          1. mimo.db (Room v2)
        </button>
        <button
          type="button"
          onClick={() => setActiveTab("vectors")}
          className={`py-2.5 px-2 border-b-2 transition ${
            activeTab === "vectors"
              ? "border-[#7E4BDE] text-[#7E4BDE] bg-[#7E4BDE]/10"
              : "border-transparent opacity-70 hover:opacity-100"
          }`}
        >
          2. Grading &amp; Vectors ({verification.passed}/{verification.total})
        </button>
        <button
          type="button"
          onClick={() => setActiveTab("telemetry")}
          className={`py-2.5 px-2 border-b-2 transition ${
            activeTab === "telemetry"
              ? "border-[#7E4BDE] text-[#7E4BDE] bg-[#7E4BDE]/10"
              : "border-transparent opacity-70 hover:opacity-100"
          }`}
        >
          3. Live SQL &amp; /v1/* API
        </button>
        <button
          type="button"
          onClick={() => setActiveTab("audit")}
          className={`py-2.5 px-2 border-b-2 transition ${
            activeTab === "audit"
              ? "border-[#7E4BDE] text-[#7E4BDE] bg-[#7E4BDE]/10"
              : "border-transparent opacity-70 hover:opacity-100"
          }`}
        >
          4. Evidence Audit
        </button>
      </div>

      {/* Tab Body */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs">
        {/* === TAB 1: ROOM DB & SNAPSHOTS === */}
        {activeTab === "room_db" && (
          <div className="space-y-4">
            {/* F1-F12 Economy & Derived Metrics Strip */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              <div
                className={`p-3 rounded-2xl border ${
                  nightMode ? "bg-[#252746] border-[#3F4273]" : "bg-[#F6F7FB] border-[#E4E6F1]"
                }`}
              >
                <div className="text-[10px] font-mono opacity-65">F1: isSolvedCorrectly</div>
                <div className="text-lg font-extrabold text-[#66BC5A] mt-0.5">
                  {economyCounters.solvedCount} / {economyCounters.totalRows}
                </div>
                <div className="text-[10px] opacity-60">tries &gt;= 1</div>
              </div>
              <div
                className={`p-3 rounded-2xl border ${
                  nightMode ? "bg-[#252746] border-[#3F4273]" : "bg-[#F6F7FB] border-[#E4E6F1]"
                }`}
              >
                <div className="text-[10px] font-mono opacity-65">F2/F3: AnswersInChapter</div>
                <div className="text-lg font-extrabold text-[#7E4BDE] mt-0.5">
                  {economyCounters.answersInChapter.answeredCorrectly} /{" "}
                  {economyCounters.answersInChapter.answeredTotal}
                </div>
                <div className="text-[10px] opacity-60">Pending in_queue=1</div>
              </div>
              <div
                className={`p-3 rounded-2xl border ${
                  nightMode ? "bg-[#252746] border-[#3F4273]" : "bg-[#F6F7FB] border-[#E4E6F1]"
                }`}
              >
                <div className="text-[10px] font-mono opacity-65">F5: firstTryCount</div>
                <div className="text-lg font-extrabold text-[#3890FA] mt-0.5">
                  {economyCounters.firstTryCount}
                </div>
                <div className="text-[10px] opacity-60">tries&gt;=1 &amp;&amp; attempts==1</div>
              </div>
              <div
                className={`p-3 rounded-2xl border ${
                  nightMode ? "bg-[#252746] border-[#3F4273]" : "bg-[#F6F7FB] border-[#E4E6F1]"
                }`}
              >
                <div className="text-[10px] font-mono opacity-65">F11: mimo_prefs.xml</div>
                <div className="text-lg font-extrabold text-[#F1C325] mt-0.5">
                  {economyCounters.localCoinsCache}
                </div>
                <div className="text-[10px] opacity-60">local_coins cache</div>
              </div>
            </div>

            {/* Outbox & Cold-Start SQL Controls */}
            <div
              className={`p-3.5 rounded-2xl border space-y-2.5 ${
                nightMode ? "bg-[#252746] border-[#3F4273]" : "bg-[#F6F7FB] border-[#E4E6F1]"
              }`}
            >
              <div className="font-bold flex items-center justify-between">
                <span>Room DAO (cg/a) &amp; Outbox Sync Controls</span>
                <span className="font-mono text-[10px] opacity-70">
                  PK(lesson_id, tutorial_id) · C-16 Verified
                </span>
              </div>
              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  disabled={busy}
                  onClick={async () => {
                    setBusy(true);
                    try {
                      await onSyncOutbox();
                    } finally {
                      setBusy(false);
                    }
                  }}
                  className="px-3 py-1.5 rounded-xl bg-[#7E4BDE] text-white font-bold hover:brightness-105 transition"
                >
                  ⬆ Sync Outbox (POST /v1/tutorials/&#123;id&#125;/progress)
                </button>
                <button
                  type="button"
                  disabled={busy}
                  onClick={async () => {
                    setBusy(true);
                    try {
                      await onColdStartSql();
                    } finally {
                      setBusy(false);
                    }
                  }}
                  className="px-3 py-1.5 rounded-xl bg-[#F05A6E]/15 text-[#F05A6E] border border-[#F05A6E]/30 font-bold hover:bg-[#F05A6E]/25 transition"
                  title="Executes M07/M09 observed cold-start SQL: DELETE FROM lesson_progress WHERE in_queue = 1"
                >
                  ⚡ Cold Start SQL (DELETE WHERE in_queue=1)
                </button>
                <button
                  type="button"
                  disabled={busy}
                  onClick={async () => {
                    setBusy(true);
                    try {
                      await onClearAllTables();
                    } finally {
                      setBusy(false);
                    }
                  }}
                  className="px-3 py-1.5 rounded-xl bg-black/10 font-bold hover:bg-black/20 transition"
                >
                  🗑 Database_Impl.clearAllTables()
                </button>
              </div>
            </div>

            {/* Load Real Captured M07 Emulator SQLite Snapshots */}
            <div
              className={`p-3.5 rounded-2xl border space-y-2 ${
                nightMode ? "bg-[#252746] border-[#3F4273]" : "bg-[#F6F7FB] border-[#E4E6F1]"
              }`}
            >
              <div className="font-bold">
                Restore Captured Android Emulator SQLite Snapshot (MISSION 07 DB/*)
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <select
                  value={selectedSnapshot}
                  onChange={(e) => setSelectedSnapshot(e.target.value)}
                  className={`flex-1 min-w-[210px] px-3 py-1.5 rounded-xl font-mono text-xs border ${
                    nightMode
                      ? "bg-[#1D1F32] border-[#3F4273] text-white"
                      : "bg-white border-[#E4E6F1] text-[#252746]"
                  }`}
                >
                  {SNAPSHOTS.map((s) => (
                    <option key={s.snapshot} value={s.snapshot}>
                      {s.snapshot} (lesson_progress={s.lessonProgress.length}, tc={s.tutorialCompletionsCount})
                    </option>
                  ))}
                </select>
                <button
                  type="button"
                  disabled={busy}
                  onClick={async () => {
                    setBusy(true);
                    try {
                      await onLoadSnapshot(selectedSnapshot);
                    } finally {
                      setBusy(false);
                    }
                  }}
                  className="px-3.5 py-1.5 rounded-xl bg-[#3890FA] text-white font-bold hover:brightness-105 transition"
                >
                  Restore Snapshot into DB
                </button>
              </div>
            </div>

            {/* Table 1: lesson_progress (11 columns verbatim) */}
            <div className="space-y-1.5">
              <div className="font-bold flex items-center justify-between">
                <span>
                  Table <code>lesson_progress</code> ({roomTables.lessonProgress.length} rows)
                </span>
                <span className="font-mono text-[10px] opacity-65">
                  11 columns · PK(lesson_id, tutorial_id)
                </span>
              </div>
              <div className="overflow-x-auto rounded-2xl border border-current/15">
                <table className="w-full text-[11px] font-mono border-collapse">
                  <thead>
                    <tr className={nightMode ? "bg-[#252746]" : "bg-[#F6F7FB]"}>
                      <th className="p-2 text-left">lesson_id</th>
                      <th className="p-2 text-left">tutorial_id</th>
                      <th className="p-2 text-left">track_id</th>
                      <th className="p-2 text-left">tries</th>
                      <th className="p-2 text-left">attempts</th>
                      <th className="p-2 text-left">in_queue</th>
                      <th className="p-2 text-left">pub_ver</th>
                      <th className="p-2 text-left">completed_at</th>
                    </tr>
                  </thead>
                  <tbody>
                    {roomTables.lessonProgress.length === 0 ? (
                      <tr>
                        <td colSpan={8} className="p-4 text-center opacity-60">
                          No rows in lesson_progress (solve a lesson or restore a snapshot above)
                        </td>
                      </tr>
                    ) : (
                      roomTables.lessonProgress.map((r) => (
                        <tr
                          key={`${r.tutorialId}:${r.lessonId}`}
                          className="border-t border-current/10"
                        >
                          <td className="p-2 font-bold text-[#7E4BDE]">{r.lessonId}</td>
                          <td className="p-2">{r.tutorialId} (v{r.tutorialVersion})</td>
                          <td className="p-2">{r.trackId}</td>
                          <td className="p-2">
                            <span
                              className={`px-1.5 py-0.5 rounded font-bold ${
                                r.tries >= 1
                                  ? "bg-[#66BC5A]/20 text-[#66BC5A]"
                                  : "bg-[#F05A6E]/20 text-[#F05A6E]"
                              }`}
                            >
                              {r.tries} ({r.tries >= 1 ? "SOLVED" : "UNSOLVED"})
                            </span>
                          </td>
                          <td className="p-2">{r.attempts}</td>
                          <td className="p-2">
                            <span
                              className={`px-1.5 py-0.5 rounded ${
                                r.inQueue === 1
                                  ? "bg-[#F1C325]/25 text-[#D5A80E]"
                                  : "bg-current/10 opacity-70"
                              }`}
                            >
                              {r.inQueue}
                            </span>
                          </td>
                          <td className="p-2">{r.publishSetVersion}</td>
                          <td className="p-2 opacity-70">{r.completedAt}</td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Tables 2 & 3: tutorial_completions & chapter_completions */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div
                className={`p-3 rounded-2xl border ${
                  nightMode ? "bg-[#252746] border-[#3F4273]" : "bg-[#F6F7FB] border-[#E4E6F1]"
                }`}
              >
                <div className="font-bold font-mono text-[11px] mb-1">
                  tutorial_completions ({roomTables.tutorialCompletions.length} rows)
                </div>
                {roomTables.tutorialCompletions.length === 0 ? (
                  <div className="text-[11px] opacity-60">0 completed tutorials cached</div>
                ) : (
                  <div className="space-y-1 max-h-28 overflow-y-auto font-mono text-[11px]">
                    {roomTables.tutorialCompletions.map((tc) => (
                      <div key={`${tc.trackId}:${tc.tutorialId}`} className="flex justify-between">
                        <span>tutorial_id={tc.tutorialId} (track={tc.trackId})</span>
                        <span className="text-[#66BC5A] font-bold">is_completed={tc.isCompleted}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
              <div
                className={`p-3 rounded-2xl border ${
                  nightMode ? "bg-[#252746] border-[#3F4273]" : "bg-[#F6F7FB] border-[#E4E6F1]"
                }`}
              >
                <div className="font-bold font-mono text-[11px] mb-1">
                  chapter_completions ({roomTables.chapterCompletions.length} rows)
                </div>
                {roomTables.chapterCompletions.length === 0 ? (
                  <div className="text-[11px] opacity-60">0 completed chapters cached</div>
                ) : (
                  <div className="space-y-1 max-h-28 overflow-y-auto font-mono text-[11px]">
                    {roomTables.chapterCompletions.map((cc) => (
                      <div key={`${cc.trackId}:${cc.chapterId}`} className="flex justify-between">
                        <span>chapter_id={cc.chapterId}</span>
                        <span className="text-[#7E4BDE]">tutorial_id={cc.tutorialId}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* === TAB 2: BYTECODE GRADING & PROGRESS VECTORS === */}
        {activeTab === "vectors" && (
          <div className="space-y-4">
            {/* Live Interactive qm.i.a + qm.e/f/g Tester */}
            <div
              className={`p-3.5 rounded-2xl border space-y-3 ${
                nightMode ? "bg-[#252746] border-[#3F4273]" : "bg-[#F6F7FB] border-[#E4E6F1]"
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-extrabold">
                  Live Bytecode Grader Lab (<code>Lqm/i.a</code> + <code>qm.e/f/g</code>)
                </span>
                <span className="font-mono text-[10px] px-2 py-0.5 rounded bg-[#66BC5A]/20 text-[#66BC5A] font-bold">
                  VERIFIED_STATIC [HANDOFF/04 §2-§3]
                </span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-[10px] font-mono opacity-70 mb-1">
                    User Input (raw):
                  </label>
                  <input
                    type="text"
                    value={testUserStr}
                    onChange={(e) => setTestUserStr(e.target.value)}
                    className={`w-full px-3 py-1.5 rounded-xl font-mono text-xs border ${
                      nightMode
                        ? "bg-[#1D1F32] border-[#3F4273] text-white"
                        : "bg-white border-[#E4E6F1] text-[#252746]"
                    }`}
                  />
                  <div className="text-[10px] font-mono mt-1 opacity-75">
                    normalise(user) = <code className="text-[#3890FA]">&quot;{liveNormUser}&quot;</code>
                  </div>
                </div>
                <div>
                  <label className="block text-[10px] font-mono opacity-70 mb-1">
                    Expected Answer (raw):
                  </label>
                  <input
                    type="text"
                    value={testExpectedStr}
                    onChange={(e) => setTestExpectedStr(e.target.value)}
                    className={`w-full px-3 py-1.5 rounded-xl font-mono text-xs border ${
                      nightMode
                        ? "bg-[#1D1F32] border-[#3F4273] text-white"
                        : "bg-white border-[#E4E6F1] text-[#252746]"
                    }`}
                  />
                  <div className="text-[10px] font-mono mt-1 opacity-75">
                    normalise(expected) ={" "}
                    <code className="text-[#3890FA]">&quot;{liveNormExpected}&quot;</code>
                  </div>
                </div>
              </div>
              <div className="flex items-center justify-between pt-1 border-t border-current/10">
                <span className="text-[11px] opacity-80">
                  Keep punctuation: <code>&lt; &gt; ( ) : &#123; &#125; , .</code> · Drop spaces, quotes, <code>=</code>, <code>;</code>
                </span>
                <span
                  className={`px-3 py-1 rounded-xl font-mono font-extrabold text-xs ${
                    liveVerdict === CORRECT
                      ? "bg-[#66BC5A] text-white"
                      : liveVerdict === PARTIAL
                      ? "bg-[#F1C325] text-[#252746]"
                      : "bg-[#F05A6E] text-white"
                  }`}
                >
                  Verdict: {liveVerdict}
                </span>
              </div>
            </div>

            {/* All Vector Results Table */}
            <div className="space-y-1.5">
              <div className="font-bold flex items-center justify-between">
                <span>
                  Bytecode Acceptance Vectors (`grading_vectors.json` + `progress_vectors.json`)
                </span>
                <span className="text-[#66BC5A] font-extrabold">
                  {verification.passed} / {verification.total} PASSED (100%)
                </span>
              </div>
              <div className="overflow-x-auto rounded-2xl border border-current/15 max-h-[410px]">
                <table className="w-full text-[11px] font-mono border-collapse">
                  <thead>
                    <tr className={nightMode ? "bg-[#252746]" : "bg-[#F6F7FB]"}>
                      <th className="p-2 text-left">Category</th>
                      <th className="p-2 text-left">Test Vector</th>
                      <th className="p-2 text-left">Expected</th>
                      <th className="p-2 text-left">Actual</th>
                      <th className="p-2 text-left">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {verification.results.map((r) => (
                      <tr key={r.id} className="border-t border-current/10">
                        <td className="p-2 font-bold text-[#7E4BDE]">{r.category}</td>
                        <td className="p-2">{r.description}</td>
                        <td className="p-2 opacity-80">{JSON.stringify(r.expected)}</td>
                        <td className="p-2 opacity-80">{JSON.stringify(r.actual)}</td>
                        <td className="p-2">
                          <span
                            className={`px-2 py-0.5 rounded font-bold ${
                              r.passed
                                ? "bg-[#66BC5A]/20 text-[#66BC5A]"
                                : "bg-[#F05A6E]/20 text-[#F05A6E]"
                            }`}
                          >
                            {r.passed ? "PASS" : "FAIL"}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* === TAB 3: LIVE TELEMETRY & 53 RETROFIT ENDPOINTS === */}
        {activeTab === "telemetry" && (
          <div className="space-y-4">
            <div className="space-y-2">
              <div className="font-bold flex items-center justify-between">
                <span>Live Runtime Method &amp; Room SQL Trace</span>
                <span className="font-mono text-[10px] opacity-70">
                  {telemetry.length} recent events
                </span>
              </div>
              <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
                {telemetry.map((t) => (
                  <div
                    key={t.id}
                    className={`p-2.5 rounded-xl border font-mono text-[11px] space-y-1 ${
                      nightMode ? "bg-[#252746] border-[#3F4273]" : "bg-[#F6F7FB] border-[#E4E6F1]"
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-bold text-[#7E4BDE]">
                        [{t.category}] {t.sourceClass}
                      </span>
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#66BC5A]/15 text-[#66BC5A]">
                        {t.evidenceCode}
                      </span>
                    </div>
                    <div className="opacity-90 break-all">{t.operation}</div>
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-1.5">
              <div className="font-bold">
                M09 Bytecode-Resolved Retrofit API Surface (`Lge0/r0;-&gt;a @0xabb18`)
              </div>
              <div className="overflow-x-auto rounded-2xl border border-current/15 max-h-64">
                <table className="w-full text-[11px] font-mono border-collapse">
                  <thead>
                    <tr className={nightMode ? "bg-[#252746]" : "bg-[#F6F7FB]"}>
                      <th className="p-2 text-left">Verb</th>
                      <th className="p-2 text-left">Endpoint Path</th>
                      <th className="p-2 text-left">DEX Source</th>
                      <th className="p-2 text-left">Contract Role</th>
                    </tr>
                  </thead>
                  <tbody>
                    {RESOLVED_ENDPOINTS.map((ep, i) => (
                      <tr key={i} className="border-t border-current/10">
                        <td className="p-2">
                          <span
                            className={`px-1.5 py-0.5 rounded font-bold ${
                              ep.verb === "GET"
                                ? "bg-[#3890FA]/20 text-[#3890FA]"
                                : ep.verb === "POST"
                                ? "bg-[#66BC5A]/20 text-[#66BC5A]"
                                : "bg-[#F1C325]/25 text-[#D5A80E]"
                            }`}
                          >
                            {ep.verb}
                          </span>
                        </td>
                        <td className="p-2 font-bold">{ep.path}</td>
                        <td className="p-2 opacity-75">{ep.cls}</td>
                        <td className="p-2 opacity-80">{ep.note}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* === TAB 4: EVIDENCE RECOVERY & REPOSITORY AUDIT === */}
        {activeTab === "audit" && (
          <div className="space-y-3 leading-relaxed">
            <div
              className={`p-3.5 rounded-2xl border space-y-2 ${
                nightMode ? "bg-[#252746] border-[#3F4273]" : "bg-[#F6F7FB] border-[#E4E6F1]"
              }`}
            >
              <div className="font-extrabold text-sm text-[#7E4BDE]">
                Stage 1: Evidence Recovery &amp; Repository Audit (`danmillman008-hub/game.git`)
              </div>
              <p className="text-xs opacity-85">
                All 7 branches of the reference repository were audited and separated into authentic
                Mimo 9.35 reverse-engineering evidence versus unrelated artifacts:
              </p>
              <ul className="space-y-1.5 text-[11px] font-mono">
                <li className="flex items-start gap-2">
                  <span className="text-[#66BC5A] font-bold">✓ MIMO EVIDENCE:</span>
                  <span>
                    <code>origin/arena/aebb90b7-game</code> (<code>ANALYSIS/MISSION_05..09</code>,{" "}
                    <code>COMPLETE_CURRICULUM_GRAPH.json</code>, <code>mimo-ui/SOURCE/assets</code>,
                    26 runtime <code>mimo.db</code> snapshots, 94 ARSC vectors) &amp;{" "}
                    <code>origin/arena/ecb8af07-game</code> (<code>HANDOFF/01..15</code>,{" "}
                    <code>mimo-re/complete-extraction/00..17</code>, <code>grading_vectors.json</code>,{" "}
                    <code>progress_vectors.json</code>).
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-[#F05A6E] font-bold">✕ ISOLATED / HALTED:</span>
                  <span>
                    <code>ttac-4.3.6.apk</code> &amp; <code>origin/arena/dd2b6beb-game</code> (TTAC
                    project halted per instructions), <code>pharmacy-inventory (3).html</code>,{" "}
                    <code>Streets-of-Rage_Genesis_EN.zip</code>, and the Konkur Biology prototype
                    overlay (<code>v12.5-fa</code>) — excluded from this pure Mimo 9.35 original
                    reconstruction.
                  </span>
                </li>
              </ul>
            </div>

            <div
              className={`p-3.5 rounded-2xl border space-y-2 ${
                nightMode ? "bg-[#252746] border-[#3F4273]" : "bg-[#F6F7FB] border-[#E4E6F1]"
              }`}
            >
              <div className="font-extrabold text-sm text-[#66BC5A]">
                Stages 2–6: Complete Original Architecture &amp; Behavioral Parity Matrix
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
                <div className="p-2.5 rounded-xl bg-black/5">
                  <b>C1 ContentRepository:</b> Shipped <code>tracks.json</code> (v753), 19 Tracks,
                  144 Sections, 1,029 Tutorials, 1,947 Chapters, 18,272 Lessons.
                </div>
                <div className="p-2.5 rounded-xl bg-black/5">
                  <b>C2–C3 DSL &amp; Renderers:</b> <code>Lte/c.b</code> 27-tag HTML/XML DSL +{" "}
                  <code>gm.h.a</code> 9 interaction families + <code>lesson-webview.js</code> bridge.
                </div>
                <div className="p-2.5 rounded-xl bg-black/5">
                  <b>C4–C5 Grading &amp; Session:</b> <code>Lqm/i.a</code> normaliser, 3-way{" "}
                  <code>ValidatedInput</code> verdict, and <code>V/W/X/U</code> state machine.
                </div>
                <div className="p-2.5 rounded-xl bg-black/5">
                  <b>C6–C16 Persistence &amp; Fullstack:</b> Exact 3 Room tables +{" "}
                  <code>room_master_table</code> in PostgreSQL + <code>DeveloperMenuActivity</code>.
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
