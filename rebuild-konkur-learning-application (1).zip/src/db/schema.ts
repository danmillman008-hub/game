import {
  pgTable,
  serial,
  integer,
  text,
  boolean,
  bigint,
  real,
  timestamp,
  varchar,
  jsonb,
  primaryKey,
} from "drizzle-orm/pg-core";

// ============================================================================
// SUBSYSTEM 1: MIMO 9.35 KONKUR v12.5-fa CORE APPLICATION TABLES
// ============================================================================

export const lessonProgress = pgTable("lesson_progress", {
  id: serial("id").primaryKey(),
  lessonId: integer("lesson_id").notNull(),
  lessonIndex: integer("lesson_index").notNull().default(0),
  chapterId: integer("chapter_id").notNull(),
  tutorialId: integer("tutorial_id").notNull(),
  tutorialVersion: integer("tutorial_version").notNull().default(1),
  trackId: integer("track_id").notNull().default(1),
  tutorialTitle: text("tutorial_title").notNull().default(""),
  courseKey: text("course_key").notNull().default("bio12"),
  tries: integer("tries").notNull().default(0),
  attempts: integer("attempts").notNull().default(1),
  isPracticeProgress: boolean("is_practice_progress").notNull().default(false),
  inQueue: boolean("in_queue").notNull().default(true),
  publishSetVersion: integer("publish_set_version").notNull().default(753),
  startedAt: bigint("started_at", { mode: "number" }).notNull(),
  completedAt: bigint("completed_at", { mode: "number" }).notNull(),
});

export const mistakeQueue = pgTable("mistake_queue", {
  id: serial("id").primaryKey(),
  questionKey: text("question_key").notNull(),
  topicId: text("topic_id").notNull().default(""),
  subject: text("subject").notNull().default(""),
  difficulty: text("difficulty").notNull().default("medium"),
  userChoice: integer("user_choice"),
  correctIndex: integer("correct_index").notNull().default(0),
  consecutiveCorrect: integer("consecutive_correct").notNull().default(0),
  resolved: boolean("resolved").notNull().default(false),
  createdAt: bigint("created_at", { mode: "number" }).notNull(),
});

export const examSessions = pgTable("exam_sessions", {
  id: serial("id").primaryKey(),
  examTitle: text("exam_title").notNull(),
  examKind: text("exam_kind").notNull().default("comprehensive"),
  status: text("status").notNull().default("completed_full"),
  questionCount: integer("question_count").notNull().default(20),
  correctCount: integer("correct_count").notNull().default(0),
  wrongCount: integer("wrong_count").notNull().default(0),
  blankCount: integer("blank_count").notNull().default(0),
  pctWithNeg: integer("pct_with_neg").notNull().default(0),
  pctNoNeg: integer("pct_no_neg").notNull().default(0),
  durationMinutes: integer("duration_minutes").notNull().default(270),
  remainingSeconds: integer("remaining_seconds").notNull().default(0),
  currentQuestionIndex: integer("current_question_index").notNull().default(0),
  answersJson: text("answers_json").notNull().default("{}"),
  checkedJson: text("checked_json").notNull().default("{}"),
  marksJson: text("marks_json").notNull().default("{}"),
  createdAt: bigint("created_at", { mode: "number" }).notNull(),
});

export const learnerProfile = pgTable("learner_profile", {
  id: serial("id").primaryKey(),
  profileKey: text("profile_key").notNull().default("default"),
  displayName: text("display_name").notNull().default("داوطلب کنکور تجربی"),
  isGuest: boolean("is_guest").notNull().default(false),
  selectionKind: text("selection_kind").notNull().default("course"),
  programKey: text("program_key").notNull().default("grade12"),
  courseKey: text("course_key").notNull().default("bio12"),
  activeChapterIdx: integer("active_chapter_idx").notNull().default(0),
  coins: integer("coins").notNull().default(1272),
  keysLabel: text("keys_label").notNull().default("∞"),
  streak: integer("streak").notNull().default(1),
  xp: integer("xp").notNull().default(480),
  weeklyXp: integer("weekly_xp").notNull().default(480),
  dailyGoalXp: integer("daily_goal_xp").notNull().default(50),
  nightMode: boolean("night_mode").notNull().default(false),
  completedNodesJson: text("completed_nodes_json")
    .notNull()
    .default('["bio12:c1:l1"]'),
  ledgerJson: text("ledger_json").notNull().default("[]"),
  aiSessionsJson: text("ai_sessions_json").notNull().default("[]"),
  updatedAt: bigint("updated_at", { mode: "number" }).notNull(),
});

// ============================================================================
// SUBSYSTEM 2: PEDAGOGICAL AI COMPILER & ENFORCED GUARDRAIL FORM (M1–M9)
// ============================================================================

export type StepKind =
  | "concept_bite"
  | "guided_cloze"
  | "token_assembly"
  | "trap_detector"
  | "step_solver"
  | "konkur_test";

export type AtomicConceptNode = {
  id: string;
  title: string;
  textbookQuote: string;
  cognitiveLevel: "remember" | "understand" | "apply" | "analyze";
  isPrerequisite: boolean;
  targetMechanic: StepKind;
};

export type PrerequisiteEdge = {
  fromId: string;
  toId: string;
  relation: string;
};

export type KonkurModifierItem = {
  id: string;
  phrase: string;
  category:
    | "قید کمّی (همه/برخی/اغلب)"
    | "فرمول و رابطه کلیدی"
    | "استثنای کتاب درسی"
    | "ترتیب و توالی مکانیزم";
  explanation: string;
};

export type DesignerTrapItem = {
  id: string;
  trapTitle: string;
  trapCategory:
    | "تله قیدی"
    | "تله تعمیم افراطی"
    | "تله تقدم و تاخر"
    | "تله واحد و علامت"
    | "تله خلط مفاهیم مشابه";
  commonWrongBelief: string;
  scientificTruth: string;
};

export type PedagogicalBlueprint = {
  atomicConcepts: AtomicConceptNode[];
  prerequisiteChain: PrerequisiteEdge[];
  konkurModifiersAndFormulas: KonkurModifierItem[];
  designerTraps: DesignerTrapItem[];
  missingLinkMapping: {
    mimoOriginalMechanic: string;
    konkurIsomorphicMechanic: string;
    bridgingRationale: string;
  };
};

export type QualityMetricItem = {
  id: string;
  label: string;
  score: number;
  maxScore: number;
  weight: number;
  status: "optimal" | "warning" | "violation";
  diagnosticNote: string;
  algorithmicFormula: string;
};

export type GuardrailViolation = {
  code: string;
  severity: "critical" | "warning";
  stepIndex?: number;
  field: string;
  message: string;
  autoFixInstruction: string;
};

export type QualityAuditReport = {
  overallScore: number;
  passedGate: boolean;
  gradeBadge:
    | "A+ (تراز میمو-سنجش)"
    | "A (استاندارد)"
    | "B (نیازمند بازبینی)"
    | "F (رد شده توسط گاردریل)";
  metrics: QualityMetricItem[];
  violations: GuardrailViolation[];
};

export type ConceptBiteStep = {
  kind: "concept_bite";
  title: string;
  hookAnalogy: string;
  bodyMarkdown: string;
  highlightedModifiers: string[];
  coreFormulaOrRule: string;
  interactiveCheckQuestion: string;
  interactiveCheckAnswer: boolean;
  interactiveCheckExplanation: string;
};

export type GuidedClozeStep = {
  kind: "guided_cloze";
  prompt: string;
  templateWithBlank: string;
  correctAnswer: string;
  chipOptions: string[];
  targetedModifierId: string;
  nudgeHint: string;
  deepExplanation: string;
};

export type TokenAssemblyStep = {
  kind: "token_assembly";
  prompt: string;
  assemblyMode:
    | "causal_chain"
    | "formula_derivation"
    | "stoichiometry_pipeline"
    | "syntactic_logic";
  orderedTokens: string[];
  distractorTokens: { token: string; trapReason: string }[];
  nudgeHint: string;
  assemblyExplanation: string;
};

export type TrapDetectorStep = {
  kind: "trap_detector";
  prompt: string;
  contextType: "statement_autopsy" | "math_solution_bug" | "chemistry_exception";
  segments: string[];
  flawedSegmentIndex: number;
  trapCategory: string;
  fixOptions: string[];
  correctFixIndex: number;
  diagnosticAutopsy: string;
};

export type StepSolverStep = {
  kind: "step_solver";
  problemStatement: string;
  subSteps: {
    stageLabel: string;
    question: string;
    options: string[];
    correctIndex: number;
    microFeedback: string;
  }[];
  finalTakeaway: string;
};

export type KonkurTestStep = {
  kind: "konkur_test";
  questionStem: string;
  sourceBadge: string;
  targetTimeSeconds: number;
  options: [string, string, string, string];
  correctIndex: number;
  optionDiagnostics: {
    optionIndex: number;
    isCorrect: boolean;
    trapOrMisconceptionLabel: string;
    detailedAnalysis: string;
  }[];
  eliminationShortcut: string;
};

export type KonkurStepContent =
  | ConceptBiteStep
  | GuidedClozeStep
  | TokenAssemblyStep
  | TrapDetectorStep
  | StepSolverStep
  | KonkurTestStep;

export const konkurCourses = pgTable("konkur_courses", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 160 }).notNull().unique(),
  title: varchar("title", { length: 220 }).notNull(),
  subject: varchar("subject", { length: 80 }).notNull(),
  grade: varchar("grade", { length: 60 }).notNull(),
  reshte: varchar("reshte", { length: 60 }).notNull(),
  icon: varchar("icon", { length: 16 }).notNull().default("🧬"),
  color: varchar("color", { length: 40 }).notNull().default("emerald"),
  tagline: varchar("tagline", { length: 320 }).notNull().default(""),
  description: text("description").notNull().default(""),
  position: integer("position").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const konkurLessons = pgTable("konkur_lessons", {
  id: serial("id").primaryKey(),
  courseId: integer("course_id")
    .notNull()
    .references(() => konkurCourses.id, { onDelete: "cascade" }),
  slug: varchar("slug", { length: 160 }).notNull().unique(),
  title: varchar("title", { length: 220 }).notNull(),
  chapterReference: varchar("chapter_reference", { length: 240 }).notNull(),
  rawTextbookExcerpt: text("raw_textbook_excerpt").notNull(),
  xpReward: integer("xp_reward").notNull().default(40),
  estimatedMinutes: integer("estimated_minutes").notNull().default(5),
  status: varchar("status", { length: 40 }).notNull().default("published"),
  pedagogicalBlueprint: jsonb("pedagogical_blueprint")
    .$type<PedagogicalBlueprint>()
    .notNull(),
  qualityAudit: jsonb("quality_audit").$type<QualityAuditReport>().notNull(),
  position: integer("position").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const konkurSteps = pgTable("konkur_steps", {
  id: serial("id").primaryKey(),
  lessonId: integer("lesson_id")
    .notNull()
    .references(() => konkurLessons.id, { onDelete: "cascade" }),
  position: integer("position").notNull().default(0),
  type: varchar("type", { length: 40 }).$type<StepKind>().notNull(),
  conceptNodeId: varchar("concept_node_id", { length: 64 }).notNull(),
  scaffoldingLevel: integer("scaffolding_level").notNull().default(1),
  cognitiveLoadWords: integer("cognitive_load_words").notNull().default(40),
  content: jsonb("content").$type<KonkurStepContent>().notNull(),
});

export const learnerProgress = pgTable("learner_progress", {
  id: serial("id").primaryKey(),
  stepId: integer("step_id")
    .notNull()
    .references(() => konkurSteps.id, { onDelete: "cascade" }),
  lessonId: integer("lesson_id")
    .notNull()
    .references(() => konkurLessons.id, { onDelete: "cascade" }),
  correctFirstTry: boolean("correct_first_try").notNull().default(true),
  attempts: integer("attempts").notNull().default(1),
  xpEarned: integer("xp_earned").notNull().default(10),
  completedAt: timestamp("completed_at").notNull().defaultNow(),
});

export const agentCompilationLogs = pgTable("agent_compilation_logs", {
  id: serial("id").primaryKey(),
  subject: varchar("subject", { length: 80 }).notNull(),
  topicTitle: varchar("topic_title", { length: 220 }).notNull(),
  rawExcerpt: text("raw_excerpt").notNull(),
  initialScore: integer("initial_score").notNull(),
  finalScore: integer("final_score").notNull(),
  passedGuardrail: boolean("passed_guardrail").notNull().default(true),
  violationsCount: integer("violations_count").notNull().default(0),
  autoRepaired: boolean("auto_repaired").notNull().default(false),
  createdLessonId: integer("created_lesson_id"),
  auditSnapshot: jsonb("audit_snapshot").$type<QualityAuditReport>().notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type KonkurCourse = typeof konkurCourses.$inferSelect;
export type KonkurLesson = typeof konkurLessons.$inferSelect;
export type KonkurStep = typeof konkurSteps.$inferSelect;
export type AgentCompilationLog = typeof agentCompilationLogs.$inferSelect;

// ============================================================================
// SUBSYSTEM 3: LEARNHARNESS ADAPTIVE MASTERY (BKT + KST + FSRS-5 + PLANNER)
// ============================================================================

export interface MimoBeatStep {
  id: string;
  phase: "probe" | "plan" | "teach" | "practice";
  kind:
    | "probe_diagnostic"
    | "unconditional_truth"
    | "predict_before_teach"
    | "fill_blank"
    | "check_mcq"
    | "ordering_chain"
    | "practice_problem";
  nodeSlug: string;
  title: string;
  principleBadge: string;
  contentMarkdown: string;
  formulaLatex?: string;
  promptQuestion: string;
  options?: {
    id: string;
    label: string;
    isTrap?: boolean;
    trapReason?: string;
  }[];
  correctAnswer: string;
  fillTemplate?: string;
  fillChoices?: string[];
  orderingItems?: string[];
  correctOrder?: string[];
  hints: string[];
  modelSolution: string;
  dokLevel: number;
}

export interface KonkurQuestionItem {
  id: string;
  number: number;
  subject: string;
  topic: string;
  linkedNodeSlug: string;
  sourceTag: string;
  stem: string;
  formula?: string;
  options: {
    index: 1 | 2 | 3 | 4;
    text: string;
  }[];
  correctOption: 1 | 2 | 3 | 4;
  trapOption: 1 | 2 | 3 | 4;
  trapName: string;
  trapExplanation: string;
  detailedSolution: string;
  idealTimeSec: number;
}

export interface ExamQuestionLog {
  questionId: string;
  number: number;
  selectedOption: 1 | 2 | 3 | 4 | null;
  correctOption: 1 | 2 | 3 | 4;
  status: "correct" | "wrong" | "blank";
  fellForTrap: boolean;
  flag: "none" | "doubt" | "time_consuming" | "trap_alert";
  linkedNodeSlug: string;
  errorCategory?:
    | "conceptual_gap"
    | "prerequisite_gap"
    | "designer_trap"
    | "careless_slip";
}

export const learnerProfiles = pgTable("learner_profiles", {
  id: serial("id").primaryKey(),
  fullName: text("full_name").notNull(),
  track: text("track").notNull().default("tajrobi"),
  gradeLevel: text("grade_level").notNull().default("دوازدهم / فارغ‌التحصیل"),
  targetRank: integer("target_rank").notNull().default(150),
  xp: integer("xp").notNull().default(1420),
  level: integer("level").notNull().default(7),
  streakDays: integer("streak_days").notNull().default(12),
  hearts: integer("hearts").notNull().default(5),
  maxHearts: integer("max_hearts").notNull().default(5),
  targetRetention: real("target_retention").notNull().default(0.85),
  flowBandAccuracy: real("flow_band_accuracy").notNull().default(0.78),
  forgettingScale: real("forgetting_scale").notNull().default(1.0),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const knowledgeNodes = pgTable("knowledge_nodes", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  track: text("track").notNull(),
  subject: text("subject").notNull(),
  chapter: text("chapter").notNull(),
  title: text("title").notNull(),
  unconditionalTruth: text("unconditional_truth").notNull(),
  discoveryMotivation: text("discovery_motivation").notNull(),
  commonTrap: text("common_trap").notNull(),
  nodeType: text("node_type").notNull().default("concept"),
  bloomLevel: text("bloom_level").notNull().default("Analyze"),
  dokLevel: integer("dok_level").notNull().default(2),
  prerequisites: jsonb("prerequisites").$type<string[]>().notNull().default([]),
  masteryP: real("mastery_p").notNull().default(0.25),
  stabilityDays: real("stability_days").notNull().default(1.5),
  difficulty: real("difficulty").notNull().default(5.2),
  retrievability: real("retrievability").notNull().default(0.88),
  kstState: text("kst_state").notNull().default("outer_fringe"),
  aidedSuccesses: integer("aided_successes").notNull().default(0),
  unaidedSuccesses: integer("unaided_successes").notNull().default(0),
  lapses: integer("lapses").notNull().default(0),
  lastReviewedAt: timestamp("last_reviewed_at").defaultNow().notNull(),
});

export const mimoLessons = pgTable("mimo_lessons", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  track: text("track").notNull(),
  subject: text("subject").notNull(),
  chapter: text("chapter").notNull(),
  title: text("title").notNull(),
  subtitle: text("subtitle").notNull(),
  estimatedMinutes: integer("estimated_minutes").notNull().default(8),
  xpReward: integer("xp_reward").notNull().default(60),
  konkurWeight: text("konkur_weight").notNull(),
  mermaidPlan: text("mermaid_plan").notNull(),
  beats: jsonb("beats").$type<MimoBeatStep[]>().notNull(),
  completedCount: integer("completed_count").notNull().default(0),
});

export const learningEvidence = pgTable("learning_evidence", {
  id: serial("id").primaryKey(),
  nodeSlug: text("node_slug").notNull(),
  lessonSlug: text("lesson_slug").notNull(),
  phase: text("phase").notNull(),
  stepKind: text("step_kind").notNull(),
  isCorrect: boolean("is_correct").notNull(),
  confidencePct: integer("confidence_pct").notNull().default(75),
  thinkingTrace: text("thinking_trace").notNull().default(""),
  supportUsed: text("support_used").notNull().default("unaided"),
  detectedTrap: text("detected_trap"),
  masteryBefore: real("mastery_before").notNull(),
  masteryAfter: real("mastery_after").notNull(),
  stabilityAfter: real("stability_after").notNull(),
  xapiVerb: text("xapi_verb").notNull().default("attempted"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const konkurExams = pgTable("konkur_exams", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  title: text("title").notNull(),
  organizer: text("organizer").notNull(),
  track: text("track").notNull(),
  durationMinutes: integer("duration_minutes").notNull().default(15),
  negativeMarkingRatio: integer("negative_marking_ratio").notNull().default(3),
  questions: jsonb("questions").$type<KonkurQuestionItem[]>().notNull(),
});

export const examSubmissions = pgTable("exam_submissions", {
  id: serial("id").primaryKey(),
  examSlug: text("exam_slug").notNull(),
  examTitle: text("exam_title").notNull(),
  organizer: text("organizer").notNull(),
  rawPercent: real("raw_percent").notNull(),
  withoutNegativePercent: real("without_negative_percent").notNull(),
  estimatedTaraz: integer("estimated_taraz").notNull(),
  correctCount: integer("correct_count").notNull(),
  wrongCount: integer("wrong_count").notNull(),
  blankCount: integer("blank_count").notNull(),
  trapFallCount: integer("trap_fall_count").notNull(),
  timeSpentSec: integer("time_spent_sec").notNull(),
  questionLogs: jsonb("question_logs").$type<ExamQuestionLog[]>().notNull(),
  remediationSlugs: jsonb("remediation_slugs").$type<string[]>().notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const weeklyStudyPlans = pgTable("weekly_study_plans", {
  id: serial("id").primaryKey(),
  dayOfWeek: text("day_of_week").notNull(),
  subject: text("subject").notNull(),
  topic: text("topic").notNull(),
  linkedNodeSlug: text("linked_node_slug").notNull(),
  studyType: text("study_type").notNull(),
  targetMinutes: integer("target_minutes").notNull().default(90),
  actualMinutes: integer("actual_minutes").notNull().default(0),
  targetTests: integer("target_tests").notNull().default(30),
  completedTests: integer("completed_tests").notNull().default(0),
  correctTests: integer("correct_tests").notNull().default(0),
  wrongTests: integer("wrong_tests").notNull().default(0),
  satisfaction: text("satisfaction").notNull().default("good"),
  advisorNote: text("advisor_note").notNull().default(""),
  isCompleted: boolean("is_completed").notNull().default(false),
});

export const blueprintPhases = pgTable("blueprint_phases", {
  id: serial("id").primaryKey(),
  phaseNumber: integer("phase_number").notNull().unique(),
  code: text("code").notNull(),
  title: text("title").notNull(),
  weightPct: integer("weight_pct").notNull(),
  status: text("status").notNull().default("ready"),
  customNotes: text("custom_notes").notNull().default(""),
});

// ============================================================================
// SUBSYSTEM 4: MIMO 9.35 ORIGINAL DEX / ROOM SQLITE RECONSTRUCTION
// ============================================================================

export interface DevOverridesConfig {
  unlockAll: boolean;
  unlimitedKeys: boolean;
  hardModeDefault: boolean;
  preserveOutboxOnColdStart: boolean;
  simulateOffline: boolean;
  fakeDiscountDrawer: boolean;
  fakeStreakSheet: boolean;
  fakeLeaderboardSheet: boolean;
  useUnpublishedTracksPackage: boolean;
}

export interface PlaygroundFileItem {
  name: string;
  codeLanguage: string;
  content: string;
  solvedContent?: string | null;
}

export interface AiChatMessageItem {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  finishReason?: "Stop" | "Length";
  timestamp: number;
}

export const roomMasterTable = pgTable("room_master_table", {
  id: integer("id").primaryKey(),
  identityHash: text("identity_hash").notNull(),
});

export const roomLessonProgress = pgTable(
  "room_lesson_progress",
  {
    lessonId: integer("lesson_id").notNull(),
    completedAt: bigint("completed_at", { mode: "number" }).notNull(),
    startedAt: bigint("started_at", { mode: "number" }).notNull(),
    tries: integer("tries").notNull(),
    tutorialId: integer("tutorial_id").notNull(),
    tutorialVersion: integer("tutorial_version").notNull(),
    trackId: integer("track_id").notNull(),
    publishSetVersion: integer("publish_set_version").notNull(),
    attempts: integer("attempts").notNull(),
    isPracticeProgress: integer("is_practice_progress").notNull(),
    inQueue: integer("in_queue").notNull(),
  },
  (table) => [
    primaryKey({
      name: "room_lesson_progress_pk",
      columns: [table.lessonId, table.tutorialId],
    }),
  ]
);

export const tutorialCompletions = pgTable(
  "tutorial_completions",
  {
    tutorialId: integer("tutorial_id").notNull(),
    isCompleted: integer("is_completed").notNull(),
    updatedAt: bigint("updated_at", { mode: "number" }).notNull(),
    trackId: integer("track_id").notNull(),
  },
  (table) => [
    primaryKey({
      name: "tutorial_completions_pk",
      columns: [table.tutorialId, table.trackId],
    }),
  ]
);

export const chapterCompletions = pgTable(
  "chapter_completions",
  {
    chapterId: integer("chapter_id").notNull(),
    createdAt: bigint("created_at", { mode: "number" }).notNull(),
    trackId: integer("track_id").notNull(),
    tutorialId: integer("tutorial_id").notNull(),
  },
  (table) => [
    primaryKey({
      name: "chapter_completions_pk",
      columns: [table.chapterId, table.trackId],
    }),
  ]
);

export const mimoUserState = pgTable("mimo_user_state", {
  id: integer("id").primaryKey(),
  displayName: text("display_name").notNull().default("Alex Rivera"),
  email: text("email").notNull().default("alex@getmimo.com"),
  isAnonymous: boolean("is_anonymous").notNull().default(false),
  subscriptionTier: text("subscription_tier").notNull().default("PRO"),
  coins: integer("coins").notNull().default(200),
  currentKeys: integer("current_keys").notNull().default(5),
  unlimitedKeys: boolean("unlimited_keys").notNull().default(true),
  sparksXp: integer("sparks_xp").notNull().default(480),
  dailySparks: integer("daily_sparks").notNull().default(30),
  dailySparksGoal: integer("daily_sparks_goal").notNull().default(50),
  streakDays: integer("streak_days").notNull().default(7),
  streakFreezeCount: integer("streak_freeze_count").notNull().default(2),
  streakChallengeActive: boolean("streak_challenge_active")
    .notNull()
    .default(false),
  streakChallengeDay: integer("streak_challenge_day").notNull().default(0),
  leagueTier: integer("league_tier").notNull().default(3),
  currentTrackId: integer("current_track_id").notNull().default(50),
  appearance: text("appearance").notNull().default("light"),
  uiLocale: text("ui_locale").notNull().default("en"),
  favoriteTracks: jsonb("favorite_tracks")
    .$type<number[]>()
    .notNull()
    .default([50, 219, 226, 125]),
  ownedItems: jsonb("owned_items")
    .$type<string[]>()
    .notNull()
    .default(["icon_default", "streak_freeze_1"]),
  devOverrides: jsonb("dev_overrides")
    .$type<DevOverridesConfig>()
    .notNull()
    .default({
      unlockAll: true,
      unlimitedKeys: true,
      hardModeDefault: false,
      preserveOutboxOnColdStart: true,
      simulateOffline: false,
      fakeDiscountDrawer: false,
      fakeStreakSheet: false,
      fakeLeaderboardSheet: false,
      useUnpublishedTracksPackage: false,
    }),
  updatedAt: bigint("updated_at", { mode: "number" }).notNull(),
});

export const mimoSavedCode = pgTable("mimo_saved_code", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  codeLanguage: text("code_language").notNull(),
  template: text("template").notNull(),
  trackId: integer("track_id"),
  tutorialId: integer("tutorial_id"),
  chapterId: integer("chapter_id"),
  lessonId: integer("lesson_id"),
  files: jsonb("files").$type<PlaygroundFileItem[]>().notNull(),
  lastOutput: text("last_output").notNull().default(""),
  updatedAt: bigint("updated_at", { mode: "number" }).notNull(),
});

export const mimoAiConversations = pgTable("mimo_ai_conversations", {
  id: serial("id").primaryKey(),
  lessonId: integer("lesson_id").notNull(),
  tutorialId: integer("tutorial_id").notNull(),
  mode: text("mode").notNull(),
  systemMessage: jsonb("system_message").notNull(),
  messages: jsonb("messages").$type<AiChatMessageItem[]>().notNull(),
  userMessageCount: integer("user_message_count").notNull().default(0),
  updatedAt: bigint("updated_at", { mode: "number" }).notNull(),
});

export const mimoTelemetryLog = pgTable("mimo_telemetry_log", {
  id: serial("id").primaryKey(),
  category: text("category").notNull(),
  sourceClass: text("source_class").notNull(),
  operation: text("operation").notNull(),
  payload: jsonb("payload").notNull(),
  evidenceCode: text("evidence_code").notNull(),
  createdAt: bigint("created_at", { mode: "number" }).notNull(),
});
