import {
  pgTable,
  serial,
  text,
  integer,
  real,
  boolean,
  timestamp,
  jsonb,
} from "drizzle-orm/pg-core";

export interface MimoBeatStep {
  id: string;
  phase: "probe" | "plan" | "teach" | "practice";
  kind:
    | "probe_diagnostic"
    | "unconditional_truth"
    | "predict_before_teach"
    | "fill_blank"
    | "check_mcq"
    | "ordering_chain"
    | "practice_problem";
  nodeSlug: string;
  title: string;
  principleBadge: string;
  contentMarkdown: string;
  formulaLatex?: string;
  promptQuestion: string;
  options?: {
    id: string;
    label: string;
    isTrap?: boolean;
    trapReason?: string;
  }[];
  correctAnswer: string;
  fillTemplate?: string;
  fillChoices?: string[];
  orderingItems?: string[];
  correctOrder?: string[];
  hints: string[];
  modelSolution: string;
  dokLevel: number;
}

export interface KonkurQuestionItem {
  id: string;
  number: number;
  subject: string;
  topic: string;
  linkedNodeSlug: string;
  sourceTag: string;
  stem: string;
  formula?: string;
  options: {
    index: 1 | 2 | 3 | 4;
    text: string;
  }[];
  correctOption: 1 | 2 | 3 | 4;
  trapOption: 1 | 2 | 3 | 4;
  trapName: string;
  trapExplanation: string;
  detailedSolution: string;
  idealTimeSec: number;
}

export interface ExamQuestionLog {
  questionId: string;
  number: number;
  selectedOption: 1 | 2 | 3 | 4 | null;
  correctOption: 1 | 2 | 3 | 4;
  status: "correct" | "wrong" | "blank";
  fellForTrap: boolean;
  flag: "none" | "doubt" | "time_consuming" | "trap_alert";
  linkedNodeSlug: string;
  errorCategory?: "conceptual_gap" | "prerequisite_gap" | "designer_trap" | "careless_slip";
}

export const learnerProfiles = pgTable("learner_profiles", {
  id: serial("id").primaryKey(),
  fullName: text("full_name").notNull(),
  track: text("track").notNull().default("tajrobi"), // tajrobi | riazi | ensani
  gradeLevel: text("grade_level").notNull().default("دوازدهم / فارغ‌التحصیل"),
  targetRank: integer("target_rank").notNull().default(250),
  xp: integer("xp").notNull().default(420),
  level: integer("level").notNull().default(4),
  streakDays: integer("streak_days").notNull().default(7),
  hearts: integer("hearts").notNull().default(5),
  maxHearts: integer("max_hearts").notNull().default(5),
  targetRetention: real("target_retention").notNull().default(0.85),
  flowBandAccuracy: real("flow_band_accuracy").notNull().default(0.78),
  forgettingScale: real("forgetting_scale").notNull().default(1.0),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const knowledgeNodes = pgTable("knowledge_nodes", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  track: text("track").notNull(), // tajrobi | riazi | ensani
  subject: text("subject").notNull(),
  chapter: text("chapter").notNull(),
  title: text("title").notNull(),
  unconditionalTruth: text("unconditional_truth").notNull(), // LearnHarness Principle i
  discoveryMotivation: text("discovery_motivation").notNull(), // LearnHarness Principle ii
  commonTrap: text("common_trap").notNull(),
  nodeType: text("node_type").notNull().default("concept"), // axiom | concept | theorem | technique
  bloomLevel: text("bloom_level").notNull().default("Analyze"),
  dokLevel: integer("dok_level").notNull().default(2),
  prerequisites: jsonb("prerequisites").$type<string[]>().notNull().default([]),
  masteryP: real("mastery_p").notNull().default(0.25), // BKT P(L_t)
  stabilityDays: real("stability_days").notNull().default(1.5), // FSRS Stability S
  difficulty: real("difficulty").notNull().default(5.2), // FSRS Difficulty D (1..10)
  retrievability: real("retrievability").notNull().default(0.88), // FSRS R
  kstState: text("kst_state").notNull().default("outer_fringe"), // mastered | outer_fringe | learning | locked
  aidedSuccesses: integer("aided_successes").notNull().default(0),
  unaidedSuccesses: integer("unaided_successes").notNull().default(0),
  lapses: integer("lapses").notNull().default(0),
  lastReviewedAt: timestamp("last_reviewed_at").defaultNow().notNull(),
});

export const mimoLessons = pgTable("mimo_lessons", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  track: text("track").notNull(),
  subject: text("subject").notNull(),
  chapter: text("chapter").notNull(),
  title: text("title").notNull(),
  subtitle: text("subtitle").notNull(),
  estimatedMinutes: integer("estimated_minutes").notNull().default(8),
  xpReward: integer("xp_reward").notNull().default(60),
  konkurWeight: text("konkur_weight").notNull(),
  mermaidPlan: text("mermaid_plan").notNull(),
  beats: jsonb("beats").$type<MimoBeatStep[]>().notNull(),
  completedCount: integer("completed_count").notNull().default(0),
});

export const learningEvidence = pgTable("learning_evidence", {
  id: serial("id").primaryKey(),
  nodeSlug: text("node_slug").notNull(),
  lessonSlug: text("lesson_slug").notNull(),
  phase: text("phase").notNull(), // probe | plan | teach | practice | exam
  stepKind: text("step_kind").notNull(),
  isCorrect: boolean("is_correct").notNull(),
  confidencePct: integer("confidence_pct").notNull().default(75),
  thinkingTrace: text("thinking_trace").notNull().default(""),
  supportUsed: text("support_used").notNull().default("unaided"), // unaided | hint_1 | hint_2 | worked_example
  detectedTrap: text("detected_trap"),
  masteryBefore: real("mastery_before").notNull(),
  masteryAfter: real("mastery_after").notNull(),
  stabilityAfter: real("stability_after").notNull(),
  xapiVerb: text("xapi_verb").notNull().default("attempted"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const konkurExams = pgTable("konkur_exams", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  title: text("title").notNull(),
  organizer: text("organizer").notNull(), // سنجش | قلم‌چی | گزینه دو | ترکیبی لرن‌هارنس
  track: text("track").notNull(),
  durationMinutes: integer("duration_minutes").notNull().default(15),
  negativeMarkingRatio: integer("negative_marking_ratio").notNull().default(3), // 3 wrong = -1 right
  questions: jsonb("questions").$type<KonkurQuestionItem[]>().notNull(),
});

export const examSubmissions = pgTable("exam_submissions", {
  id: serial("id").primaryKey(),
  examSlug: text("exam_slug").notNull(),
  examTitle: text("exam_title").notNull(),
  organizer: text("organizer").notNull(),
  rawPercent: real("raw_percent").notNull(), // ((3*C - W) / (3*N)) * 100
  withoutNegativePercent: real("without_negative_percent").notNull(),
  estimatedTaraz: integer("estimated_taraz").notNull(),
  correctCount: integer("correct_count").notNull(),
  wrongCount: integer("wrong_count").notNull(),
  blankCount: integer("blank_count").notNull(),
  trapFallCount: integer("trap_fall_count").notNull(),
  timeSpentSec: integer("time_spent_sec").notNull(),
  questionLogs: jsonb("question_logs").$type<ExamQuestionLog[]>().notNull(),
  remediationSlugs: jsonb("remediation_slugs").$type<string[]>().notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const weeklyStudyPlans = pgTable("weekly_study_plans", {
  id: serial("id").primaryKey(),
  dayOfWeek: text("day_of_week").notNull(),
  subject: text("subject").notNull(),
  topic: text("topic").notNull(),
  linkedNodeSlug: text("linked_node_slug").notNull(),
  studyType: text("study_type").notNull(), // میمو-درس (LearnHarness) | تست آموزشی | تست زمان‌دار | مرور FSRS
  targetMinutes: integer("target_minutes").notNull().default(90),
  actualMinutes: integer("actual_minutes").notNull().default(0),
  targetTests: integer("target_tests").notNull().default(30),
  completedTests: integer("completed_tests").notNull().default(0),
  correctTests: integer("correct_tests").notNull().default(0),
  wrongTests: integer("wrong_tests").notNull().default(0),
  satisfaction: text("satisfaction").notNull().default("good"), // excellent | good | medium | review_needed
  advisorNote: text("advisor_note").notNull().default(""),
  isCompleted: boolean("is_completed").notNull().default(false),
});

export const blueprintPhases = pgTable("blueprint_phases", {
  id: serial("id").primaryKey(),
  phaseNumber: integer("phase_number").notNull().unique(),
  code: text("code").notNull(),
  title: text("title").notNull(),
  weightPct: integer("weight_pct").notNull(),
  status: text("status").notNull().default("ready"), // completed | in_progress | ready
  customNotes: text("custom_notes").notNull().default(""),
});
