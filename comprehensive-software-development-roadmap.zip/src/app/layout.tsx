import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Vazirmatn, JetBrains_Mono } from "next/font/google";
import "./globals.css";

const vazirmatn = Vazirmatn({
  subsets: ["arabic", "latin"],
  weight: ["400", "500", "600", "700", "800"],
  variable: "--font-vazirmatn",
  display: "swap",
});

const jetbrainsMono = JetBrains_Mono({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-jetbrains-mono",
  display: "swap",
});

export const metadata: Metadata = {
  title: "کنکور-میمو × لرن‌هارنس | نقشه گنج مهندسی، یادگیری تطبیقی و شبیه‌ساز آزمون کنکور",
  description:
    "معماری یکپارچه Mimo Micro-Learning، هسته شناختی LearnHarness (Probe-Plan-Teach-Practice)، نظریه فضای دانش Gramophone (KST + BKT + FSRS-5) و شبیه‌ساز آزمون کنکور با نمره منفی ۳۳٪.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html
      lang="fa"
      dir="rtl"
      className={`${vazirmatn.variable} ${jetbrainsMono.variable}`}
    >
      <body className="min-h-screen bg-[#FAF9F5] text-[#1A1C1A] antialiased selection:bg-[#001551] selection:text-white">
        {children}
      </body>
    </html>
  );
}
