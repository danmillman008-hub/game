"use client";

import React, { useState, useEffect, useCallback } from "react";
import BlueprintCommandCenter from "@/components/BlueprintCommandCenter";
import MimoLearnPlayer, {
  type EnrichedKnowledgeNode,
  type MimoLessonItem,
} from "@/components/MimoLearnPlayer";
import KonkurExamSimulator, {
  type KonkurExamData,
  type ExamSubmissionData,
} from "@/components/KonkurExamSimulator";
import SwissPlannerAndCompiler, {
  type StudyPlanRow,
  type EvidenceRow,
} from "@/components/SwissPlannerAndCompiler";
import {
  Compass,
  Zap,
  FileCheck2,
  CalendarRange,
  Flame,
  Heart,
  Sparkles,
  Award,
  Activity,
} from "lucide-react";

interface LearnerProfileData {
  id: number;
  fullName: string;
  track: string;
  gradeLevel: string;
  targetRank: number;
  xp: number;
  level: number;
  streakDays: number;
  hearts: number;
  maxHearts: number;
  targetRetention: number;
  flowBandAccuracy: number;
  forgettingScale: number;
}

interface BlueprintPhaseRow {
  id: number;
  phaseNumber: number;
  code: string;
  title: string;
  weightPct: number;
  status: string;
  customNotes: string;
}

export default function HomePage() {
  const [activeTab, setActiveTab] = useState<
    "blueprint" | "learn" | "exam" | "planner"
  >("blueprint");
  const [loading, setLoading] = useState<boolean>(true);
  const [profile, setProfile] = useState<LearnerProfileData | null>(null);
  const [nodes, setNodes] = useState<EnrichedKnowledgeNode[]>([]);
  const [lessons, setLessons] = useState<MimoLessonItem[]>([]);
  const [evidence, setEvidence] = useState<EvidenceRow[]>([]);
  const [exams, setExams] = useState<KonkurExamData[]>([]);
  const [submissions, setSubmissions] = useState<ExamSubmissionData[]>([]);
  const [studyPlans, setStudyPlans] = useState<StudyPlanRow[]>([]);
  const [blueprintPhases, setBlueprintPhases] = useState<BlueprintPhaseRow[]>([]);
  const [targetLessonSlug, setTargetLessonSlug] = useState<string | null>(null);

  const fetchState = useCallback(async () => {
    try {
      const res = await fetch("/api/state", { cache: "no-store" });
      if (!res.ok) return;
      const data = await res.json();
      setProfile(data.profile ?? null);
      setNodes(data.nodes ?? []);
      setLessons(data.lessons ?? []);
      setEvidence(data.evidence ?? []);
      setExams(data.exams ?? []);
      setSubmissions(data.submissions ?? []);
      setStudyPlans(data.studyPlans ?? []);
      setBlueprintPhases(data.blueprintPhases ?? []);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchState();
  }, [fetchState]);

  const handlePhaseStatusChange = async (
    phaseNumber: number,
    status: "completed" | "in_progress" | "ready"
  ) => {
    await fetch("/api/ingest", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ phaseNumber, status }),
    });
    await fetchState();
  };

  const handleLaunchRemediationQuest = (nodeSlug: string) => {
    const matchedLesson = lessons.find((l) =>
      l.beats.some((b) => b.nodeSlug === nodeSlug)
    );
    if (matchedLesson) {
      setTargetLessonSlug(matchedLesson.slug);
    }
    setActiveTab("learn");
  };

  const handlePlayCompiledLesson = (lessonSlug: string) => {
    setTargetLessonSlug(lessonSlug);
    setActiveTab("learn");
  };

  const latestTaraz = submissions[0]?.estimatedTaraz ?? 6480;
  const flowPct = Math.round((profile?.flowBandAccuracy ?? 0.79) * 100);
  const inFlowBand = flowPct >= 70 && flowPct <= 85;

  return (
    <div className="min-h-screen flex flex-col swiss-grid-bg">
      {/* Top Swiss Konkur × Mimo Telemetry Header */}
      <header className="sticky top-0 z-30 bg-[#FAF9F5]/95 backdrop-blur border-b-2 border-[#1A1C1A]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          {/* Brand Logo */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#1A1C1A] text-white flex items-center justify-center font-mono font-extrabold text-lg shadow-[2px_2px_0px_#BC000A]">
                K×M
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-base sm:text-lg font-extrabold text-[#1A1C1A] tracking-tight">
                    کنکور-میمو × لرن‌هارنس
                  </span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#001551] text-white font-bold">
                    KST + BKT + FSRS-5
                  </span>
                </div>
                <p className="text-[11px] text-[#46464B]">
                  {profile?.fullName || "معمار سیستم و داوطلب کنکور"} • هدف رتبه زیر{" "}
                  <strong className="font-mono">{profile?.targetRank ?? 120}</strong>
                </p>
              </div>
            </div>
          </div>

          {/* Live Gamification & Cognitive Telemetry Pills */}
          <div className="flex flex-wrap items-center gap-2 text-xs font-bold">
            <div
              title="امتیاز تجربه و سطح در پلیر میمو"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white border border-[#1A1C1A] shadow-[2px_2px_0px_#1A1C1A]"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#001551]" />
              <span className="font-mono text-[#001551]">
                {profile?.xp ?? 640} XP (Lv.{profile?.level ?? 5})
              </span>
            </div>

            <div
              title="پیوستگی مطالعه روزانه"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-50 border border-amber-600 text-amber-900"
            >
              <Flame className="w-3.5 h-3.5 text-amber-600" />
              <span>{profile?.streakDays ?? 9} روز استریک</span>
            </div>

            <div
              title="قلب‌های انرژی میمو"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-50 border border-[#BC000A] text-[#BC000A]"
            >
              <Heart className="w-3.5 h-3.5 fill-[#BC000A] text-[#BC000A]" />
              <span className="font-mono">
                {profile?.hearts ?? 5}/{profile?.maxHearts ?? 5}
              </span>
            </div>

            <div
              title="کنترلر باند جریان Gramophone (هدف: ۷۰٪ تا ۸۵٪)"
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border ${
                inFlowBand
                  ? "bg-emerald-50 border-[#059669] text-emerald-900"
                  : "bg-amber-50 border-amber-600 text-amber-900"
              }`}
            >
              <Activity className="w-3.5 h-3.5" />
              <span className="font-mono">Flow: {flowPct}% (باند ۷۰-۸۵٪)</span>
            </div>

            <div
              title="آخرین تراز تخمینی کنکور (سنجش / قلم‌چی)"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#001551] text-white"
            >
              <Award className="w-3.5 h-3.5 text-amber-300" />
              <span>
                تراز: <strong className="font-mono">{latestTaraz}</strong>
              </span>
            </div>
          </div>
        </div>

        {/* Primary 4-Studio Navigation Bar */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 pb-3 flex flex-wrap gap-2">
          <button
            onClick={() => setActiveTab("blueprint")}
            className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-extrabold border-2 transition cursor-pointer ${
              activeTab === "blueprint"
                ? "bg-[#1A1C1A] text-white border-[#1A1C1A] shadow-[2px_2px_0px_#BC000A]"
                : "bg-white hover:bg-[#F4F4F0] text-[#1A1C1A] border-[#1A1C1A]"
            }`}
          >
            <Compass className="w-4 h-4 text-amber-400" />
            <span>۱. نقشه گنج مهندسی و پرامپت‌های ایجنت (Master Blueprint)</span>
          </button>

          <button
            onClick={() => setActiveTab("learn")}
            className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-extrabold border-2 transition cursor-pointer ${
              activeTab === "learn"
                ? "bg-[#059669] text-white border-[#1A1C1A] shadow-[2px_2px_0px_#1A1C1A]"
                : "bg-white hover:bg-[#F4F4F0] text-[#1A1C1A] border-[#1A1C1A]"
            }`}
          >
            <Zap className="w-4 h-4" />
            <span>۲. بخش یادگیری میمو × لرن‌هارنس (Mimo × LearnHarness Player)</span>
          </button>

          <button
            onClick={() => setActiveTab("exam")}
            className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-extrabold border-2 transition cursor-pointer ${
              activeTab === "exam"
                ? "bg-[#BC000A] text-white border-[#1A1C1A] shadow-[2px_2px_0px_#1A1C1A]"
                : "bg-white hover:bg-[#F4F4F0] text-[#1A1C1A] border-[#1A1C1A]"
            }`}
          >
            <FileCheck2 className="w-4 h-4" />
            <span>۳. شبیه‌ساز آزمون کنکور و پاسخ‌برگ کلیدی (نمره منفی ۳۳٪)</span>
          </button>

          <button
            onClick={() => setActiveTab("planner")}
            className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-extrabold border-2 transition cursor-pointer ${
              activeTab === "planner"
                ? "bg-[#001551] text-white border-[#1A1C1A] shadow-[2px_2px_0px_#1A1C1A]"
                : "bg-white hover:bg-[#F4F4F0] text-[#1A1C1A] border-[#1A1C1A]"
            }`}
          >
            <CalendarRange className="w-4 h-4" />
            <span>۴. برنامه‌ریزی Swiss Konkur و کامپایلر جزوه به میمو</span>
          </button>
        </div>
      </header>

      {/* Main Content Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6">
        {loading ? (
          <div className="bg-white border-2 border-[#1A1C1A] rounded-2xl p-12 text-center space-y-3">
            <div className="w-10 h-10 border-4 border-[#001551] border-t-transparent rounded-full animate-spin mx-auto" />
            <p className="text-sm font-extrabold text-[#1A1C1A]">
              در حال بارگذاری گراف فضای دانش (KST)، موتور LearnHarness، پلیر میمو و نقشه گنج مهندسی...
            </p>
          </div>
        ) : (
          <>
            {activeTab === "blueprint" && (
              <BlueprintCommandCenter
                blueprintPhases={blueprintPhases}
                onPhaseStatusChange={handlePhaseStatusChange}
                onJumpToMimoPlayer={() => setActiveTab("learn")}
              />
            )}

            {activeTab === "learn" && (
              <MimoLearnPlayer
                nodes={nodes}
                lessons={lessons}
                initialLessonSlug={targetLessonSlug}
                onRefreshState={fetchState}
              />
            )}

            {activeTab === "exam" && (
              <KonkurExamSimulator
                exams={exams}
                submissions={submissions}
                onRefreshState={fetchState}
                onLaunchRemediationQuest={handleLaunchRemediationQuest}
              />
            )}

            {activeTab === "planner" && (
              <SwissPlannerAndCompiler
                studyPlans={studyPlans}
                nodes={nodes}
                evidence={evidence}
                onRefreshState={fetchState}
                onPlayCompiledLesson={handlePlayCompiledLesson}
              />
            )}
          </>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t-2 border-[#1A1C1A] bg-white py-4 px-4 sm:px-6 text-xs text-[#46464B]">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <div>
            <strong>پلتفرم یکپارچه کنکور-میمو × لرن‌هارنس</strong> — تلفیق ریپوهای{" "}
            <code className="font-mono">newlearning (Gramophone)</code>،{" "}
            <code className="font-mono">my-first (Learnly + Adaptive Agent)</code>،{" "}
            <code className="font-mono">moshavere-va-azmoon (Swiss Konkur)</code> و{" "}
            <code className="font-mono">amosblomqvist/learnharness</code>
          </div>
          <div className="font-mono text-[11px]">
            MASTER_BLUEPRINT.md included in repository root
          </div>
        </div>
      </footer>
    </div>
  );
}
