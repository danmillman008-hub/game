import {
  pgTable,
  serial,
  integer,
  text,
  boolean,
  bigint,
} from "drizzle-orm/pg-core";

/**
 * Mimo 9.35 11-field LessonProgress table (VERIFIED_DATABASE, E27)
 * Rule A5: isSolvedCorrectly ≡ tries >= 1
 */
export const lessonProgress = pgTable("lesson_progress", {
  id: serial("id").primaryKey(),
  lessonId: integer("lesson_id").notNull(),
  lessonIndex: integer("lesson_index").notNull().default(0),
  chapterId: integer("chapter_id").notNull(),
  tutorialId: integer("tutorial_id").notNull(),
  tutorialVersion: integer("tutorial_version").notNull().default(1),
  trackId: integer("track_id").notNull().default(1),
  tutorialTitle: text("tutorial_title").notNull().default(""),
  courseKey: text("course_key").notNull().default("bio12"),
  tries: integer("tries").notNull().default(0),
  attempts: integer("attempts").notNull().default(1),
  isPracticeProgress: boolean("is_practice_progress").notNull().default(false),
  inQueue: boolean("in_queue").notNull().default(true),
  publishSetVersion: integer("publish_set_version").notNull().default(753),
  startedAt: bigint("started_at", { mode: "number" }).notNull(),
  completedAt: bigint("completed_at", { mode: "number" }).notNull(),
});

/**
 * Persistent mistake & review queue (R8 — FSRS-lite: 2 consecutive correct resolves)
 */
export const mistakeQueue = pgTable("mistake_queue", {
  id: serial("id").primaryKey(),
  questionKey: text("question_key").notNull(),
  topicId: text("topic_id").notNull().default(""),
  subject: text("subject").notNull().default(""),
  difficulty: text("difficulty").notNull().default("medium"),
  userChoice: integer("user_choice"),
  correctIndex: integer("correct_index").notNull().default(0),
  consecutiveCorrect: integer("consecutive_correct").notNull().default(0),
  resolved: boolean("resolved").notNull().default(false),
  createdAt: bigint("created_at", { mode: "number" }).notNull(),
});

/**
 * Konkur Exam Hub sessions (saved in-progress exams + completed report cards)
 */
export const examSessions = pgTable("exam_sessions", {
  id: serial("id").primaryKey(),
  examTitle: text("exam_title").notNull(),
  examKind: text("exam_kind").notNull().default("comprehensive"),
  status: text("status").notNull().default("completed_full"), // 'saved' | 'completed_full' | 'completed_partial'
  questionCount: integer("question_count").notNull().default(20),
  correctCount: integer("correct_count").notNull().default(0),
  wrongCount: integer("wrong_count").notNull().default(0),
  blankCount: integer("blank_count").notNull().default(0),
  pctWithNeg: integer("pct_with_neg").notNull().default(0),
  pctNoNeg: integer("pct_no_neg").notNull().default(0),
  durationMinutes: integer("duration_minutes").notNull().default(270),
  remainingSeconds: integer("remaining_seconds").notNull().default(0),
  currentQuestionIndex: integer("current_question_index").notNull().default(0),
  answersJson: text("answers_json").notNull().default("{}"),
  checkedJson: text("checked_json").notNull().default("{}"),
  marksJson: text("marks_json").notNull().default("{}"),
  createdAt: bigint("created_at", { mode: "number" }).notNull(),
});

/**
 * Learner profile, token economy ledger, and active path state
 */
export const learnerProfile = pgTable("learner_profile", {
  id: serial("id").primaryKey(),
  profileKey: text("profile_key").notNull().default("default"),
  displayName: text("display_name").notNull().default("داوطلب کنکور تجربی"),
  isGuest: boolean("is_guest").notNull().default(false),
  selectionKind: text("selection_kind").notNull().default("course"), // 'program' | 'course'
  programKey: text("program_key").notNull().default("grade12"),
  courseKey: text("course_key").notNull().default("bio12"),
  activeChapterIdx: integer("active_chapter_idx").notNull().default(0),
  coins: integer("coins").notNull().default(1272),
  keysLabel: text("keys_label").notNull().default("∞"),
  streak: integer("streak").notNull().default(1),
  xp: integer("xp").notNull().default(480),
  weeklyXp: integer("weekly_xp").notNull().default(480),
  dailyGoalXp: integer("daily_goal_xp").notNull().default(50),
  nightMode: boolean("night_mode").notNull().default(false),
  completedNodesJson: text("completed_nodes_json").notNull().default("[]"),
  ledgerJson: text("ledger_json").notNull().default("[]"),
  aiSessionsJson: text("ai_sessions_json").notNull().default("[]"),
  updatedAt: bigint("updated_at", { mode: "number" }).notNull(),
});
