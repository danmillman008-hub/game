"use client";

import React, { useState, useEffect, useCallback } from "react";
import { MimoIcon } from "@/components/MimoIcon";
import {
  LearnPathSubsystem,
} from "@/components/LearnPathSubsystem";
import { LessonPlayerModal } from "@/components/LessonPlayerModal";
import {
  ExamSubsystem,
  SavedExamSnapshot,
  CompletedExamResult,
} from "@/components/ExamSubsystem";
import {
  AiAndProfileSubsystem,
  ChatMessage,
  LedgerEntry,
} from "@/components/AiAndProfileSubsystem";
import {
  KONKUR_COURSES,
  KONKUR_QUESTIONS,
  MIMO_TUTORIALS,
  chapterRefFor,
  LessonProgressRow,
  MistakeItem,
  MicroLesson,
  LessonBlock,
  faNum,
} from "@/lib/mimo-engine";
import { MIMO_ARSC_COUNTS } from "@/lib/mimo-vectors";

type ScreenName =
  | "learn"
  | "select-path"
  | "path-overview"
  | "section-detail"
  | "lesson"
  | "native-done"
  | "section-practice"
  | "exam-hub"
  | "exam-run"
  | "exam-result"
  | "ai"
  | "native-studio"
  | "leaderboard"
  | "user-profile"
  | "profile"
  | "native-tokens"
  | "native-output";

type TabKey = "Learn" | "Practice" | "AI" | "Leaderboard" | "Profile";

const SCREEN_TO_TAB: Record<ScreenName, TabKey> = {
  learn: "Learn",
  "select-path": "Learn",
  "path-overview": "Learn",
  "section-detail": "Learn",
  lesson: "Learn",
  "native-done": "Learn",
  "section-practice": "Learn",
  "exam-hub": "Practice",
  "exam-run": "Practice",
  "exam-result": "Practice",
  ai: "AI",
  "native-studio": "AI",
  leaderboard: "Leaderboard",
  "user-profile": "Leaderboard",
  profile: "Profile",
  "native-tokens": "Profile",
  "native-output": "Profile",
};

const FULLSCREEN_SCREENS = new Set<ScreenName>([
  "lesson",
  "native-done",
  "exam-run",
]);

const STORAGE_KEY = "mimo.935.unified.state.v3";

export default function MimoKonkurUnifiedApp() {
  // Navigation & UI Chrome State
  const [screen, setScreen] = useState<ScreenName>("learn");
  const [nightMode, setNightMode] = useState<boolean>(false);
  const [fullViewport, setFullViewport] = useState<boolean>(false);
  const [showArchDrawer, setShowArchDrawer] = useState<boolean>(false);
  const [showPlaygroundSheet, setShowPlaygroundSheet] =
    useState<boolean>(false);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  // Learner & Curriculum State
  const [displayName, setDisplayName] = useState("داوطلب کنکور تجربی");
  const [isGuest, setIsGuest] = useState<boolean>(false);
  const [selectionKind, setSelectionKind] = useState<"course" | "program">(
    "course"
  );
  const [programKey, setProgramKey] = useState<string>("grade12");
  const [courseKey, setCourseKey] = useState<string>("bio12");
  const [activeChapterIdx, setActiveChapterIdx] = useState<number>(0);
  const [selectedLessonId, setSelectedLessonId] =
    useState<string>("bio12:c1:l1");

  // Economy & Progress State
  const [coins, setCoins] = useState<number>(1272);
  const [streak, setStreak] = useState<number>(1);
  const [xp, setXp] = useState<number>(480);
  const [weeklyXp, setWeeklyXp] = useState<number>(480);
  const [dailyGoalXp] = useState<number>(50);
  const [completedNodes, setCompletedNodes] = useState<string[]>([
    "bio12:c1:l1",
  ]);
  const [lessonProgress, setLessonProgress] = useState<LessonProgressRow[]>([]);
  const [mistakes, setMistakes] = useState<MistakeItem[]>([]);
  const [ledger, setLedger] = useState<LedgerEntry[]>([
    {
      id: "init-1",
      reasonFa: "موجودی آغازین مسیر یادگیری میمو",
      deltaXp: 480,
      deltaCoins: 1272,
      ts: 1730800000000,
    },
  ]);
  const [lastCelebrationStats, setLastCelebrationStats] = useState<{
    dxp: number;
    dcoins: number;
    lessonTitle: string;
  } | null>(null);

  // Exam State
  const [savedExam, setSavedExam] = useState<SavedExamSnapshot | null>(null);
  const [lastExamResult, setLastExamResult] =
    useState<CompletedExamResult | null>(null);
  const [examHistory, setExamHistory] = useState<CompletedExamResult[]>([]);

  // AI Tutor State
  const [aiContextBanner, setAiContextBanner] = useState<string | null>(null);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      id: "welcome-1",
      sender: "bot",
      text: "سلام! من دستیار آموزشی محلی میمو هستم (بدون مدل زبانی خارجی و بدون اینترنت). نام هر مبحث از زیست، شیمی، فیزیک یا ریاضی را بنویسید یا از داخل درس و آزمون سؤال خود را به اینجا بفرستید.",
      sourceRef: "local-content:v12.5-fa",
    },
  ]);

  const showToast = useCallback((msg: string) => {
    setToastMsg(msg);
  }, []);

  useEffect(() => {
    if (!toastMsg) return;
    const t = setTimeout(() => setToastMsg(null), 2600);
    return () => clearTimeout(t);
  }, [toastMsg]);

  // Load initial state from localStorage + PostgreSQL /api/state
  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed.courseKey) setCourseKey(parsed.courseKey);
        if (parsed.programKey) setProgramKey(parsed.programKey);
        if (parsed.selectionKind) setSelectionKind(parsed.selectionKind);
        if (typeof parsed.activeChapterIdx === "number")
          setActiveChapterIdx(parsed.activeChapterIdx);
        if (typeof parsed.coins === "number") setCoins(parsed.coins);
        if (typeof parsed.streak === "number") setStreak(parsed.streak);
        if (typeof parsed.xp === "number") setXp(parsed.xp);
        if (typeof parsed.weeklyXp === "number") setWeeklyXp(parsed.weeklyXp);
        if (typeof parsed.nightMode === "boolean")
          setNightMode(parsed.nightMode);
        if (Array.isArray(parsed.completedNodes))
          setCompletedNodes(parsed.completedNodes);
        if (Array.isArray(parsed.lessonProgress))
          setLessonProgress(parsed.lessonProgress);
        if (Array.isArray(parsed.mistakes)) setMistakes(parsed.mistakes);
        if (Array.isArray(parsed.examHistory))
          setExamHistory(parsed.examHistory);
        if (parsed.savedExam) setSavedExam(parsed.savedExam);
      }
    } catch {
      // ignore localStorage error
    }

    // Also hydrate from PostgreSQL database if available
    fetch("/api/state")
      .then((r) => r.json())
      .then((data) => {
        if (data?.ok && data.profile) {
          const p = data.profile;
          if (Array.isArray(data.lessonProgress) && data.lessonProgress.length > 0) {
            setLessonProgress(data.lessonProgress);
          }
          if (Array.isArray(data.mistakes) && data.mistakes.length > 0) {
            setMistakes(data.mistakes);
          }
          if (p.completedNodesJson) {
            try {
              const cn = JSON.parse(p.completedNodesJson);
              if (Array.isArray(cn) && cn.length > 0) setCompletedNodes(cn);
            } catch {
              // ignore
            }
          }
        }
      })
      .catch(() => {
        // Offline fallback works seamlessly
      });
  }, []);

  // Save state to localStorage + sync profile to PostgreSQL
  const persistState = useCallback(
    (patch?: Partial<{
      courseKey: string;
      programKey: string;
      selectionKind: "course" | "program";
      activeChapterIdx: number;
      coins: number;
      streak: number;
      xp: number;
      weeklyXp: number;
      nightMode: boolean;
      completedNodes: string[];
      lessonProgress: LessonProgressRow[];
      mistakes: MistakeItem[];
      examHistory: CompletedExamResult[];
      savedExam: SavedExamSnapshot | null;
      ledger: LedgerEntry[];
    }>) => {
      const next = {
        courseKey: patch?.courseKey ?? courseKey,
        programKey: patch?.programKey ?? programKey,
        selectionKind: patch?.selectionKind ?? selectionKind,
        activeChapterIdx: patch?.activeChapterIdx ?? activeChapterIdx,
        coins: patch?.coins ?? coins,
        streak: patch?.streak ?? streak,
        xp: patch?.xp ?? xp,
        weeklyXp: patch?.weeklyXp ?? weeklyXp,
        nightMode: patch?.nightMode ?? nightMode,
        completedNodes: patch?.completedNodes ?? completedNodes,
        lessonProgress: patch?.lessonProgress ?? lessonProgress,
        mistakes: patch?.mistakes ?? mistakes,
        examHistory: patch?.examHistory ?? examHistory,
        savedExam:
          patch && "savedExam" in patch ? patch.savedExam : savedExam,
        ledger: patch?.ledger ?? ledger,
      };
      try {
        window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      } catch {
        // ignore
      }
      fetch("/api/state", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "sync_profile",
          profile: {
            displayName,
            isGuest,
            selectionKind: next.selectionKind,
            programKey: next.programKey,
            courseKey: next.courseKey,
            activeChapterIdx: next.activeChapterIdx,
            coins: next.coins,
            streak: next.streak,
            xp: next.xp,
            weeklyXp: next.weeklyXp,
            nightMode: next.nightMode,
            completedNodes: next.completedNodes,
            ledger: next.ledger,
          },
        }),
      }).catch(() => {});
    },
    [
      courseKey,
      programKey,
      selectionKind,
      activeChapterIdx,
      coins,
      streak,
      xp,
      weeklyXp,
      nightMode,
      completedNodes,
      lessonProgress,
      mistakes,
      examHistory,
      savedExam,
      ledger,
      displayName,
      isGuest,
    ]
  );

  // Record a micro-lesson progress row (Mimo 9.35 11-field LessonProgress + FSRS-lite mistakes)
  const handleRecordMicroProgress = (
    micro: MicroLesson,
    stepIdx: number,
    ok: boolean,
    block?: LessonBlock,
    userChoiceIdx?: number
  ): LessonProgressRow => {
    const ref = chapterRefFor(selectedLessonId);
    const prev = lessonProgress.find((r) => r.lessonId === micro.id);
    const now = Date.now();
    const row: LessonProgressRow = {
      lessonId: micro.id,
      lessonIndex: stepIdx,
      chapterId: ref.chapter.id,
      tutorialId: ref.tutorial.id,
      tutorialVersion: ref.tutorial.version,
      trackId: 1,
      tutorialTitle: ref.tutorial.title,
      courseKey: ref.courseKey,
      tries: ok ? 1 : 0, // Rule A5: isSolvedCorrectly ≡ tries >= 1
      attempts: (prev ? prev.attempts : 0) + 1,
      isPracticeProgress: false,
      inQueue: true,
      publishSetVersion: 753,
      startedAt: prev ? prev.startedAt : now,
      completedAt: now,
    };

    const nextProgress = lessonProgress
      .filter((r) => r.lessonId !== micro.id)
      .concat(row);
    setLessonProgress(nextProgress);

    // Sync row to DB
    fetch("/api/state", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "upsert_lesson_progress", row }),
    }).catch(() => {});

    // Update FSRS-lite mistakeQueue if this was a question block
    if (block) {
      const qKey = block.questionId || String(micro.id);
      const existingM = mistakes.find((m) => m.questionKey === qKey);
      let updatedMistake: MistakeItem | null = null;

      if (!ok) {
        updatedMistake = {
          questionKey: qKey,
          topicId: `${ref.subject}:${ref.tutorial.title}`,
          subject: ref.subject,
          difficulty: ref.question.difficulty,
          userChoice: userChoiceIdx,
          correctIndex: ref.question.correctIndex,
          consecutiveCorrect: 0,
          resolved: false,
          createdAt: now,
        };
      } else if (existingM && !existingM.resolved) {
        const nextConsec = (existingM.consecutiveCorrect || 0) + 1;
        updatedMistake = {
          ...existingM,
          consecutiveCorrect: nextConsec,
          resolved: nextConsec >= 2,
        };
      }

      if (updatedMistake) {
        const nextMistakes = mistakes
          .filter((m) => m.questionKey !== qKey)
          .concat(updatedMistake);
        setMistakes(nextMistakes);
        fetch("/api/state", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            action: "upsert_mistake",
            mistake: updatedMistake,
          }),
        }).catch(() => {});
        persistState({ lessonProgress: nextProgress, mistakes: nextMistakes });
        return row;
      }
    }

    persistState({ lessonProgress: nextProgress });
    return row;
  };

  // Complete a full Lesson Chapter (8 micro-lessons)
  const handleFinishChapter = (hadCorrect: boolean, hardModeUsed: boolean) => {
    const ref = chapterRefFor(selectedLessonId);
    const dxp = 20 + (hadCorrect ? 10 : 0) + (hardModeUsed ? 15 : 0);
    const dcoins = 10 + (hadCorrect ? 5 : 0) + (hardModeUsed ? 8 : 0);

    const nextCoins = coins + dcoins;
    const nextXp = xp + dxp;
    const nextWeekly = weeklyXp + dxp;
    const nextCompleted = completedNodes.includes(selectedLessonId)
      ? completedNodes
      : [...completedNodes, selectedLessonId];
    const nextLedger: LedgerEntry[] = [
      {
        id: `led-${Date.now()}`,
        reasonFa: `تکمیل درس «${ref.lessonTitle}» (${ref.courseName})`,
        deltaXp: dxp,
        deltaCoins: dcoins,
        ts: Date.now(),
      },
      ...ledger,
    ];

    setCoins(nextCoins);
    setXp(nextXp);
    setWeeklyXp(nextWeekly);
    setCompletedNodes(nextCompleted);
    setLedger(nextLedger);
    setLastCelebrationStats({
      dxp,
      dcoins,
      lessonTitle: `${ref.courseName} · ${ref.lessonTitle}`,
    });
    persistState({
      coins: nextCoins,
      xp: nextXp,
      weeklyXp: nextWeekly,
      completedNodes: nextCompleted,
      ledger: nextLedger,
    });
    setScreen("native-done");
  };

  // Transfer question/lesson/exam context to AI Chat
  const handleOpenAiWithContext = (ctxText: string, detailHtml: string) => {
    setAiContextBanner(ctxText);
    setChatMessages((prev) => [
      ...prev,
      {
        id: `ctx-${Date.now()}`,
        sender: "ctx",
        text: ctxText,
        html: detailHtml,
        sourceRef: "بستهٔ ساختاریافتهٔ میمو (M09)",
      },
    ]);
    setScreen("ai");
    showToast("زمینهٔ سؤال و پاسخ تشریحی به هوش مصنوعی محلی منتقل شد");
  };

  // Send a local chat message in AI tab (zero LLM, 100% content-package driven)
  const handleSendChatMessage = (
    text: string,
    mode: "TEACH" | "PRACTICE"
  ) => {
    const userMsg: ChatMessage = {
      id: `u-${Date.now()}`,
      sender: "user",
      text,
    };

    const norm = text.trim();
    const matchedQ =
      KONKUR_QUESTIONS.find(
        (q) =>
          norm.includes(q.topic) ||
          q.topic.includes(norm) ||
          norm.includes(q.subject) ||
          q.stemFa.includes(norm) ||
          q.keyTermFa.includes(norm)
      ) || KONKUR_QUESTIONS[0];

    let replyHtml = "";
    if (mode === "TEACH") {
      replyHtml = `<b>درسنامهٔ محلی «${matchedQ.subject} · ${matchedQ.topic}»:</b><br>• <b>نکتهٔ کلیدی:</b> ${matchedQ.explanationFa}<br>• <b>فرمول و رابطه:</b> <code dir="ltr">${matchedQ.labFormulaFa}</code><br>• <b>مراحل استدلال:</b> ${matchedQ.sequenceStepsFa.join(" ← ")}`;
    } else {
      replyHtml = `<b>تمرین پیشنهادی «${matchedQ.subject} · ${
        matchedQ.topic
      }» (دشواری ${matchedQ.difficultyLabel}):</b><br>• <b>صورت سؤال:</b> ${
        matchedQ.stemFa
      }<br>${matchedQ.options
        .map((o, i) => `گزینهٔ ${faNum(i + 1)}: ${o}`)
        .join(" | ")}<br>• <b>کلید و پاسخنامه:</b> گزینهٔ ${faNum(
        matchedQ.correctIndex + 1
      )} — ${matchedQ.explanationFa}`;
    }

    const botMsg: ChatMessage = {
      id: `b-${Date.now() + 1}`,
      sender: "bot",
      text: matchedQ.explanationFa,
      html: replyHtml,
      sourceRef: matchedQ.sourceRef,
    };

    setChatMessages((prev) => [...prev, userMsg, botMsg]);
  };

  // Finish an exam and record mistakes + XP
  const handleFinishExam = (result: CompletedExamResult) => {
    setLastExamResult(result);
    const nextHistory = [result, ...examHistory];
    setExamHistory(nextHistory);
    setSavedExam(null);

    // Record wrong questions into mistakeQueue
    const now = Date.now();
    const updatedMistakes = [...mistakes];
    result.questions.forEach((q, idx) => {
      const userAns = result.answers[idx];
      if (userAns !== undefined && userAns - 1 !== q.correctIndex) {
        const existingIdx = updatedMistakes.findIndex(
          (m) => m.questionKey === q.id
        );
        const item: MistakeItem = {
          questionKey: q.id,
          topicId: `${q.subject}:${q.topic}`,
          subject: q.subject,
          difficulty: q.difficulty,
          userChoice: userAns - 1,
          correctIndex: q.correctIndex,
          consecutiveCorrect: 0,
          resolved: false,
          createdAt: now,
        };
        if (existingIdx >= 0) updatedMistakes[existingIdx] = item;
        else updatedMistakes.push(item);
      }
    });
    setMistakes(updatedMistakes);

    const nextXp = xp + 30;
    const nextCoins = coins + 15;
    setXp(nextXp);
    setCoins(nextCoins);

    fetch("/api/state", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action: "save_exam",
        exam: {
          examTitle: result.examTitle,
          examKind: result.examKind,
          status: result.partial ? "completed_partial" : "completed_full",
          questionCount: result.questions.length,
          correctCount: result.correctCount,
          wrongCount: result.wrongCount,
          blankCount: result.blankCount,
          pctWithNeg: result.pctWithNeg,
          pctNoNeg: result.pctNoNeg,
          durationMinutes: result.durationMinutes,
          remainingSeconds: 0,
          answers: result.answers,
        },
      }),
    }).catch(() => {});

    persistState({
      examHistory: nextHistory,
      savedExam: null,
      mistakes: updatedMistakes,
      xp: nextXp,
      coins: nextCoins,
    });
    setScreen("exam-result");
  };

  // Current course & chapter info
  const activeCourse =
    KONKUR_COURSES.find((c) => c.key === courseKey) || KONKUR_COURSES[0];
  const flatCourseLessons = activeCourse.chapters.flatMap((ch) => ch.lessons);
  const courseCompletionPct = Math.round(
    (flatCourseLessons.filter((l) => completedNodes.includes(l.id)).length /
      Math.max(1, flatCourseLessons.length)) *
      100
  );
  const currentTab = SCREEN_TO_TAB[screen];
  const isFullscreen = FULLSCREEN_SCREENS.has(screen);

  return (
    <div
      className={`min-h-screen flex flex-col ${nightMode ? "mimo-night" : ""}`}
      style={{ background: "var(--bg)", color: "var(--text)" }}
      dir="rtl"
    >
      {/* ====================================================================
          TOP WORKSPACE HEADER (Quick Screen Switcher, Viewport Toggle, Export)
         ==================================================================== */}
      <header
        className="px-4 py-2.5 border-b flex flex-wrap items-center justify-between gap-2 shrink-0"
        style={{
          background: "var(--card)",
          borderColor: "var(--line)",
        }}
      >
        <div className="flex items-center gap-2.5">
          <div
            className="w-8 h-8 rounded-xl flex items-center justify-center text-white font-bold"
            style={{ background: "var(--primary)" }}
          >
            <MimoIcon name="ic_cap_filled" size={20} mono />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-sm font-extrabold">
                میمو ۹٫۳۵ · اپلیکیشن یادگیری کنکور
              </h1>
              <span
                className="px-2 py-0.5 rounded-full text-[10.5px] font-bold border"
                style={{
                  background: "var(--progress-weak)",
                  borderColor: "var(--primary)",
                  color: "var(--primary)",
                }}
              >
                v12.5-fa یکپارچه · بدون فرانکشتاین
              </span>
            </div>
            <p className="text-[11px]" style={{ color: "var(--text-weak)" }}>
              ۹۴ وکتور ARSC ({faNum(MIMO_ARSC_COUNTS.vectors)}) · ۹ خانوادهٔ رندرر · ولیدیتورهای A6–A11 · نگاشت قطعی{" "}
              <code dir="ltr">chapterRefFor()</code> ·{" "}
              <code dir="ltr">SERVER CONFIRMED = 0</code>
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-1.5">
          <button
            type="button"
            onClick={() => setShowArchDrawer((v) => !v)}
            className="px-3 py-1.5 rounded-full text-xs font-bold border cursor-pointer"
            style={{
              background: showArchDrawer
                ? "var(--primary)"
                : "var(--card-pressed)",
              borderColor: "var(--primary)",
              color: showArchDrawer ? "#FFFFFF" : "var(--primary)",
            }}
          >
            {showArchDrawer
              ? "✕ بستن گزارش مهندسی"
              : "📋 گزارش پیشرفت و رفع گیرهای ریپو"}
          </button>

          <button
            type="button"
            onClick={() => setFullViewport((f) => !f)}
            className="px-3 py-1.5 rounded-full text-xs font-bold border cursor-pointer"
            style={{
              background: "var(--card-pressed)",
              borderColor: "var(--line)",
            }}
          >
            {fullViewport ? "📱 قاب استاندارد ۳۹۲px" : "🖥️ نمای عریض"}
          </button>

          <button
            type="button"
            onClick={() => {
              const next = !nightMode;
              setNightMode(next);
              persistState({ nightMode: next });
            }}
            className="px-3 py-1.5 rounded-full text-xs font-bold border cursor-pointer"
            style={{
              background: "var(--card-pressed)",
              borderColor: "var(--line)",
            }}
          >
            {nightMode ? "☀️ حالت روز" : "🌙 حالت شب"}
          </button>

          <a
            href="/Mimo.html"
            download="Mimo.html"
            onClick={() => showToast("دانلود فایل خودکفای Mimo.html آغاز شد")}
            className="px-3 py-1.5 rounded-full text-xs font-bold text-white"
            style={{
              background: "var(--primary)",
              textDecoration: "none",
            }}
          >
            ↓ دانلود Mimo.html
          </a>
        </div>
      </header>

      {/* ====================================================================
          COLLAPSIBLE DIAGNOSTIC REPORT (Answers "تا کجا پیش رفتیم و کجا گیر کردیم")
         ==================================================================== */}
      {showArchDrawer && (
        <section
          className="px-4 py-4 border-b text-xs space-y-3 max-w-6xl mx-auto w-full"
          style={{
            background: "var(--card)",
            borderColor: "var(--primary)",
          }}
        >
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-extrabold" style={{ color: "var(--primary)" }}>
              کالبدشکافی کامل ریپو (شاخهٔ arena/aebb90b7-game تا کامیت 9179b8c4): تا کجا پیش رفته بودید، کجا گیر کرده بودید، و چه ارتقاهایی انجام شد؟
            </h2>
            <span className="font-mono text-[11px]" dir="ltr">
              HEAD: 9179b8c4 → Unified v3.0
            </span>
          </div>

          <div className="grid md:grid-cols-2 gap-3">
            <div
              className="p-3.5 rounded-xl border space-y-1.5"
              style={{
                background: "var(--card-pressed)",
                borderColor: "var(--line)",
              }}
            >
              <b className="block text-xs" style={{ color: "var(--error)" }}>
                ❌ ۶ ایراد ریشه‌ای و نقاط گیرکرده در نسخهٔ قبلی (طراحی فرانکشتاینی):
              </b>
              <ul className="list-disc pr-4 space-y-1 leading-relaxed">
                <li>
                  <b>۱. باگ نگاشت هش‌پایه در <code dir="ltr">chapterRefFor(id)</code> (مورد R2 و R10):</b> کد کاراکترهای شناسهٔ درس جمع زده می‌شد (<code dir="ltr">key % tuts.length</code>)؛ در نتیجه کلیک روی درس زیست‌شناسی، درسنامهٔ فیزیک یا ریاضی را باز می‌کرد!
                </li>
                <li>
                  <b>۲. باگ کلیک روی گرهٔ جاری (<code dir="ltr">#curNode</code>):</b> در <code dir="ltr">proto-ui.js</code> کلیک روی <code dir="ltr">#curNode</code> مستقیماً مودال استاتیک را باز می‌کرد بدون اینکه <code dir="ltr">setChapterModal()</code> اجرا شود.
                </li>
                <li>
                  <b>۳. کارنامهٔ هاردکدشده و جعلی در پایان آزمون (مورد R9):</b> در <code dir="ltr">proto-ui.js</code> (خطوط ۳۱۸–۳۲۷)، پایان آزمون همیشه عدد ثابت <code dir="ltr">۶۸٪</code> و ۳ سؤال غلط ثابت را نشان می‌داد و پاسخ‌های واقعی کاربر را نادیده می‌گرفت!
                </li>
                <li>
                  <b>۴. وصله‌پینه‌کاری DOM بین <code dir="ltr">phone.html</code> و <code dir="ltr">native.js</code>:</b> دو هندلر کلیک متداخل روی <code dir="ltr">document</code>، پرش بین چیدمان چپ‌به‌راست و راست‌به‌چپ، و استاتیک بودن صفحات <code dir="ltr">path-overview</code> (همیشه ۴۳٪ و ۲۲٪).
                </li>
                <li>
                  <b>۵. ناقص بودن رندررهای موتور درس (موارد R4–R7):</b> نبودِ <code dir="ltr">ValidatedInput</code> (A9/A10)، <code dir="ltr">Spell</code> ترتیبی (A8)، <code dir="ltr">InteractiveWebView</code> محلی، <code dir="ltr">FillTheGap</code> تعاملی با شکاف واقعی، و <code dir="ltr">Hard Mode</code>.
                </li>
                <li>
                  <b>۶. ناقص بودن تمرین گرهٔ رعد (<code dir="ltr">section-practice</code>):</b> دکمه‌های ۱ تا ۴ بدون متن گزینه و بدون بررسی واقعی پاسخ بودند.
                </li>
              </ul>
            </div>

            <div
              className="p-3.5 rounded-xl border space-y-1.5"
              style={{
                background: "var(--card-pressed)",
                borderColor: "var(--success)",
              }}
            >
              <b className="block text-xs" style={{ color: "var(--success)" }}>
                ✅ معماری جدید، تمیز و یکپارچه (انجام‌شده در این نسخه):
              </b>
              <ul className="list-disc pr-4 space-y-1 leading-relaxed">
                <li>
                  <b>۱. نگاشت ۱۰۰٪ قطعی <code dir="ltr">chapterRefFor(id)</code>:</b> هر ۱۲ کتاب کنکور (۶۰ فصل و ۱۸۰ درس) مستقیماً به درسنامه و مبحث هم‌نام خودش در همان درس (زیست/شیمی/فیزیک/ریاضی) وصل شد (صفر هش تصادفی).
                </li>
                <li>
                  <b>۲. موتور درس ۸گامی با هر ۹ خانوادهٔ رندرر میمو ۹٫۳۵:</b> پیاده‌سازی کامل <code dir="ltr">hook → explain → InteractiveWebView → MultipleChoice → feedback → FillTheGap → Spell + ValidatedInput → Reveal</code> همراه با سوییچ <code dir="ltr">Hard Mode</code> و شیت بازخورد استاندارد میمو.
                </li>
                <li>
                  <b>۳. کارنامه، پاسخبرگ و پاسخنامهٔ ۱۰۰٪ واقعی و پویا:</b> محاسبهٔ دقیق درصد با نمرهٔ منفی ⅓، درصد بدون نمرهٔ منفی، تفکیک درس‌به‌درس، و ثبت خودکار غلط‌ها در صف مرور <code dir="ltr">FSRS-lite</code>.
                </li>
                <li>
                  <b>۴. یکپارچگی کامل بصری و دیتابیس:</b> استفاده از همان ۹۴ وکتور استخراج‌شدهٔ ARSC و توکن‌های رنگ میمو ۹٫۳۵ + ذخیره‌سازی همزمان در PostgreSQL (Drizzle ORM) و <code dir="ltr">localStorage</code> + بازسازی فایل خودکفای <code dir="ltr">Mimo.html</code>.
                </li>
              </ul>
            </div>
          </div>
        </section>
      )}

      {/* ====================================================================
          QUICK SCREEN SWITCHER BAR (For instant verification of all 16 screens)
         ==================================================================== */}
      <div
        className="px-4 py-1.5 border-b flex items-center gap-1.5 overflow-x-auto mimo-scroll shrink-0"
        style={{
          background: "var(--card-pressed)",
          borderColor: "var(--line)",
        }}
      >
        <span className="text-[11px] font-bold shrink-0 pl-1" style={{ color: "var(--text-weak)" }}>
          پرش سریع صفحات:
        </span>
        {(
          [
            ["learn", "نقشهٔ یادگیری"],
            ["select-path", "انتخاب مسیر (۱۲ کتاب)"],
            ["path-overview", "نمای دوره"],
            ["section-detail", "جزئیات فصل"],
            ["lesson", "پلیر درس (۸ ریزدرس)"],
            ["section-practice", "تمرین گره رعد ⚡"],
            ["exam-hub", "هاب آزمون (۷ بخش)"],
            ["exam-run", "اجرای آزمون + تایمر"],
            ["exam-result", "کارنامهٔ واقعی"],
            ["ai", "چت هوش مصنوعی"],
            ["native-studio", "استودیو ۴فازی"],
            ["leaderboard", "امتیازها و وضعیت من"],
            ["profile", "پروفایل"],
            ["native-tokens", "ساختار توکن‌ها"],
            ["native-output", "خروجی Mimo.html"],
          ] as [ScreenName, string][]
        ).map(([sc, label]) => {
          const on = screen === sc;
          return (
            <button
              key={sc}
              type="button"
              onClick={() => {
                if (sc === "exam-run" && !savedExam) {
                  setSavedExam({
                    examTitle: "آزمون جامع کنکور",
                    examKind: "comprehensive",
                    questionIds: KONKUR_QUESTIONS.map((q) => q.id),
                    qi: 0,
                    answers: {},
                    checked: {},
                    marks: {},
                    durationMinutes: 270,
                    timerState: "idle",
                    remainingSeconds: 270 * 60,
                  });
                }
                setScreen(sc);
              }}
              className="px-2.5 py-1 rounded-full text-[11px] font-bold border shrink-0 cursor-pointer transition-colors"
              style={{
                background: on ? "var(--primary)" : "var(--card)",
                borderColor: on ? "var(--primary)" : "var(--line)",
                color: on ? "#FFFFFF" : "var(--text-weak)",
              }}
            >
              {label}
            </button>
          );
        })}
      </div>

      {/* ====================================================================
          MAIN MIMO 9.35 STAGE (#phone Frame or Full-Viewport)
         ==================================================================== */}
      <main className="flex-1 flex items-center justify-center p-0 sm:p-4 overflow-hidden">
        <div
          id="phone"
          data-fullscreen={isFullscreen ? "1" : "0"}
          className={`flex flex-col relative overflow-hidden transition-all ${
            fullViewport
              ? "w-full max-w-4xl h-[calc(100vh-110px)] sm:rounded-3xl sm:border shadow-xl"
              : "w-full sm:w-[392px] h-[calc(100vh-110px)] sm:h-[780px] sm:rounded-[28px] sm:border shadow-2xl"
          }`}
          style={{
            background: "var(--card)",
            borderColor: "var(--line)",
          }}
        >
          {/* Screen Content Host */}
          <div className="flex-1 min-h-0 overflow-hidden flex flex-col">
            {(screen === "learn" ||
              screen === "select-path" ||
              screen === "path-overview" ||
              screen === "section-detail" ||
              screen === "section-practice" ||
              screen === "native-done") && (
              <LearnPathSubsystem
                screen={screen}
                selectionKind={selectionKind}
                programKey={programKey}
                courseKey={courseKey}
                activeChapterIdx={activeChapterIdx}
                selectedLessonId={selectedLessonId}
                completedNodes={completedNodes}
                lessonProgress={lessonProgress}
                coins={coins}
                streak={streak}
                lastCelebrationStats={lastCelebrationStats}
                onNavigate={(target) => setScreen(target as ScreenName)}
                onSelectCourse={(ck) => {
                  setSelectionKind("course");
                  setCourseKey(ck);
                  setActiveChapterIdx(0);
                  const firstLessonId = `${ck}:c1:l1`;
                  setSelectedLessonId(firstLessonId);
                  persistState({
                    selectionKind: "course",
                    courseKey: ck,
                    activeChapterIdx: 0,
                  });
                  setScreen("path-overview");
                  const found = KONKUR_COURSES.find((c) => c.key === ck);
                  showToast(`مسیر «${found?.name || ck}» انتخاب شد`);
                }}
                onSelectProgram={(pk) => {
                  setSelectionKind("program");
                  setProgramKey(pk);
                  const mappedCourse =
                    pk === "grade12"
                      ? "bio12"
                      : pk === "grade11"
                      ? "bio11"
                      : "bio10";
                  setCourseKey(mappedCourse);
                  setActiveChapterIdx(0);
                  setSelectedLessonId(`${mappedCourse}:c1:l1`);
                  persistState({
                    selectionKind: "program",
                    programKey: pk,
                    courseKey: mappedCourse,
                    activeChapterIdx: 0,
                  });
                  setScreen("path-overview");
                  showToast("برنامهٔ راهبردی آزمون انتخاب شد");
                }}
                onSelectChapterIdx={(idx) => {
                  setActiveChapterIdx(idx);
                  const ch = activeCourse.chapters[idx];
                  if (ch && ch.lessons[0]) {
                    setSelectedLessonId(ch.lessons[0].id);
                  }
                  persistState({ activeChapterIdx: idx });
                }}
                onOpenLessonPlayer={(lessonId) => {
                  setSelectedLessonId(lessonId);
                  setScreen("lesson");
                }}
                onCompleteBoltPractice={(correctCount, totalCount) => {
                  const dxp = correctCount * 5 + 10;
                  const dc = correctCount * 3 + 5;
                  const nextXp = xp + dxp;
                  const nextCoins = coins + dc;
                  setXp(nextXp);
                  setCoins(nextCoins);
                  persistState({ xp: nextXp, coins: nextCoins });
                  showToast(
                    `تمرین مبحث ثبت شد: ${faNum(correctCount)} از ${faNum(
                      totalCount
                    )} درست (+${faNum(dxp)} XP)`
                  );
                }}
                onToast={showToast}
              />
            )}

            {screen === "lesson" && (
              <LessonPlayerModal
                chapterRef={chapterRefFor(selectedLessonId)}
                existingProgress={lessonProgress}
                onRecordMicroProgress={handleRecordMicroProgress}
                onFinishChapter={handleFinishChapter}
                onQuitToLearn={() => setScreen("learn")}
                onQuitToSelectPath={() => setScreen("select-path")}
                onOpenAiWithContext={handleOpenAiWithContext}
                onToast={showToast}
              />
            )}

            {(screen === "exam-hub" ||
              screen === "exam-run" ||
              screen === "exam-result") && (
              <ExamSubsystem
                mode={screen}
                isGuest={isGuest}
                mistakes={mistakes}
                savedExam={savedExam}
                lastResult={lastExamResult}
                onCreateLocalProfile={() => {
                  setIsGuest(false);
                  setDisplayName("یادگیرندهٔ میمو");
                  showToast("پروفایل محلی ساخته شد");
                }}
                onBackToLearn={() => setScreen("learn")}
                onStartOrResumeExam={(snap) => {
                  setSavedExam(snap);
                  persistState({ savedExam: snap });
                  setScreen("exam-run");
                }}
                onSaveExamAndExit={(snap) => {
                  setSavedExam(snap);
                  persistState({ savedExam: snap });
                  setScreen("exam-hub");
                  showToast(
                    `آزمون در سؤال ${faNum(
                      snap.qi + 1
                    )} ذخیره شد · بعداً از همین نقطه ادامه می‌دهید`
                  );
                }}
                onFinishExam={handleFinishExam}
                onBackToHub={() => setScreen("exam-hub")}
                onOpenAiWithContext={handleOpenAiWithContext}
                onOpenPlaygroundSheet={() => setShowPlaygroundSheet(true)}
                onToast={showToast}
              />
            )}

            {(screen === "ai" ||
              screen === "native-studio" ||
              screen === "leaderboard" ||
              screen === "user-profile" ||
              screen === "profile" ||
              screen === "native-tokens" ||
              screen === "native-output") && (
              <AiAndProfileSubsystem
                screen={screen}
                nightMode={nightMode}
                displayName={displayName}
                activeCourseName={activeCourse.name}
                courseCompletionPct={courseCompletionPct}
                coins={coins}
                streak={streak}
                xp={xp}
                weeklyXp={weeklyXp}
                dailyGoalXp={dailyGoalXp}
                lessonProgress={lessonProgress}
                mistakes={mistakes}
                examHistory={examHistory}
                ledger={ledger}
                aiContextBanner={aiContextBanner}
                chatMessages={chatMessages}
                onSendChatMessage={handleSendChatMessage}
                onClearChat={() => {
                  setAiContextBanner(null);
                  setChatMessages([
                    {
                      id: `w-${Date.now()}`,
                      sender: "bot",
                      text: "گفتگوی تازه آغاز شد! روی کدام مبحث از زیست، شیمی، فیزیک یا ریاضی کار کنیم؟",
                      sourceRef: "local-content:v12.5-fa",
                    },
                  ]);
                  showToast("گفتگوی تازه شروع شد");
                }}
                onNavigate={(target) => setScreen(target as ScreenName)}
                onOpenLessonByTopic={(topic) => {
                  const tut = MIMO_TUTORIALS.find((t) => t.topic === topic);
                  if (tut) {
                    const subjMap: Record<string, string> = {
                      زیست: "bio12",
                      شیمی: "chem12",
                      فیزیک: "phys12",
                      ریاضی: "math12",
                    };
                    const ck = subjMap[tut.subject] || "bio12";
                    setCourseKey(ck);
                    setSelectedLessonId(`${ck}:c1:l1`);
                  }
                  setScreen("lesson");
                }}
                onToggleNightMode={() => {
                  const next = !nightMode;
                  setNightMode(next);
                  persistState({ nightMode: next });
                }}
                onClaimDailyGoal={() => {
                  const nextCoins = coins + 25;
                  const nextStreak = streak + 1;
                  setCoins(nextCoins);
                  setStreak(nextStreak);
                  persistState({ coins: nextCoins, streak: nextStreak });
                  showToast("هدف روزانه ثبت شد (+۲۵ سکه · +۱ روز استریک)");
                }}
                onOpenPlaygroundSheet={() => setShowPlaygroundSheet(true)}
                onResetAllData={() => {
                  window.localStorage.removeItem(STORAGE_KEY);
                  fetch("/api/state", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ action: "reset_all" }),
                  }).catch(() => {});
                  setCoins(1272);
                  setStreak(1);
                  setXp(480);
                  setWeeklyXp(480);
                  setCompletedNodes(["bio12:c1:l1"]);
                  setLessonProgress([]);
                  setMistakes([]);
                  setExamHistory([]);
                  setSavedExam(null);
                  showToast("اطلاعات به حالت پیش‌فرض بازنشانی شد");
                }}
                onToast={showToast}
              />
            )}
          </div>

          {/* ================================================================
              5 APPROVED BOTTOM TABS (#tabs — F13, F47: Hidden in Fullscreen)
             ================================================================ */}
          {!isFullscreen && (
            <nav
              id="tabs"
              className="grid grid-cols-5 border-t shrink-0 select-none"
              style={{
                height: 64,
                background: "var(--card)",
                borderColor: "var(--line)",
              }}
            >
              {(
                [
                  {
                    tab: "Learn" as TabKey,
                    dest: "learn" as ScreenName,
                    label: "یادگیری",
                    iconOff: "ic_cap",
                    iconOn: "ic_cap_filled",
                  },
                  {
                    tab: "Practice" as TabKey,
                    dest: "exam-hub" as ScreenName,
                    label: "تمرین",
                    iconOff: "ic_flash",
                    iconOn: "ic_flash_filled",
                  },
                  {
                    tab: "AI" as TabKey,
                    dest: "ai" as ScreenName,
                    label: "هوش مصنوعی",
                    iconOff: "ic_magic_wand",
                    iconOn: "ic_magic_wand_filled",
                  },
                  {
                    tab: "Leaderboard" as TabKey,
                    dest: "leaderboard" as ScreenName,
                    label: "امتیازها",
                    iconOff: "ic_trophy",
                    iconOn: "ic_trophy_filled",
                  },
                  {
                    tab: "Profile" as TabKey,
                    dest: "profile" as ScreenName,
                    label: "پروفایل",
                    iconOff: "ic_user_circle",
                    iconOn: "ic_user_circle_filled",
                  },
                ]
              ).map((item) => {
                const active = currentTab === item.tab;
                return (
                  <button
                    key={item.tab}
                    type="button"
                    data-tab={item.tab}
                    onClick={() => setScreen(item.dest)}
                    className="flex flex-col items-center justify-center gap-1 cursor-pointer transition-colors"
                    style={{
                      color: active ? "var(--primary)" : "var(--weak-icon)",
                    }}
                  >
                    <MimoIcon
                      name={active ? item.iconOn : item.iconOff}
                      size={22}
                      mono
                    />
                    <span
                      className="text-[11px]"
                      style={{ fontWeight: active ? 700 : 600 }}
                    >
                      {item.label}
                    </span>
                  </button>
                );
              })}
            </nav>
          )}

          {/* Custom Exam Builder Sheet (#playgroundSheet) */}
          {showPlaygroundSheet && (
            <div
              className="absolute inset-0 z-50 flex flex-col justify-end"
              style={{ background: "rgba(37, 39, 70, 0.55)" }}
            >
              <div
                className="w-full rounded-t-3xl p-5 space-y-3 border-t"
                style={{
                  background: "var(--sheet)",
                  borderColor: "var(--line)",
                }}
              >
                <div className="flex items-center justify-between">
                  <b className="text-base">ساخت آزمون سفارشی</b>
                  <button
                    type="button"
                    onClick={() => setShowPlaygroundSheet(false)}
                    className="w-8 h-8 flex items-center justify-center rounded-lg cursor-pointer"
                  >
                    <MimoIcon name="ic_close" size={20} mono />
                  </button>
                </div>
                <p className="text-xs" style={{ color: "var(--text-weak)" }}>
                  انتخاب قالب آزمون کنکور:
                </p>
                <div className="space-y-2">
                  {[
                    {
                      title: "آزمون جامع سفارشی",
                      desc: "همهٔ درس‌ها · ۲۷۰ دقیقه پیش‌فرض · کارنامهٔ کامل",
                      icon: "ic_file",
                      kind: "comprehensive" as const,
                      mins: 270,
                    },
                    {
                      title: "آزمون تک‌درس زیست‌شناسی",
                      desc: "پرسش‌های منتخب زیست دهم، یازدهم و دوازدهم",
                      icon: "img_brain",
                      kind: "normal" as const,
                      mins: 25,
                      subj: "زیست" as const,
                    },
                    {
                      title: "آزمون سرعتی زمان‌دار",
                      desc: "مدت ۲۰ دقیقه · تمرین مدیریت زمان جلسه",
                      icon: "ic_task_completed",
                      kind: "timed" as const,
                      mins: 20,
                    },
                    {
                      title: "آزمون تحلیلی و رفع اشکال",
                      desc: "پاسخنامهٔ تشریحی فعال در حین آزمون + شبیه‌سازی نمرهٔ منفی",
                      icon: "ic_sparks",
                      kind: "analytical" as const,
                      mins: 35,
                    },
                  ].map((tpl, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => {
                        setShowPlaygroundSheet(false);
                        const pool = tpl.subj
                          ? KONKUR_QUESTIONS.filter(
                              (q) => q.subject === tpl.subj
                            )
                          : KONKUR_QUESTIONS;
                        const snap: SavedExamSnapshot = {
                          examTitle: tpl.title,
                          examKind: tpl.kind,
                          questionIds: pool.map((q) => q.id),
                          qi: 0,
                          answers: {},
                          checked: {},
                          marks: {},
                          durationMinutes: tpl.mins,
                          timerState: "idle",
                          remainingSeconds: tpl.mins * 60,
                        };
                        setSavedExam(snap);
                        setScreen("exam-run");
                        showToast(`آزمون «${tpl.title}» ساخته و آغاز شد`);
                      }}
                      className="w-full p-3 rounded-xl border flex items-center gap-3 text-right cursor-pointer"
                      style={{
                        background: "var(--card-pressed)",
                        borderColor: "var(--line)",
                      }}
                    >
                      <div
                        className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
                        style={{ background: "var(--progress-weak)" }}
                      >
                        <MimoIcon name={tpl.icon} size={28} />
                      </div>
                      <div className="flex-1">
                        <b className="text-xs block">{tpl.title}</b>
                        <small
                          className="text-[11px]"
                          style={{ color: "var(--text-weak)" }}
                        >
                          {tpl.desc}
                        </small>
                      </div>
                      <MimoIcon name="ic_arrow_left" size={16} mono />
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Toast Notification */}
          {toastMsg && (
            <div
              role="status"
              aria-live="polite"
              className="absolute bottom-20 left-4 right-4 z-50 px-4 py-2.5 rounded-2xl text-xs font-bold text-white text-center shadow-lg"
              style={{ background: "rgba(37, 39, 70, 0.94)" }}
            >
              {toastMsg}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
