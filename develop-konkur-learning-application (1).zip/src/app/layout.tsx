import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "میمو ۹٫۳۵ · اپلیکیشن یادگیری کنکور (نسخهٔ یکپارچه و بومی v12.5-fa)",
  description:
    "اپلیکیشن یادگیری کنکور تجربی و ریاضی بر پایهٔ معماری مهندسی معکوس‌شدهٔ Mimo 9.35 (M09) و قواعد v12.5-fa · بدون سرور · ۹ خانوادهٔ رندرر و ولیدیتورهای A6 تا A11",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fa" dir="rtl">
      <body className="antialiased">{children}</body>
    </html>
  );
}
