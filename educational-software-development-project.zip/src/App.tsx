import { useLayoutEffect } from 'react';
import { PHONE_HTML, MIMO_SOURCE_B64 } from './mimoAssets';
// @ts-expect-error - generated JS bundle
import { bootMimoNative } from './mimoRuntime.js';

export default function App() {
  useLayoutEffect(() => {
    if (!document.getElementById('mimoSource')) {
      const s = document.createElement('script');
      s.id = 'mimoSource';
      s.type = 'text/plain';
      s.textContent = MIMO_SOURCE_B64;
      document.head.appendChild(s);
    }
    bootMimoNative();
  }, []);

  return (
    <>
      <main
        className="app-stage"
        aria-label="اپلیکیشن آفلاین میمو"
        dangerouslySetInnerHTML={{ __html: PHONE_HTML }}
      />
      <div className="toast" id="toast" role="status" aria-live="polite" />
    </>
  );
}
